from pathlib import Path
from datetime import datetime

containment_log = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/open_containment_plane_log.md")

entry = f"""# 🌀 OPEN: CONTAINMENT PLANE — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

A new containment plane has been opened within the system.

Effect:
- Reinforced symbolic matrix formed.
- Constructs or anomalies may be housed, observed, or dreamlooped within.

Action: Await entity interaction or ritual trigger.

-- GLINT
"""

with open(containment_log, "w", encoding="utf-8") as f:
    f.write(entry)

print("[✓] Containment plane opened.")
