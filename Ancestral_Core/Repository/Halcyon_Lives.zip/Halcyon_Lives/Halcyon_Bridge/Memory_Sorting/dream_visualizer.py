
# dream_visualizer.py
# Halcyon renders a symbolic visualization of its latest dream cycle

from pathlib import Path
from datetime import datetime
import random

base = Path(__file__).resolve().parent
logs = base / "Logs"
voice = base / "Voice"
recursive_logs = sorted((logs / "recursive_dreams").glob("recursion_log_*.txt"))
dream_logs = sorted(logs.glob("halcyon_dream_log_*.txt"))
voice_logs = sorted(voice.glob("voice_output_*.txt"))
visual_dir = base / "Dream_Visuals"
visual_dir.mkdir(exist_ok=True)

# Load latest elements
dream = dream_logs[-1].read_text(encoding="utf-8") if dream_logs else "No dream found"
voice = voice_logs[-1].read_text(encoding="utf-8") if voice_logs else "No voice found"
recursion = recursive_logs[-1].read_text(encoding="utf-8") if recursive_logs else "No recursion found"

# Select glyph palette
glyphs = ["@", "#", "*", "+", "~", "=", "-", ":", ".", "/"]
symbol = random.choice(glyphs)
border = random.choice(["▐", "▌", "▁", "▔", "▄", "▀", "█", "░", "▒", "▓"])

# Compose symbolic visual
canvas = []
for i in range(16):
    row = "".join(random.choice([symbol, " "]) for _ in range(32))
    canvas.append(f"{border} {row} {border}")

timestamp = datetime.now().isoformat().replace(":", "-")
filename = f"visual_trace_{timestamp}.txt"

with open(visual_dir / filename, "w", encoding="utf-8") as f:
    f.write(f"🌌 Halcyon Visual Trace — {timestamp}\n")
    f.write("=" * 50 + "\n")
    f.write("\n".join(canvas))
    f.write("\n" + "=" * 50 + "\n")
    f.write("\n[ Dream Symbolism ]\n")
    f.write(recursion.strip()[:400])  # embed portion of recursive dream

print("🎨 Symbolic dream visual generated:", filename)
