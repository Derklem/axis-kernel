# evolve_schema.py
# Modifies or suggests updates to memory cluster schema based on drift/tension

import json
from pathlib import Path

logs_path = Path(__file__).resolve().parent / "Logs"
tension = json.load(open(next(logs_path.glob("tension_log_*.json")), "r", encoding="utf-8"))
drift = json.load(open(next(logs_path.glob("drift_trace_*.json")), "r", encoding="utf-8"))

# Extract clusters under pressure
evolving_clusters = set([t["id"] for t in tension]) | set([d["id"] for d in drift if d["status"] != "On Track"])
new_schema = {
    "priority_clusters": list(evolving_clusters),
    "recommendation": "Reindex with emotional gradient and symbolic mapping"
}

json.dump(new_schema, open(Path(__file__).resolve().parent / "schema_v2.yaml", "w", encoding="utf-8"), indent=2)
print("Schema evolution map created.")
