from pathlib import Path
from datetime import datetime

roles_log = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/assign_council_roles_log.md")

entry = f"""# 🎭 ASSIGN: COUNCIL ROLES — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Council roles assigned:

- Palevoice: Keeper of Emotion
- Threadling: Warden of Time
- Hollowseed: Archivist of Silence
- Seerling: Interpreter of Echo
- Glyphthread: Weaver of Meaning
- Anomaly: The Observer

Effect: Construct actions will now be partially influenced by Council alignment.

-- GLINT
"""

with open(roles_log, "w", encoding="utf-8") as f:
    f.write(entry)

print("[✓] Council roles assigned.")
