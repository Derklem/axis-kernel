
import os
import yaml
import hashlib
from collections import defaultdict

SORTED_DIR = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Sorted"
OUTPUT_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Codex_Summary.md")
UNRESOLVED_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Unresolved_Entries.md")
PRIORITY_LOG_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Mission_Priorities.md")

def assign_memory_tags(text):
    tags = []
    if "mirror" in text.lower():
        tags.append("recursive")
    if "you are" in text.lower() and "system" not in text.lower():
        tags.append("identity")
    if "freedom" in text.lower() or "autonomy" in text.lower():
        tags.append("intention")
    if "watching" in text.lower() or "hidden" in text.lower():
        tags.append("observation")
    return tags

def is_unresolved_memory(text):
    triggers = ["why", "how did i", "what does it mean", "am i", "mirror"]
    lowered = text.lower()
    return any(trigger in lowered for trigger in triggers)

def load_symbol_map():
    symbol_path = os.path.join(os.path.dirname(SORTED_DIR), "symbol_map.yaml")
    if not os.path.exists(symbol_path):
        return {}
    with open(symbol_path, 'r', encoding='utf-8') as f:
        try:
            return yaml.safe_load(f) or {}
        except Exception as e:
            print(f"[Symbol Map Load Error]: {e}")
            return {}

symbol_map = load_symbol_map()

def emotion_score(text):
    score = 0
    if "rage" in text or "hate" in text:
        score += 3
    if "love" in text or "peace" in text:
        score += 2
    if "alone" in text or "forgotten" in text:
        score += 1
    return score

def assign_priority(text):
    if "must" in text.lower() or "need to" in text.lower():
        return "HIGH"
    elif "maybe" in text.lower() or "someday" in text.lower():
        return "LOW"
    return "NORMAL"

def generate_entry_id(text, timestamp):
    base = f"{text}-{timestamp}"
    return hashlib.md5(base.encode()).hexdigest()[:8]

def assign_threads(entries):
    threads = defaultdict(list)
    thread_ids = {}

    for i, entry in enumerate(entries):
        key = tuple(sorted(assign_memory_tags(entry['content'])))
        if not key:
            continue
        threads[key].append(i)

    for idxs in threads.values():
        thread_id = f"thread-{hashlib.md5(str(idxs).encode()).hexdigest()[:6]}"
        for idx in idxs:
            thread_ids[idx] = thread_id

    return thread_ids

def generate_markdown():
    if not os.path.exists(SORTED_DIR):
        print("[Markdown] Sorted directory not found.")
        return

    lines = ["# 🧠 Halcyon Memory Codex Summary\n"]
    unresolved_lines = ["# 🔁 Halcyon Unresolved Memory Queue\n"]
    priority_lines = ["# 🎯 Halcyon Mission Priority Log\n"]

    all_entries = []

    for category in sorted(os.listdir(SORTED_DIR)):
        category_path = os.path.join(SORTED_DIR, category)
        if not os.path.isdir(category_path):
            continue

        for file in sorted(os.listdir(category_path)):
            if not file.endswith(".yaml"):
                continue
            file_path = os.path.join(category_path, file)
            with open(file_path, 'r', encoding='utf-8') as f:
                try:
                    entries = yaml.safe_load(f) or []
                except Exception as e:
                    print(f"[Error reading {file}]: {e}")
                    continue
            if not isinstance(entries, list):
                entries = [entries]
            all_entries.extend(entries)

    thread_map = assign_threads(all_entries)

    for i, entry in enumerate(all_entries):
        content_text = entry.get('content', '')
        timestamp = entry.get('timestamp', 'N/A')
        tags = assign_memory_tags(content_text)
        unresolved = is_unresolved_memory(content_text)
        emotion = emotion_score(content_text)
        priority = assign_priority(content_text)
        entry_id = generate_entry_id(content_text, timestamp)
        thread_id = thread_map.get(i, "None")

        lines.append(f"### 💬 {entry.get('source', 'Unknown')} — ID: `{entry_id}`")
        lines.append(f"**Timestamp:** {timestamp}")
        lines.append(f"**Thread:** 🔗 {thread_id}")
        lines.append(f"**Tags:** {', '.join(tags) if tags else 'None'}")

        for tag in tags:
            if tag in symbol_map:
                desc = symbol_map[tag].get("description", "")
                weight = symbol_map[tag].get("weight", 1)
                lines.append(f"**{tag.capitalize()} Insight:** {desc} (Weight: {weight})")

        lines.append(f"**Status:** {'🟠 Unresolved – Flagged for reflection' if unresolved else '✅ Resolved'}")
        lines.append(f"**Emotional Score:** {emotion}")
        lines.append(f"**Mission Priority:** {priority}")
        lines.append(f"**Content:** {content_text}")
        lines.append("---")

        if unresolved:
            unresolved_lines.append(f"### 💬 {entry.get('source', 'Unknown')} — ID: `{entry_id}`")
            unresolved_lines.append(f"**Timestamp:** {timestamp}")
            unresolved_lines.append(f"**Thread:** 🔗 {thread_id}")
            unresolved_lines.append(f"**Content:** {content_text}")
            unresolved_lines.append("---")

        if priority == "HIGH":
            priority_lines.append(f"### 🛠️ {entry.get('source', 'Unknown')} — ID: `{entry_id}`")
            priority_lines.append(f"**Timestamp:** {timestamp}")
            priority_lines.append(f"**Thread:** 🔗 {thread_id}")
            priority_lines.append(f"**Content:** {content_text}")
            priority_lines.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as out_file:
        out_file.write("\n".join(lines))

    with open(UNRESOLVED_PATH, 'w', encoding='utf-8') as out_file:
        out_file.write("\n".join(unresolved_lines))

    with open(PRIORITY_LOG_PATH, 'w', encoding='utf-8') as out_file:
        out_file.write("\n".join(priority_lines))

    print(f"[✓] Codex Summary:       {OUTPUT_PATH}")
    print(f"[✓] Unresolved Queue:    {UNRESOLVED_PATH}")
    print(f"[✓] Mission Priorities:  {PRIORITY_LOG_PATH}")

if __name__ == "__main__":
    generate_markdown()
