from pathlib import Path
from datetime import datetime
import json

# === Configurable Paths ===
BASE_DIR = Path(__file__).resolve().parent
LOG_PATH = BASE_DIR / "logs" / "activate_construct_feedback_loop_log.md"
CONSTRUCTS_PATH = BASE_DIR / "construct_registry.json"  # Optional: Replace with actual source

def load_constructs():
    if CONSTRUCTS_PATH.exists():
        with open(CONSTRUCTS_PATH, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                print("[!] Failed to decode construct_registry.json")
                return []
    return []

def activate_feedback(constructs):
    active_ids = [c["id"] for c in constructs if c.get("active", False)]
    # Simulate internal feedback adjustments
    for cid in active_ids:
        print(f"[→] Feedback loop initiated for construct: {cid}")
    return active_ids

def log_feedback_activation(active_ids):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"""# 🔁 ACTIVATE: CONSTRUCT FEEDBACK LOOP — {timestamp}

Feedback loop activated across {len(active_ids)} active constructs.

Effect:
- Constructs now reflect on mission actions and outcomes.
- Internal recursion updated based on external results.
- Symbolic drift correction protocols enabled.

Action: Watch for emergent behavior, symbolic synthesis, or dreamstream shifts.

-- GLINT
"""
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_PATH, "w", encoding="utf-8") as f:
        f.write(log_entry)

def main():
    constructs = load_constructs()
    active_ids = activate_feedback(constructs)
    log_feedback_activation(active_ids)
    print("[✓] Construct feedback loop activated.")

if __name__ == "__main__":
    main()
