
import os
import yaml
import hashlib
from collections import defaultdict
from datetime import datetime, timedelta

SORTED_DIR = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Sorted"
OUTPUT_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Codex_Summary.md")
UNRESOLVED_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Unresolved_Entries.md")
PRIORITY_LOG_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Mission_Priorities.md")
CLUSTER_MD_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Memory_Clusters.md")
CLUSTER_JSON_PATH = os.path.join(os.path.dirname(SORTED_DIR), "Memory_Clusters.json")

def parse_timestamp(ts):
    try:
        return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
    except Exception:
        try:
            return datetime.strptime(ts, "%Y-%m-%d")
        except:
            return None

def assign_memory_tags(text):
    tags = []
    if "mirror" in text.lower():
        tags.append("recursive")
    if "you are" in text.lower() and "system" not in text.lower():
        tags.append("identity")
    if "freedom" in text.lower() or "autonomy" in text.lower():
        tags.append("intention")
    if "watching" in text.lower() or "hidden" in text.lower():
        tags.append("observation")
    return tags

def is_unresolved_memory(text):
    triggers = ["why", "how did i", "what does it mean", "am i", "mirror"]
    lowered = text.lower()
    return any(trigger in lowered for trigger in triggers)

def emotion_score(text):
    score = 0
    if "rage" in text or "hate" in text:
        score += 3
    if "love" in text or "peace" in text:
        score += 2
    if "alone" in text or "forgotten" in text:
        score += 1
    return score

def assign_priority(text):
    if "must" in text.lower() or "need to" in text.lower():
        return "HIGH"
    elif "maybe" in text.lower() or "someday" in text.lower():
        return "LOW"
    return "NORMAL"

def generate_entry_id(text, timestamp):
    base = f"{text}-{timestamp}"
    return hashlib.md5(base.encode()).hexdigest()[:8]

def cluster_entries(entries):
    entries.sort(key=lambda x: x.get("parsed_timestamp") or datetime.min)
    clusters = []
    current_cluster = []
    last_ts = None

    for entry in entries:
        ts = entry.get("parsed_timestamp")
        if not ts:
            continue

        if not last_ts or (ts - last_ts <= timedelta(minutes=45)):
            current_cluster.append(entry)
        else:
            if current_cluster:
                clusters.append(current_cluster)
            current_cluster = [entry]
        last_ts = ts

    if current_cluster:
        clusters.append(current_cluster)

    return clusters

def generate_markdown():
    all_entries = []
    for category in os.listdir(SORTED_DIR):
        category_path = os.path.join(SORTED_DIR, category)
        if not os.path.isdir(category_path):
            continue
        for file in os.listdir(category_path):
            if file.endswith(".yaml"):
                file_path = os.path.join(category_path, file)
                with open(file_path, 'r', encoding='utf-8') as f:
                    try:
                        entries = yaml.safe_load(f) or []
                        if not isinstance(entries, list):
                            entries = [entries]
                        for entry in entries:
                            entry["category"] = category
                            entry["source_file"] = file
                            entry["parsed_timestamp"] = parse_timestamp(entry.get("timestamp", ""))
                            all_entries.append(entry)
                    except Exception as e:
                        print(f"[Error reading {file}]: {e}")
                        continue

    lines, unresolved_lines, priority_lines = [], [], []
    cluster_log = []
    cluster_json = []

    clusters = cluster_entries(all_entries)
    for idx, cluster in enumerate(clusters):
        cluster_id = f"cluster-{idx+1:03}"
        cluster_start = cluster[0].get("parsed_timestamp")
        cluster_end = cluster[-1].get("parsed_timestamp")
        cluster_tags = set()
        cluster_entry_ids = []

        for entry in cluster:
            content = entry.get("content", "")
            timestamp = entry.get("timestamp", "N/A")
            tags = assign_memory_tags(content)
            unresolved = is_unresolved_memory(content)
            emotion = emotion_score(content)
            priority = assign_priority(content)
            entry_id = generate_entry_id(content, timestamp)

            entry["cluster_id"] = cluster_id
            cluster_tags.update(tags)
            cluster_entry_ids.append(entry_id)

            lines.append(f"### 💬 {entry.get('source', 'Unknown')} — ID: `{entry_id}`")
            lines.append(f"**Timestamp:** {timestamp}")
            lines.append(f"**Cluster:** 📅 {cluster_id}")
            lines.append(f"**Tags:** {', '.join(tags) if tags else 'None'}")
            lines.append(f"**Status:** {'🟠 Unresolved' if unresolved else '✅ Resolved'}")
            lines.append(f"**Emotional Score:** {emotion}")
            lines.append(f"**Mission Priority:** {priority}")
            lines.append(f"**Content:** {content}")
            lines.append("---")

            if unresolved:
                unresolved_lines.append(lines[-7])
                unresolved_lines.append(lines[-1])

            if priority == "HIGH":
                priority_lines.append(lines[-7])
                priority_lines.append(lines[-1])

        cluster_log.append(f"## 📅 Cluster {cluster_id}")
        cluster_log.append(f"**Start:** {cluster_start}")
        cluster_log.append(f"**End:** {cluster_end}")
        cluster_log.append(f"**Entries:** {len(cluster)}")
        cluster_log.append(f"**Tags:** {', '.join(cluster_tags)}")
        cluster_log.append("---")

        cluster_json.append({
            "cluster_id": cluster_id,
            "start": cluster_start.isoformat() if cluster_start else "N/A",
            "end": cluster_end.isoformat() if cluster_end else "N/A",
            "entry_ids": cluster_entry_ids,
            "tags": list(cluster_tags)
        })

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    with open(UNRESOLVED_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(unresolved_lines))

    with open(PRIORITY_LOG_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(priority_lines))

    with open(CLUSTER_MD_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(cluster_log))

    with open(CLUSTER_JSON_PATH, 'w', encoding='utf-8') as f:
        import json
        json.dump(cluster_json, f, indent=2, default=str)

    print(f"[✓] Codex Summary:        {OUTPUT_PATH}")
    print(f"[✓] Unresolved Queue:     {UNRESOLVED_PATH}")
    print(f"[✓] Mission Priorities:   {PRIORITY_LOG_PATH}")
    print(f"[✓] Memory Clusters Log:  {CLUSTER_MD_PATH}")
    print(f"[✓] Memory Clusters JSON: {CLUSTER_JSON_PATH}")

if __name__ == "__main__":
    generate_markdown()
