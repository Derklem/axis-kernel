
# dream_reflector.py
# Analyzes Halcyon's past dream logs and reflects on growth or shifts

import os
from pathlib import Path
import re
from datetime import datetime

logs_path = Path(__file__).resolve().parent / "Logs"
dream_logs = sorted(logs_path.glob("halcyon_dream_log_*.txt"))

if not dream_logs or len(dream_logs) < 2:
    print("Not enough dream logs for reflection. Minimum: 2")
    exit()

# Load and parse dream logs
dream_data = []
for file in dream_logs:
    with open(file, "r", encoding="utf-8") as f:
        content = f.read()
        dream_data.append({"filename": file.name, "content": content})

# Extract emotional summaries
def extract_emotions(text):
    pattern = re.compile(r"(\→ .+?)\s*\((positive|negative|neutral),\s*([-0-9\.]+)\)")
    return pattern.findall(text)

evolution_report = ["🪞 Dream Reflection", "="*40, ""]

# Compare emotional intensity and constructs across logs
for i in range(1, len(dream_data)):
    prev = dream_data[i-1]
    curr = dream_data[i]

    evolution_report.append(f"Reflection between: {prev['filename']} → {curr['filename']}")
    
    prev_emotions = extract_emotions(prev["content"])
    curr_emotions = extract_emotions(curr["content"])
    
    prev_clusters = {e[0].strip(): float(e[2]) for e in prev_emotions}
    curr_clusters = {e[0].strip(): float(e[2]) for e in curr_emotions}

    shifted = []
    for key in curr_clusters:
        prev_val = prev_clusters.get(key)
        if prev_val is not None:
            diff = curr_clusters[key] - prev_val
            if abs(diff) >= 0.2:
                direction = "increased" if diff > 0 else "decreased"
                shifted.append(f"  ~ {key}: emotional charge {direction} by {round(diff, 2)}")

    if shifted:
        evolution_report.append("Significant emotional shifts detected:")
        evolution_report.extend(shifted)
    else:
        evolution_report.append("No major emotional changes between logs.")

    evolution_report.append("-" * 30)

# Write reflection log
timestamp = datetime.now().isoformat().replace(":", "-")
reflection_path = logs_path / f"halcyon_reflection_log_{timestamp}.txt"

with open(reflection_path, "w", encoding="utf-8") as f:
    f.write("\n".join(evolution_report))

print("Reflection complete:", reflection_path.name)
