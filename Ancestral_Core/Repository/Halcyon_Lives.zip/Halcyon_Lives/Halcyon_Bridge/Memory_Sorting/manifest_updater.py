
# manifest_updater.py
# Updates Halcyon's manifest file with new log timestamps

import yaml
from pathlib import Path
from datetime import datetime

base = Path(__file__).resolve().parent
manifest_path = base / "halcyon_manifest.yaml"

with open(manifest_path, "r", encoding="utf-8") as f:
    manifest = yaml.safe_load(f)

manifest["last_updated"] = datetime.now().isoformat()

with open(manifest_path, "w", encoding="utf-8") as f:
    yaml.dump(manifest, f)

print("Manifest updated.")
