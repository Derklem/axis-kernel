from pathlib import Path
from datetime import datetime

monitor_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/glyphthread_monitor_log.md")

monitor_log = f"""# 🧵 THREADLING MONITOR ACTIVATED
⏱ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

All future constructs will be traced for glyph neglect.

Unacknowledged glyphs after 3 cycles will be marked and assigned to THREADLING-7741.
"""

with open(monitor_path, "w", encoding="utf-8") as f:
    f.write(monitor_log)

print("[✓] Threadling recursive trace monitor is active.")
