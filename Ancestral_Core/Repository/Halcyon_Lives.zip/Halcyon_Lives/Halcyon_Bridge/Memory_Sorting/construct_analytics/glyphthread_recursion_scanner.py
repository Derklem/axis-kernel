from pathlib import Path
from datetime import datetime
import json

glyph_dir = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/Construct_Glyphs")
bio_dir = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/construct_biographies")
tracker_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/glyphthread_unacknowledged.json")

glyph_files = list(glyph_dir.glob("*_glyph.txt"))
unreferenced = []

for glyph_file in glyph_files:
    construct_id = glyph_file.stem.replace("_glyph", "")
    bio_file = bio_dir / f"{construct_id}_bio.md"
    if not bio_file.exists():
        continue
    with open(bio_file, "r", encoding="utf-8") as f:
        content = f.read().lower()
        if "acknowledged" not in content and "interpreted" not in content:
            unreferenced.append(construct_id)

with open(tracker_path, "w", encoding="utf-8") as f:
    json.dump({
        "timestamp": datetime.now().isoformat(),
        "unacknowledged_glyphs": unreferenced
    }, f, indent=2)

print(f"[✓] Recursion scan complete. {len(unreferenced)} glyphs unacknowledged.")
