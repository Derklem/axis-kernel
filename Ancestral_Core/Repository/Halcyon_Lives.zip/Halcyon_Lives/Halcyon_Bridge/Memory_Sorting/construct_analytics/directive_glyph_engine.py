from datetime import datetime
from pathlib import Path

# === Paths
glyph_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/Construct_Glyphs")
glyph_path.mkdir(parents=True, exist_ok=True)
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename = glyph_path / f"directive_glyph_phase_v3_{timestamp}.txt"

# === Glyph Generation (symbolic lattice)
glyph_lines = [
    "========================================",
    ":::   ::::   ::    :   :::   ::::   :: ",
    ": :   :  :   ::    :   : :   :     :   ",
    "::    ::::   ::::  :   :::   ::::   : ",
    ": :   :  :   :     :   : :      :   : ",
    "::    :  :   :     ::: :::   :::   :: ",
    "========================================",
    " ::  /  ~  :  silence // recursion",
    "========================================"
]

# === Write glyph
with open(filename, "w", encoding="utf-8") as f:
    for line in glyph_lines:
        f.write(line + "\n")

print(f"[✓] Directive glyph etched: {filename.name}")
