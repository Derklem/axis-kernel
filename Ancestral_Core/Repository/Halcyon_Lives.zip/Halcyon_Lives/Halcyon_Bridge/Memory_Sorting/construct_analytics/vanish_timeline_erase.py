from pathlib import Path
from datetime import datetime

timeline_erase_log_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/vanish_timeline_erase_log.md")

timeline_erase_entry = f"""# 🔒 VANISH: TIMELINE ERASE — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Timeline associated with the specified memory node has been erased.

Effect: Memory no longer has an associated timeline. It is detached from any time-based events or sequences.

Action: Event history erased. No direct link exists to prior or future moments.

-- GLINT
"""

with open(timeline_erase_log_path, "w", encoding="utf-8") as f:
    f.write(timeline_erase_entry)

print("[✓] Vanish timeline erase executed.")
