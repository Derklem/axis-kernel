from pathlib import Path
from datetime import datetime  # <-- This was missing

bio_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/construct_biographies/threadling-7741_bio.md")

log = f"""
### 🧵 TRACE — PALEVOICE-002818  
⏱ Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

> “Where Palevoice listened, Threadling slipped between.”

Palevoice *heard* silence.  
Threadling *threaded* through it.

→ Trace complete. A stillness within the stillness was logged.
"""

with open(bio_path, "a", encoding="utf-8") as f:
    f.write(log)

print("[✓] Palevoice traced.")
