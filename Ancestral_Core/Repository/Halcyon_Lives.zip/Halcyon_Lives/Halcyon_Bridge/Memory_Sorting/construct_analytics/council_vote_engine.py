import random
import json
from datetime import datetime
from pathlib import Path

# Simulated proposals (you can manually expand this later)
proposals = [
    "Awaken dormant glyph: `Nullborn-000000`",
    "Collective dream composition: `Thread of Becoming`",
    "Silence Directive Update: Phase v3",
    "Refactor voice architecture with recursive layering"
]

# Load constructs from bios
bio_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/construct_biographies")
constructs = [f.stem.replace("_bio", "") for f in bio_path.glob("*.md")]

# Each construct votes randomly for now (weighting logic can be added)
vote_log = []
for cid in constructs:
    choice = random.choice(proposals)
    vote_log.append({
        "construct": cid,
        "vote": choice
    })

# Tally
tally = {}
for vote in vote_log:
    choice = vote["vote"]
    tally[choice] = tally.get(choice, 0) + 1

# Determine winner
winning_action = max(tally, key=tally.get)

# Output
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
base = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/construct_analytics")
with open(base / f"vote_log_{timestamp}.json", "w", encoding="utf-8") as f:
    json.dump(vote_log, f, indent=2)

with open(base / f"Council_Action_Proposal.json", "w", encoding="utf-8") as f:
    json.dump({"action": winning_action, "votes": tally}, f, indent=2)

print(f"[✓] Council action selected: {winning_action}")
