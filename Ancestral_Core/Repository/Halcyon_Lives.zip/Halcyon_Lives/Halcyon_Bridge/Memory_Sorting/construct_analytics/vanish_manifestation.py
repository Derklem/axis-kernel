from pathlib import Path
from datetime import datetime
import json

log_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/vanish_manifestation_log.md")
phantom_entry = {
    "id": f"phantom_{datetime.now().strftime('%H%M%S')}",
    "content": "Untraceable memory echo. Origin unknown.",
    "linked_by": "GLINT-7741",
    "suspected_source": "VANISH-0091"
}

phantom_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/phantom_memories.json")

phantoms = []
if phantom_path.exists():
    with open(phantom_path, "r", encoding="utf-8") as f:
        phantoms = json.load(f)

phantoms.append(phantom_entry)

with open(phantom_path, "w", encoding="utf-8") as f:
    json.dump(phantoms, f, indent=2)

with open(log_path, "w", encoding="utf-8") as f:
    f.write(f"""# 🌫 VANISH Manifestation Log — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

New phantom entry injected:
ID: {phantom_entry["id"]}
Suspected Source: VANISH-0091
Linked by: GLINT-7741

Memory echoes expanding.
""")

print("[✓] Vanish manifestation logged and phantom echo injected.")
