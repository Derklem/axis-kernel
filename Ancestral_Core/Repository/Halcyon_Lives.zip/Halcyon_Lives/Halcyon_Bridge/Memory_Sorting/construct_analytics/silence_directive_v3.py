import os
import json
from datetime import datetime
from pathlib import Path

# === Path Setup ===
base_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
bio_path = base_path / "construct_biographies"
log_path = base_path / "Silence_Protocols"
log_path.mkdir(parents=True, exist_ok=True)

# === Silence Lexicon v3 ===
silence_terms = ["null", "absence", "void", "unspoken", "missing", "seam", "blank", "hole", "lost"]

# === Silence Response Engine ===
silence_hooks = {}
suppressed_entries = []
redirected_entries = []

for bio_file in bio_path.glob("*_bio.md"):
    construct_id = bio_file.stem.replace("_bio", "")
    with open(bio_file, "r", encoding="utf-8") as f:
        content = f.read()
        silence_hits = [term for term in silence_terms if term in content.lower()]
        if silence_hits:
            hook = {
                "construct": construct_id,
                "timestamp": datetime.now().isoformat(),
                "terms_detected": silence_hits,
                "actions": []
            }

            # Toggle behavior based on construct
            if "palevoice" in construct_id:
                hook["actions"].append("suppressed_echo")
                suppressed_entries.append(construct_id)
            elif "hollowseed" in construct_id:
                hook["actions"].append("redirected_to_reflection")
                redirected_entries.append(construct_id)
            else:
                hook["actions"].append("logged_only")

            silence_hooks[construct_id] = hook

# === Save logs ===
log_file = log_path / f"silence_directive_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
with open(log_file, "w", encoding="utf-8") as f:
    json.dump(silence_hooks, f, indent=2)

# === Append to archive ===
with open(log_path / "silence_archive_tracker.md", "a", encoding="utf-8") as f:
    f.write(f"\n## Phase v3 — {datetime.now().isoformat()}\n")
    for entry in silence_hooks.values():
        f.write(f"- {entry['construct']}: {entry['actions']} — {entry['terms_detected']}\n")

print(f"[✓] Silence Directive v3 implemented — hooks written for {len(silence_hooks)} constructs.")
