import os
import re
import json
from pathlib import Path
from datetime import datetime

# === Configuration ===
base_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
construct_folder = base_path / "Construct_Glyphs"
log_folder = base_path / "Logs"
codex_folder = base_path / "Codex"
bio_folder = base_path / "construct_biographies"
output_folder = base_path / "construct_analytics"
output_folder.mkdir(parents=True, exist_ok=True)

# === Load Construct IDs ===
construct_ids = [f.stem.replace("_glyph", "") for f in construct_folder.glob("*_glyph.txt")]

pulse_data = {
    cid: {
        "construct_id": cid,
        "pulses": {
            "dream_logs": 0,
            "broadcasts": 0,
            "reflections": 0,
            "codices": 0,
            "biographies": 0
        },
        "last_pulse": None
    } for cid in construct_ids
}

# === Utility: Mention Scanner ===
def scan_mentions(file_path, construct_ids):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read().lower()
            return {
                cid: len(re.findall(re.escape(cid.lower()), content))
                for cid in construct_ids if cid.lower() in content
            }
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return {}

# === Source Mapping ===
sources = {
    "dream_logs": list(log_folder.glob("halcyon_dream_log_*.txt")),
    "broadcasts": list(log_folder.glob("voice_output_*.txt")),
    "reflections": list(log_folder.glob("halcyon_reflection_log_*.txt")) + list(log_folder.glob("recursive_reflections_*.txt")),
    "codices": list(codex_folder.glob("*.md")),
    "biographies": list(bio_folder.glob("*.md"))
}

# === Scan and Populate ===
for pulse_type, files in sources.items():
    for file in files:
        mentions = scan_mentions(file, construct_ids)
        timestamp = datetime.fromtimestamp(file.stat().st_mtime).isoformat()
        for cid, count in mentions.items():
            pulse_data[cid]["pulses"][pulse_type] += count
            if not pulse_data[cid]["last_pulse"] or timestamp > pulse_data[cid]["last_pulse"]:
                pulse_data[cid]["last_pulse"] = timestamp

# === Save Pulse Map ===
output_file = output_folder / "pulse_map.json"
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(list(pulse_data.values()), f, indent=2)

print(f"[✓] Construct pulse map written to {output_file}")
