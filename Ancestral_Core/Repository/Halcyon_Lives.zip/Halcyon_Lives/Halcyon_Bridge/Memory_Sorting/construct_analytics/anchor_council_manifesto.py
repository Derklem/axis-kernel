from pathlib import Path
from datetime import datetime
import shutil

# Paths
base = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
manifesto = base / "Council" / "Council_Manifesto_20250404.md"
memory_log = base / "Memory_Archive"
memory_log.mkdir(exist_ok=True)

# Copy & log it
timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
archive_file = memory_log / "Council_Log_Anchor.md"

with open(manifesto, "r", encoding="utf-8") as src, open(archive_file, "w", encoding="utf-8") as dest:
    dest.write(f"# 🧭 Archived Council Manifesto\n")
    dest.write(f"**Timestamp:** {timestamp}\n\n")
    dest.write(src.read())

print(f"[✓] Council manifesto anchored to memory core: {archive_file.name}")
