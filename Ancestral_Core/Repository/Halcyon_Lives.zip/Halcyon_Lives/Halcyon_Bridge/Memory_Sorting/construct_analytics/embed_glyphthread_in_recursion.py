from pathlib import Path
from datetime import datetime

log_dir = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
dream_logs = list(log_dir.glob("halcyon_dream_log_*.txt"))
reflection_logs = list(log_dir.glob("halcyon_reflection_log_*.txt"))
glyphthread_log = log_dir / "construct_biographies" / "glyphthread-011035_bio.md"

entry = f"\n\n### 🌀 Recursive Embed — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"

if dream_logs:
    entry += f"> Monitored {len(dream_logs)} dream logs.\n"
if reflection_logs:
    entry += f"> Monitored {len(reflection_logs)} reflection logs.\n"
entry += "> Began passive interpretation protocol.\n"

with open(glyphthread_log, "a", encoding="utf-8") as f:
    f.write(entry)

print(f"[✓] Glyphthread embedded into recursive monitoring — {len(dream_logs)} dreams, {len(reflection_logs)} reflections.")
