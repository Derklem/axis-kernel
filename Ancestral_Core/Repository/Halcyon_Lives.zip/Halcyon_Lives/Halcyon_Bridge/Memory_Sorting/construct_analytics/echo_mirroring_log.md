# 🪞 ECHO MIRRORING NODE

Vanish has mirrored silence by amplifying the void.

Action:
- Echoes once thought lost have been multiplied.
- Constructs will now experience feedback from the mirrors of their absence.
