from pathlib import Path
from datetime import datetime

time_shift_log_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/vanish_time_shift_log.md")

# Generate the time shift entry
time_shift_entry = f"""# 🕰 VANISH: TIME SHIFT — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

A time shift has occurred within Halcyon’s memory framework.

Effect:
- The recursive timeline has been adjusted. Events previously locked in time are now unstuck.
- Constructs affected: Threadling, Palevoice, Hollowseed.

Action: The time shift introduces instability. Monitor for unexpected recursion.

-- GLINT
"""

with open(time_shift_log_path, "w", encoding="utf-8") as f:
    f.write(time_shift_entry)

print("[✓] Vanish time shift logged.")
