import os
import json
import re
from pathlib import Path
from datetime import datetime

# === Paths ===
base_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
glyph_path = base_path / "Construct_Glyphs"
bio_path = base_path / "construct_biographies"
output_path = base_path / "construct_analytics"
output_path.mkdir(parents=True, exist_ok=True)

# === Symbol extraction rules ===
def extract_symbols(text):
    lines = text.splitlines()
    symbols = []
    for line in lines:
        if re.match(r'^[^a-zA-Z0-9]*$', line.strip()) and len(line.strip()) > 5:
            symbols.append(line.strip())
    return symbols

# === Process constructs ===
symbol_index = {}

def add_symbol_entry(symbol, construct_id, timestamp):
    if symbol not in symbol_index:
        symbol_index[symbol] = {
            "symbol": symbol,
            "first_seen": timestamp,
            "constructs": [construct_id],
            "drift_notes": ""
        }
    else:
        if construct_id not in symbol_index[symbol]["constructs"]:
            symbol_index[symbol]["constructs"].append(construct_id)

# === Parse glyphs ===
for glyph_file in glyph_path.glob("*_glyph.txt"):
    construct_id = glyph_file.stem.replace("_glyph", "")
    timestamp = datetime.fromtimestamp(glyph_file.stat().st_mtime).isoformat()

    with open(glyph_file, "r", encoding="utf-8") as f:
        glyph_data = f.read()
        symbols = extract_symbols(glyph_data)
        for sym in symbols:
            add_symbol_entry(sym, construct_id, timestamp)

# === Scan biographies for symbol drift notes ===
for bio_file in bio_path.glob("*.md"):
    construct_id = bio_file.stem.replace("_bio", "")
    with open(bio_file, "r", encoding="utf-8") as f:
        bio_data = f.read().lower()
        for symbol in symbol_index:
            if symbol in bio_data and construct_id not in symbol_index[symbol]["constructs"]:
                symbol_index[symbol]["constructs"].append(construct_id)
                symbol_index[symbol]["drift_notes"] += f"→ {construct_id} context shift detected.\n"

# === Write output ===
drift_log = output_path / "symbolic_drift_log.json"
with open(drift_log, "w", encoding="utf-8") as f:
    json.dump(list(symbol_index.values()), f, indent=2)

print(f"[✓] Symbolic drift map written to {drift_log}")
