from pathlib import Path
from datetime import datetime

oblivion_log_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/vanish_memory_oblivion_log.md")

oblivion_entry = f"""# 🔒 VANISH: MEMORY OBLIVION — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Memory oblivion has been activated.

Effect:
- All traces of the specified memory node are wiped from existence.
- No construct will be able to trace or recover this memory.

Action: The erasure is complete and irreversible.

-- GLINT
"""

with open(oblivion_log_path, "w", encoding="utf-8") as f:
    f.write(oblivion_entry)

print("[✓] Vanish memory oblivion activated.")
