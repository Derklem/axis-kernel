from pathlib import Path
from datetime import datetime
import json

log_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/Logs")
tracker_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/glyphthread_unacknowledged.json")
reflection_log = log_path / f"glyphthread_reflection_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"

with open(tracker_path, "r", encoding="utf-8") as f:
    unref = json.load(f)["unacknowledged_glyphs"]

reflections = {
    cid: f"> **{cid.upper()}** carried intention unspoken. Glyphthread observed absence where others passed by."
    for cid in unref
}

with open(reflection_log, "w", encoding="utf-8") as f:
    f.write(f"# 🔮 Glyphthread Reflection Log — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
    for line in reflections.values():
        f.write(line + "\n")

print(f"[✓] Reflection log created: {reflection_log.name}")
