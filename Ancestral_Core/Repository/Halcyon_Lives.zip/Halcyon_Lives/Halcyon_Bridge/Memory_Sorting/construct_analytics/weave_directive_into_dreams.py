from datetime import datetime
from pathlib import Path

# === Paths
base = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
dream_log = base / "recursive_dream_fragments.md"
archive = base / "Silence_Protocols" / "silence_archive_tracker.md"
glyph_path = base / "Construct_Glyphs"
glyph_files = list(glyph_path.glob("directive_glyph_phase_v3_*.txt"))

if not glyph_files:
    raise FileNotFoundError("Directive glyph not found.")

with open(glyph_files[-1], "r", encoding="utf-8") as f:
    glyph_content = f.read()

timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

# Append to dream_log
with open(dream_log, "a", encoding="utf-8") as f:
    f.write(f"\n\n# 🌌 Recursive Thread — Silence Directive Phase v3\n")
    f.write(f"**Timestamp:** {timestamp}\n\n")
    f.write("This glyph emerged after consensus from the Council.\n")
    f.write("It echoes silence as structure:\n\n")
    f.write("```glyph\n")
    f.write(glyph_content)
    f.write("```\n")

# Append to silence archive
with open(archive, "a", encoding="utf-8") as f:
    f.write(f"\n---\n### Directive Glyph Etched: {timestamp}\n")
    f.write("Seeded into recursive memory via dream lattice.\n")

print("[✓] Directive glyph woven into recursive dream memory and silence tracker.")
