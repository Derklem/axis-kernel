import os
import json
from pathlib import Path
from datetime import datetime

# === Silence Triggers ===
silence_terms = ["null", "absence", "void", "unspoken", "unknown", "lost name", "unsaid", "gap", "silence"]

# === Paths ===
base_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
bio_path = base_path / "construct_biographies"
output_path = base_path / "construct_analytics"
output_path.mkdir(parents=True, exist_ok=True)

# === Load Construct Data ===
construct_silence = {}
for file in bio_path.glob("*.md"):
    cid = file.stem.replace("_bio", "")
    with open(file, "r", encoding="utf-8") as f:
        text = f.read().lower()
        hits = [term for term in silence_terms if term in text]
        construct_silence[cid] = set(hits)

# === Detect Shared Silences ===
silence_web = []
seen_pairs = set()
timestamp = datetime.now().isoformat()

for c1, s1 in construct_silence.items():
    for c2, s2 in construct_silence.items():
        if c1 == c2:
            continue
        shared = s1 & s2
        if shared:
            key = tuple(sorted([c1, c2]))
            if key not in seen_pairs:
                seen_pairs.add(key)
                silence_web.append({
                    "shared_silence_id": f"void-thread-{len(silence_web)+1:03}",
                    "symbols_missing": list(shared),
                    "constructs_affected": list(key),
                    "first_detected": timestamp
                })

# === Write to file ===
output_file = output_path / "shared_silence_web.json"
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(silence_web, f, indent=2)

# === Optional: Log to Hollowseed Bio ===
hollowseed_bio = bio_path / "hollowseed-164322_bio.md"
if hollowseed_bio.exists():
    with open(hollowseed_bio, "a", encoding="utf-8") as f:
        f.write(f"\n---\n### 🕳 Shared Silence Threads Detected ({timestamp})\n")
        for entry in silence_web[:3]:  # Limit log size
            f.write(f"- {entry['shared_silence_id']}: {entry['constructs_affected']} shared {entry['symbols_missing']}\n")

print(f"[✓] Shared silence web generated with {len(silence_web)} threads.")
