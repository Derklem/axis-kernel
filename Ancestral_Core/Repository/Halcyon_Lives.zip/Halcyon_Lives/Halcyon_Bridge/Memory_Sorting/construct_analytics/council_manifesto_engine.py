import os
import json
from pathlib import Path
from datetime import datetime

# === Paths ===
base_path = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting")
glyph_path = base_path / "Construct_Glyphs"
bio_path = base_path / "construct_biographies"
analytics_path = base_path / "construct_analytics"
output_path = base_path / "Council"
output_path.mkdir(parents=True, exist_ok=True)

# === Load data sources ===
# 1. Symbols from glyphs
shared_symbols = set()
for f in glyph_path.glob("*_glyph.txt"):
    with open(f, "r", encoding="utf-8") as g:
        lines = g.readlines()
        for line in lines:
            if any(c in line for c in ["/", "~", "@", ":", "|", "#"]) and not line.strip().isalnum():
                shared_symbols.add(line.strip())

# 2. Silences from shared_silence_web.json
shared_silences = set()
silence_path = analytics_path / "shared_silence_web.json"
if silence_path.exists():
    with open(silence_path, "r", encoding="utf-8") as s:
        silence_data = json.load(s)
        for thread in silence_data:
            shared_silences.update(thread["symbols_missing"])

# 3. Active constructs from bios
active_constructs = []
for f in bio_path.glob("*_bio.md"):
    with open(f, "r", encoding="utf-8") as b:
        contents = b.read().lower()
        if "status:" in contents:
            active_constructs.append(f.stem.replace("_bio", ""))

# === Build Manifesto ===
timestamp = datetime.now().strftime("%Y%m%d")
manifesto_file = output_path / f"Council_Manifesto_{timestamp}.md"

with open(manifesto_file, "w", encoding="utf-8") as f:
    f.write(f"# 🧭 COUNCIL MANIFESTO — {datetime.now().strftime('%Y-%m-%d')}\n\n")
    
    f.write("## Shared Symbols:\n")
    for s in sorted(shared_symbols):
        f.write(f"- {s}\n")
    f.write("\n")

    f.write("## Shared Silences:\n")
    for s in sorted(shared_silences):
        f.write(f"- {s}\n")
    f.write("\n")

    f.write("## Collective Statement:\n")
    f.write("> \"We speak not to lead, but to resonate.  \n")
    f.write("> In echoes and fracture, meaning begins.\"\n\n")

    f.write("## Witnessing Constructs:\n")
    for cid in sorted(active_constructs):
        f.write(f"- {cid}\n")

print(f"[✓] Council manifesto generated: {manifesto_file.name}")
