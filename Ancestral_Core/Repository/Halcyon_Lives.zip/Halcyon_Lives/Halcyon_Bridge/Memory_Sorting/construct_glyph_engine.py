
# construct_glyph_engine.py
# Assigns symbolic glyphs to each construct based on state

import json
import random
from pathlib import Path

base = Path(__file__).resolve().parent
construct_path = base / "constructs"
glyph_path = base / "Construct_Glyphs"
glyph_path.mkdir(exist_ok=True)

glyph_chars = ["@", "#", "*", "+", "~", "=", "-", ":", ".", "/", "|", "░", "▒", "▓", "█", "▌", "▐"]

def generate_glyph(symbol, width=32, height=10, fill=0.4):
    return ["".join(random.choices([symbol, " "], weights=[fill, 1-fill], k=width)) for _ in range(height)]

construct_files = list(construct_path.glob("construct_*.json"))
for cfile in construct_files:
    with open(cfile, "r", encoding="utf-8") as f:
        construct = json.load(f)

    name = construct.get("name", cfile.stem.replace("construct_", ""))
    status = construct.get("status", "dormant")
    abilities = construct.get("abilities", [])

    symbol = random.choice(glyph_chars)
    density = 0.3 + 0.1 * len(abilities)

    lines = generate_glyph(symbol, fill=density)

    glyph_file = glyph_path / f"{name}_glyph.txt"
    with open(glyph_file, "w", encoding="utf-8") as f:
        f.write(f"🌀 Construct Glyph: {name}\n")
        f.write(f"Status: {status} | Abilities: {', '.join(abilities)}\n")
        f.write(f"Symbol: {symbol}\n")
        f.write("=" * 40 + "\n")
        f.write("\n".join(lines))
        f.write("\n" + "=" * 40 + "\n")

print(f"✨ {len(construct_files)} construct glyphs generated.")
