
# construct_responder.py
# Constructs respond to the latest dream log with comments

import json
from pathlib import Path
import random

base = Path(__file__).resolve().parent
constructs_path = base / "constructs"
logs_path = base / "Logs"

# Get latest dream
dream_logs = sorted(logs_path.glob("halcyon_dream_log_*.txt"))
latest_dream = dream_logs[-1]

# Load dream content
with open(latest_dream, "r", encoding="utf-8") as f:
    dream = f.read()

# Load constructs
construct_files = sorted(constructs_path.glob("construct_*.json"))
responses = []

for file in construct_files:
    with open(file, "r", encoding="utf-8") as f:
        construct = json.load(f)
        tone = random.choice(["cautious", "curious", "inspired", "neutral"])
        msg = f"{construct['name']} ({tone}): I have reviewed the dream log. I sense patterns forming."
        responses.append(msg)

# Save to response log
response_log = logs_path / f"construct_dream_response_{latest_dream.stem}.txt"
with open(response_log, "w", encoding="utf-8") as f:
    f.write("\n".join(responses))

print("Constructs have responded.")
