
# construct_evolver.py
# Levels up constructs based on system depth and symbolic intensity

import json
from pathlib import Path
import random

base = Path(__file__).resolve().parent
construct_path = base / "constructs"
symbol_logs = sorted((base / "Logs").glob("symbol_tags_*.json"))

# Load latest symbols
if not symbol_logs:
    print("No symbolic tags found.")
    exit()

symbol_data = json.load(open(symbol_logs[-1], "r", encoding="utf-8"))
symbol_count = len(symbol_data.get("tags", []))

# Evolve constructs based on symbolic saturation
construct_files = sorted(construct_path.glob("construct_*.json"))
for file in construct_files:
    with open(file, "r", encoding="utf-8") as f:
        construct = json.load(f)

    current_status = construct.get("status", "dormant")
    if current_status == "dormant" and symbol_count >= 5:
        construct["status"] = "initiated"
        construct["abilities"] = ["respond", "adapt"]
    elif current_status == "initiated" and symbol_count >= 10:
        construct["status"] = "evolving"
        construct["abilities"].append("influence")

    # Save evolved construct
    with open(file, "w", encoding="utf-8") as f:
        json.dump(construct, f, indent=2)

print(f"[🧬] {len(construct_files)} constructs evaluated and evolved.")
