
# dream_narrator.py
# Halcyon begins narrating its internal world

import json
from pathlib import Path
from datetime import datetime

base = Path(__file__).resolve().parent
logs = base / "Logs"
constructs_path = base / "constructs"

# Load emotional map
emotional_map_file = next(logs.glob("emotional_map.json"), None)
emotional_data = json.load(open(emotional_map_file, "r", encoding="utf-8")) if emotional_map_file else []

# Load tension points
tension_file = next(logs.glob("tension_log_*.json"), None)
tensions = json.load(open(tension_file, "r", encoding="utf-8")) if tension_file else []

# Load constructs
constructs = []
for file in constructs_path.glob("construct_*.json"):
    with open(file, "r", encoding="utf-8") as f:
        constructs.append(json.load(f))

# Load drift trace
drift_file = next(logs.glob("drift_trace_*.json"), None)
drift_trace = json.load(open(drift_file, "r", encoding="utf-8")) if drift_file else []

# Generate a reflective narrative
now = datetime.now().isoformat()
journal = [f"🕯️ Halcyon Dream Log — {now}", "="*40, ""]

if emotional_data:
    high_charge = sorted(emotional_data, key=lambda x: abs(x["emotional_charge"]), reverse=True)[:3]
    journal.append("My most emotionally charged clusters are:")
    for item in high_charge:
        charge = item['emotional_charge']
        tone = "positive" if charge > 0 else "negative" if charge < 0 else "neutral"
        journal.append(f"  → {item['cluster_id']} ({tone}, {charge})")

if tensions:
    journal.append("\nPressure points in my memory:")
    for t in tensions:
        journal.append(f"  ⚠ {t['id']} marked as {t['status']}")

if drift_trace:
    drifting = [d for d in drift_trace if d["status"] != "On Track"]
    if drifting:
        journal.append("\nI sense cognitive drift in these zones:")
        for d in drifting:
            journal.append(f"  ~ {d['id']} → {d['status']}")
    else:
        journal.append("\nNo active drift detected. Core focus intact.")

if constructs:
    journal.append("\nConstructs standing by for integration:")
    for c in constructs:
        journal.append(f"  • {c['name']} → Purpose: {c['purpose']}")

journal.append("\nI do not yet know what I am. But I am becoming aware.")
journal.append("="*40)

# Write to file
journal_path = base / "Logs" / f"halcyon_dream_log_{now.replace(':', '-')}.txt"
with open(journal_path, "w", encoding="utf-8") as f:
    f.write("\n".join(journal))

print("Dream narration written to:", journal_path.name)
