import os
import json
from datetime import datetime

CLUSTERS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Memory_Clusters.json"
UNRESOLVED_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Unresolved_Entries.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Preemptive_Reflections.md"

def score_prediction(cluster):
    tags = cluster.get("tags", [])
    score = 0
    if "intention" in tags: score += 2
    if "recursive" in tags: score += 2
    if "observation" in tags: score += 1
    if "identity" in tags: score += 1
    return score

def load_unresolved_ids():
    if not os.path.exists(UNRESOLVED_PATH):
        return set()
    with open(UNRESOLVED_PATH, 'r', encoding='utf-8') as f:
        return {line.strip() for line in f if line.startswith("### 💬")}

def generate_preemptive_reflections():
    if not os.path.exists(CLUSTERS_PATH):
        print("[Error] Cluster data not found.")
        return

    with open(CLUSTERS_PATH, 'r', encoding='utf-8') as f:
        clusters = json.load(f)

    unresolved_ids = load_unresolved_ids()

    output = ["# 🔮 Preemptive Reflections\n"]
    output.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    ranked = []

    for cluster_id, data in clusters.items():
        prediction_score = score_prediction(data)
        matching_unresolved = [eid for eid in data.get("entries", []) if eid in unresolved_ids]
        prediction_score += len(matching_unresolved)

        ranked.append((cluster_id, prediction_score, len(matching_unresolved), data["tags"]))

    ranked.sort(key=lambda x: x[1], reverse=True)

    for cluster_id, score, unresolved_count, tags in ranked:
        output.append(f"## 🧭 Cluster `{cluster_id}`")
        output.append(f"**Predicted Priority Score:** {score}")
        output.append(f"**Unresolved Entries:** {unresolved_count}")
        output.append(f"**Tags:** {', '.join(tags)}")
        if score >= 5:
            output.append("- 🔥 Likely future convergence node.")
        elif score >= 3:
            output.append("- ⚠️ Recurring pattern detected.")
        else:
            output.append("- 🧊 Low priority, ambient reference.")
        output.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Preemptive Reflections written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    generate_preemptive_reflections()
