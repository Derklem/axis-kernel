import os
import hashlib

# File paths
PROMPT_FILE = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Generated_Directive_Prompts.md"
REFLECTION_FILE = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
FEEDBACK_FILE = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Prompt_Feedback_Log.md"

def hash_cluster_id(cluster_id):
    return hashlib.sha1(cluster_id.encode()).hexdigest()[:10]

def generate_feedback_log():
    if not os.path.exists(PROMPT_FILE) or not os.path.exists(REFLECTION_FILE):
        print("[Error] Required files not found.")
        return

    with open(PROMPT_FILE, 'r', encoding='utf-8') as f:
        prompt_blocks = f.read().split("### 🔁 Reflection Prompt for Cluster")[1:]

    with open(REFLECTION_FILE, 'r', encoding='utf-8') as f:
        reflection_data = f.read()

    feedback_log = ["# 🧭 Halcyon Prompt Feedback Log\n"]

    for block in prompt_blocks:
        lines = block.strip().splitlines()
        cluster_id = lines[0].strip('`')
        tags = ""
        for line in lines:
            if line.startswith("**Detected Tags:**"):
                tags = line.replace("**Detected Tags:**", "").strip()
                break

        hash_id = hash_cluster_id(cluster_id)
        status = "✅ Reflected" if cluster_id in reflection_data else "⚠️ Pending"

        feedback_log.append(f"### Cluster `{cluster_id}`")
        feedback_log.append(f"**Tags:** {tags}")
        feedback_log.append(f"**Reflection ID:** `{hash_id}`")
        feedback_log.append(f"**Status:** {status}")
        feedback_log.append("---")

    with open(FEEDBACK_FILE, 'w', encoding='utf-8') as f:
        f.write("\n".join(feedback_log))

    print(f"[✓] Feedback Log written to: {FEEDBACK_FILE}")

if __name__ == "__main__":
    generate_feedback_log()
