from pathlib import Path
import time

input_path = Path("D:/Halcyon_Lives/Bridge/Input/gpt_input.txt")
output_path = Path("D:/Halcyon_Lives/Bridge/Output/gpt_output.txt")
last_input = ""

print("[🔗] GPT Listen Loop Initialized...")

while True:
    if input_path.exists():
        with input_path.open("r", encoding="utf-8") as f:
            current_input = f.read().strip()
        if current_input and current_input != last_input:
            print(f"[📨] FRACTLING → GPT: {current_input}")
            print("[🧠] Awaiting GPT response...")

            # ⛔️ This is the manual point:
            # You'll copy the current_input into this tab (here), I will respond.
            # Then you'll paste my reply into gpt_output.txt manually.

            last_input = current_input
    time.sleep(3)
