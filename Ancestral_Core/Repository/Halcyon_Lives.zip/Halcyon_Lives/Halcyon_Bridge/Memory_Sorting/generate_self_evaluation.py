import os
from datetime import datetime

DIALOGUE_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Internal_Dialogue_Log.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Self_Evaluation_Threads.md"

def evaluate_dialogues():
    if not os.path.exists(DIALOGUE_PATH):
        print("[Error] Dialogue log not found.")
        return

    with open(DIALOGUE_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    output = ["# 🧪 Halcyon Self-Evaluation Threads\n"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    output.append(f"**Evaluated At:** {now}\n")

    current_cluster = ""
    in_cluster = False
    response_quality = "Unknown"
    buffer = []

    for line in lines:
        if line.startswith("## 🌀 Dialogue on"):
            current_cluster = line.split("`")[1]
            in_cluster = True
            response_quality = "Unknown"
            buffer.clear()
        elif in_cluster and line.startswith("🟢 *Halcyon:*"):
            buffer.append(line)
            response = line.split(":", 1)[1].strip().lower()
            if any(term in response for term in ["pending", "reopen", "revisit", "loop"]):
                response_quality = "Reflective"
            elif any(term in response for term in ["more data", "need to analyze", "working on it", "scanning"]):
                response_quality = "Investigative"
            elif any(term in response for term in ["conclude", "finalize", "locked", "closing this"]):
                response_quality = "Premature"
        elif line.strip() == "---" and in_cluster:
            output.append(f"### 🔍 Cluster `{current_cluster}`")
            output.append(f"**Response Type:** {response_quality}")
            if response_quality == "Premature":
                output.append("- 🟡 Premature conclusion. May require reevaluation.")
            elif response_quality == "Investigative":
                output.append("- 🔵 Strong follow-up. Searching for insight.")
            elif response_quality == "Reflective":
                output.append("- 🟢 Healthy self-awareness. Loop acknowledged.")
            else:
                output.append("- ⚪ Unclassified response pattern.")
            output.append("---")
            in_cluster = False

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Self-Evaluation Threads written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    evaluate_dialogues()
