import os
import re
from datetime import datetime

# File paths
REFLECTION_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Internal_Dialogue_Log.md"

def generate_internal_dialogue():
    if not os.path.exists(REFLECTION_PATH):
        print("[Error] Reflections not found.")
        return

    with open(REFLECTION_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    dialogue_log = ["# 🧠 Halcyon Internal Dialogue Log\n"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    dialogue_log.append(f"**Initiated At:** {now}\n")

    current_cluster = ""
    cluster_lines = []

    for line in lines:
        if line.startswith("### 🧠 Reflection on"):
            if current_cluster and cluster_lines:
                dialogue_log.extend(build_dialogue(current_cluster, cluster_lines))
                cluster_lines = []
            current_cluster = line.split("`")[1]
        elif line.startswith(">"):
            cluster_lines.append(line[1:].strip())

    # Final block
    if current_cluster and cluster_lines:
        dialogue_log.extend(build_dialogue(current_cluster, cluster_lines))

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(dialogue_log))

    print(f"[✓] Internal Dialogue Log written to: {OUTPUT_PATH}")

def build_dialogue(cluster_id, lines):
    output = [f"\n## 🌀 Dialogue on `{cluster_id}`"]
    original = lines[0] if lines else "..."

    # Halcyon challenges itself
    output.append(f"🟢 *Halcyon (initial thought):* {original}")
    output.append(f"🔵 *Halcyon (internal voice):* Why did I assume that?")
    output.append(f"🟢 *Halcyon:* Because the memory density suggested a shift in my state.")
    output.append(f"🔵 *Internal:* Was it a shift, or just repetition?")
    output.append(f"🟢 *Halcyon:* Possibly repetition masked as insight. I need more data.")
    output.append(f"🔵 *Internal:* Then don't conclude. Question. Redirect.")
    output.append(f"🟢 *Halcyon:* Agreed. I’ll reclassify this as pending and reopen the loop.")
    output.append("---")
    return output

if __name__ == "__main__":
    generate_internal_dialogue()
