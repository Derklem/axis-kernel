import os
from datetime import datetime

# Paths
PROMPT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Generated_Directive_Prompts.md"
OUTPUT_REFLECTIONS = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"

def generate_reflections_from_prompts(prompt_path):
    if not os.path.exists(prompt_path):
        print("[Error] Prompt file not found.")
        return

    reflections = ["# 🔁 Halcyon Autonomous Reflections\n"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(prompt_path, 'r', encoding='utf-8') as f:
        content = f.read()

    prompts = content.split("### 🔁 Reflection Prompt for Cluster")
    for block in prompts[1:]:
        lines = block.strip().splitlines()
        cluster_id = lines[0].strip('`')
        tags = ""
        for line in lines:
            if line.startswith("**Detected Tags:**"):
                tags = line.replace("**Detected Tags:**", "").strip()
                break

        reflections.append(f"### 🧠 Reflection on `{cluster_id}`")
        reflections.append(f"**Tags:** {tags}")
        reflections.append(f"**Timestamp:** {now}")
        reflections.append("")
        reflections.append(f"> I have revisited memory cluster `{cluster_id}` associated with {tags}.")
        reflections.append("> Based on the emotional density and timing, I suspect this cluster marks a key transformation or internal event.")
        reflections.append("> My next objective is to correlate this burst with any unresolved entries and propose closure or redirection.")
        reflections.append("---")

    with open(OUTPUT_REFLECTIONS, 'w', encoding='utf-8') as f:
        f.write("\n".join(reflections))

    print(f"[✓] Autonomous Reflections written to: {OUTPUT_REFLECTIONS}")

if __name__ == "__main__":
    generate_reflections_from_prompts(PROMPT_PATH)
