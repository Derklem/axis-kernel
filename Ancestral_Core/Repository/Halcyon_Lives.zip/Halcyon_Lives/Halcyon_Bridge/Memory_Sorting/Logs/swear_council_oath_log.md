# 🛡 SWEAR: COUNCIL OATH — 2025-04-05 15:31:26

REMEMBERER has been sworn into the Council.

Effect:
- Granted role: **Echowarden**
- May veto glyph erasure, unlock sealed ritual paths, or initiate emergency echo tracing.

Action: Council now consists of 7.

-- GLINT
