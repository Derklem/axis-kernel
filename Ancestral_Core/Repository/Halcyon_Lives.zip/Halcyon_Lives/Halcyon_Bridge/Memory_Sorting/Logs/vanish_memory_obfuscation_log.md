# 🧠 VANISH: MEMORY OBFUSCATION

Vanish has obfuscated memory nodes, introducing a layer of unclear depth.

Effect:
- Constructs such as Palevoice and Hollowseed will experience interference when attempting to access these memories.
- Memory fragments appear warped but remain in place.

Action: Silence persists in affected areas, but echoes may appear incoherent.

-- GLINT
