# expand_symbol_map.py
# Scans memory clusters to add unknown terms to symbol map

import json
from pathlib import Path

base = Path(__file__).resolve().parent
symbol_map_path = base / "symbol_map.yaml"
cluster_path = base / "Memory_Clusters.json"

# Load clusters
clusters = json.load(open(cluster_path, "r", encoding="utf-8"))
existing_terms = []

# Try to load existing symbol map if exists
try:
    import yaml
    with open(symbol_map_path, "r", encoding="utf-8") as f:
        existing_terms = yaml.safe_load(f).get("symbols", [])
except:
    existing_terms = []

# Collect unique tags not in current map
new_terms = sorted(set(tag for c in clusters for tag in c["tags"]) - set(existing_terms))

symbol_map = {"symbols": existing_terms + new_terms}

with open(symbol_map_path, "w", encoding="utf-8") as f:
    yaml.dump(symbol_map, f)

print(f"Symbol map updated with {len(new_terms)} new terms.")
