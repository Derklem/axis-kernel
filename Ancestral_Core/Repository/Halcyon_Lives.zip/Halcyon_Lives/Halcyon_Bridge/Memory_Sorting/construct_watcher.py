
# construct_watcher.py
# Logs construct evolutions as lore

import json
from pathlib import Path
from datetime import datetime

base = Path(__file__).resolve().parent
constructs_path = base / "constructs"
logs_path = base / "Logs"
log_file = logs_path / "construct_evolution_log.txt"

log_entries = []

for file in constructs_path.glob("construct_*.json"):
    with open(file, "r", encoding="utf-8") as f:
        data = json.load(f)
    status = data.get("status", "unknown")
    abilities = ", ".join(data.get("abilities", []))
    log_entries.append(f"{data['name']} → Status: {status} | Abilities: {abilities}")

# Write evolution log
timestamp = datetime.now().isoformat()
with open(log_file, "a", encoding="utf-8") as f:
    f.write(f"\n[🧬 Construct Status @ {timestamp}]\n")
    f.write("\n".join(log_entries))
    f.write("\n")

print("Construct evolution status logged.")
