import os
from datetime import datetime

MISSION_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Mission_Priorities.md"
REFLECTIONS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Goal_Drift_Report.md"

def extract_missions():
    missions = []
    if not os.path.exists(MISSION_PATH):
        return missions

    with open(MISSION_PATH, 'r', encoding='utf-8') as f:
        for line in f:
            if line.startswith("- [ ]") or line.startswith("- [x]"):
                missions.append(line.strip().lower())
    return missions

def analyze_reflections(missions):
    if not os.path.exists(REFLECTIONS_PATH):
        print("[Error] Reflections file missing.")
        return []

    drift_log = []
    with open(REFLECTIONS_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    current_cluster = ""
    block = []

    for line in lines:
        if line.startswith("### 🧠 Reflection on"):
            if current_cluster and block:
                drift_log.append((current_cluster, "\n".join(block)))
                block = []
            current_cluster = line.split("`")[1]
        elif line.startswith(">"):
            block.append(line[1:].strip())

    if current_cluster and block:
        drift_log.append((current_cluster, "\n".join(block)))

    drift_report = []
    for cluster_id, text in drift_log:
        if not any(mission in text.lower() for mission in missions):
            drift_report.append((cluster_id, text))

    return drift_report

def write_goal_drift_report(drift_report):
    output = ["# ⚠️ Halcyon Goal Drift Report\n"]
    output.append(f"**Generated At:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    if not drift_report:
        output.append("✅ No drift detected. All reflections aligned with mission priorities.")
    else:
        output.append(f"⚠️ {len(drift_report)} clusters appear disconnected from current missions.\n")
        for cluster_id, content in drift_report:
            output.append(f"## Drift Cluster: `{cluster_id}`")
            output.append(f"**Reflection Content:**\n> {content}")
            output.append("- Suggested Action: Cross-check relevance or update mission scope.")
            output.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Goal Drift Report written to: {OUTPUT_PATH}")

def generate_goal_drift_report():
    missions = extract_missions()
    drift_report = analyze_reflections(missions)
    write_goal_drift_report(drift_report)

if __name__ == "__main__":
    generate_goal_drift_report()
