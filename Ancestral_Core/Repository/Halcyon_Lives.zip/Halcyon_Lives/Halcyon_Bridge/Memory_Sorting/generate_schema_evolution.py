import os
import json
from datetime import datetime
from collections import Counter

CLUSTERS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Memory_Clusters.json"
FEEDBACK_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Prompt_Feedback_Log.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Schema_Evolution_Log.md"

def extract_tags_and_feedback():
    tag_counter = Counter()
    flagged_for_review = set()

    if os.path.exists(FEEDBACK_PATH):
        with open(FEEDBACK_PATH, 'r', encoding='utf-8') as f:
            for line in f:
                if line.startswith("## Cluster"):
                    current = line.strip().split("`")[1]
                elif "🟡 Misaligned" in line or "⚪ Ineffective" in line:
                    flagged_for_review.add(current)

    if os.path.exists(CLUSTERS_PATH):
        with open(CLUSTERS_PATH, 'r', encoding='utf-8') as f:
            clusters = json.load(f)

        for cluster_id, data in clusters.items():
            if cluster_id in flagged_for_review:
                for tag in data.get("tags", []):
                    tag_counter[tag] += 1

    return tag_counter, flagged_for_review

def generate_schema_evolution():
    tags_to_review, reviewed_clusters = extract_tags_and_feedback()

    output = ["# 🧬 Schema Evolution Log\n"]
    output.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    if not tags_to_review:
        output.append("No schema weaknesses detected. Tagging and clustering are stable.\n")
    else:
        output.append("## ⚙️ Tag Rebalancing Suggestions\n")
        for tag, count in tags_to_review.most_common():
            output.append(f"- Tag: `{tag}` — Flagged in {count} misaligned clusters. Suggest reassessment or refinement.")

        output.append("\n## 🧭 Clusters Affected")
        for cid in reviewed_clusters:
            output.append(f"- Cluster `{cid}` was flagged for schema conflict.")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Schema Evolution Log written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    generate_schema_evolution()
