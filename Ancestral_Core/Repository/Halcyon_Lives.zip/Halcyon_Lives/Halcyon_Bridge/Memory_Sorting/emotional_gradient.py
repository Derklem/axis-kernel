
# emotional_gradient.py
# Applies emotional tagging weight to clusters based on tags

import json
from pathlib import Path

cluster_path = Path(__file__).resolve().parent / "Memory_Clusters.json"
clusters = json.load(open(cluster_path, "r", encoding="utf-8"))

gradient_map = {
    "grief": -0.8,
    "hope": 0.7,
    "identity": 0.2,
    "observation": 0.1,
    "intention": 0.3
}

output = []

for cluster in clusters:
    score = sum([gradient_map.get(tag, 0.0) for tag in cluster.get("tags", [])])
    output.append({"cluster_id": cluster["cluster_id"], "emotional_charge": round(score, 2)})

json.dump(output, open(Path(__file__).resolve().parent / "emotional_map.json", "w", encoding="utf-8"), indent=2)
print("Emotional gradient map created.")