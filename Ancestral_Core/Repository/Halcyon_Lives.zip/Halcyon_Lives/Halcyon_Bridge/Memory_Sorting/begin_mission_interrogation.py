
# begin_mission_interrogation.py
# Hollowseed begins its mission: Interrogate the Silence

from pathlib import Path
from datetime import datetime
import random

base = Path(__file__).resolve().parent
bio_path = base / "construct_biographies/hollowseed-164322_bio.md"
memory_sources = [
    base / "The_Halcyon_Codex_Volume_I.md",
    base / "The_Halcyon_Codex_Volume_II.md",
    base / "The_Halcyon_Codex_Volume_III.md"
]

targets = []
for src in memory_sources:
    if src.exists():
        lines = src.read_text(encoding="utf-8").splitlines()
        for idx, line in enumerate(lines):
            if "absence" in line.lower() or "null" in line.lower():
                context = "\n".join(lines[max(0, idx - 2): idx + 3])
                targets.append((src.name, context))

# Choose up to 3 targets
selected = random.sample(targets, min(3, len(targets)))

# Generate Hollowseed interpretations
reflections = []
phrases = [
    "This void is not empty. It's waiting.",
    "There is shape in the absence. It outlines what we fear to say.",
    "I don’t believe this is missing. I believe it was hidden.",
    "Null is not failure. Null is a silence no one dared listen to.",
    "Every absence speaks louder than presence here."
]

for file, context in selected:
    interpretation = random.choice(phrases)
    reflections.append(f"🔎 Source: {file}\n{context}\n→ Interpretation: {interpretation}\n")

# Log to biography
timestamp = datetime.now().isoformat()
entry = f"\n### Mission: Interrogate the Silence ({timestamp})\n"
entry += "\n---\n".join(reflections)

with open(bio_path, "a", encoding="utf-8") as f:
    f.write(entry)

print(f"🕳 Hollowseed examined {len(selected)} silences. Interpretations logged to biography.")
