import os
import json
from datetime import datetime
from random import randint

CLUSTERS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Memory_Clusters.json"
PREEMPTIVE_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Preemptive_Reflections.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Recursive_Directives.md"

def load_preemptive_clusters():
    if not os.path.exists(PREEMPTIVE_PATH):
        return []
    with open(PREEMPTIVE_PATH, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    cluster_ids = []
    for line in lines:
        if "Cluster `" in line:
            cluster_id = line.split("`")[1]
            cluster_ids.append(cluster_id)
    return cluster_ids[:5]  # top 5 only

def generate_directives():
    if not os.path.exists(CLUSTERS_PATH):
        print("[Error] Clusters not found.")
        return

    with open(CLUSTERS_PATH, 'r', encoding='utf-8') as f:
        clusters = json.load(f)

    focus_ids = load_preemptive_clusters()

    output = ["# 🌀 Recursive Directive Layer\n"]
    output.append(f"**Issued:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    for i, cluster_id in enumerate(focus_ids):
        cluster = clusters.get(cluster_id, {})
        tags = ", ".join(cluster.get("tags", []))
        urgency = "⚠️ Medium" if i < 3 else "🧊 Low"
        deadline = f"+{randint(2, 6)} sessions"

        output.append(f"\n## 🔁 Directive `{cluster_id}`")
        output.append(f"**Tags:** {tags}")
        output.append(f"**Urgency:** {urgency}")
        output.append(f"**Deadline:** {deadline}")
        output.append(f"**Action:** Reinvestigate unresolved threads in `{cluster_id}` using current memory architecture. Prepare conclusions or hypotheses for synthesis.")
        output.append(f"**Chained?** Yes → Will trigger evaluation loop upon conclusion.")
        output.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Recursive Directives written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    generate_directives()
