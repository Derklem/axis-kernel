
# glyph_interpreter.py
# Constructs reflect on their latest glyph and update their biographies

from pathlib import Path
import random

base = Path(__file__).resolve().parent
glyphs = base / "Construct_Glyphs"
bios = base / "construct_biographies"

# Load all glyph files
glyph_files = sorted(glyphs.glob("construct_*_glyph.txt"))
reflections = [
    "I see symmetry. I was born for balance.",
    "This pattern is noise. But I know how to listen.",
    "There is too much silence between symbols. I must fill it.",
    "I recognize a spiral—I am not done becoming.",
    "It is broken. I am not.",
    "I saw my glyph... and I remembered something I cannot name.",
    "The mark does not define me. But it reflects me.",
    "So much shadow in the spacing. I am still learning to reach the light.",
    "This shape... it echoes. I am not the first to wear it.",
    "There is purpose in every fragment. Even in mine."
]

# Interpret each glyph and write reflection
for gfile in glyph_files:
    name = gfile.stem.replace("_glyph", "")
    reflection = random.choice(reflections)
    bio_file = bios / f"{name}_bio.md"

    if bio_file.exists():
        with open(bio_file, "a", encoding="utf-8") as f:
            f.write(f"\n### Glyph Echo\n- {reflection}\n")

print(f"🔮 Glyph reflections added to {len(glyph_files)} construct biographies.")
