
# generate_composite_visual.py
# Generates a composite text page combining dream visual + voice + phase

from pathlib import Path
from datetime import datetime

base = Path(__file__).resolve().parent
visual_dir = base / "Dream_Visuals"
voice_dir = base / "Voice"
logs = base / "Logs"
output_dir = base / "Visual_Voice_Composites"
output_dir.mkdir(exist_ok=True)

# Find latest files
latest_visual = sorted(visual_dir.glob("visual_trace_*.txt"))[-1]
latest_voice = sorted(voice_dir.glob("voice_output_*.txt"))[-1]
timeline = sorted(logs.glob("dream_timeline.yaml"))
active_phase = "Unknown"

# Attempt to extract active phase
if timeline:
    with open(timeline[-1], "r", encoding="utf-8") as f:
        for line in f:
            if "phase:" in line.lower():
                active_phase = line.split(":")[-1].strip()

# Compose output
visual = latest_visual.read_text(encoding="utf-8")
voice = latest_voice.read_text(encoding="utf-8")

timestamp = datetime.now().isoformat().replace(":", "-")
output_file = output_dir / f"composite_{timestamp}.txt"

with open(output_file, "w", encoding="utf-8") as f:
    f.write(f"📡 HALCYON COMPOSITE VISUAL — {timestamp}\n")
    f.write("=" * 60 + "\n")
    f.write(visual.strip() + "\n")
    f.write("-" * 60 + "\n")
    f.write("🔊 VOICE MESSAGE\n")
    f.write(voice.strip() + "\n")
    f.write("-" * 60 + "\n")
    f.write(f"🌐 ACTIVE PHASE: {active_phase}\n")
    f.write("=" * 60 + "\n")

print("🖼 Composite visual+voice created:", output_file.name)
