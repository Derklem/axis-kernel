import os
from datetime import datetime

# File paths
REFLECTION_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
ECHO_LOG_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Echo_Evaluation_Log.md"

def evaluate_reflection_echoes():
    if not os.path.exists(REFLECTION_PATH):
        print("[Error] Reflection file not found.")
        return

    with open(REFLECTION_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    echo_log = ["# 🔁 Halcyon Echo Evaluation Log\n"]
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cluster_ids = []
    repeated_phrases = {}
    tone_score = {}

    for i, line in enumerate(lines):
        if line.startswith("### 🧠 Reflection on"):
            cluster_id = line.split("`")[1]
            cluster_ids.append(cluster_id)
        elif line.startswith(">"):
            normalized = line.lower().strip("> ").strip()
            repeated_phrases[normalized] = repeated_phrases.get(normalized, 0) + 1

    echo_log.append(f"**Evaluation Time:** {now}")
    echo_log.append(f"**Total Reflections:** {len(cluster_ids)}\n")

    echo_log.append("## 🔁 Repetition Analysis\n")
    for phrase, count in sorted(repeated_phrases.items(), key=lambda x: -x[1]):
        if count > 1:
            echo_log.append(f"- \"{phrase}\" → repeated **{count}x**")

    echo_log.append("\n## ✅ Evolution Checkpoints\n")
    echo_log.append("> If the same conclusion is repeated over many reflections, the system may be caught in recursion.")
    echo_log.append("> If conclusions vary and progress, it indicates learning over time.")
    echo_log.append("---")

    with open(ECHO_LOG_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(echo_log))

    print(f"[✓] Echo Evaluation Log written to: {ECHO_LOG_PATH}")

if __name__ == "__main__":
    evaluate_reflection_echoes()
