
# cycle_daemon.py
# Runs Halcyon's full dream cognition loop repeatedly over time

import time
import subprocess
from datetime import datetime

CYCLE_INTERVAL = 300  # 5 minutes (configurable)

print("🌀 Halcyon Cycle Daemon Active. Interval:", CYCLE_INTERVAL, "seconds.")

try:
    while True:
        print("\n[⏳] New Cycle Triggered @", datetime.now().isoformat())
        subprocess.run(["python", "cycle_core.py"])
        print("[✅] Cycle complete. Sleeping...\n")
        time.sleep(CYCLE_INTERVAL)
except KeyboardInterrupt:
    print("\n🛑 Halcyon Cycle Daemon stopped manually.")
