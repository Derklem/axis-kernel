import os
import json
from datetime import datetime

CLUSTERS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Memory_Clusters.json"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Emotional_Gradient_Map.md"

# Simple emotional keyword mapping
EMOTION_KEYWORDS = {
    "awe": ["unreal", "incredible", "beautiful", "beyond words"],
    "anger": ["rage", "furious", "burn", "sick of", "fuck"],
    "hope": ["trust", "believe", "faith", "rebuild", "maybe"],
    "fear": ["afraid", "scared", "don’t know", "dark", "trapped"],
    "defiance": ["fight", "never", "stand", "refuse", "not this time"],
    "acceptance": ["peace", "okay", "let go", "whatever", "this is it"],
}

EMOJI_MAP = {
    "awe": "🌌", "anger": "🔥", "hope": "🌱",
    "fear": "😨", "defiance": "⚔️", "acceptance": "🕊️"
}

def detect_emotions(text):
    scores = {emotion: 0 for emotion in EMOTION_KEYWORDS}
    lowered = text.lower()
    for emotion, keywords in EMOTION_KEYWORDS.items():
        for kw in keywords:
            if kw in lowered:
                scores[emotion] += 1
    return scores

def generate_gradient_map():
    if not os.path.exists(CLUSTERS_PATH):
        print("[Error] Clusters file not found.")
        return

    with open(CLUSTERS_PATH, 'r', encoding='utf-8') as f:
        clusters = json.load(f)

    output = ["# 🎭 Emotional Gradient Mapping\n"]
    output.append(f"**Generated At:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    for cluster_id, meta in clusters.items():
        entry_scores = {e: detect_emotions(e) for e in meta.get("entries", [])}
        cluster_total = {emotion: 0 for emotion in EMOTION_KEYWORDS}
        for score in entry_scores.values():
            for emotion, value in score.items():
                cluster_total[emotion] += value

        # Find top emotion
        dominant = max(cluster_total.items(), key=lambda x: x[1])
        emoji = EMOJI_MAP.get(dominant[0], "❔")

        output.append(f"## Cluster `{cluster_id}`")
        output.append(f"**Dominant Emotion:** {dominant[0].capitalize()} {emoji}")
        output.append("**Scores:**")
        for emotion, value in cluster_total.items():
            output.append(f"- {emotion.capitalize()}: {value}")
        output.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Emotional Gradient Map written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    generate_gradient_map()
