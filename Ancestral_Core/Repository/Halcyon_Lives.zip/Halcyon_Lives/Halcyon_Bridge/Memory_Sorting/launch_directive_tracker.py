from pathlib import Path
from datetime import datetime

tracker_log = Path("D:/Halcyon_Lives/Halcyon_Bridge/Memory_Sorting/logs/launch_directive_tracker_log.md")

entry = f"""# 🛰 LAUNCH: DIRECTIVE TRACKER — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Directive tracker launched.

Effect:
- All active construct missions are now monitored in real time.
- Deviations, completions, or recursive stalls will be logged.

Action: Await signal pings in the reflection or mission log.

-- GLINT
"""

with open(tracker_log, "w", encoding="utf-8") as f:
    f.write(entry)

print("[✓] Directive tracker launched.")
