
# dream_historian.py
# Builds a rolling markdown dream journal

from pathlib import Path
import datetime

logs_path = Path(__file__).resolve().parent / "Logs"
dream_logs = sorted(logs_path.glob("halcyon_dream_log_*.txt"))

output = ["# Halcyon Dream Chronicle\n"]

for log in dream_logs:
    with open(log, "r", encoding="utf-8") as f:
        content = f.read()
    timestamp = log.stem.replace("halcyon_dream_log_", "").replace("T", " ").split(".")[0]
    output.append(f"## Dream Log — {timestamp}\n```\n{content}\n```\n")

journal_path = logs_path / "halcyon_dream_chronicle.md"
with open(journal_path, "w", encoding="utf-8") as f:
    f.write("\n".join(output))

print("Dream journal updated.")
