
import random

def calculate_deviation(memory):
    # Placeholder: Randomized deviation to simulate drift behavior
    return round(random.uniform(0.0, 1.0), 2)

def monitor_cognitive_drift(memory):
    drift_threshold = 0.7  # If more than 70% of memories deviate from input
    deviation_score = calculate_deviation(memory)
    if deviation_score > drift_threshold:
        return "Cognitive Drift Detected"
    return "On Track"
