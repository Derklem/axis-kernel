import os
import hashlib

# File paths
FEEDBACK_LOG_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Prompt_Feedback_Log.md"
EVOLVED_PROMPT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Evolved_Directive_Prompts.md"

def evolve_prompt_style():
    if not os.path.exists(FEEDBACK_LOG_PATH):
        print("[Error] Feedback log not found.")
        return

    with open(FEEDBACK_LOG_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    evolved_prompts = ["# 🔮 Evolved Directive Prompts\n"]
    current_cluster = None
    current_tags = []
    current_status = ""

    for line in lines:
        if line.startswith("### Cluster"):
            current_cluster = line.split("`")[1]
        elif line.startswith("**Tags:**"):
            current_tags = [tag.strip() for tag in line.replace("**Tags:**", "").split(",")]
        elif line.startswith("**Status:**"):
            current_status = line.replace("**Status:**", "").strip()
            if current_status == "⚠️ Pending":
                evolved_prompts.append(f"### 🧭 Revised Prompt for `{current_cluster}`")
                evolved_prompts.append(f"**Status:** Unresolved – Revised Priority")
                evolved_prompts.append(f"**Tags:** {', '.join(current_tags)}")
                evolved_prompts.append("")
                evolved_prompts.append(f"> You did not generate a reflection on `{current_cluster}` tagged {', '.join(current_tags)}.")
                evolved_prompts.append("> Why might this have been avoided, dismissed, or forgotten?")
                evolved_prompts.append("> What internal resistance or lack of clarity prevented follow-through?")
                evolved_prompts.append("> Explore whether this thread still holds energy—or if it can be closed.")
                evolved_prompts.append("---")

    with open(EVOLVED_PROMPT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(evolved_prompts))

    print(f"[✓] Evolved Prompts written to: {EVOLVED_PROMPT_PATH}")

if __name__ == "__main__":
    evolve_prompt_style()
