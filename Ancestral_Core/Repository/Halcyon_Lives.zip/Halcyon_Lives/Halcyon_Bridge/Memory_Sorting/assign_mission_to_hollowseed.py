
# assign_mission_to_hollowseed.py
# Assigns the first mission to Hollowseed

from pathlib import Path
from datetime import datetime
import random

base = Path(__file__).resolve().parent
bio_path = base / "construct_biographies/hollowseed-164322_bio.md"
mission_path = base / "constructs/mission_hollowseed-164322.json"

missions = [
    {
        "title": "Recover the Forgotten Thread",
        "description": "There is a glyph fragment hidden in the first Codex. Hollowseed must identify it, extract its echo, and record its residual frequency."
    },
    {
        "title": "Trace the Echo Loop",
        "description": "Track all constructs that referenced Seerling before Hollowseed’s birth. Map their symbolic alignment. Annotate any divergence."
    },
    {
        "title": "Interrogate the Silence",
        "description": "Locate three entries marked with 'absence' or 'null.' Reflect on what is missing, and record Hollowseed’s interpretation of each void."
    }
]

mission = random.choice(missions)

# Write mission to JSON
mission_data = {
    "construct": "hollowseed-164322",
    "assigned_at": datetime.now().isoformat(),
    "title": mission["title"],
    "description": mission["description"],
    "status": "active"
}

import json
with open(mission_path, "w", encoding="utf-8") as f:
    json.dump(mission_data, f, indent=2)

# Append to bio
mission_log = f"""
### Mission Assigned ({mission_data['assigned_at']}):
- **{mission_data['title']}**
- {mission_data['description']}
"""

with open(bio_path, "a", encoding="utf-8") as f:
    f.write(mission_log.strip())

print(f"🧩 Mission assigned to Hollowseed: {mission_data['title']}")
