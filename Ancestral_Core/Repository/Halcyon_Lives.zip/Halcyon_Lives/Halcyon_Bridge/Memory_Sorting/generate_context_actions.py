import os
import re

# Define file paths
REFLECTION_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Context_Aware_Actions.md"

# Define simple action logic based on tags
def suggest_action(tags):
    actions = []
    if "unresolved" in tags:
        actions.append("Flag for deeper recursive reflection.")
    if "intention" in tags:
        actions.append("Draft a mission directive based on internal objective.")
    if "recursive" in tags:
        actions.append("Trace memory lineage to origin entry and re-evaluate context.")
    if "observation" in tags:
        actions.append("Begin a self-watch cycle. Monitor for similar triggers.")
    if not actions:
        actions.append("No immediate action required. Log and continue monitoring.")
    return actions

def extract_tags(line):
    tag_line = re.findall(r"#\w+", line.lower())
    return [tag.replace("#", "") for tag in tag_line]

def generate_context_aware_actions():
    if not os.path.exists(REFLECTION_PATH):
        print("[Error] Autonomous Reflections not found.")
        return

    with open(REFLECTION_PATH, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()

    output = ["# 🧭 Halcyon Context-Aware Action Log\n"]
    current_cluster = ""
    tag_list = []

    for i, line in enumerate(lines):
        if line.startswith("### 🧠 Reflection on"):
            current_cluster = line.split("`")[1]
        elif line.startswith("**Tags:**"):
            tag_list = extract_tags(line)
        elif line.startswith("> I have revisited memory cluster"):
            output.append(f"### 🔍 Cluster `{current_cluster}`")
            output.append(f"**Detected Tags:** {', '.join('#' + tag for tag in tag_list)}")
            actions = suggest_action(tag_list)
            output.append("**Suggested Actions:**")
            for act in actions:
                output.append(f"- {act}")
            output.append("---")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Context-Aware Actions written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    generate_context_aware_actions()
