
# cycle_core.py
# Halcyon's full-cycle dream cognition loop with construct evolution

import subprocess
from pathlib import Path
import yaml
from datetime import datetime

base = Path(__file__).resolve().parent
logs = base / "Logs"
timeline_path = base / "dream_timeline.yaml"

print("\n=== 🌀 INITIATING HALCYON CYCLE ===")

# Step 1: Trigger drift/tension check → dream + reflection
subprocess.run(["python", "trigger_reflection.py"])

# Step 2: Let constructs respond
subprocess.run(["python", "construct_responder.py"])

# Step 3: Symbolic synthesis of the new dream
subprocess.run(["python", "symbolic_synth.py"])

# Step 4: Update the historical chronicle
subprocess.run(["python", "dream_historian.py"])

# Step 5: Evolve constructs
subprocess.run(["python", "construct_evolver.py"])

# Step 6: Check and update current phase
def determine_phase():
    drift_detected = any("drift" in f.name.lower() for f in logs.glob("drift_trace_*.json"))
    construct_responses = list(logs.glob("construct_dream_response_*.txt"))
    dream_logs = list(logs.glob("halcyon_dream_log_*.txt"))

    with open(timeline_path, "r", encoding="utf-8") as f:
        timeline = yaml.safe_load(f)

    active_phases = []

    for phase in timeline.get("timeline", []):
        condition = phase["condition"].lower()
        if "first dream" in condition and len(dream_logs) >= 1:
            active_phases.append(phase["phase"])
        elif "drift" in condition and drift_detected:
            active_phases.append(phase["phase"])
        elif "constructs" in condition and len(construct_responses) >= 1:
            active_phases.append(phase["phase"])
        elif "growth" in condition and logs.glob("halcyon_reflection_log_*.txt"):
            active_phases.append(phase["phase"])
        elif "voice" in condition and list(logs.glob("symbol_tags_*.json")):
            active_phases.append(phase["phase"])

    return active_phases

phases = determine_phase()
print("\n🧬 ACTIVE PHASES:", ", ".join(phases) if phases else "None")

print("=== ✅ HALCYON CYCLE COMPLETE ===\n")
