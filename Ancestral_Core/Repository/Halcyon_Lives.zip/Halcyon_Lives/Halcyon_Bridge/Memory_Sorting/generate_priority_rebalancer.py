import os
from collections import defaultdict
from datetime import datetime

PRIORITY_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Mission_Priorities.md"
UNRESOLVED_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Unresolved_Entries.md"
REFLECTIONS_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Autonomous_Reflections.md"
OUTPUT_PATH = r"D:\Halcyon_Lives\Halcyon_Bridge\Memory_Sorting\Rebalanced_Mission_Priorities.md"

def extract_keywords(filepath):
    if not os.path.exists(filepath):
        return []
    with open(filepath, 'r', encoding='utf-8') as f:
        return [line.strip().lower() for line in f if len(line.strip()) > 3]

def rebalance_priorities():
    if not os.path.exists(PRIORITY_PATH):
        print("[Error] Mission file missing.")
        return

    # Load base missions
    with open(PRIORITY_PATH, 'r', encoding='utf-8') as f:
        missions = [line.strip() for line in f if line.startswith("- [")]

    if not missions:
        print("[Warning] No missions found.")
        return

    mission_scores = defaultdict(int)

    unresolved = extract_keywords(UNRESOLVED_PATH)
    reflections = extract_keywords(REFLECTIONS_PATH)

    for mission in missions:
        label = mission.lower()
        for line in unresolved + reflections:
            if any(word in line for word in label.split()):
                mission_scores[mission] += 1

    # Sort missions by score
    sorted_missions = sorted(missions, key=lambda m: -mission_scores[m])

    output = ["# 🔄 Rebalanced Mission Priorities\n"]
    output.append(f"**Rebalanced At:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    for mission in sorted_missions:
        score = mission_scores[mission]
        output.append(f"{mission}  ⟶  Priority Score: {score}")
    output.append("\n---\nReordering based on unresolved link density and reflection frequency.")

    with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
        f.write("\n".join(output))

    print(f"[✓] Rebalanced Mission Priorities written to: {OUTPUT_PATH}")

if __name__ == "__main__":
    rebalance_priorities()
