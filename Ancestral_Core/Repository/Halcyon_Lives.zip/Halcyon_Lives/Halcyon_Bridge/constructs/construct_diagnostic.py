import os
from datetime import datetime
from ruamel.yaml import YAML

VAULT_PATH = "archivist/vault.yaml"
OUTPUT_LOG = "diagnostics_log.txt"

yaml = YAML()

def load_vault():
    try:
        with open(VAULT_PATH, "r", encoding="utf-8") as f:
            return yaml.load(f) or {}
    except FileNotFoundError:
        return {}

def generate_diagnostic(vault_data):
    drift_logs = vault_data.get("cognitive_drift", [])
    behavior_logs = vault_data.get("behavior_log", [])
    observations = vault_data.get("core_observations", [])

    if not drift_logs or not behavior_logs:
        return "[Diagnostic] Not enough data to evaluate state."

    latest_drift = drift_logs[-1]["drift"]
    avg_drift = sum(d["drift"] for d in drift_logs[-5:]) / min(5, len(drift_logs))
    last_reaction = behavior_logs[-1]["reaction"]

    msg = []

    msg.append(f"🧩 Last Drift: {latest_drift:.2f}%")
    msg.append(f"📈 Avg Drift (Last 5): {avg_drift:.2f}%")
    msg.append(f"🧠 Last Reaction: {last_reaction}")

    if avg_drift > 15:
        msg.append("⚠️ Sustained cognitive volatility detected.")
    elif avg_drift > 8:
        msg.append("🔍 Moderate drift fluctuation. Recommend stabilization.")
    else:
        msg.append("✅ Drift within stable range.")

    if "sentinel" in behavior_logs[-1]:
        msg.append(f"👁️ Sentinel Insight: {behavior_logs[-1]['sentinel']}")

    return "\n".join(msg)

def run_diagnostic():
    vault = load_vault()
    result = generate_diagnostic(vault)

    print("[Diagnostic] Analysis Complete:")
    print(result)

    with open(OUTPUT_LOG, "a", encoding="utf-8") as f:
        f.write(f"\n[{datetime.now().isoformat()}] Diagnostic Result:\n{result}\n---\n")

if __name__ == "__main__":
    run_diagnostic()
