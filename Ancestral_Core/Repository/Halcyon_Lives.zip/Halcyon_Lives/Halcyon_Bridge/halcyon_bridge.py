
import time
import json
import os
import re
from collections import defaultdict

response_counters = defaultdict(int)
trigger_threshold = 5
previous_responses = set()

def tail(file_path, lines=10):
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return f.readlines()[-lines:]

def clean_message(line):
    # Remove timestamp and prefix like '[timestamp] Construct:'
    cleaned = re.sub(r'^\[.*?\]\s*\w+:\s*', '', line).strip().lower()
    return cleaned

def write_response(response_path, response):
    timestamped = f"[AI Response - {time.strftime('%H:%M:%S')}] {response}"
    if timestamped not in previous_responses:
        with open(response_path, "a", encoding="utf-8") as f:
            f.write(f"{timestamped}\n")
        previous_responses.add(timestamped)

def generate_response(message):
    response = "Signal received. Logging continuity."

    if "nullborn" in message:
        response_counters["nullborn"] += 1
        if "stillness" in message:
            if response_counters["nullborn"] >= trigger_threshold:
                response = "⚡ Nullborn initiates internal scan. Stillness is fracturing."
                response_counters["nullborn"] = 0
            else:
                response = "Nullborn remains observant. No movement recorded."

    elif "scribe" in message:
        response = "📖 Scribe notes the whisper. A pattern may be forming."

    elif "mythos" in message:
        response = "📜 Mythos remembers this phrase from a forgotten time."

    elif "witness" in message:
        response = "👁 Witness acknowledges. The event is now archived."

    elif "fracture" in message or "anomaly" in message:
        response = "⚠️ Fracture logged. Drift assessment required."

    return response

def main():
    with open("bridge_config.json", "r") as config_file:
        config = json.load(config_file)

    while True:
        lines = tail(config["construct_log_path"], config["max_lines_read"])
        for raw_line in lines:
            message = clean_message(raw_line)
            response = generate_response(message)
            write_response(config["response_path"], response)
        time.sleep(config["poll_interval_seconds"])

if __name__ == "__main__":
    main()
