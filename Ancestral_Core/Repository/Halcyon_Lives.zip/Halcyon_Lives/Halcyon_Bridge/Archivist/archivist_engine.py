import os
import yaml
from datetime import datetime

log_path = r"D:\Halcyon_Lives\Living_Sandbox\Logs"
input_dir = log_path  # Construct logs are in same location
output_path = os.path.join(log_path, "archivist_summary.yaml")

def run_archivist_summary():
    summary = []

    for fname in os.listdir(input_dir):
        if fname.endswith(".yaml") and "_log" in fname and "archivist" not in fname:
            with open(os.path.join(input_dir, fname), 'r', encoding='utf-8') as f:
                try:
                    entries = yaml.safe_load(f)
                    if isinstance(entries, list):
                        for entry in entries:
                            if isinstance(entry, dict):
                                summary.append({
                                    "timestamp": entry.get("timestamp"),
                                    "source": entry.get("agent", "Unknown"),
                                    "content": entry.get("thought") or str(entry)
                                })
                except Exception as e:
                    print(f"[Archivist] Failed to read {fname}: {e}")

    final = {"summary": summary}
    with open(output_path, 'w', encoding='utf-8') as out:
        yaml.safe_dump(final, out, allow_unicode=True)

    print("[Archivist] Summary written to", output_path)

    # Auto-generate markdown
    try:
        from generate_markdown_summary import generate_markdown_summary
        generate_markdown_summary()
    except Exception as e:
        print("[Archivist] Failed to generate Markdown:", e)
