import yaml
import os

summary_path = r"D:\Halcyon_Lives\Living_Sandbox\Logs\archivist_summary.yaml"
output_path = r"D:\Halcyon_Lives\Living_Sandbox\Logs\archivist_summary.md"

def generate_markdown():
    if not os.path.exists(summary_path):
        print("[Markdown] Summary YAML not found.")
        return

    with open(summary_path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)

    summary_entries = data.get("summary", [])
    if not summary_entries:
        print("[Markdown] No summary entries found.")
        return

    lines = ["# 📜 Halcyon Construct Summary\n"]

    for entry in summary_entries:
        lines.append(f"## 🧠 {entry.get('source', 'Unknown')}")
        lines.append(f"**Timestamp:** {entry.get('timestamp', 'N/A')}")
        lines.append(f"**Reflection:** {entry.get('content', 'No content available.')}")
        lines.append("---")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    print(f"[Markdown] Summary written to {output_path}")

if __name__ == "__main__":
    generate_markdown()
