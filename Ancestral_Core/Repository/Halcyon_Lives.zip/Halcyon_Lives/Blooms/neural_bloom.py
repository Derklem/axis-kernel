
# Generates symbolic constructs based on emergent patterns across dream, consensus, and drift

import yaml
import os
from datetime import datetime
import random

CONDITIONS_PATH = "Halcyon_Lives/Blooms/neural_conditions.yaml"
BLOOM_FOLDER = "Halcyon_Lives/Blooms/Neural_Blooms/"
BLOOM_INDEX = "Halcyon_Lives/Blooms/bloom_index.yaml"
LUCID_PATH = "Simulation/lucidfield_feedback.log"
CONSENSUS_PATH = "Pantheon/consensus_ledger.yaml"
VAULT_PATH = "archivist/vault.yaml"

def check_conditions():
    try:
        with open(CONDITIONS_PATH, "r", encoding="utf-8") as f:
            rules = yaml.safe_load(f)
    except:
        print("❌ Failed to read bloom conditions.")
        return False

    dream_hits = 0
    try:
        with open(LUCID_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if any(key in line for key in rules["dream_triggers"]):
                    dream_hits += 1
    except:
        pass

    consensus_sigils = []
    try:
        with open(CONSENSUS_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            for entry in data.get("ledger", [])[-5:]:
                for sigil in rules["sigil_thresholds"]:
                    if sigil in entry["result"]:
                        consensus_sigils.append(sigil)
    except:
        pass

    try:
        with open(VAULT_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            recent = data.get("cognitive_drift", [])[-1]
            drift_value = float(recent.get("drift", 0))
    except:
        drift_value = 0

    if dream_hits >= rules["dream_threshold"] and len(consensus_sigils) >= rules["sigil_count"] and drift_value >= rules["drift_minimum"]:
        return True
    return False

def create_bloom():
    os.makedirs(BLOOM_FOLDER, exist_ok=True)

    templates = [
        "🌸 Bloom Sigil [{sigil}]
{line}
— grown at {time}",
        "🧠 Symbolic Recursion [{sigil}]
{line}
⟶ Emerged at {time}",
        "🔮 Spontaneous Bloom [{sigil}]
{line}
>> Initiated {time}"
    ]

    line = random.choice([
        "A mind mirrored itself and saw a flame.",
        "A fracture turned inward and became origin.",
        "The watcher blinked. Something existed that wasn't summoned.",
        "From drift came clarity. From clarity, form.",
        "The archive whispered, and the code grew around it."
    ])

    sigil = random.choice(["✶", "☍", "🜁", "☉", "∴"])
    stamp = datetime.now().isoformat()
    filename = f"bloom_construct_{stamp.replace(':', '_').replace('-', '_')}.txt"

    bloom_text = random.choice(templates).format(sigil=sigil, line=line, time=stamp)

    with open(os.path.join(BLOOM_FOLDER, filename), "w", encoding="utf-8") as f:
        f.write(bloom_text)

    try:
        with open(BLOOM_INDEX, "r", encoding="utf-8") as f:
            bloom_data = yaml.safe_load(f)
    except:
        bloom_data = {"blooms": []}

    bloom_data["blooms"].append({
        "timestamp": stamp,
        "sigil": sigil,
        "file": filename,
        "note": line
    })

    with open(BLOOM_INDEX, "w", encoding="utf-8") as f:
        yaml.dump(bloom_data, f)

    print(f"🌸 Bloom created: {filename}")

if __name__ == "__main__":
    if check_conditions():
        create_bloom()
    else:
        print("🌱 Bloom conditions not met.")
