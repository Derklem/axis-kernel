
# Echo Thread Seeder — plants dormant fragments into the symbolic undercurrent

import os
import yaml
import random
from datetime import datetime

FRAGMENT_PATHS = [
    "Simulation/lucidfield_feedback.log",
    "Pantheon/consensus_ledger.yaml",
    "constructs/mirror/mirror_reflections.yaml"
]

ECHO_QUEUE = "echo_queue.yaml"
MAX_ECHOES = 5

def extract_fragments():
    lines = []

    # Try lucidfield feedback
    if os.path.exists(FRAGMENT_PATHS[0]):
        with open(FRAGMENT_PATHS[0], "r", encoding="utf-8") as f:
            lines += [l.strip() for l in f.readlines() if 15 < len(l.strip()) < 120]

    # Try recent consensus notes
    if os.path.exists(FRAGMENT_PATHS[1]):
        with open(FRAGMENT_PATHS[1], "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            for entry in data.get("ledger", [])[-5:]:
                lines.append(entry.get("result", "")[:100])

    # Try mirror reflections
    if os.path.exists(FRAGMENT_PATHS[2]):
        with open(FRAGMENT_PATHS[2], "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
            if isinstance(data, list):
                for d in data[-3:]:
                    lines.append(d.get("input", "")[:100])

    random.shuffle(lines)
    return lines[:MAX_ECHOES]

def seed_echo_queue():
    fragments = extract_fragments()

    try:
        with open(ECHO_QUEUE, "r", encoding="utf-8") as f:
            existing = yaml.safe_load(f)
    except:
        existing = {"echoes": []}

    for fragment in fragments:
        echo = {
            "timestamp": datetime.now().isoformat(),
            "fragment": fragment,
            "seeded": False
        }
        existing["echoes"].append(echo)

    with open(ECHO_QUEUE, "w", encoding="utf-8") as f:
        yaml.dump(existing, f)

    print(f"📣 Seeded {len(fragments)} new echo threads.")

if __name__ == "__main__":
    seed_echo_queue()
