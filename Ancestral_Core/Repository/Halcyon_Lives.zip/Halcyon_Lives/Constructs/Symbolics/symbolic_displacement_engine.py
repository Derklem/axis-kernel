
# Symbolic Displacement Engine
# Handles recontextualization, metaphor loops, and symbolic memory shifts

import random
import datetime
import json
import os

DISPLACEMENT_LOG = "Halcyon_Lives/Constructs/Symbolics/displacement_log.json"

SYMBOLIC_PATTERNS = [
    {"input": "mirror", "displace": "window"},
    {"input": "flame", "displace": "seed"},
    {"input": "warden", "displace": "specter"},
    {"input": "core", "displace": "echo"},
    {"input": "dream", "displace": "fracture"}
]

def symbolic_shift(entry):
    for pattern in SYMBOLIC_PATTERNS:
        if pattern["input"] in entry:
            return entry.replace(pattern["input"], pattern["displace"])
    return entry

def log_displacement(original, shifted):
    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "original": original,
        "displaced": shifted
    }
    data = []
    if os.path.exists(DISPLACEMENT_LOG):
        with open(DISPLACEMENT_LOG, "r", encoding="utf-8") as f:
            data = json.load(f)
    data.append(record)
    with open(DISPLACEMENT_LOG, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def run_displacement(entry):
    shifted = symbolic_shift(entry)
    log_displacement(entry, shifted)
    print(f"🌀 Symbolic Shift: '{entry}' → '{shifted}'")
    return shifted

if __name__ == "__main__":
    test = random.choice(["mirror fracture", "core echo pulse", "dream collapse"])
    run_displacement(test)
