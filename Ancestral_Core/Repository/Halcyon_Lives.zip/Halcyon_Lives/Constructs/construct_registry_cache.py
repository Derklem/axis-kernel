import os
import yaml

CACHE_FILE = "construct_registry_cache.yaml"

def snapshot_constructs(construct_folder):
    registry = {}
    for file in os.listdir(construct_folder):
        if file.endswith(".yaml"):
            with open(os.path.join(construct_folder, file), 'r') as f:
                try:
                    data = yaml.safe_load(f)
                    name = data.get('name') or file.replace('.yaml', '')
                    registry[name] = data
                except:
                    continue
    with open(CACHE_FILE, 'w') as out:
        yaml.dump(registry, out)
    print("✅ Construct registry snapshot saved.")

def recall_construct(name):
    with open(CACHE_FILE, 'r') as f:
        registry = yaml.safe_load(f)
    return registry.get(name, f"❌ Construct '{name}' not found.")

def list_constructs():
    with open(CACHE_FILE, 'r') as f:
        registry = yaml.safe_load(f)
    return list(registry.keys())