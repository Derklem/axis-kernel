
# Vault Guardian Trigger
# Locks and protects files from edits after symbolic threshold is reached

import os
import datetime
import json

VAULT_LOG = "Halcyon_Lives/Constructs/Threads/vault_guardian_log.json"
GUARD_THRESHOLD = 8

def activate_guardian():
    files_to_lock = [
        "archivist/vault.yaml",
        "pantheon_mission_seeds.yaml"
    ]

    locked = []
    for file in files_to_lock:
        if os.path.exists(file):
            os.chmod(file, 0o444)  # read-only
            locked.append(file)

    log_entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "locked_files": locked,
        "threshold_trigger": GUARD_THRESHOLD
    }

    with open(VAULT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(log_entry) + "\n")
    print(f"🛡️ Vault Guardian activated. Files locked: {len(locked)}")

if __name__ == "__main__":
    activate_guardian()
