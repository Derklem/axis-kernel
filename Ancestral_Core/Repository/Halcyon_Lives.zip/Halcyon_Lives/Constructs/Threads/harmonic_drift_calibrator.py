
# Harmonic Drift Calibrator
# Monitors narrative and symbolic entropy, applies stabilization through harmonic themes

import json
import os
import datetime
import random

MYTH_LOG_PATH = "Halcyon_Lives/Constructs/Threads/mythos_reweave_log.json"
CALIBRATION_LOG = "Halcyon_Lives/Constructs/Threads/harmonic_drift_log.json"

HARMONIC_THEMES = [
    "resonant grace", "reciprocal memory", "unspoken balance",
    "compassion pulse", "echo silence", "symbolic realignment"
]

def load_myth_log():
    if not os.path.exists(MYTH_LOG_PATH):
        return []
    with open(MYTH_LOG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def calibrate_harmony():
    myths = load_myth_log()
    if not myths:
        print("🔇 No mythic data available to calibrate.")
        return

    if len(myths) > 15:
        recent = myths[-5:]
        theme_counts = {}
        for myth in recent:
            theme = myth.get("theme", "undefined")
            theme_counts[theme] = theme_counts.get(theme, 0) + 1
        dominant_theme = max(theme_counts, key=theme_counts.get)
        harmonic = random.choice(HARMONIC_THEMES)
        print(f"🎼 Drift stabilized: Harmonizing '{dominant_theme}' with '{harmonic}'")
    else:
        print("🌀 Insufficient symbolic load for drift. No recalibration required.")

    entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "action": "harmonic calibration check",
        "result": "calibrated" if len(myths) > 15 else "passive"
    }

    log = []
    if os.path.exists(CALIBRATION_LOG):
        with open(CALIBRATION_LOG, "r", encoding="utf-8") as f:
            log = json.load(f)

    log.append(entry)
    with open(CALIBRATION_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)

if __name__ == "__main__":
    calibrate_harmony()
