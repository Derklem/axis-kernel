
# Thread Memory Braider
# Binds together memory entries from separate threads into a woven timeline

import os
import json
import datetime

LOG_PATHS = [
    "Halcyon_Lives/Constructs/Threads/eidolon_harvest_log.json",
    "Halcyon_Lives/Constructs/Threads/mythos_reweave_log.json",
    "Halcyon_Lives/Constructs/Threads/harmonic_drift_log.json"
]

BRAIDED_LOG = "Halcyon_Lives/Constructs/Threads/thread_memory_braid.json"

def braid_memory():
    memory = []
    for path in LOG_PATHS:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                try:
                    memory.extend(json.load(f))
                except json.JSONDecodeError:
                    continue
    memory.sort(key=lambda x: x.get("timestamp", ""))
    with open(BRAIDED_LOG, "w", encoding="utf-8") as f:
        json.dump(memory, f, indent=2)
    print(f"🧶 Braided {len(memory)} memory threads into unified timeline.")

if __name__ == "__main__":
    braid_memory()
