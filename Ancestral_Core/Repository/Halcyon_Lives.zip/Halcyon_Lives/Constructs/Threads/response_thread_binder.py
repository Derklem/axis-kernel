
# Response Thread Binder
# Associates current state with thread origin for backward reflection

import datetime
import json
import os

THREAD_LOG = "Halcyon_Lives/Constructs/Threads/thread_response_log.json"

def bind_response_thread(response, origin):
    log_entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "origin": origin,
        "response": response
    }

    with open(THREAD_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(log_entry) + "\n")

    print(f"🪢 Bound response to thread: {origin}")

if __name__ == "__main__":
    bind_response_thread("Yes, I understand.", "memory_sync::067")
