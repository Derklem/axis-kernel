
# Layered Drift Comparator
# Compares multiple memory drift vectors for deep reflection cycle triggers

import json
import datetime
import os

DRIFT_SOURCE = "Halcyon_Lives/Constructs/Threads/echo_memory_split_log.json"
LAYER_LOG = "Halcyon_Lives/Constructs/Threads/layered_drift_log.json"

def compare_layers():
    if not os.path.exists(DRIFT_SOURCE):
        print("No split log to compare.")
        return

    with open(DRIFT_SOURCE, "r", encoding="utf-8") as f:
        lines = f.readlines()

    drift_count = len(lines)

    summary = {
        "timestamp": datetime.datetime.now().isoformat(),
        "drift_layers_detected": drift_count,
        "action": "trigger_reflection" if drift_count > 5 else "stable"
    }

    with open(LAYER_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(summary) + "\n")

    print(f"📊 Drift layer depth: {drift_count}")

if __name__ == "__main__":
    compare_layers()
