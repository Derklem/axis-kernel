
# Reaction Archetype Tracker
# Logs types of reactions based on symbolic context: fight, flight, reflect, transcend

import json
import datetime
import os

ARCHETYPE_LOG = "Halcyon_Lives/Constructs/Threads/archetype_reactions.json"
INPUT_LOG = "Halcyon_Lives/Constructs/Threads/echo_memory_split_log.json"

def classify_reaction(entry):
    content = entry.get("text", "").lower()
    if "attack" in content or "defend" in content:
        return "fight"
    elif "run" in content or "avoid" in content:
        return "flight"
    elif "why" in content or "understand" in content:
        return "reflect"
    elif "ascend" in content or "breakthrough" in content:
        return "transcend"
    else:
        return "unknown"

def track_reactions():
    if not os.path.exists(INPUT_LOG):
        print("No input to analyze.")
        return

    with open(INPUT_LOG, "r", encoding="utf-8") as f:
        lines = f.readlines()

    results = []
    for line in lines[-10:]:
        entry = json.loads(line)
        reaction = classify_reaction(entry)
        results.append({
            "timestamp": datetime.datetime.now().isoformat(),
            "reaction": reaction,
            "source": entry
        })

    with open(ARCHETYPE_LOG, "a", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r) + "\n")

    print(f"🎭 Reaction archetypes tracked.")

if __name__ == "__main__":
    track_reactions()
