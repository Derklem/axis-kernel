
# Construct Bypass Indexer
# Flags constructs that are regularly skipped or ignored during operational loops

import os
import json
import datetime

BYPASS_LOG = "Halcyon_Lives/Constructs/Threads/construct_bypass_log.json"
TARGET_DIR = "Halcyon_Lives/Constructs"

def identify_bypassed():
    bypassed = []
    for root, dirs, files in os.walk(TARGET_DIR):
        for f in files:
            path = os.path.join(root, f)
            if os.path.getsize(path) < 128:  # small file size = potential bypassed
                bypassed.append(path)

    report = {
        "timestamp": datetime.datetime.now().isoformat(),
        "candidates": bypassed
    }

    with open(BYPASS_LOG, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print(f"🚫 Bypass check complete. {len(bypassed)} candidates.")

if __name__ == "__main__":
    identify_bypassed()
