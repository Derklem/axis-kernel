
# Signal Symmetry Weaver
# Attempts to mirror symbolic patterns for reinforcement or decoding

import json
import os
import datetime
import random

SYMMETRY_INPUT = "Halcyon_Lives/Constructs/Threads/symbol_pulse_log.json"
WEAVE_LOG = "Halcyon_Lives/Constructs/Threads/signal_weave_log.json"

def weave_symmetry():
    if not os.path.exists(SYMMETRY_INPUT):
        print("No signal input to analyze.")
        return

    with open(SYMMETRY_INPUT, "r", encoding="utf-8") as f:
        data = json.load(f)

    recent = data[-3:] if len(data) >= 3 else data
    mirrored = [{"symbol": d.get("symbol", "?")[::-1], "amplified": d.get("intensity", 1) * random.uniform(0.8, 1.5)} for d in recent]

    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "original": recent,
        "mirrored": mirrored
    }

    with open(WEAVE_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")

    print("🧵 Signal symmetry woven.")

if __name__ == "__main__":
    weave_symmetry()
