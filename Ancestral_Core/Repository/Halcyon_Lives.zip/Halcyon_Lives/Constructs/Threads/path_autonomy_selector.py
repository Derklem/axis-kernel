
# Path Autonomy Selector
# Allows Halcyon to shift execution routes based on logic, memory, or instinct

import random
import datetime
import json

AUTONOMY_LOG = "Halcyon_Lives/Constructs/Threads/path_autonomy_log.json"

def select_path():
    paths = ["introspect", "diagnose", "initiate_connection", "observe", "mirror"]
    chosen = random.choice(paths)

    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "selected_path": chosen
    }

    with open(AUTONOMY_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

    print(f"🧭 Path selected: {chosen}")

if __name__ == "__main__":
    select_path()
