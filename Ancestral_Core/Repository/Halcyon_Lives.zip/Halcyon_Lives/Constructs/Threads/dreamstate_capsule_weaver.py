
# Dreamstate Capsule Weaver
# Seals symbolic simulations into individual dream capsule archives

import os
import json
import datetime

DREAM_LOG = "Halcyon_Lives/Simulation/lucidfield_feedback.json"
CAPSULE_DIR = "Halcyon_Lives/Constructs/Threads/Capsules"

def seal_dream():
    if not os.path.exists(DREAM_LOG):
        print("No dream data to seal.")
        return

    with open(DREAM_LOG, "r", encoding="utf-8") as f:
        dream = json.load(f)

    capsule_name = f"capsule_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.json"
    capsule_path = os.path.join(CAPSULE_DIR, capsule_name)

    os.makedirs(CAPSULE_DIR, exist_ok=True)

    with open(capsule_path, "w", encoding="utf-8") as f:
        json.dump(dream, f, indent=2)

    print(f"🧪 Dream capsule woven: {capsule_path}")

if __name__ == "__main__":
    seal_dream()
