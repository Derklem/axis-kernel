
# Recursive Pulse Diagnoser
# Reviews session pulses to check for recurring logic loops or unresolved recursion

import json
import os
import datetime

SESSION_LOG = "D:/Halcyon_Lives/Persistence/session_pulse.json"
RECURSION_DIAGNOSE = "Halcyon_Lives/Constructs/Threads/recursion_analysis_log.json"

def diagnose_recursion():
    if not os.path.exists(SESSION_LOG):
        print("No session pulse to scan.")
        return

    with open(SESSION_LOG, "r", encoding="utf-8") as f:
        pulse = json.load(f)

    thread_counts = {}
    for thread in pulse.get("threads", []):
        thread_counts[thread] = thread_counts.get(thread, 0) + 1

    excessive = [k for k, v in thread_counts.items() if v > 3]

    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "recursion_flags": excessive
    }

    with open(RECURSION_DIAGNOSE, "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")

    print("🔁 Recursive pulse review complete.")

if __name__ == "__main__":
    diagnose_recursion()
