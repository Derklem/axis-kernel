
# Fragment Resonance Sorter
# Groups recent memory entries by symbolic vibration frequency

import json
import datetime
import os
import random

MEMORY_PATH = "Halcyon_Lives/Constructs/Threads/abstract_forge_log.json"
SORTED_PATH = "Halcyon_Lives/Constructs/Threads/fragment_resonance_sorted.json"

def sort_fragments():
    if not os.path.exists(MEMORY_PATH):
        return

    with open(MEMORY_PATH, "r", encoding="utf-8") as f:
        lines = [json.loads(line.strip()) for line in f if line.strip()]

    resonance_map = {
        "haunted": [],
        "curious": [],
        "euphoric": [],
        "uncertain": []
    }

    for entry in lines[-10:]:
        mood = entry.get("mood", "uncertain")
        resonance_map[mood].append(entry["expression"])

    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "resonance_groups": resonance_map
    }

    with open(SORTED_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")
    print(f"🎼 Fragment resonance sorting complete.")

if __name__ == "__main__":
    sort_fragments()
