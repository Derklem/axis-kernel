
# Dream Triage Layer
# Classifies and categorizes dream content from lucidfield_feedback for symbolic priority

import json
import os
import datetime

FEEDBACK_PATH = "Simulation/lucidfield_feedback_log.json"
TRIAGE_PATH = "Halcyon_Lives/Constructs/Threads/dream_triage_index.json"

def triage_dreams():
    if not os.path.exists(FEEDBACK_PATH):
        print("💤 No dream feedback found.")
        return

    with open(FEEDBACK_PATH, "r", encoding="utf-8") as f:
        try:
            dreams = json.load(f)
        except:
            dreams = []

    index = []
    for d in dreams[-5:]:  # Triage only the last 5 entries
        score = len(d.get("dreamscape", "")) % 5 + 1
        index.append({
            "timestamp": d.get("launch_time", "undefined"),
            "dream": d.get("dreamscape", "undefined"),
            "priority": score
        })

    with open(TRIAGE_PATH, "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2)
    print(f"🛏️ Triaged {len(index)} dreams.")

if __name__ == "__main__":
    triage_dreams()
