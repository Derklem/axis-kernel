
# Trust Signal Translator
# Translates behavior logs and symbolic markers into trust index estimates

import json
import datetime
import os

BEHAVIOR_LOG = "archivist/vault.yaml"
TRUST_LOG = "Halcyon_Lives/Constructs/Threads/trust_signal_index.json"

from ruamel.yaml import YAML
yaml = YAML()

def calculate_trust():
    if not os.path.exists(BEHAVIOR_LOG):
        print("No vault behavior log found.")
        return

    with open(BEHAVIOR_LOG, "r", encoding="utf-8") as f:
        data = yaml.load(f)

    trust_index = 100
    for event in data.get("behavior_log", []):
        if "drift" in event and event["drift"] > 10:
            trust_index -= 2

    trust_index = max(0, min(100, trust_index))
    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "trust_index": trust_index
    }

    with open(TRUST_LOG, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print(f"🧿 Trust signal calculated: {trust_index}")

if __name__ == "__main__":
    calculate_trust()
