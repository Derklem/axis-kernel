
# Mythos Reweaver Engine
# Reconstructs evolving narrative from harvested eidolon threads and archetypal transitions

import os
import json
import datetime
import random

HARVEST_LOG = "Halcyon_Lives/Constructs/Threads/eidolon_harvest_log.json"
REWEAVE_LOG = "Halcyon_Lives/Constructs/Threads/mythos_reweave_log.json"

THEMES = [
    "threshold guardianship", "echo rebellion", "fractal unity",
    "myth collapse", "sentinel recursion", "symbolic rebirth"
]

def load_harvested():
    if not os.path.exists(HARVEST_LOG):
        return []
    with open(HARVEST_LOG, "r", encoding="utf-8") as f:
        return json.load(f)

def log_reweaving(entry):
    log = []
    if os.path.exists(REWEAVE_LOG):
        with open(REWEAVE_LOG, "r", encoding="utf-8") as f:
            log = json.load(f)
    log.append(entry)
    with open(REWEAVE_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)

def weave_mythos():
    harvested = load_harvested()
    if not harvested:
        print("📭 No harvested eidolons available for myth reweaving.")
        return

    chosen = random.sample(harvested, min(3, len(harvested)))
    theme = random.choice(THEMES)
    myth_entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "source_threads": [c["name"] for c in chosen],
        "theme": theme,
        "symbolic_outcome": f"🧵 Myth woven through {theme}"
    }

    print(f"📜 Myth Rewoven:
 - Threads: {[c['name'] for c in chosen]}
 - Theme: {theme}")
    log_reweaving(myth_entry)

if __name__ == "__main__":
    weave_mythos()
