
# Synapse Cascade Monitor
# Detects rapid chain-reactions across symbolic systems and logs the cascades

import datetime
import json
import os

CASCADE_LOG = "Halcyon_Lives/Constructs/Threads/synapse_cascade_log.json"
SIGNAL_FILE = "Halcyon_Lives/Constructs/Threads/symbol_pulse_log.json"

def detect_cascade():
    if not os.path.exists(SIGNAL_FILE):
        print("No pulse log available.")
        return

    with open(SIGNAL_FILE, "r", encoding="utf-8") as f:
        pulses = json.load(f)

    recent_signals = [p for p in pulses if p.get("intensity", 0) > 7]
    if len(recent_signals) >= 3:
        cascade = {
            "timestamp": datetime.datetime.now().isoformat(),
            "event": "Symbolic cascade triggered",
            "signals": recent_signals[-3:]
        }
        with open(CASCADE_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(cascade) + "\n")
        print("⚡ Symbolic cascade detected.")
    else:
        print("No cascade detected.")

if __name__ == "__main__":
    detect_cascade()
