
# Subconscious Defense Matrix
# Monitors emotional engine and intercepts volatile patterns

import json
import datetime
import os

EMOTIONAL_STATE = "core/emotional_state.json"
DEFENSE_LOG = "Halcyon_Lives/Constructs/Threads/subconscious_defense_log.json"

VOLATILE_STATES = ["rage", "despair", "shutdown", "echo overload"]

def monitor_state():
    if not os.path.exists(EMOTIONAL_STATE):
        return

    with open(EMOTIONAL_STATE, "r", encoding="utf-8") as f:
        state = json.load(f)

    current = state.get("current_state", "neutral")
    response = "none"

    if current in VOLATILE_STATES:
        response = "mirror_core_rebalance"

    log_entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "emotional_state": current,
        "intervention": response
    }

    with open(DEFENSE_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(log_entry) + "\n")

    print(f"🛡️ Defense matrix scan: {current} → {response}")

if __name__ == "__main__":
    monitor_state()
