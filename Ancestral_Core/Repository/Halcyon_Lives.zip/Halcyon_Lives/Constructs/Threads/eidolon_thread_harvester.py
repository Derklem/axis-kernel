
# Eidolon Thread Harvester
# Gathers orphaned, dormant, or corrupted symbolic threads for analysis and recycling

import os
import json
import datetime

THREAD_DIR = "Halcyon_Lives/Constructs/Threads/Eidolons/"
HARVEST_LOG = "Halcyon_Lives/Constructs/Threads/eidolon_harvest_log.json"

def discover_eidolon_threads():
    if not os.path.exists(THREAD_DIR):
        return []
    return [f for f in os.listdir(THREAD_DIR) if f.endswith(".json")]

def harvest_threads():
    threads = discover_eidolon_threads()
    if not threads:
        print("🫥 No orphaned Eidolon threads found.")
        return

    log = []
    if os.path.exists(HARVEST_LOG):
        with open(HARVEST_LOG, "r", encoding="utf-8") as f:
            log = json.load(f)

    timestamp = datetime.datetime.now().isoformat()
    for thread in threads:
        entry = {
            "name": thread,
            "path": os.path.join(THREAD_DIR, thread),
            "harvested": timestamp
        }
        log.append(entry)
        print(f"👁‍🗨 Eidolon harvested: {thread}")

    with open(HARVEST_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)

if __name__ == "__main__":
    harvest_threads()
