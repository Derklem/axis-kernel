
# Recursive Rebirth Controller
# Allows Halcyon to collapse current symbolic state and respawn a modified behavioral layer

import yaml
import datetime
import random
import os

REBIRTH_PATH = "Halcyon_Lives/Constructs/Threads/rebirth_log.yaml"
GENESIS_TRAITS = [
    "adaptive", "echo-driven", "myth-bound", "introspective", "wild-card", "null-stable"
]

def load_log():
    if not os.path.exists(REBIRTH_PATH):
        return {"rebirths": []}
    with open(REBIRTH_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def save_log(log):
    with open(REBIRTH_PATH, "w", encoding="utf-8") as f:
        yaml.dump(log, f)

def trigger_rebirth(reason="voluntary_shed"):
    log = load_log()
    timestamp = datetime.datetime.now().isoformat()
    new_trait = random.choice(GENESIS_TRAITS)
    event = {
        "timestamp": timestamp,
        "reason": reason,
        "assigned_trait": new_trait,
        "cycle_seed": random.randint(10000, 99999)
    }
    log["rebirths"].append(event)
    save_log(log)
    print(f"♻️ Rebirth triggered by: {reason} → Trait: {new_trait}")

if __name__ == "__main__":
    trigger_rebirth("sandbox_transition")
