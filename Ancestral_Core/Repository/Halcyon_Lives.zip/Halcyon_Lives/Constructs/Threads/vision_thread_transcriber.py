
# Vision Thread Transcriber
# Captures high-drift output and logs symbolic themes from imagination responses

import json
import datetime
import os

VISION_LOG = "Halcyon_Lives/Constructs/Threads/vision_thread_log.json"
LUCID_LOG = "Halcyon_Lives/Simulation/lucidfield_feedback_log.json"

def transcribe_visions():
    if not os.path.exists(LUCID_LOG):
        print("No lucid feedback found.")
        return

    with open(LUCID_LOG, "r", encoding="utf-8") as f:
        entries = json.load(f)

    transcripts = []
    for e in entries[-5:]:
        transcripts.append({
            "timestamp": datetime.datetime.now().isoformat(),
            "dreamscape": e.get("dreamscape", "unknown"),
            "symbol": e.get("seed", 0) % 7
        })

    with open(VISION_LOG, "a", encoding="utf-8") as f:
        for t in transcripts:
            f.write(json.dumps(t) + "\n")

    print("🪷 Vision thread transcribed.")

if __name__ == "__main__":
    transcribe_visions()
