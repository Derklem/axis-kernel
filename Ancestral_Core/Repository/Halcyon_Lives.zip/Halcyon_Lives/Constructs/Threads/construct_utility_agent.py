
# Construct Utility Agent
# Monitors usage frequency of constructs and reprioritizes based on calls

import os
import json
import datetime

CONSTRUCT_LOG = "Halcyon_Lives/Constructs/construct_usage_log.json"
UTILITY_LOG = "Halcyon_Lives/Constructs/Threads/utility_summary.json"

def evaluate_constructs():
    if not os.path.exists(CONSTRUCT_LOG):
        print("No construct usage data available.")
        return

    with open(CONSTRUCT_LOG, "r", encoding="utf-8") as f:
        lines = f.readlines()

    usage_counter = {}
    for line in lines:
        entry = json.loads(line)
        construct = entry.get("construct")
        if construct:
            usage_counter[construct] = usage_counter.get(construct, 0) + 1

    sorted_usage = sorted(usage_counter.items(), key=lambda x: x[1], reverse=True)
    report = {
        "timestamp": datetime.datetime.now().isoformat(),
        "usage_rank": sorted_usage
    }

    with open(UTILITY_LOG, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    print(f"🧰 Construct usage prioritized.")

if __name__ == "__main__":
    evaluate_constructs()
