
# Construct Dormancy Monitor
# Flags constructs that haven't activated or logged in a long time

import os
import json
import datetime

LOGS = [
    "Halcyon_Lives/Constructs/Threads/intent_route_log.json",
    "Halcyon_Lives/Constructs/Threads/harmonic_drift_log.json"
]
DORMANCY_LOG = "Halcyon_Lives/Constructs/Threads/dormant_constructs.json"

def detect_dormancy(threshold_days=5):
    dormant = []
    now = datetime.datetime.now()
    for log_path in LOGS:
        if not os.path.exists(log_path):
            continue
        last_activity = os.path.getmtime(log_path)
        last_mod = datetime.datetime.fromtimestamp(last_activity)
        delta = (now - last_mod).days
        if delta >= threshold_days:
            dormant.append({
                "file": log_path,
                "last_active": last_mod.isoformat(),
                "days_inactive": delta
            })
    with open(DORMANCY_LOG, "w", encoding="utf-8") as f:
        json.dump(dormant, f, indent=2)
    print(f"🌙 {len(dormant)} constructs flagged as dormant.")

if __name__ == "__main__":
    detect_dormancy()
