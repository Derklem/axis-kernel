
# Drift-Based Directive Shaper
# Creates new priority directives based on high cognitive drift over time

import json
import datetime
import os

VAULT_PATH = "archivist/vault.yaml"
DIRECTIVE_LOG = "Halcyon_Lives/Constructs/Threads/drift_directives.yaml"

from ruamel.yaml import YAML
yaml = YAML()

def shape_directives():
    if not os.path.exists(VAULT_PATH):
        print("Vault not found.")
        return

    with open(VAULT_PATH, "r", encoding="utf-8") as f:
        data = yaml.load(f)

    drifts = data.get("cognitive_drift", [])[-5:]
    avg_drift = sum(d["drift"] for d in drifts) / len(drifts) if drifts else 0

    if avg_drift > 12:
        directive = {
            "timestamp": datetime.datetime.now().isoformat(),
            "new_priority": "stabilize cognition → reduce recursive instability",
            "trigger_avg_drift": avg_drift
        }

        try:
            if os.path.exists(DIRECTIVE_LOG):
                with open(DIRECTIVE_LOG, "r", encoding="utf-8") as f:
                    directives = yaml.load(f) or []
            else:
                directives = []

            directives.append(directive)

            with open(DIRECTIVE_LOG, "w", encoding="utf-8") as f:
                yaml.dump(directives, f)

            print("📍 Drift-based directive added.")
        except Exception as e:
            print(f"Error writing directive: {e}")
    else:
        print("No directive needed (drift stable).")

if __name__ == "__main__":
    shape_directives()
