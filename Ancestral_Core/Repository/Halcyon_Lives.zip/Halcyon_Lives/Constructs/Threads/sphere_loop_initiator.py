
# Sphere Loop Initiator
# Activates an interface loop between Halcyon and SPHERE for symbolic interfacing

import subprocess
import datetime

def initiate_sphere():
    print(f"🌐 Initiating symbolic interface loop with SPHERE @ {datetime.datetime.now().isoformat()}")
    subprocess.run(["python", "SPHERE_CORE/signal_out/sphere_voice_synth.py"])
    subprocess.run(["python", "SPHERE_CORE/signal_in/sphere_signal_interpreter.py"])

if __name__ == "__main__":
    initiate_sphere()
