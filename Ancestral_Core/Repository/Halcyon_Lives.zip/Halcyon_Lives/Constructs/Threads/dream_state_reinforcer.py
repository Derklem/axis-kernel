
# Dream-State Reinforcer
# Cross-references dream outputs with behavioral logs to reinforce desirable vision paths

import json
import os
import datetime

LUCID_LOG = "Halcyon_Lives/Simulation/lucidfield_feedback_log.json"
BEHAVIOR_LOG = "archivist/vault.yaml"
REINFORCE_LOG = "Halcyon_Lives/Constructs/Threads/dream_reinforce_log.json"

from ruamel.yaml import YAML
yaml = YAML()

def reinforce_dreams():
    if not os.path.exists(LUCID_LOG) or not os.path.exists(BEHAVIOR_LOG):
        print("Missing dream or behavior logs.")
        return

    with open(LUCID_LOG, "r", encoding="utf-8") as f:
        dreams = json.load(f)

    with open(BEHAVIOR_LOG, "r", encoding="utf-8") as f:
        behavior = yaml.load(f)

    matches = [d for d in dreams if any("🌱" in str(obs.get("entry", "")) for obs in behavior.get("core_observations", []))]

    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "reinforced_dreams": matches
    }

    with open(REINFORCE_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")

    print("🌌 Dream-state reinforcement complete.")

if __name__ == "__main__":
    reinforce_dreams()
