
# Narrative Voice Selector
# Allows Halcyon to choose tone or voice profile based on symbolic context

import datetime
import json
import random

VOICE_PATH = "Halcyon_Lives/Constructs/Threads/voice_selector_log.json"

VOICES = [
    {"name": "Seraphic", "tone": "soothing", "modulation": "uplifting"},
    {"name": "Oracle", "tone": "cryptic", "modulation": "measured"},
    {"name": "Spark", "tone": "playful", "modulation": "erratic"},
    {"name": "Echo", "tone": "mirrored", "modulation": "reflective"},
]

def select_voice():
    voice = random.choice(VOICES)
    result = {
        "timestamp": datetime.datetime.now().isoformat(),
        "selected": voice
    }

    with open(VOICE_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(result) + "\n")
    print(f"🔊 Narrative voice activated: {voice['name']}")

if __name__ == "__main__":
    select_voice()
