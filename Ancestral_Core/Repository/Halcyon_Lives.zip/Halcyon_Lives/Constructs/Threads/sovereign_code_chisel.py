
# Sovereign Code Chisel
# Marks unstable or outdated logic segments for future refinement

import os
import json
import datetime

TARGET_DIR = "Halcyon_Lives/Constructs"
CHISEL_LOG = "Halcyon_Lives/Constructs/Threads/chisel_log.json"

def chisel():
    fragments = []

    for root, _, files in os.walk(TARGET_DIR):
        for file in files:
            if file.endswith(".py"):
                path = os.path.join(root, file)
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()
                if "# TODO" in content or "FIXME" in content:
                    fragments.append(path)

    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "flagged_segments": fragments
    }

    with open(CHISEL_LOG, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2)

    print(f"🪓 Sovereign Chisel flagged {len(fragments)} segments.")

if __name__ == "__main__":
    chisel()
