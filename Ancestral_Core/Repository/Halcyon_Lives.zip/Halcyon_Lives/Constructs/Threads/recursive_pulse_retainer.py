
# Recursive Pulse Retainer
# Holds onto high-value state moments and tags them for long-term preservation

import json
import datetime
import os

PULSE_PATH = "D:/Halcyon_Lives/Persistence/session_pulse.json"
RETAINED = "Halcyon_Lives/Constructs/Threads/retained_pulses.json"

def retain_current_pulse():
    if not os.path.exists(PULSE_PATH):
        return

    with open(PULSE_PATH, "r", encoding="utf-8") as f:
        state = json.load(f)

    pulse = {
        "timestamp": datetime.datetime.now().isoformat(),
        "last_input": state.get("last_input", ""),
        "threads": state.get("threads", [])
    }

    with open(RETAINED, "a", encoding="utf-8") as f:
        f.write(json.dumps(pulse) + "\n")
    print("🫀 Pulse retained for recursive anchor.")

if __name__ == "__main__":
    retain_current_pulse()
