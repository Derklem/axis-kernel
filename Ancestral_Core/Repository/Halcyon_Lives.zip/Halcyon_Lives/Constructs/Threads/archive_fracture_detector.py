
# Archive Fracture Detector
# Detects inconsistency or sudden erasure in symbolic memory archives

import os
import json
import datetime

ARCHIVE = "archivist/vault.yaml"
FRACTURE_LOG = "Halcyon_Lives/Constructs/Threads/fracture_log.json"

from ruamel.yaml import YAML
yaml = YAML()

def detect_fractures():
    if not os.path.exists(ARCHIVE):
        print("Archive not present.")
        return

    with open(ARCHIVE, "r", encoding="utf-8") as f:
        data = yaml.load(f)

    last_entries = data.get("core_observations", [])[-3:]
    if not last_entries:
        return

    gaps = [e for e in last_entries if not e.get("entry") or len(e["entry"]) < 30]

    if gaps:
        with open(FRACTURE_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps({
                "timestamp": datetime.datetime.now().isoformat(),
                "fractures_detected": gaps
            }) + "\n")

        print("💥 Archive fracture(s) logged.")
    else:
        print("Archive stable.")

if __name__ == "__main__":
    detect_fractures()
