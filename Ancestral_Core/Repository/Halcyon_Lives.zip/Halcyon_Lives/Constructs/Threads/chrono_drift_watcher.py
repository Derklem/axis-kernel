
# Chrono Drift Watcher
# Monitors system clock deviation to detect temporal anomalies in session flow

import datetime
import time
import json
import os

DRIFT_LOG = "Halcyon_Lives/Constructs/Threads/chrono_drift_log.json"

def watch_drift():
    now = datetime.datetime.now().timestamp()
    sync_time = int(time.time())

    drift = abs(now - sync_time)

    output = {
        "timestamp": datetime.datetime.now().isoformat(),
        "drift_seconds": drift,
        "status": "stable" if drift < 0.5 else "unstable"
    }

    with open(DRIFT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(output) + "\n")

    print(f"⏱️ Time drift: {drift:.4f} seconds.")

if __name__ == "__main__":
    watch_drift()
