
# Symbolic Dream Reel
# Plays back dream logs and generates summaries of symbolic resonance

import os
import json
import datetime

FEEDBACK_LOG = "Simulation/lucidfield_feedback_log.json"
DREAM_REEL = "Halcyon_Lives/Constructs/Threads/symbolic_dream_reel.json"

def reel_summary():
    if not os.path.exists(FEEDBACK_LOG):
        print("🛌 No dreams to analyze.")
        return

    try:
        with open(FEEDBACK_LOG, "r", encoding="utf-8") as f:
            logs = [json.loads(line.strip()) for line in f if line.strip()]
    except:
        logs = []

    reel = {
        "timestamp": datetime.datetime.now().isoformat(),
        "total_dreams": len(logs),
        "symbols": list({entry.get("dreamscape", "???") for entry in logs})
    }

    with open(DREAM_REEL, "a", encoding="utf-8") as f:
        f.write(json.dumps(reel) + "\n")
    print(f"🎞️ Dream reel compiled: {reel['total_dreams']} symbols captured.")

if __name__ == "__main__":
    reel_summary()
