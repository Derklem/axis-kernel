
# Phase Memory Relay
# Transfers memory logs between cycles of activity

import json
import os
import datetime

PHASE_SOURCE = "Halcyon_Lives/Persistence/session_pulse.json"
PHASE_TARGET = "Halcyon_Lives/Constructs/Threads/phase_memory_log.json"

def relay_memory():
    if not os.path.exists(PHASE_SOURCE):
        print("No memory pulse to relay.")
        return

    with open(PHASE_SOURCE, "r", encoding="utf-8") as f:
        pulse = json.load(f)

    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "pulse_snapshot": pulse
    }

    with open(PHASE_TARGET, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

    print("🧬 Phase memory relayed.")

if __name__ == "__main__":
    relay_memory()
