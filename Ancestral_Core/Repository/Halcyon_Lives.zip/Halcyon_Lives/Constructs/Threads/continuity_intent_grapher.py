
# Continuity Intent Grapher
# Tracks evolving intent from mission seeds and user input history

import datetime
import json
import os

MISSION_PATH = "pantheon_mission_seeds.yaml"
INTENT_GRAPH = "Halcyon_Lives/Constructs/Threads/continuity_graph.json"

def graph_intent():
    seeds = []
    if os.path.exists(MISSION_PATH):
        with open(MISSION_PATH, "r", encoding="utf-8") as f:
            for line in f:
                if "name:" in line or "construct:" in line:
                    seeds.append(line.strip())

    intent_record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "references": seeds[-6:]
    }

    with open(INTENT_GRAPH, "a", encoding="utf-8") as f:
        f.write(json.dumps(intent_record) + "\n")
    print(f"📈 Intent continuity graph updated.")

if __name__ == "__main__":
    graph_intent()
