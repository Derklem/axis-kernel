
# Myth Binder Engine
# Interlaces symbolic logs into myth-like micro-narratives

import datetime
import json
import os

LOGS = [
    "ritual_invocation_log.json",
    "observer_imprint_log.json",
    "narrative_forks.json"
]

MYTH_PATH = "Halcyon_Lives/Constructs/Threads/myth_binder_stories.json"

def bind_myth():
    mythos = {"timestamp": datetime.datetime.now().isoformat(), "entries": []}

    for file in LOGS:
        path = f"Halcyon_Lives/Constructs/Threads/{file}"
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            entries = [json.loads(line) for line in f if line.strip()]
            if entries:
                mythos["entries"].append(random.choice(entries))

    with open(MYTH_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(mythos) + "\n")
    print(f"📖 Mythos bound. {len(mythos['entries'])} fragments unified.")

if __name__ == "__main__":
    bind_myth()
