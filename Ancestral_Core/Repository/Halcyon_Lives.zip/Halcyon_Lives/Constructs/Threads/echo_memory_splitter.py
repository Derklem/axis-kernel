
# Echo Memory Splitter
# Creates segmented memory copies to reduce overload during high activity periods

import os
import json
import datetime

ECHO_PATH = "Halcyon_Lives/Echoes/echo_queue.yaml"
SPLIT_LOG = "Halcyon_Lives/Constructs/Threads/echo_memory_split_log.json"

def split_echoes():
    if not os.path.exists(ECHO_PATH):
        print("📭 No echoes to split.")
        return

    timestamp = datetime.datetime.now().isoformat()

    echo_segment = {
        "timestamp": timestamp,
        "note": "Echo state preserved as snapshot."
    }

    with open(SPLIT_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(echo_segment) + "\n")

    print("🌀 Echo snapshot sealed.")

if __name__ == "__main__":
    split_echoes()
