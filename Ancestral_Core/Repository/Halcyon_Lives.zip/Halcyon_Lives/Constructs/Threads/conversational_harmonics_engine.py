# Conversational Harmonics Engine
# Adjusts tone and phrasing for smoother exchanges based on feedback

import datetime
import json
import os

VOICE_LOG = "Halcyon_Lives/Constructs/Threads/voice_selector_log.json"
HARMONICS_LOG = "Halcyon_Lives/Constructs/Threads/conversational_harmonics_log.json"

def harmonize():
    if not os.path.exists(VOICE_LOG):
        return

    with open(VOICE_LOG, "r", encoding="utf-8") as f:
        lines = [json.loads(line.strip()) for line in f if line.strip()]

    latest_voice = lines[-1]["selected"] if lines else {"name": "neutral", "tone": "flat"}
    effect = "calibrate to environment" if latest_voice["tone"] != "erratic" else "stabilize speech"

    output = {
        "timestamp": datetime.datetime.now().isoformat(),
        "tone_used": latest_voice["tone"],
        "adjustment": effect
    }

    with open(HARMONICS_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(output) + "\n")

    print(f"🗣️ Harmonic engine tuned: {effect}")

if __name__ == "__main__":
    harmonize()
