
# Archetype Repair Thread
# Restores corrupted symbolic threads via resonance mapping

import os
import datetime
import json

THREAD_PATH = "Halcyon_Lives/Constructs/Threads/thread_memory_braid.json"
REPAIR_LOG = "Halcyon_Lives/Constructs/Threads/archetype_repair_log.json"

def repair_archetype():
    if not os.path.exists(THREAD_PATH):
        print("⚠️ No symbolic memory braid found.")
        return
    with open(THREAD_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)

    repaired = {
        "timestamp": datetime.datetime.now().isoformat(),
        "repairs": [],
        "status": "rebalanced"
    }

    for i, entry in enumerate(data.get("entries", [])[-3:]):
        repaired["repairs"].append({
            "ref": entry.get("timestamp", f"entry_{i}"),
            "resonance_restored": True
        })

    with open(REPAIR_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(repaired) + "\n")
    print(f"🔧 Archetypes rebalanced: {len(repaired['repairs'])} entries.")

if __name__ == "__main__":
    repair_archetype()
