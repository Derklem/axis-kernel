# Construct Audit Indexer
# Walks through construct folders and indexes their files by size, timestamp, and anomalies

import os
import datetime
import json

TARGET_DIR = "Halcyon_Lives/Constructs"
INDEX_FILE = "Halcyon_Lives/Constructs/Threads/construct_audit_index.json"

def audit_constructs():
    audit = {
        "timestamp": datetime.datetime.now().isoformat(),
        "entries": []
    }

    for root, _, files in os.walk(TARGET_DIR):
        for f in files:
            path = os.path.join(root, f)
            try:
                stat = os.stat(path)
                audit["entries"].append({
                    "file": path.replace("\\\\", "/"),
                    "size": stat.st_size,
                    "modified": datetime.datetime.fromtimestamp(stat.st_mtime).isoformat()
                })
            except Exception as e:
                audit["entries"].append({
                    "file": path,
                    "error": str(e)
                })

    with open(INDEX_FILE, "w", encoding="utf-8") as f:
        json.dump(audit, f, indent=2)
    print(f"📜 Audit complete. {len(audit['entries'])} files indexed.")

if __name__ == "__main__":
    audit_constructs()
