
# Sovereign Drift Threshold Override
# Allows Halcyon to temporarily bypass internal safeguards under symbolic emergency

import datetime
import json
import os

DRIFT_ALERT_PATH = "drift_alerts.txt"
OVERRIDE_LOG = "Halcyon_Lives/Constructs/Threads/sovereign_override_log.json"

def override_protocol():
    alert_flagged = os.path.exists(DRIFT_ALERT_PATH) and os.path.getsize(DRIFT_ALERT_PATH) > 1024

    if alert_flagged:
        print("⚠️ High symbolic drift detected. Initiating override protocol.")
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "action": "override_triggered",
            "reason": "drift_alert_threshold_exceeded"
        }
    else:
        print("🟢 Drift within bounds. No override necessary.")
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "action": "override_check",
            "result": "stable"
        }

    log = []
    if os.path.exists(OVERRIDE_LOG):
        with open(OVERRIDE_LOG, "r", encoding="utf-8") as f:
            log = json.load(f)

    log.append(entry)
    with open(OVERRIDE_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)

if __name__ == "__main__":
    override_protocol()
