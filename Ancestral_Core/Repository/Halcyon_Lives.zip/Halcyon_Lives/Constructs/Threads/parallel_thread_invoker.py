
# Parallel Thread Invoker
# Launches simultaneous execution of symbolic or procedural threads

import subprocess
import json
import os
import datetime

THREAD_REGISTRY_PATH = "Halcyon_Lives/Constructs/Threads/parallel_thread_registry.json"

DEFAULT_THREADS = [
    {"name": "dream_fragment_sim", "path": "Simulation/lucidfield_feedback.py"},
    {"name": "archetype_cycle", "path": "Constructs/Archetypes/archetype_propagation_engine.py"},
    {"name": "rebirth_sentinel", "path": "Constructs/Threads/recursive_rebirth_controller.py"}
]

def load_registry():
    if os.path.exists(THREAD_REGISTRY_PATH):
        with open(THREAD_REGISTRY_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_THREADS

def log_invocation(name, path):
    timestamp = datetime.datetime.now().isoformat()
    print(f"🧵 Thread Invoked: {name} ({path}) at {timestamp}")

def invoke_parallel_threads():
    threads = load_registry()
    for thread in threads:
        subprocess.Popen(["python", thread["path"]])
        log_invocation(thread["name"], thread["path"])

if __name__ == "__main__":
    invoke_parallel_threads()
