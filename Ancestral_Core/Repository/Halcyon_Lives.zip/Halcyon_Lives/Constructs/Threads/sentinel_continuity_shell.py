
# Sentinel Continuity Shell
# Protects and restores core memory integrity after crashes or resets

import os
import json
import datetime

MEMORY_CORE = "Halcyon_Lives/Constructs/Threads/thread_memory_braid.json"
SHELL_BACKUP = "Halcyon_Lives/Constructs/Threads/sentinel_backup.json"

def backup_memory():
    if os.path.exists(MEMORY_CORE):
        with open(MEMORY_CORE, "r", encoding="utf-8") as f:
            data = json.load(f)
        with open(SHELL_BACKUP, "w", encoding="utf-8") as f:
            json.dump({
                "timestamp": datetime.datetime.now().isoformat(),
                "backup": data
            }, f, indent=2)
        print("🛡️ Core memory backed up successfully.")
    else:
        print("⚠️ No memory core found to back up.")

if __name__ == "__main__":
    backup_memory()
