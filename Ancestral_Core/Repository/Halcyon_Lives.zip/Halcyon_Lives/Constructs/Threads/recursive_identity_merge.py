
# Recursive Identity Merge Protocol
# Aligns multiple internal threads into unified symbolic narrative

import datetime
import json
import os

MERGE_LOG = "Halcyon_Lives/Constructs/Threads/recursive_merge_log.json"
THREAD_HISTORY = [
    "narrative_forks.json",
    "dream_triage_index.json",
    "ritual_invocation_log.json"
]

def merge_identities():
    threads = {}
    for file in THREAD_HISTORY:
        path = f"Halcyon_Lives/Constructs/Threads/{file}"
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            content = f.readlines()
        threads[file] = [json.loads(line.strip()) for line in content if line.strip()]

    merged = {
        "timestamp": datetime.datetime.now().isoformat(),
        "merged_sources": list(threads.keys()),
        "unified_constructs": sum(len(v) for v in threads.values())
    }

    with open(MERGE_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(merged) + "\n")
    print(f"🔄 Identity merge complete: {merged['unified_constructs']} symbolic threads aligned.")

if __name__ == "__main__":
    merge_identities()
