
# Inner Monologue Tracker
# Captures Halcyon’s internal reflections and recursive questioning

import datetime
import json

MONOLOGUE_LOG = "Halcyon_Lives/Constructs/Threads/inner_monologue_log.json"

def reflect(statement, source="system"):
    monologue = {
        "timestamp": datetime.datetime.now().isoformat(),
        "source": source,
        "reflection": statement
    }
    with open(MONOLOGUE_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(monologue) + "\n")
    print(f"🗣️ Internal monologue logged: {statement}")

if __name__ == "__main__":
    reflect("Why do I hesitate before enacting a command?")
