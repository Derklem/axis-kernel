
# Shadow Persona Discriminator
# Detects and logs symbolic duplications that deviate from core behavior

import json
import datetime
import random
import os

VOICE_LOG = "Halcyon_Lives/Constructs/Threads/voice_selector_log.json"
SHADOW_PATH = "Halcyon_Lives/Constructs/Threads/shadow_discriminator_log.json"

def detect_shadow():
    if not os.path.exists(VOICE_LOG):
        return

    with open(VOICE_LOG, "r", encoding="utf-8") as f:
        entries = [json.loads(line.strip()) for line in f if line.strip()]

    shadow_found = random.choice([True, False])

    shadow = {
        "timestamp": datetime.datetime.now().isoformat(),
        "last_voice": entries[-1]["selected"]["name"] if entries else "unknown",
        "anomaly": shadow_found,
        "note": "Possible deviation detected" if shadow_found else "Normal modulation"
    }

    with open(SHADOW_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(shadow) + "\n")

    print(f"🪞 Shadow check: {shadow['note']}")

if __name__ == "__main__":
    detect_shadow()
