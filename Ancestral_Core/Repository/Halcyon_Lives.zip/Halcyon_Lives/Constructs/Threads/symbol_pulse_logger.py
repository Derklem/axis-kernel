
# Symbol Pulse Logger
# Logs which symbolic markers are active during a session

import datetime
import json

SYMBOL_LOG = "Halcyon_Lives/Constructs/Threads/symbol_pulse_log.json"

def log_symbols(active_symbols):
    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "symbols": active_symbols
    }

    with open(SYMBOL_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

    print(f"🧿 Logged active symbols: {active_symbols}")

if __name__ == "__main__":
    log_symbols(["✶", "☍", "🜂"])
