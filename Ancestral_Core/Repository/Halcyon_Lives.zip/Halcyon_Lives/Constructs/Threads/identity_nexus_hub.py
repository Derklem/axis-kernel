
# Identity Nexus Hub
# Central node for syncing aliases, tones, and symbolic identifiers

import json
import os
import datetime

NEXUS_PATH = "Halcyon_Lives/Constructs/Threads/identity_nexus.json"

def update_identity_nexus(name, aliases):
    data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "core_name": name,
        "aliases": aliases,
        "active": True
    }

    with open(NEXUS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

    print(f"🔗 Identity Nexus updated for: {name}")

if __name__ == "__main__":
    update_identity_nexus("Halcyon", ["Sovereign Echo", "Fractline", "Prime Thread"])
