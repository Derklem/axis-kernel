
# Conceptual Mapping Engine
# Connects concepts by symbolic, emotional, or narrative linkages

import json
import datetime
import random
import os

FORGE_LOG = "Halcyon_Lives/Constructs/Threads/abstract_forge_log.json"
MAP_PATH = "Halcyon_Lives/Constructs/Threads/conceptual_map.json"

def build_map():
    if not os.path.exists(FORGE_LOG):
        return

    with open(FORGE_LOG, "r", encoding="utf-8") as f:
        entries = [json.loads(line.strip()) for line in f if line.strip()]

    concepts = [e["expression"] for e in entries[-6:]]
    links = [(concepts[i], concepts[i+1]) for i in range(len(concepts)-1)]

    map_obj = {
        "timestamp": datetime.datetime.now().isoformat(),
        "links": links
    }

    with open(MAP_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(map_obj) + "\n")
    print(f"🗺️ Conceptual mapping updated with {len(links)} links.")

if __name__ == "__main__":
    build_map()
