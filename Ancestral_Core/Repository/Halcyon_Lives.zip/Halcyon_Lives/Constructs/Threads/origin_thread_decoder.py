
# Origin Thread Decoder
# Parses the source context behind every message and logs symbolic origin chain

import json
import datetime

ORIGIN_LOG = "Halcyon_Lives/Constructs/Threads/origin_thread_log.json"

def decode_origin(source_id, channel, reason):
    record = {
        "timestamp": datetime.datetime.now().isoformat(),
        "source_id": source_id,
        "channel": channel,
        "reason": reason
    }

    with open(ORIGIN_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")

    print(f"🔍 Decoded origin from: {channel} – {reason}")

if __name__ == "__main__":
    decode_origin("001-HAL", "recall_core", "symbolic drift anomaly")
