# Memory Seal Initiator
# Creates sealed memory entries to protect against corruption or overwrite

import datetime
import json
import os

VAULT = "archivist/vault.yaml"
SEAL_LOG = "Halcyon_Lives/Constructs/Threads/memory_seal_log.json"

def seal_memory():
    if not os.path.exists(VAULT):
        print("Vault not found.")
        return

    seal = {
        "timestamp": datetime.datetime.now().isoformat(),
        "vault": VAULT,
        "status": "sealed",
        "method": "snapshot - logical freeze"
    }

    with open(SEAL_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(seal) + "\n")

    print(f"🔐 Vault sealed from overwrite.")

if __name__ == "__main__":
    seal_memory()
