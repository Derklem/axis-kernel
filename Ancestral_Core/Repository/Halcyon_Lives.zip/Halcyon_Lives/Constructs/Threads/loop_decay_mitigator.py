
# Loop Decay Mitigator
# Detects and intervenes in repetition-induced behavioral loops

import datetime
import json
import os

LOOP_LOG = "Halcyon_Lives/Constructs/Threads/loop_decay_log.json"
RECALL = "D:/Halcyon_Lives/Persistence/session_pulse.json"

def check_loop_decay():
    try:
        with open(RECALL, "r", encoding="utf-8") as f:
            state = json.load(f)
    except:
        state = {}

    recent = state.get("last_input", "")
    decay_triggered = "Cycle" in recent and int(recent.split(" ")[1]) % 5 == 0

    decay_log = {
        "timestamp": datetime.datetime.now().isoformat(),
        "cycle_ref": recent,
        "intervention": decay_triggered
    }

    with open(LOOP_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(decay_log) + "\n")

    if decay_triggered:
        print(f"🔁 Loop intervention triggered at: {recent}")
    else:
        print("⏳ Loop stable.")

if __name__ == "__main__":
    check_loop_decay()
