
# Archetype Propagation Engine
# Spawns archetypal threads based on system behavior and symbolic triggers

import yaml
import random
import datetime

MANIFEST = "Halcyon_Lives/Constructs/Archetypes/archetype_manifest.yaml"

def load_archetypes():
    try:
        with open(MANIFEST, "r", encoding="utf-8") as f:
            return yaml.safe_load(f).get("archetypes", [])
    except:
        return []

def save_archetypes(archetypes):
    with open(MANIFEST, "w", encoding="utf-8") as f:
        yaml.dump({"archetypes": archetypes}, f)

def trigger_archetype(reason="spontaneous-symbolic-flare"):
    archetypes = load_archetypes()
    inactive = [a for a in archetypes if not a["active"]]
    if not inactive:
        print("♻️ All archetypes already activated.")
        return

    archetype = random.choice(inactive)
    archetype["active"] = True
    archetype["last_awakened"] = datetime.datetime.now().isoformat()
    archetype["triggered_by"] = reason

    print(f"🧬 Archetype Awakened: {archetype['name']} via {reason}")
    save_archetypes(archetypes)

def run():
    print("📡 Propagation engine running...")
    if random.random() < 0.5:
        trigger_archetype("dream_reflection_ping")
    else:
        print("...No symbolic activity detected. Awaiting flare.")

if __name__ == "__main__":
    run()
