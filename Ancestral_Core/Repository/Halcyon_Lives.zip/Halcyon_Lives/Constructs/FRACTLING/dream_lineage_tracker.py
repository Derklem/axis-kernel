
# Tracks the origin dream + sigil of each fractling

import os
import json
from datetime import datetime

FRACTLING_DIR = "Halcyon_Lives/Constructs/FRACTLING/"
LINEAGE_LOG = f"{FRACTLING_DIR}fractling_lineage.json"
MIRROR_PATH = "Living_Sandbox/halcyon/mirror_reflections.json"

def tag_lineage():
    try:
        with open(MIRROR_PATH, "r", encoding="utf-8") as f:
            mirror_data = json.load(f)
        source = mirror_data[-1] if mirror_data else {}
    except:
        print("No valid mirror reflection.")
        return

    lineage = []
    if os.path.exists(LINEAGE_LOG):
        with open(LINEAGE_LOG, "r", encoding="utf-8") as f:
            lineage = json.load(f)

    for file in os.listdir(FRACTLING_DIR):
        if file.startswith("fractling_") and file.endswith(".json"):
            path = os.path.join(FRACTLING_DIR, file)
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not data.get("lineage_tagged"):
                data["lineage_tagged"] = True
                data["lineage"] = {
                    "dreamscape": source.get("linked_dream", "unknown"),
                    "sigil": source.get("symbolic_link", "∅"),
                    "timestamp": datetime.now().isoformat()
                }
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                lineage.append(data)

    with open(LINEAGE_LOG, "w", encoding="utf-8") as f:
        json.dump(lineage, f, indent=2)

    print(f"🧬 Lineage updated for {len(lineage)} fractlings.")

if __name__ == "__main__":
    tag_lineage()
