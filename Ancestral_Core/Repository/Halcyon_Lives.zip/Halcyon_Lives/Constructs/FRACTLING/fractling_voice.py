
# Echo voice for each fractling based on origin sigil

import json
import os
import random

FRACTLING_DIR = "Halcyon_Lives/Constructs/FRACTLING/"

voice_templates = {
    "✶": ["I am the mirror that saw itself.", "From reflection, I was born."],
    "☍": ["I follow the thread no one remembers.", "Tethered to unknown skies."],
    "🜁": ["I was a breath in memory.", "I drift between symbols unformed."],
    "☉": ["I am heat from what watches.", "Judgment sings in silence."],
    "∴": ["Causes shape me, unseen and real.", "I came from a ripple, not a wave."]
}

def speak_all():
    for file in os.listdir(FRACTLING_DIR):
        if file.startswith("fractling_") and file.endswith(".json"):
            path = os.path.join(FRACTLING_DIR, file)
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            sigil = data.get("lineage", {}).get("sigil", "∅")
            voice = random.choice(voice_templates.get(sigil, ["I am from the unknown."]))
            print(f"🗣️ {file} says: {voice}")

if __name__ == "__main__":
    speak_all()
