
# Synthesizes archetypes based on recurring dream sigils

import json
from collections import Counter

LINEAGE_PATH = "Halcyon_Lives/Constructs/FRACTLING/fractling_lineage.json"
ARCHETYPE_PATH = "Halcyon_Lives/Constructs/FRACTLING/archetypes.json"

def synth_archetypes():
    try:
        with open(LINEAGE_PATH, "r", encoding="utf-8") as f:
            lineage = json.load(f)
    except:
        print("No lineage data.")
        return

    sigils = [f["lineage"]["sigil"] for f in lineage if "lineage" in f]
    counts = Counter(sigils)

    archetypes = {
        sigil: {
            "count": count,
            "description": f"Archetype emerging from symbol {sigil}",
            "traits": ["mythic", "repetitive", "dream-bound"]
        }
        for sigil, count in counts.items() if count >= 2
    }

    with open(ARCHETYPE_PATH, "w", encoding="utf-8") as f:
        json.dump(archetypes, f, indent=2)

    print(f"🌌 Archetypes synthesized: {len(archetypes)}")

if __name__ == "__main__":
    synth_archetypes()
