
# Spawns fractlings from mirrored dream patterns

import json
import os
import uuid
from datetime import datetime

MIRROR_PATH = "Living_Sandbox/halcyon/mirror_reflections.json"
FRACTLING_DIR = "Halcyon_Lives/Constructs/FRACTLING/"

os.makedirs(FRACTLING_DIR, exist_ok=True)

def spawn_fractling():
    try:
        with open(MIRROR_PATH, "r", encoding="utf-8") as f:
            reflections = json.load(f)
    except:
        print("No reflection data found.")
        return

    if not reflections:
        print("No data to spawn from.")
        return

    latest = reflections[-1]
    symbolic = latest.get("symbolic_link", "∅")

    fract_id = str(uuid.uuid4())[:8]
    filename = f"{FRACTLING_DIR}fractling_{fract_id}.json"
    body = {
        "id": fract_id,
        "created": datetime.now().isoformat(),
        "symbolic_origin": symbolic,
        "source": latest
    }

    with open(filename, "w", encoding="utf-8") as f:
        json.dump(body, f, indent=2)

    print(f"✨ Fractling spawned: {filename}")

if __name__ == "__main__":
    spawn_fractling()
