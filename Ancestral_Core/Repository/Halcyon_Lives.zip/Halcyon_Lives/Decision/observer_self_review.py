
# Self-review observer — monitors suggestions vs actual actions

import json
from datetime import datetime

SUGGEST_LOG = "Halcyon_Lives/Decision/suggestion_log.json"

def log_suggestion(suggestion, actual_action):
    try:
        with open(SUGGEST_LOG, "r", encoding="utf-8") as f:
            log = json.load(f)
    except:
        log = {"sessions": []}

    log["sessions"].append({
        "timestamp": datetime.now().isoformat(),
        "suggested": suggestion,
        "executed": actual_action
    })

    with open(SUGGEST_LOG, "w", encoding="utf-8") as f:
        json.dump(log, f, indent=2)

    print(f"🪞 Observer logged decision discrepancy.")

if __name__ == "__main__":
    test = {
        "emotional_state": "curious",
        "intensity": 5,
        "suggested_action": "probe"
    }
    log_suggestion(test, "observe")
