
# Recursive Behavior Engine — Halcyon adapts based on past outcomes

import json
import yaml
from datetime import datetime
from decision_scaffold import run_scaffold
from observer_self_review import log_suggestion
from emotional_modulator import modulate_emotion

TRACE_LOG = "Halcyon_Lives/Decision/behavioral_trace.yaml"

def load_trace():
    try:
        with open(TRACE_LOG, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except:
        return {"cycles": []}

def save_trace(trace):
    with open(TRACE_LOG, "w", encoding="utf-8") as f:
        yaml.dump(trace, f)

def behavior_cycle():
    suggestion = run_scaffold()
    action_taken = suggestion["suggested_action"]  # In a full loop, this could diverge

    log_suggestion(suggestion, action_taken)

    trace = load_trace()
    trace["cycles"].append({
        "timestamp": datetime.now().isoformat(),
        "suggested": suggestion["suggested_action"],
        "executed": action_taken,
        "emotion": suggestion["emotional_state"],
        "intensity": suggestion["intensity"]
    })
    save_trace(trace)

    modulate_emotion(trace)

if __name__ == "__main__":
    behavior_cycle()
