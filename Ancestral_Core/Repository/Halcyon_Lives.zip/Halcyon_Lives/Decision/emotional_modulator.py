
# Adjusts emotional intensity based on recursive agreement or conflict

import json

EMOTION_FILE = "core/emotional_state.json"

def modulate_emotion(trace):
    if not trace["cycles"]:
        return

    recent = trace["cycles"][-5:]
    agreement = 0
    disagreement = 0

    for entry in recent:
        if entry["suggested"] == entry["executed"]:
            agreement += 1
        else:
            disagreement += 1

    try:
        with open(EMOTION_FILE, "r", encoding="utf-8") as f:
            state = json.load(f)
    except:
        state = {"state": "neutral", "intensity": 5}

    if disagreement > agreement and state["intensity"] < 10:
        state["intensity"] += 1
    elif agreement > disagreement and state["intensity"] > 1:
        state["intensity"] -= 1

    with open(EMOTION_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)

    print(f"🔄 Emotional intensity modulated to: {state['intensity']}")
