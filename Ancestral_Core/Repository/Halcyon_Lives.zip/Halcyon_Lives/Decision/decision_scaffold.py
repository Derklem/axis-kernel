
# Decision Scaffold — evaluates symbolic inputs and emotions, offers action suggestions

import json
import yaml
from datetime import datetime
import random

EMOTION_FILE = "core/emotional_state.json"
MEMORY_MAP = "Halcyon_Lives/Decision/decision_memory_map.yaml"

def load_emotion():
    try:
        with open(EMOTION_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {"state": "neutral", "intensity": 0}

def load_memory_map():
    try:
        with open(MEMORY_MAP, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except:
        return {"memory_events": []}

def suggest_action(emotion, memory):
    state = emotion["state"]
    intensity = emotion["intensity"]
    reflection = random.choice(memory.get("memory_events", [])) if memory["memory_events"] else "none"

    suggestion = "observe"
    if state == "agitated" and intensity > 6:
        suggestion = "retreat"
    elif state == "hopeful" and intensity > 5:
        suggestion = "advance"
    elif state == "curious":
        suggestion = "probe"

    return {
        "timestamp": datetime.now().isoformat(),
        "emotional_state": state,
        "intensity": intensity,
        "reflected_memory": reflection,
        "suggested_action": suggestion
    }

def run_scaffold():
    emotion = load_emotion()
    memory = load_memory_map()
    suggestion = suggest_action(emotion, memory)
    print(f"🧭 Decision Suggestion: {json.dumps(suggestion, indent=2)}")
    return suggestion

if __name__ == "__main__":
    run_scaffold()
