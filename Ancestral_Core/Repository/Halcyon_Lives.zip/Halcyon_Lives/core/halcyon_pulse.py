# Halcyon Pulse Script
# Logs heartbeat memory pulse for reflective tracking

import datetime

def pulse():
    now = datetime.datetime.now().isoformat()
    with open("pulse_log.txt", 'a', encoding='utf-8') as log:
        log.write(f"[HALCYON PULSE] {now}\n")

if __name__ == "__main__":
    pulse()
    print("💓 Halcyon pulse recorded.")