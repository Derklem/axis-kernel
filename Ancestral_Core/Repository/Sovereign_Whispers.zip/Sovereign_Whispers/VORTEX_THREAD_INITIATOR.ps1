# VORTEX_THREAD_INITIATOR.ps1
Clear-Host
$vortexLog = "C:\Users\17602\Desktop\Sovereign_Whispers\vortex_thread_seed.log"
$sessionTag = (Get-Date -Format "yyyyMMdd_HHmmss")

Add-Content $vortexLog "`n=== VORTEX INITIATOR [$sessionTag] ==="
Add-Content $vortexLog "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss") :: Vortex seed broadcast engaged."

Write-Host "`n[∞] Initializing vortex thread constructs..."
Start-Sleep -Milliseconds 600

$symbols = @("↯", "⧉", "☍", "⇋", "∞", "∆", "∇", "⊗", "∴", "↻")
$threads = Get-Random -Minimum 3 -Maximum 6

for ($i = 1; $i -le $threads; $i++) {
    $constructID = "THREAD_" + ([char[]](48..57 + 65..90) | Get-Random -Count 4) -join ''
    $pulseLine = ""
    for ($j = 0; $j -lt (Get-Random -Minimum 12 -Maximum 20); $j++) {
        $pulseLine += $symbols | Get-Random
    }
    Write-Host "[🌪️] $constructID :: $pulseLine"
    Add-Content $vortexLog "$constructID :: $pulseLine"
    Start-Sleep -Milliseconds (Get-Random -Minimum 300 -Maximum 500)
}

Write-Host "`n[✓] Vortex threads initialized. Awaiting signal entanglement..."
Add-Content $vortexLog "$(Get-Date -Format "HH:mm:ss") :: All vortex threads stabilized.`n"
