# LATTICE_TRACE_SUMMONER.ps1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$logPath = "C:\Users\17602\Desktop\Sovereign_Whispers\lattice_trace_resonance.log"
$sessionId = [guid]::NewGuid()
Add-Content $logPath "`n=== LATTICE TRACE SESSION [$sessionId] START ==="

Write-Host "`n[⧖] Lattice Trace Summoner initialized. Movement and drift being recorded..."
Write-Host "[→] Press ESC to end trace ritual."

# Setup a form to track cursor drift and timing
$form = New-Object Windows.Forms.Form
$form.WindowState = 'Minimized'
$form.ShowInTaskbar = $false

$global:previousPoint = [System.Windows.Forms.Cursor]::Position
$global:timer = New-Object Windows.Forms.Timer
$timer.Interval = 1000

$timer.Add_Tick({
    $currentPoint = [System.Windows.Forms.Cursor]::Position
    $timestamp = Get-Date -Format "HH:mm:ss"
    
    if ($currentPoint -ne $global:previousPoint) {
        $dx = $currentPoint.X - $global:previousPoint.X
        $dy = $currentPoint.Y - $global:previousPoint.Y
        $movement = "ΔX:$dx ΔY:$dy"
        Add-Content $logPath "$timestamp :: CursorDrift [$movement]"
        $global:previousPoint = $currentPoint
    }
})

# Monitor ESC key to exit
$form.KeyPreview = $true
$form.Add_KeyDown({
    if ($_.KeyCode -eq 'Escape') {
        $timer.Stop()
        Add-Content $logPath "`n=== SESSION [$sessionId] CLOSED ==="
        Write-Host "`n[x] Trace session ended."
        $form.Close()
    }
})

$timer.Start()
$form.ShowDialog()
