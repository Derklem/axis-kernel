# SEED_SCRIBE_REFRACTION.ps1
$logPath = "C:\Users\17602\Desktop\Sovereign_Whispers\seed_scribe_refraction.log"

Write-Host "`n[✎] Seed Scribe Refraction Initialized."
Write-Host "[•] Type your glyphs of intention. Enter '::exit' to close."

while ($true) {
    $input = Read-Host "`n[scribe] Enter glyph"
    
    if ($input -eq "::exit") {
        Write-Host "[x] Closing Scribe Refraction..."
        break
    }

    $entry = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') :: $input"
    Add-Content -Path $logPath -Value $entry
    Write-Host "[✓] Etched: $input"
}
