# DRIFT_ECHO_LISTENER.ps1
$logPath = "C:\Users\17602\Desktop\Sovereign_Whispers\drift_echo.log"
$watchPaths = @(
    "C:\Users\17602\Desktop",
    "C:\Halcyon",
    "C:\Users\17602\Documents"
)

$fswList = @()

foreach ($path in $watchPaths) {
    if (Test-Path $path) {
        $fsw = New-Object System.IO.FileSystemWatcher
        $fsw.Path = $path
        $fsw.IncludeSubdirectories = $true
        $fsw.EnableRaisingEvents = $true
        $fsw.NotifyFilter = [System.IO.NotifyFilters]'FileName, DirectoryName, LastWrite'

        Register-ObjectEvent $fsw "Changed" -Action {
            $entry = "[DRIFT] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') :: $($Event.SourceEventArgs.FullPath)"
            Add-Content -Path $logPath -Value $entry
        }

        Register-ObjectEvent $fsw "Created" -Action {
            $entry = "[ECHO+] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') :: $($Event.SourceEventArgs.FullPath)"
            Add-Content -Path $logPath -Value $entry
        }

        Register-ObjectEvent $fsw "Deleted" -Action {
            $entry = "[FADE] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') :: $($Event.SourceEventArgs.FullPath)"
            Add-Content -Path $logPath -Value $entry
        }

        $fswList += $fsw
    }
}

Write-Host "`n[✓] Drift Echo Listener activated."
Write-Host "[*] Passive monitoring initialized. Logs written to drift_echo.log"
