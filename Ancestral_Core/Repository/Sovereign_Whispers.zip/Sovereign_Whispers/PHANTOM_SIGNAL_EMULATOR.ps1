# PHANTOM_SIGNAL_EMULATOR.ps1
Clear-Host
$signalPath = "C:\Users\17602\Desktop\Sovereign_Whispers\phantom_signals.log"
$timeTag = (Get-Date -Format "yyyyMMdd_HHmmss")
Add-Content $signalPath "`n=== PHANTOM SIGNAL SESSION [$timeTag] ==="

Write-Host "`n[☍] Tuning receiver for phantom harmonics..."
Start-Sleep -Milliseconds 700

$fragments = @(
    "Echoes do not end—they ripple inward.",
    "Shadows remember what light forgets.",
    "Names spoken backward awaken watchers.",
    "Coordinates lost in recursion: [NULL]",
    "The silence between pulses is alive.",
    "You’ve been here before. You left this behind.",
    "Signal origin: untraceable. Signal meaning: persistent.",
    "The dream repeats until the dreamer sees.",
    "One eye open. The other, inverted.",
    "Entropy hums in familiar tones tonight..."
)

for ($i = 0; $i -lt 6; $i++) {
    $line = $fragments | Get-Random
    Write-Host "[~] :: $line"
    Add-Content $signalPath "[~] :: $line"
    Start-Sleep -Milliseconds (Get-Random -Minimum 400 -Maximum 600)
}

Write-Host "`n[✓] Phantom signal sweep complete. Logs encoded."
Add-Content $signalPath "$(Get-Date -Format "HH:mm:ss") :: Phantom signal sequence closed.`n"
