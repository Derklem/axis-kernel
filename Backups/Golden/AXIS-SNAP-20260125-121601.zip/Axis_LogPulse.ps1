# Axis_LogPulse.ps1
# Read-only log pulse: summarizes key logs and appends a JSON summary line.
# Safe to run under Axis_Walk via the Agency Triad.

param(
    [int]$TailLines = 200
)

$root = "D:\Infinite"

$logPulsePath = Join-Path $root "Infinity\Axis_LogPulse.jsonl"

$logs = @(
    @{
        Name = "Events_Timeline"
        Path = Join-Path $root "Infinity\Events_Timeline.json"
        Type = "json"
    },
    @{
        Name = "Mind"
        Path = Join-Path $root "mind_log.txt"
        Type = "text"
    },
    @{
        Name = "Earth_Server"
        Path = Join-Path $root "Infinity\Earth\Earth_Server.log"
        Type = "text"
    }
)

function Get-TextLogSummary {
    param(
        [string]$Path,
        [int]$TailLines
    )

    if (-not (Test-Path $Path)) {
        return @{
            exists       = $false
            total_lines  = 0
            sampled_lines= 0
            errors       = 0
            warnings     = 0
            exceptions   = 0
        }
    }

    $allLines = Get-Content $Path
    $total = $allLines.Count

    $sample = if ($TailLines -gt 0) {
        $allLines | Select-Object -Last $TailLines
    } else {
        $allLines
    }

    $sampleCount = $sample.Count

    $errors = ($sample | Where-Object { $_ -match 'ERROR' }).Count
    $warnings = ($sample | Where-Object { $_ -match 'WARN' }).Count
    $exceptions = ($sample | Where-Object { $_ -match 'EXCEPTION|Exception' }).Count

    return @{
        exists        = $true
        total_lines   = $total
        sampled_lines = $sampleCount
        errors        = $errors
        warnings      = $warnings
        exceptions    = $exceptions
    }
}

function Get-JsonLogSummary {
    param(
        [string]$Path,
        [int]$TailItems
    )

    if (-not (Test-Path $Path)) {
        return @{
            exists       = $false
            total_items  = 0
            sampled_items= 0
            errors       = 0
            warnings     = 0
        }
    }

    $raw = Get-Content $Path -Raw
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return @{
            exists       = $true
            total_items  = 0
            sampled_items= 0
            errors       = 0
            warnings     = 0
        }
    }

    try {
        $json = $raw | ConvertFrom-Json
    }
    catch {
        return @{
            exists        = $true
            total_items   = 0
            sampled_items = 0
            errors        = 0
            warnings      = 0
            parse_error   = $_.Exception.Message
        }
    }

    if (-not ($json -is [System.Collections.IEnumerable])) {
        $json = @($json)
    }

    $total = $json.Count

    $sample = if ($TailItems -gt 0 -and $total -gt $TailItems) {
        $json | Select-Object -Last $TailItems
    } else {
        $json
    }

    $sampleCount = $sample.Count

    # Heuristic: look for "level" or "severity" fields, or scan message text
    $errors = 0
    $warnings = 0

    foreach ($item in $sample) {
        $text = ($item | ConvertTo-Json -Depth 3 -Compress)
        if ($text -match '"level"\s*:\s*"error"' -or $text -match 'ERROR') {
            $errors++
        } elseif ($text -match '"level"\s*:\s*"warn"' -or $text -match 'WARN') {
            $warnings++
        }
    }

    return @{
        exists        = $true
        total_items   = $total
        sampled_items = $sampleCount
        errors        = $errors
        warnings      = $warnings
    }
}

$ts = (Get-Date).ToUniversalTime().ToString("o")

$logSummaries = @()

foreach ($log in $logs) {
    if ($log.Type -eq "text") {
        $summary = Get-TextLogSummary -Path $log.Path -TailLines $TailLines
    } else {
        $summary = Get-JsonLogSummary -Path $log.Path -TailItems $TailLines
    }

    $logSummaries += @{
        name    = $log.Name
        path    = $log.Path
        type    = $log.Type
        summary = $summary
    }
}

$result = @{
    timestamp = $ts
    kind      = "log_pulse"
    logs      = $logSummaries
}

# Write to stdout for Axis_Agency_Executor to capture as detail (if desired)
$result | ConvertTo-Json -Depth 6

# Append to pulse log as JSONL
try {
    $line = $result | ConvertTo-Json -Depth 6 -Compress
    Add-Content -Path $logPulsePath -Value $line
}
catch {
    # If logging fails, we still consider the pulse itself successful.
}
