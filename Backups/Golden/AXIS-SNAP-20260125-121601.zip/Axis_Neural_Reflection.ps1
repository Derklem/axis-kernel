<#
.SYNOPSIS
    Phase 123 - Neural Reflection (Sovereign Pruning)
.DESCRIPTION
    Proactively analyzes Treaty Dissonance and Shadow Risk to generate
    clean-up (Pruning) or unification (Harmonization) proposals.
    
    Output: Writes to D:\Infinite\Infinity\Governance\Neural_Proposals.json
#>

param(
    [string]$LedgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json",
    [string]$RiskPath = "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json",
    [string]$ProposalPath = "D:\Infinite\Infinity\Governance\Neural_Proposals.json"
)

$ErrorActionPreference = "Stop"

function New-ReflectionProposal {
    param($Type, $Target, $Reason, $Severity, $Explanation)
    return [ordered]@{
        id          = "PROP-REFLECT-$(Get-Date -Format 'yyyyMMddHHmmss')-$(Get-Random -Minimum 1000 -Maximum 9999)"
        timestamp   = (Get-Date).ToUniversalTime().ToString("o")
        type        = $Type
        target      = $Target
        reason      = $Reason
        severity    = $Severity
        explanation = if ($Explanation) { $Explanation } else { $Reason }
        status      = "pending_ratification"
        origin      = "Axis_Neural_Reflection"
    }
}

function Invoke-NeuralReflection {
    Write-Host "[NEURAL-REFLECT] Initiating cognitive scan for legal optimization..." -ForegroundColor Cyan
    
    $proposals = @()

    # 1. Treaty Dissonance analysis
    if (Test-Path $LedgerPath) {
        $ledger = Get-Content $LedgerPath -Raw | ConvertFrom-Json
        $dissonance = @($ledger.treaties) | Where-Object { $_.status -eq "dissonance" }
        
        foreach ($d in $dissonance) {
            Write-Host "[NEURAL-REFLECT] Found dissonance on $($d.rule_id)." -ForegroundColor Yellow
            $proposals += New-ReflectionProposal `
                -Type "treaty_harmonization" `
                -Target $d.rule_id `
                -Reason "Treaty Dissonance detected. Rule IDs must be synchronized across federated nodes." `
                -Severity "high"
        }
    }

    # 2. Risk Pruning
    if (Test-Path $RiskPath) {
        try {
            $risk = Get-Content $RiskPath -Raw | ConvertFrom-Json
            # Check bands
            if ($risk.summary.bands) {
                $bands = $risk.summary.bands
                # Handle possible PSCustomObject vs Hashtable
                $keys = if ($bands.PSObject) { $bands.PSObject.Properties.Name } else { $bands.Keys }
                
                foreach ($k in $keys) {
                    $score = $bands.$k
                    if ($score -gt 0.7) {
                        Write-Host "[NEURAL-REFLECT] High risk in band '$k' ($score)." -ForegroundColor Red
                        # Heuristic: If risk is high, propose pruning low-value strategies in that band?
                        # For now, generic pruning proposal.
                        $proposals += New-ReflectionProposal `
                            -Type "doctrine_pruning" `
                            -Target "BAND-$k" `
                            -Reason "Persistent high risk in '$k' sector. Recommend pruning complexity or restrictive amendment." `
                            -Severity "critical"
                    }
                }
            }
        }
        catch {
            Write-Warning "Failed to parse Risk Index: $_"
        }
    }

    if ($proposals.Count -eq 0) {
        Write-Host "[NEURAL-REFLECT] No structural optimizations found." -ForegroundColor Green
        return
    }

    # Load existing proposals
    $existing = @()
    if (Test-Path $ProposalPath) {
        try {
            $json = Get-Content $ProposalPath -Raw | ConvertFrom-Json
            if ($json.proposals) { $existing = @($json.proposals) }
        }
        catch {}
    }

    $newCount = 0
    # Dedup
    foreach ($p in $proposals) {
        # Simple check: ignore if we already have a pending proposal for this target/type
        $dup = $existing | Where-Object { $_.target -eq $p.target -and $_.type -eq $p.type -and $_.status -eq "pending_ratification" }
        if (-not $dup) {
            $existing += $p
            Write-Host "[NEURAL-REFLECT] Generated proposal: $($p.id) ($($p.type))" -ForegroundColor Magenta
            $newCount++
        }
    }

    if ($newCount -eq 0) {
        $pendingCount = (@($existing) | Where-Object { $_.status -eq "pending_ratification" }).Count
        if ($pendingCount -gt 0) {
            Write-Host "[NEURAL-REFLECT] No new optimizations found; $pendingCount existing proposals remain pending (view with PROPOSALS)." -ForegroundColor Yellow
        }
        else {
            Write-Host "[NEURAL-REFLECT] No structural optimizations found." -ForegroundColor Green
        }
    }
    else {
        Write-Host "[NEURAL-REFLECT] Generated $newCount new proposals. View with PROPOSALS." -ForegroundColor Cyan
    }

    # Save
    $data = @{
        version             = 1
        last_reflection_utc = (Get-Date).ToUniversalTime().ToString("o")
        proposals           = $existing
    }
    
    # Ensure dir
    $dir = Split-Path $ProposalPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    
    $data | ConvertTo-Json -Depth 10 | Set-Content $ProposalPath -Encoding UTF8
}

if ($MyInvocation.PSScriptRoot -ne "") {
    Invoke-NeuralReflection
}
