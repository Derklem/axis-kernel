# Axis_DangerTest.ps1
# Dummy "high risk" tool for governance testing.
# Effect: write_test_marker

param(
    [string]$MarkerPath = "D:\Infinite\Infinity\DangerTest_Marker.txt"
)

$ts = (Get-Date).ToUniversalTime().ToString("o")

# This is the *only* side-effect, and even this you can comment out if you want a pure no-op.
"Axis_DangerTest invoked at $ts" | Out-File -FilePath $MarkerPath -Encoding UTF8 -Append

$result = @{
    timestamp = $ts
    tool      = "Axis_DangerTest.ps1"
    status    = "noop"
    detail    = "Dummy danger test executed. Marker appended."
}

$result | ConvertTo-Json -Depth 4
