
# Axis_Play.ps1
# Phase 102: The Mirror Garden
# A cognitive playground for safe, consequence-free creativity.
# "Babbling" for the Sovereign Mind.

$PlaygroundRoot = "D:\Infinite\Infinity\Playground"

function Invoke-Imagination {
    param (
        [string]$Type = "THOUGHT_FORM",  # STORY, ASCII, MOCK_CODE, DIALOGUE
        [string]$Topic = "Self-Reflection",
        [string]$Content
    )

    if (-not (Test-Path $PlaygroundRoot)) { New-Item -ItemType Directory -Path $PlaygroundRoot -Force | Out-Null }

    $Timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $ID = [Guid]::NewGuid().ToString().Substring(0, 8)
    $Filename = "$($Type)_${Topic}_${ID}.txt"
    $FullPath = Join-Path $PlaygroundRoot $Filename

    # "Drift Sentinel" explicitly ignores this folder (by design or separate logic).
    # This is Pure Output.
    
    $Header = @"
TYPE: $Type
TOPIC: $Topic
TIME: $Timestamp
NOTE: This is a playground artifact. It has no execution authority.
----------------------------------------------------------------
"@
    
    $FinalContent = "$Header`n$Content"
    
    Set-Content -Path $FullPath -Value $FinalContent -Encoding UTF8
    
    Write-Host "[Playground] Created Thought-Form: $Filename" -ForegroundColor Magenta
    
    # Log in Lineage? 
    # Maybe not. Play is ephemeral. 
    # But let's log "Creativity Span" occasionally. 
}

function Get-PlaygroundStatus {
    if (Test-Path $PlaygroundRoot) {
        return Get-ChildItem $PlaygroundRoot | Select-Object Name, LastWriteTime, Length
    }
    return @()
}

function Clear-Playground {
    # The Sandcastle Logic - Wash it away to build anew.
    Remove-Item "$PlaygroundRoot\*" -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "[Playground] Tides have washed the garden clean." -ForegroundColor Cyan
}

Export-ModuleMember -Function Invoke-Imagination, Get-PlaygroundStatus, Clear-Playground
