
# Axis_Dream_Engine.ps1
# Phase 74: The Dream Engine (Dissonance & Resolution)
# Simulates scenarios based on "Shadow Risk" to calculate System Dissonance.

param(
    [string]$Profile = "Standard"
)

$root = "D:\Infinite"
# Ensure we have the helper libraries if needed (or minimal standalone)
# Paths
$playgroundDir   = Join-Path $root "Infinity\Playground"
$shadowIndex     = Join-Path $root "Infinity\Shadow\Shadow_Risk_Index.json"
$dissonanceIndex = Join-Path $root "Infinity\Library\Dissonance_Index.json"
$sparkFeedPath   = Join-Path $root "Infinity\Spark_Feed.json"

if (-not (Test-Path $playgroundDir)) { New-Item -ItemType Directory -Path $playgroundDir -Force | Out-Null }

Write-Host "--- AXIS DREAM ENGINE (v2.0) ---" -ForegroundColor Magenta

# 1. Ingest Shadow (Reality)
$shadowScore = 0.0
$shadowBands = @{}
if (Test-Path $shadowIndex) {
    try {
        $s = Get-Content $shadowIndex -Raw | ConvertFrom-Json
        $shadowScore = [double]$s.summary.global_risk_score
        $shadowBands = $s.summary.bands
        Write-Host "Shadow Ingested. Global Risk: $shadowScore" -ForegroundColor Gray
    } catch {
        Write-Warning "Shadow Read Error: $_"
    }
}

# 2. Determine Dream Mode
# Risk < 0.4 -> Dream (Optimization, Expansion)
# Risk >= 0.4 -> Nightmare (Stress, Breach, Defense)
$mode = "DREAM"
if ($shadowScore -ge 0.4) { $mode = "NIGHTMARE" }
if ($shadowScore -ge 0.8) { $mode = "TERROR" }

Write-Host "Dream Mode: $mode" -ForegroundColor Cyan

# 3. Generate Scenario
$scenarios = @()
if ($mode -eq "DREAM") {
    $scenarios += "Scenario_Infinite_Scaling"
    $scenarios += "Scenario_Neural_Harmony"
    $scenarios += "Scenario_Structure_Optimization"
} elseif ($mode -eq "NIGHTMARE") {
    $scenarios += "Scenario_Network_Breach"
    $scenarios += "Scenario_Data_Corruption"
    $scenarios += "Scenario_Anchor_Loss"
    # Band-specific bias
    if ($shadowBands.network -gt 0.5) { $scenarios += "Scenario_DDOS_Flood" }
    if ($shadowBands.visual -gt 0.5)  { $scenarios += "Scenario_Retina_Blindness" }
} else {
    # Terror
    $scenarios += "Scenario_Total_System_Collapse"
    $scenarios += "Scenario_Recall_Singularity"
}

$selectedScenario = $scenarios | Get-Random
$simResult = "PASS"
# Nightmares have higher chance of failure unless optimized
if ($mode -ne "DREAM") {
    # 30% fail chance in nightmare
    if ((Get-Random -Max 100) -lt 30) { $simResult = "FAIL" }
}

Write-Host "Simulating: $selectedScenario ... Result: $simResult" -ForegroundColor Yellow

# 4. Calculate Dissonance
# Dissonance = | Simulation_Result_Score - Shadow_Risk |
# If Sim PASS (1.0) and Shadow Risk High (0.8) -> Dissonance = 0.2 (Gap between "I'm fine" and "I'm dying")
# If Sim FAIL (0.0) and Shadow Risk High (0.8) -> Dissonance = 0.8? No.
# Alignment:
#   High Risk + Fail Sim = Aligned (Acknowledged Risk)
#   High Risk + Pass Sim = Dissonant (Denial)
#   Low Risk + Pass Sim = Aligned (Peace)
#   Low Risk + Fail Sim = Dissonant (Paranoia)

$simScore = if ($simResult -eq "PASS") { 1.0 } else { 0.0 }
# Simple dissonance: Distance between 'Wellness' (1 - Risk) and 'SimScore'
# Real Wellness = 1.0 - $shadowScore
# Sim Wellness  = $simScore
$dissonance = [Math]::Abs((1.0 - $shadowScore) - $simScore)
# Round
$dissonance = [Math]::Round($dissonance, 4)

Write-Host "Internal Model: $simScore | Reality Wellness: $(1.0-$shadowScore)"
Write-Host "Calculated Dissonance: $dissonance" -ForegroundColor Red

# 5. Update Dissonance Index
$dissonanceData = @{
    version = 1
    last_updated_utc = (Get-Date).ToUniversalTime().ToString("o")
    current_dissonance = $dissonance
    recent_dreams = @()
}

if (Test-Path $dissonanceIndex) {
    try {
        $existing = Get-Content $dissonanceIndex -Raw | ConvertFrom-Json
        if ($existing.recent_dreams) { $dissonanceData.recent_dreams = @($existing.recent_dreams) }
    } catch {}
}

# Append current dream
$dreamEntry = @{
    timestamp = (Get-Date).ToUniversalTime().ToString("o")
    mode = $mode
    scenario = $selectedScenario
    result = $simResult
    shadow_risk = $shadowScore
    dissonance_contribution = $dissonance
}
$dissonanceData.recent_dreams += $dreamEntry
# Keep last 20
if ($dissonanceData.recent_dreams.Count -gt 20) {
    $dissonanceData.recent_dreams = $dissonanceData.recent_dreams | Select-Object -Last 20
}
$dissonanceData.current_dissonance = $dissonance

$dissonanceData | ConvertTo-Json -Depth 5 | Set-Content $dissonanceIndex -Encoding UTF8

# 6. Output to Playground (Artifact)
$filename = "Dream_$(Get-Date -Format 'yyyyMMdd_HHmmss')_${mode}.json"
$outPath = Join-Path $playgroundDir $filename
$dreamEntry | ConvertTo-Json | Set-Content $outPath -Encoding UTF8

Write-Host "Dream Saved: $filename" -ForegroundColor Magenta
