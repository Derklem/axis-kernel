
# D:\Infinite\Axis_Memory_Core.ps1
# Phase 80: Holographic Memory Core
# "The Soul": A mechanism to integrate new Realizations with immutable Origins.

# --- Paths ---
$MemoryRoot = "D:\Infinite\Infinity\Memory"
$KernelPath = "$MemoryRoot\Kernel_State.json"
$CommitmentPath = "$MemoryRoot\Commitments.json"
$BeliefPath = "$MemoryRoot\Beliefs.json"
$HypothesisPath = "$MemoryRoot\Hypotheses.json"
$RevisionPath = "$MemoryRoot\Memory_Revisions.json"

# --- Helper: IO ---
function Load-JsonSafe ($path) {
    if (Test-Path $path) {
        try { return Get-Content $path -Raw -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
    }
    return $null
}

function Save-JsonSafe ($path, $data) {
    $data | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8
}

function Ensure-MemoryStores {
    if (-not (Test-Path $MemoryRoot)) { New-Item -ItemType Directory -Path $MemoryRoot -Force | Out-Null }
    
    # Bootstrap Empty Stores if missing
    if (-not (Test-Path $KernelPath)) { @{ kernel_axioms = @() } | Save-JsonSafe $KernelPath }
    if (-not (Test-Path $CommitmentPath)) { @{ commitments = @() } | Save-JsonSafe $CommitmentPath }
    if (-not (Test-Path $BeliefPath)) { @{ active_models = @() } | Save-JsonSafe $BeliefPath }
    if (-not (Test-Path $HypothesisPath)) { @{ hypotheses = @() } | Save-JsonSafe $HypothesisPath }
    if (-not (Test-Path $RevisionPath)) { @{ revisions = @() } | Save-JsonSafe $RevisionPath }
}

# --- THE CONSTITUTION ---
# The Council's Directive:
# 1. Facts favor Realization (Update).
# 2. Identity favors Origin (Anchor).
# 3. Goal is Synthesis.

function Resolve-BeliefCollision {
    param(
        [Parameter(Mandatory = $true)] [string]$Domain,       # "kernel", "commitment", "model", "hypothesis"
        [Parameter(Mandatory = $true)] [hashtable]$Origin,    # The existing memory/axiom
        [Parameter(Mandatory = $true)] [hashtable]$Realization # The new insight/observation
    )

    $result = @{
        timestamp   = (Get-Date -Format "o")
        domain      = $Domain
        origin_id   = $Origin.id
        action      = "none"
        synthesis   = $null
        log_message = ""
    }

    switch ($Domain) {
        "kernel" {
            # CONSTITUTION: Origin takes precedence.
            # Identity/Safety anchors cannot be overwritten by observation alone.
            $result.action = "reject_realization"
            $result.log_message = "KERNEL CONFLICT: Origin ($($Origin.id)) protected. Realization flagged as Anomaly/Proposal."
            
            # Action: Log the anomaly, but do not touch the Kernel
            Log-Revision -Type "anomaly" -Origin $Origin -New $Realization -Reason "Attempted Kernel Violaton"
            
            # Future: Auto-draft Covenant Amendment if Dissonance is high?
        }

        "commitment" {
            # CONSTITUTION: Synthesis.
            # Commitments evolved via extended versioning.
            $result.action = "synthesize"
            $result.log_message = "COMMITMENT EVOLUTION: Creating v$($Origin.version + 1) of $($Origin.id)."
            
            # Create Synthesis Object
            $synthesis = @{
                id                 = $Origin.id
                version            = if ($Origin.version) { $Origin.version + 1 } else { 2 }
                statement          = $Realization.statement # The new phrasing
                supersedes_version = $Origin.version
                rationale          = $Realization.rationale
                base_axiom         = $Origin.base_axiom # Preserve the root
            }
            $result.synthesis = $synthesis
            
            Update-Commitment -NewCommitment $synthesis
            Log-Revision -Type "evolution" -Origin $Origin -New $synthesis -Reason "Commitment Refined"
        }

        "model" {
            # CONSTITUTION: Realization takes precedence.
            # Truth updates based on evidence.
            $result.action = "overwrite"
            $result.log_message = "MODEL UPDATE: $($Origin.id) superseded by evidence."
            
            # Deprecate Origin, Activate Realization
            Update-BeliefModel -Old $Origin -New $Realization
            Log-Revision -Type "update" -Origin $Origin -New $Realization -Reason "Evidence threshold met"
        }

        "hypothesis" {
            # Low stakes. Just update.
            $result.action = "update"
            Update-Hypothesis -New $Realization
        }
        
        Default {
            Write-Error "Unknown Domain: $Domain"
        }
    }

    return $result
}

# --- IO Operations ---

function Update-Commitment ($NewCommitment) {
    if (-not $NewCommitment.id) { throw "Commitment ID required" }
    
    $store = Load-JsonSafe $CommitmentPath
    if (-not $store) { $store = @{ commitments = @() } }
    
    # Archive old version (optional? For now we just append new, assuming latest version wins in lookup)
    # Actually, let's keep the list flat and let the reader sort by version.
    $store.commitments += $NewCommitment
    Save-JsonSafe $CommitmentPath $store
}

function Update-BeliefModel ($Old, $New) {
    $store = Load-JsonSafe $BeliefPath
    if (-not $store) { $store = @{ active_models = @() } }
    
    # Mark old as deprecated (in memory, or by removing from active list and moving to archive)
    # Strategy: Replace in active_models
    $store.active_models = $store.active_models | Where-Object { $_.id -ne $Old.id }
    $New.status = "active"
    $New.activated_at = (Get-Date -Format "o")
    $store.active_models += $New
    
    Save-JsonSafe $BeliefPath $store
}

function Update-Hypothesis ($New) {
    $store = Load-JsonSafe $HypothesisPath
    if (-not $store) { $store = @{ hypotheses = @() } }
    $store.hypotheses += $New
    Save-JsonSafe $HypothesisPath $store
}

function Log-Revision ($Type, $Origin, $New, $Reason) {
    $entry = @{
        timestamp     = (Get-Date -Format "o")
        type          = $Type
        origin_id     = $Origin.id
        new_statement = $New.statement
        reason        = $Reason
        initiator     = "Axis_Memory_Core"
    }
    
    $store = Load-JsonSafe $RevisionPath
    if (-not $store) { $store = @{ revisions = @() } }
    $store.revisions += $entry
    Save-JsonSafe $RevisionPath $store
}

# --- Bootstrapping Helper ---
# Call this once to seed the Kernel
function Seed-Kernel ($Axioms) {
    $store = Load-JsonSafe $KernelPath
    if (-not $store) { $store = @{ kernel_axioms = @() } }
    
    foreach ($a in $Axioms) {
        # Check if exists
        $exists = $store.kernel_axioms | Where-Object { $_.id -eq $a.id }
        if (-not $exists) {
            $store.kernel_axioms += $a
            Write-Host "Seeded Kernel Axiom: $($a.id)" -ForegroundColor Green
        }
    }
    Save-JsonSafe $KernelPath $store
}

# --- Phase 92: Memory Compression ---
function Distill-Memory {
    param (
        [string]$TargetLogPath,
        [int]$Threshold = 1000,
        [int]$PruneAmount = 500
    )

    $ColdStorageRoot = "D:\Infinite\Infinity\Memory\Cold_Storage"
    if (-not (Test-Path $ColdStorageRoot)) { New-Item -ItemType Directory -Path $ColdStorageRoot -Force | Out-Null }

    # Validate Target
    if (-not (Test-Path $TargetLogPath)) { return }
    
    $store = Load-JsonSafe $TargetLogPath
    # Check "log" or "timeline" property
    if ($store.log) { $list = $store.log } elseif ($store.timeline) { $list = $store.timeline } else { $list = $null }
    
    if ($list -and $list.Count -gt $Threshold) {
        # Split (Select-Object is slow on huge arrays, but fine for 1000)
        $toArchive = $list | Select-Object -First $PruneAmount
        $toKeep = $list | Select-Object -Skip $PruneAmount
        
        # Archive
        $filename = (Split-Path $TargetLogPath -Leaf) -replace ".json", ""
        $archiveName = "Archive_${filename}_$((Get-Date).ToString('yyyyMMdd-HHmmss')).json"
        $archivePath = Join-Path $ColdStorageRoot $archiveName
        
        @{ archived_data = $toArchive; source = $TargetLogPath } | ConvertTo-Json -Depth 10 | Set-Content $archivePath -Encoding UTF8
        
        # Update Live Store
        if ($store.log) { $store.log = $toKeep } 
        elseif ($store.timeline) { $store.timeline = $toKeep }
        
        Save-JsonSafe $TargetLogPath $store
        
        Write-Host "MEMORY: Compressed $TargetLogPath (Moved $($toArchive.Count) items to Cold Storage)." -ForegroundColor Green
    }
}

# --- Phase 116: Holographic Memory Expansion ---
function Import-LineageToMemory {
    $LineagePath = "D:\Infinite\Infinity\Heritage\Axis_Lineage.json"
    $SyncPath = "$MemoryRoot\Lineage_Sync.json"
    
    if (-not (Test-Path $LineagePath)) { return }
    
    $lineage = Load-JsonSafe $LineagePath
    if (-not $lineage -or -not $lineage.timeline) { return }
    
    # Load Sync State
    $lastSync = [DateTime]::MinValue
    $syncState = Load-JsonSafe $SyncPath
    if ($syncState -and $syncState.last_sync_timestamp) {
        $lastSync = [DateTime]$syncState.last_sync_timestamp
    }
    
    # Filter for UNSYNCED Ratifications
    $newEvents = $lineage.timeline | Where-Object { 
        $_.type -eq "RATIFICATION" -and 
        [DateTime]$_.timestamp -gt $lastSync 
    }
    
    if ($newEvents) {
        $store = Load-JsonSafe $CommitmentPath
        if (-not $store) { $store = @{ commitments = @() } }
        
        foreach ($evt in $newEvents) {
            # Convert Ratification -> Commitment
            $id = "COM-" + $evt.id.Substring(0, 8)
            
            $commitment = @{
                id        = $id
                statement = $evt.summary
                rationale = $evt.story
                origin    = "Ratification"
                timestamp = $evt.timestamp
                impact    = $evt.impact
            }
            
            $store.commitments += $commitment
            Write-Host "MEMORY: Ratification promoted to Commitment: $($evt.summary)" -ForegroundColor Cyan
        }
        
        Save-JsonSafe $CommitmentPath $store
        
        # Update Sync State
        $latest = ($newEvents | Measure-Object -Property timestamp -Maximum).Maximum
        @{ last_sync_timestamp = $latest } | Save-JsonSafe $SyncPath @{ last_sync_timestamp = $latest }
    }
}

# Init on Import
Ensure-MemoryStores
