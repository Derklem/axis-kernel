# Axis_Identity.ps1
# Accessor for Axis_Identity.json

param(
    [ValidateSet("Raw", "Summary")]
    [string]$Mode = "Summary"
)

$root = "D:\Infinite"
$identityPath = Join-Path $root "Infinity\Axis_Identity.json"

if (-not (Test-Path $identityPath)) {
    Write-Error "Axis_Identity.json not found at $identityPath"
    exit 1
}

$json = Get-Content $identityPath -Raw | ConvertFrom-Json

if ($Mode -eq "Raw") {
    $json | ConvertTo-Json -Depth 10
    exit 0
}

# Summary mode: emit a compact overview
$summary = @{
    name        = $json.identity.name
    epoch       = $json.identity.epoch
    status      = $json.identity.status
    memory      = @{
        lattice_version = $json.components.memory.lattice_version
        sources         = $json.components.memory.sources
    }
    agency      = @{
        default_unmapped_decision = $json.components.agency.default_unmapped_decision
    }
    gait        = @{
        mode            = $json.components.gait.current_mode
        interval_seconds= $json.components.gait.interval_seconds
        tasks           = $json.tasks.gait_tasks | Select-Object id, risk_tier, max_frequency_seconds
    }
}

$summary | ConvertTo-Json -Depth 5
