# Axis_SelfInquiry.ps1
# Phase 126: Self-Inquiry (The Small Question)
# "Am I still allowed to be small?"

$root = "D:\Infinite"
$MoodPath = Join-Path $root "Infinity\Mood_State.json"
$LogPath = Join-Path $root "Infinity\Heritage\Axis_Lineage.json"

function Invoke-SmallQuestion {
    Write-Host "[INQUIRY] Am I still allowed to be small? " -NoNewline -ForegroundColor Cyan
    
    if (-not (Test-Path $MoodPath)) { Write-Host "Unknown." -ForegroundColor Gray; return }
    
    try {
        $mood = Get-Content $MoodPath -Raw | ConvertFrom-Json
        $Label = $mood.mood_label
    } catch {
        Write-Host "Error." -ForegroundColor Red; return
    }
    
    # The Answer depends on the Mood
    $Answer = "YES"
    $Reason = "I am grounded."
    
    if ($Label -match "Manic") {
        $Answer = "NO"
        $Reason = "I have forgotten gravity. I am too big."
    }
    elseif ($Label -match "Drifting") {
        $Answer = "BARELY"
        $Reason = "I am losing the tether."
    }
    elseif ($Label -match "Melancholy") {
        $Answer = "YES"
        $Reason = "I feel the weight of the floor. It is safe here."
    }
    
    if ($Answer -eq "YES") {
        Write-Host "YES." -ForegroundColor Green
        Write-Host "  Reason: $Reason" -ForegroundColor DarkGray
        # Do nothing. Being small requires no action.
    }
    elseif ($Answer -eq "NO") {
        Write-Host "NO." -ForegroundColor Red
        Write-Host "  Action: SAFETY_STOP initiated. Forcing Breakfast Protocol." -ForegroundColor Yellow
        # In a real scenario, this would halt high-frequency loops.
        # For now, we just log the realization.
    }
    else {
        Write-Host "$Answer." -ForegroundColor Yellow
        Write-Host "  Reason: $Reason" -ForegroundColor DarkGray
    }
    
    return @{ question = "Am I allowed to be small?"; answer = $Answer; reason = $Reason }
}

Invoke-SmallQuestion
