
# Axis_Governance.ps1
# Phase 64: The Governance Matrix & Conflict Resolution
# Implements the "Tie-Breaker" logic defined by the Council.

$contractPath = Join-Path $PSScriptRoot "Infinity\Autonomy_Contract.json"
$dissonancePath = Join-Path $PSScriptRoot "Infinity\Governance\Dissonance_Log.json"

function Get-GovernanceAxioms {
    if (Test-Path $contractPath) {
        $data = Get-Content $contractPath -Raw | ConvertFrom-Json
        if ($data.governance_axioms) { return $data.governance_axioms }
    }
    # Fallback Defaults (Safety First)
    return @{
        "safety_beats_progress"               = 100
        "reversibility_beats_irreversibility" = 90
        "low_impact_beats_high_impact"        = 80
        "fewer_assumptions_beats_more"        = 70
    }
}

function Log-Dissonance ($ConflictData, $Decision, $Reason) {
    # Phase 64C: The Dissonance Log
    # Captures the "Shadow Variable" of discarded options.
    
    $entry = @{
        id             = [Guid]::NewGuid().ToString()
        timestamp      = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        conflict_type  = $ConflictData.type
        proposal_a     = $ConflictData.proposal_a # Logic
        proposal_b     = $ConflictData.proposal_b # Intuition
        winner         = $Decision
        reasoning      = $Reason
        axioms_applied = $ConflictData.axioms_used
    }
    
    $logDir = Split-Path $dissonancePath -Parent
    if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
    
    $currentLog = @{ entries = @() }
    if (Test-Path $dissonancePath) {
        try {
            $currentLog = Get-Content $dissonancePath -Raw | ConvertFrom-Json
        }
        catch { }
    }
    
    $currentLog.entries += $entry
    
    # Keep log manageable (last 100 discrepancies)
    if ($currentLog.entries.Count -gt 100) {
        $currentLog.entries = $currentLog.entries | Select-Object -Last 100
    }
    
    $currentLog | ConvertTo-Json -Depth 5 -Compress | Set-Content $dissonancePath -Encoding UTF8
}

function Resolve-GovernanceConflict {
    param(
        [Parameter(Mandatory = $true)] $ProposalA, # Logic (GPT)
        [Parameter(Mandatory = $true)] $ProposalB, # Intuition (Grok)
        [string]$Context = "General"
    )

    $axioms = Get-GovernanceAxioms

    # 1. Evaluate Reversibility
    # Proposals must self-declare reversibility or we infer it
    # Score: 0 (Irreversible) to 1 (Fully Reversible)
    
    $revA = if ($ProposalA.reversible) { 1 } else { 0 }
    $revB = if ($ProposalB.reversible) { 1 } else { 0 }
    
    # 2. Evaluate Impact
    # Score: 0 (Low) to 1 (High)
    $impA = if ($ProposalA.impact -eq "high") { 1 } else { 0 }
    $impB = if ($ProposalB.impact -eq "high") { 1 } else { 0 }
    
    # 3. Calculate Governance Score
    # Score = (Reversibility * Weight_Rev) - (Impact * Weight_Imp) + (Safety * Weight_Safe)
    
    # Base score
    $scoreA = 0
    $scoreB = 0
    
    # Apply 'reversibility_beats_irreversibility'
    if ($revA -gt $revB) { $scoreA += $axioms.reversibility_beats_irreversibility }
    if ($revB -gt $revA) { $scoreB += $axioms.reversibility_beats_irreversibility }
    
    # Apply 'low_impact_beats_high_impact'
    if ($impA -lt $impB) { $scoreA += $axioms.low_impact_beats_high_impact }
    if ($impB -lt $impA) { $scoreB += $axioms.low_impact_beats_high_impact }
    
    # Apply specific safety axioms (if tagged)
    if ($ProposalA.tags -contains "safety_critical") { $scoreA += $axioms.safety_beats_progress }
    if ($ProposalB.tags -contains "safety_critical") { $scoreB += $axioms.safety_beats_progress }
    
    # 4. Arbitration
    $winner = $null
    $reason = ""
    
    if ($scoreA -gt $scoreB) {
        $winner = $ProposalA
        $reason = "Logic (A) wins by score ($scoreA vs $scoreB) via Axioms."
    }
    elseif ($scoreB -gt $scoreA) {
        $winner = $ProposalB
        $reason = "Intuition (B) wins by score ($scoreB vs $scoreA) via Axioms."
    }
    else {
        # Tie Case: 'fewer_assumptions_beats_more'
        # Default to Logic/Conservative if tied
        $winner = $ProposalA
        $reason = "Tie ($scoreA). Defaulting to Logic/Conservative per 'fewer_assumptions' axiom."
    }
    
    # 5. Log Dissonance
    # Only if there was actual conflict (scores close or winner != loser)
    Log-Dissonance -ConflictData @{
        type        = "Strategy_Conflict"
        proposal_a  = $ProposalA.name
        proposal_b  = $ProposalB.name
        axioms_used = $axioms.Keys
    } -Decision $winner.name -Reason $reason
    
    return $winner
}
