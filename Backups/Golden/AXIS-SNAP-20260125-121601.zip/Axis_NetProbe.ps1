function Measure-NetworkHealth {
    $Gateway = (Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway }).IPv4DefaultGateway.NextHop
    $Target = "8.8.8.8"
    
    Write-Host "--- AXIS NETWORK PROBE (SIGNAL INTELLIGENCE) ---" -ForegroundColor Cyan
    Write-Host "Target 1: Local Gateway ($Gateway)" -ForegroundColor Yellow
    Write-Host "Target 2: External DNS ($Target)" -ForegroundColor Yellow
    
    $results = @()
    
    for ($i = 1; $i -le 30; $i++) {
        $p1 = Test-Connection -ComputerName $Gateway -Count 1 -ErrorAction SilentlyContinue
        $p2 = Test-Connection -ComputerName $Target -Count 1 -ErrorAction SilentlyContinue
        
        $res = [PSCustomObject]@{
            Time        = (Get-Date).ToString("HH:mm:ss")
            Gateway_ms  = if ($p1) { $p1.ResponseTime } else { "TIMEOUT" }
            External_ms = if ($p2) { $p2.ResponseTime } else { "TIMEOUT" }
            Delta       = if ($p1 -and $p2) { $p2.ResponseTime - $p1.ResponseTime } else { "N/A" }
        }
        $results += $res
        
        $status = "OK"
        if ($res.Gateway_ms -eq "TIMEOUT") { $status = "LOCAL_DROP" }
        elseif ($res.External_ms -eq "TIMEOUT") { $status = "ISP_DROP" }
        
        $color = if ($status -eq "OK") { "Green" } else { "Red" }
        Write-Host "[$($res.Time)] GW: $($res.Gateway_ms)ms | EXT: $($res.External_ms)ms | ($status)" -ForegroundColor $color
        
        Start-Sleep -Milliseconds 500
    }
    
    return $results
}

Measure-NetworkHealth | Export-Csv "D:\Infinite\Infinity\Network_Intel_Report.csv" -NoTypeInformation
Write-Host "Intelligence Gathered. Report saved." -ForegroundColor Cyan
