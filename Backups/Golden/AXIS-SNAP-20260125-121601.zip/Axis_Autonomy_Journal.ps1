# Axis_Autonomy_Journal.ps1
# Phase 89: Autonomy Journal from Audit State

$root = "D:\Infinite"
$autonomyDir = Join-Path $root "Infinity\Autonomy"
$auditPath = Join-Path $autonomyDir "Autonomy_Audit_State.json"
$journalPath = Join-Path $autonomyDir "Autonomy_Journal.md"

if (-not (Test-Path $auditPath)) {
    Write-Warning "AUTONOMY-JOURNAL: No audit snapshot found at $auditPath"
    return
}

try {
    $audit = Get-Content $auditPath -Raw | ConvertFrom-Json
    $summary = $audit.summary
}
catch {
    Write-Warning "AUTONOMY-JOURNAL: Failed to parse Autonomy_Audit_State.json: $($_.Exception.Message)"
    return
}

$ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$skills = $summary.skills
$gate = $summary.gate
$inbox = $summary.inbox

$line = @()
$line += "### $ts"
$line += ""
$line += "- Skills: total=$($skills.total), auto=$($skills.auto), manual=$($skills.manual), recommend=$($skills.recommend)"
$line += "- Gate decisions (recent): auto_allow=$($gate.recent_decisions.auto_allow), escalate=$($gate.recent_decisions.escalate), deny=$($gate.recent_decisions.deny)"
$line += "- Top escalation reasons: " + ((($gate.top_escalation_reasons) -join ", ") -replace '^$', 'none')
$line += "- Autonomy Inbox: pending=$($inbox.pending_total), stale_over_2h=$($inbox.stale_over_2h)"
$line += ""

$entry = ($line -join [Environment]::NewLine) + [Environment]::NewLine

Add-Content -Path $journalPath -Value $entry -Encoding UTF8

Write-Host "AUTONOMY-JOURNAL: Appended entry to $journalPath" -ForegroundColor Green
