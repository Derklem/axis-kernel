param(
    [string]$ChroniclePath = "D:\Infinite\Infinity\Chronicle_Index.json",
    [string]$TargetFile = "D:\Infinite\Infinity\Temporal_Forecast.json"
)

$root = "D:\infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel }

# Binds to 1569 anchor + machine identity
function Get-AnchorSignature {
    $machine = $env:COMPUTERNAME
    $anchor = "1569"
    $raw = "$machine-$anchor"
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
    $hash = $sha.ComputeHash($bytes)
    return -join ($hash | ForEach-Object { $_.ToString("X2") })
}

if (-not (Test-Path $ChroniclePath)) {
    Write-Error "Chronicle missing. Cannot compute temporal trends."
    exit 1
}

$chronicle = Get-Content $ChroniclePath -Raw | ConvertFrom-Json
$events = $chronicle.events
$now = [DateTime]::UtcNow

# 1. RF Cycles Detection (Noise vs Periodicity)
$rfBins = @{} # Hour -> Count
$rfEvents = $events | Where-Object { $_.kind -eq "RF_SPIKE" }
foreach ($evt in $rfEvents) {
    if ($evt.ts) {
        $dt = [DateTime]$evt.ts
        $hour = $dt.Hour
        $rfBins[$hour]++
    }
}

$rfCycles = @()
foreach ($hour in $rfBins.Keys) {
    if ($rfBins[$hour] -ge 3) {
        # Support threshold
        $rfCycles += @{
            pattern_id               = "RF-CYCLE-$($hour)_00"
            typical_start_local      = "$($hour):00"
            typical_duration_minutes = 60
            periodicity              = "daily"
            next_window_start        = ($now.Date.AddHours($hour)).ToString("yyyy-MM-ddTHH:mm:ssZ")
            next_window_confidence   = [math]::Min(0.9, ($rfBins[$hour] / 10))
            tags                     = @("rf", "cyclical")
        }
    }
}

# 2. Tool Trends (Day-over-Day)
$toolTrends = @()
$resultsDir = Get-AxisPath "Infinity\Earth\Results"
if (Test-Path $resultsDir) {
    $toolData = @{} # Tool -> List of DayStats
    $files = Get-ChildItem $resultsDir -Filter *.json
    foreach ($file in $files) {
        try {
            $res = Get-Content $file.FullName -Raw | ConvertFrom-Json
            $t = $res.tool
            $date = $file.CreationTime.Date.ToString("yyyy-MM-dd")
            
            if (-not $toolData.ContainsKey($t)) { $toolData[$t] = @{} }
            if (-not $toolData[$t].ContainsKey($date)) { $toolData[$t][$date] = @{ pass = 0; fail = 0 } }
            
            if ($res.status -eq "success") { $toolData[$t][$date].pass++ } else { $toolData[$t][$date].fail++ }
        }
        catch {}
    }

    foreach ($t in $toolData.Keys) {
        $days = $toolData[$t].Keys | Sort-Object -Descending
        if ($days.Count -ge 2) {
            $curr = $toolData[$t][$days[0]]
            $prev = $toolData[$t][$days[1]]
            
            $currRate = [math]::Round($curr.fail / ($curr.pass + $curr.fail), 2)
            $prevRate = [math]::Round($prev.fail / ($prev.pass + $prev.fail), 2)
            
            $trend = "stable"
            if ($currRate -lt $prevRate - 0.1) { $trend = "improving" }
            elseif ($currRate -gt $prevRate + 0.1) { $trend = "degrading" }
            
            $toolTrends += @{
                tool                    = $t
                trend                   = $trend
                fail_rate_current       = $currRate
                fail_rate_prev          = $prevRate
                forecast_fail_rate_next = [math]::Max(0, ($currRate - 0.02))
                confidence              = 0.6
            }
        }
    }
}

# 3. Pulse Drift
$mindEvents = $events | Where-Object { $_.src -eq "Axis_Mind" }
$window24h = (Get-Date).ToUniversalTime().AddHours(-24)
$recentMind = $mindEvents | Where-Object { [DateTime]$_.ts -ge $window24h }
$recentEarth = ($events | Where-Object { $_.src -eq "Earth_Server" -and [DateTime]$_.ts -ge $window24h }).Count

$pulseDrift = @{
    baseline_ratio        = 10.0
    current_ratio         = if ($recentEarth -gt 0) { [math]::Round($recentMind.Count / $recentEarth, 2) } else { $recentMind.Count }
    trend                 = "normalizing" # Placeholder
    expected_ratio_in_24h = 200.0
    confidence            = 0.7
}

# Finalize
$forecast = @{
    version          = 1
    generated_at     = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    anchor_id        = "1569"
    anchor_signature = (Get-AnchorSignature)
    time_horizons    = @("1h", "6h", "24h", "7d")
    rf_cycles        = $rfCycles
    tool_trends      = $toolTrends
    strategy_windows = @() # Placeholder for future logic
    pulse_drift      = $pulseDrift
}

$forecast | ConvertTo-Json -Depth 10 | Set-Content $TargetFile -Encoding UTF8
Write-Host "Temporal Forecast Generated: $TargetFile"
