# Axis Pilot Module
# Purpose: Manages Pilot Identity, Sessions, and 'The Treaty' (Trust/Constraints).
# Phase: 77

$Script:PilotRoot       = "D:\Infinite\Infinity\Pilot"
$Script:RegistryFile    = "$Script:PilotRoot\Pilot_Registry.json"
$Script:SessionLogFile  = "$Script:PilotRoot\Pilot_Session_Log.json"

# Ensure directory exists
if (-not (Test-Path $Script:PilotRoot)) {
    New-Item -ItemType Directory -Force -Path $Script:PilotRoot | Out-Null
}

# State to hold current session in memory
$Script:CurrentSession = $null

function PILOT-BeginSession {
    <#
    .SYNOPSIS
        Starts a new session for a specific Pilot.
    #>
    param(
        [Parameter(Mandatory)][string]$PilotId,
        [string]$Channel = "unknown"
    )

    Write-Host "PILOT: Attempting to dock pilot [$PilotId]..." -ForegroundColor Cyan

    # 1. Validate Pilot
    if (-not (Test-Path $Script:RegistryFile)) {
        Write-Error "PILOT: Registry not found at $Script:RegistryFile"
        return $null
    }

    $registry = $null
    try {
        $registry = Get-Content -Raw -LiteralPath $Script:RegistryFile | ConvertFrom-Json
    } catch {
        Write-Error "PILOT: Failed to read registry JSON. $_"
        return $null
    }

    $pilotDef = $registry.pilots | Where-Object { $_.pilot_id -eq $PilotId }
    if (-not $pilotDef) {
        Write-Warning "PILOT: Denied. Pilot ID '$PilotId' not found in registry."
        return $null
    }

    # 2. Get Shadow Context for Snapshot (if available)
    $shadowState = $null
    if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
        $shadowState = Get-ShadowBiasState
    }

    # 3. Create Session Packet
    $sessionId = "SESS-$(Get-Date -Format 'yyyyMMdd')-" + [guid]::NewGuid().ToString().Substring(0,8).ToUpper()
    $nowUtc    = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

    $session = [ordered]@{
        session_id        = $sessionId
        pilot_id          = $PilotId
        started_utc       = $nowUtc
        ended_utc         = $null
        channel           = $Channel
        trust_band        = $pilotDef.trust_band
        shadow_risk_start = if ($shadowState) { $shadowState.risk_score } else { $null }
        bias_mode_start   = if ($shadowState) { $shadowState.mode } else { $null }
        shadow_risk_end   = $null
        bias_mode_end     = $null
    }

    # 4. Update Memory State
    $Script:CurrentSession = $session

    # 5. Persist to Log
    if (-not (Test-Path $Script:SessionLogFile)) {
        @{ version=1; log_id="PILOT-LOG-INIT"; sessions=@() } |
            ConvertTo-Json -Depth 6 |
            Set-Content -LiteralPath $Script:SessionLogFile
    }

    $log = $null
    try {
        $log = Get-Content -Raw -LiteralPath $Script:SessionLogFile | ConvertFrom-Json
    } catch {
        Write-Error "PILOT: Failed to read Session Log JSON. $_"
        return $null
    }

    if (-not $log.sessions) { $log.sessions = @() }
    $log.sessions += $session

    # Keep last N sessions if you want to bound size
    $maxSessions = 500
    if ($log.sessions.Count -gt $maxSessions) {
        $log.sessions = $log.sessions | Select-Object -Last $maxSessions
    }

    $log | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Script:SessionLogFile

    Write-Host "PILOT: Session [$sessionId] initialized for $($pilotDef.name) [$($pilotDef.trust_band)]." -ForegroundColor Green
    return $sessionId
}

function PILOT-EndSession {
    <#
    .SYNOPSIS
        Ends the current session or a specific session.
    #>
    param(
        [string]$SessionId
    )

    if (-not $SessionId -and $Script:CurrentSession) {
        $SessionId = $Script:CurrentSession.session_id
    }

    if (-not $SessionId) {
        Write-Warning "PILOT: No session to end."
        return
    }

    Write-Host "PILOT: Ending session [$SessionId]..." -ForegroundColor Yellow

    if (-not (Test-Path $Script:SessionLogFile)) {
        Write-Warning "PILOT: Session log not found; nothing to update."
        $Script:CurrentSession = $null
        return
    }

    $log = $null
    try {
        $log = Get-Content -Raw -LiteralPath $Script:SessionLogFile | ConvertFrom-Json
    } catch {
        Write-Error "PILOT: Failed to read Session Log JSON. $_"
        return
    }

    $target = $log.sessions | Where-Object { $_.session_id -eq $SessionId }
    if ($target) {
        $nowUtc = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

        # Optional: closing risk snapshot
        $shadowState = $null
        if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
            $shadowState = Get-ShadowBiasState
        }

        $target.ended_utc       = $nowUtc
        if ($shadowState) {
            $target.shadow_risk_end = $shadowState.risk_score
            $target.bias_mode_end   = $shadowState.mode
        }

        $log | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $Script:SessionLogFile
        Write-Host "PILOT: Session closed in log." -ForegroundColor Gray
    } else {
        Write-Warning "PILOT: Session [$SessionId] not found in log."
    }

    if ($Script:CurrentSession -and $Script:CurrentSession.session_id -eq $SessionId) {
        $Script:CurrentSession = $null
    }
}

function Get-PilotContext {
    <#
    .SYNOPSIS
        Returns context about the currently docked pilot.
    #>
    if (-not $Script:CurrentSession) {
        return $null
    }

    if (-not (Test-Path $Script:RegistryFile)) {
        return $null
    }

    $registry = $null
    try {
        $registry = Get-Content -Raw -LiteralPath $Script:RegistryFile | ConvertFrom-Json
    } catch {
        return $null
    }

    $pilotDef = $registry.pilots | Where-Object { $_.pilot_id -eq $Script:CurrentSession.pilot_id }
    if (-not $pilotDef) {
        return @{
            current_pilot_id  = $Script:CurrentSession.pilot_id
            current_session_id= $Script:CurrentSession.session_id
            role              = "unknown"
            trust_band        = "unknown"
            constraints       = @()
            session_start     = $Script:CurrentSession.started_utc
        }
    }

    return @{
        current_pilot_id   = $Script:CurrentSession.pilot_id
        current_session_id = $Script:CurrentSession.session_id
        role               = $pilotDef.role
        trust_band         = $pilotDef.trust_band
        constraints        = $pilotDef.constraints
        session_start      = $Script:CurrentSession.started_utc
    }
}

Export-ModuleMember -Function PILOT-BeginSession, PILOT-EndSession, Get-PilotContext
