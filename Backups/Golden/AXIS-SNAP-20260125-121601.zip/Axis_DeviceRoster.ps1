param([string]$TargetFile)

$roster = @{
    timestamp  = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    host       = $env:COMPUTERNAME
    interfaces = @()
    neighbors  = @()
}

# Interfaces
$ifaces = Get-NetIPAddress | Where-Object { $_.AddressFamily -eq "IPv4" } | Select-Object InterfaceAlias, IPAddress, PrefixLength
$roster.interfaces = $ifaces

# Neighbors (ARP)
$neigh = Get-NetNeighbor | Where-Object { $_.AddressFamily -eq "IPv4" -and $_.State -ne "Unreachable" } | Select-Object IPAddress, LinkLayerAddress, State
$roster.neighbors = $neigh

$json = $roster | ConvertTo-Json -Depth 5
if ($TargetFile) {
    $dir = Split-Path $TargetFile
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $TargetFile -Value $json -Encoding UTF8
}
else {
    Write-Output $json
}
