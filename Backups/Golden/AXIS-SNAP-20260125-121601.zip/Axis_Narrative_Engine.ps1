<#
.SYNOPSIS
    Phase 124 - Axis Narrative Engine
.DESCRIPTION
    Aggregates diverse system logs to produce coherent, time-boxed narratives
    explaining "What happened and Why".
#>

param(
    [string]$GovHistoryPath = "D:\Infinite\Infinity\Governance_History.json",
    [string]$TreatyLedgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json",
    [string]$ProposalPath = "D:\Infinite\Infinity\Governance\Neural_Proposals.json"
)

$ErrorActionPreference = "Stop"

function Get-AxisStory {
    param([int]$Hours = 24)
    
    $cutoff = (Get-Date).AddHours(-$Hours).ToUniversalTime()
    $story = @()

    # 1. Governance Chapter
    if (Test-Path $GovHistoryPath) {
        try {
            $gov = Get-Content $GovHistoryPath -Raw | ConvertFrom-Json
            $recentGov = @($gov.history) | Where-Object { 
                try { (Get-Date $_.timestamp).ToUniversalTime() -ge $cutoff } catch { $false }
            }
            # DEBUG
            # Write-Host "DEBUG: Found $($recentGov.Count) events since $cutoff from file with count $(@($gov.history).Count)" -F DarkGray

            if ($recentGov.Count -gt 0) {
                $story += "GOVERNANCE: In the last $Hours hours, the system processed $($recentGov.Count) governance events. Notable actions include: " + (($recentGov.action | Select-Object -Unique) -join ", ") + "."
            }
            else {
                $story += "GOVERNANCE: Legal framework remained stable with no amendments."
            }
        }
        catch {}
    }
    else {
        $story += "GOVERNANCE: No history found."
    }

    # 2. Treaty Chapter
    if (Test-Path $TreatyLedgerPath) {
        try {
            $ledger = Get-Content $TreatyLedgerPath -Raw | ConvertFrom-Json
            $dissonance = @($ledger.treaties) | Where-Object { $_.status -eq "dissonance" }
            if ($dissonance.Count -gt 0) {
                $story += "FEDERATION: Currently experiencing dissonance in $($dissonance.Count) treaties. This indicates active misalignment between realms."
            }
            else {
                $story += "FEDERATION: All treaties are synchronized. Consolidated consensus is holding."
            }
        }
        catch {}
    }


    # 3. Reflection Chapter (Active Minds)
    if (Test-Path $ProposalPath) {
        try {
            $props = Get-Content $ProposalPath -Raw | ConvertFrom-Json
            $pending = @($props.proposals) | Where-Object { $_.status -eq "pending_ratification" }
            if ($pending.Count -gt 0) {
                $story += "REFLECTION: The Mind has generated $($pending.Count) self-healing proposals pending review. These address issues ranging from '$($pending[0].type)' to general stability."
            }
            else {
                $story += "REFLECTION: No active self-healing proposals. The Mind is compliant with current constraints."
            }
        }
        catch {}
    }

    # 4. Input Chapter (External Signals)
    $inputSummary = Get-InputTelemetrySummary -Hours $Hours
    if ($inputSummary) {
        $story += $inputSummary
    }

    return ($story -join "`n`n")
}

function Get-InputTelemetrySummary {
    param([int]$Hours = 24)
    $TelemetryPath = "D:\Infinite\Infinity\Logs\Input_Bridge_Telemetry.jsonl"
    
    if (-not (Test-Path $TelemetryPath)) { return $null }
    
    try {
        $cutoff = (Get-Date).AddHours(-$Hours).ToUniversalTime()
        $events = @()
        
        # Read JSONL efficiently (tail is better but Full Read is safe for now as file is new)
        $lines = Get-Content $TelemetryPath
        foreach ($line in $lines) {
            try {
                $e = $line | ConvertFrom-Json
                $ts = ([DateTime]$e.timestamp).ToUniversalTime()
                if ($ts -ge $cutoff) { $events += $e }
            }
            catch {}
        }
        
        if ($events.Count -eq 0) { return "INPUT: No external files ingested in the last $Hours hours." }
        
        $ingests = $events | Where-Object { $_.event -eq "ingestion" }
        $errors = $events | Where-Object { $_.event -eq "error" }
        
        $origins = $ingests | Group-Object origin
        $originStr = ($origins | ForEach-Object { "$($_.Name): $($_.Count)" }) -join ", "
        
        return "INPUT: Processed $($ingests.Count) external files ($originStr). Encountered $($errors.Count) errors."
    }
    catch {
        return "INPUT: Error reading telemetry."
    }
}

function Get-ProposalReasoning {
    param([string]$Id)
    
    if (-not (Test-Path $ProposalPath)) { return "Registry not found." }
    
    try {
        $props = Get-Content $ProposalPath -Raw | ConvertFrom-Json
        $p = @($props.proposals) | Where-Object { $_.id -eq $Id } | Select-Object -First 1
        
        if (-not $p) { return "Proposal ID '$Id' not found." }
        
        $reason = "PROPOSAL ANALYSIS: $($p.id)`n"
        $reason += "------------------------------------------------`n"
        $reason += "TYPE:       $($p.type)`n"
        $reason += "TARGET:     $($p.target)`n"
        $reason += "SEVERITY:   $($p.severity)`n"
        $reason += "REASONING:  $($p.reason)`n"
        
        if ($p.explanation) {
            $reason += "EXPLANATION: $($p.explanation)`n"
        }
        else {
            $reason += "EXPLANATION: No extended narrative provided for this proposal.`n"
        }
        
        return $reason
    }
    catch {
        return "Error reading proposals: $_"
    }
}
