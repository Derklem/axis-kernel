
# Axis_AutonomyGate.ps1
# Phase 82: Autonomy Gate & Treaty Packet

$Script:InfinityRoot = "D:\Infinite"
$Script:AutonomyLogPath = "$Script:InfinityRoot\Infinity\Autonomy\Autonomy_Treaty_Packets.json"
$Script:AutonomyInboxPath = "$Script:InfinityRoot\Infinity\Autonomy\Autonomy_Requests_Inbox.json"

# Load Dependencies
if (Test-Path "$Script:InfinityRoot\Axis_Skills.ps1") { . "$Script:InfinityRoot\Axis_Skills.ps1" }
if (Test-Path "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1") { . "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1" }
if (Test-Path "$Script:InfinityRoot\Axis_Outcome.ps1") { . "$Script:InfinityRoot\Axis_Outcome.ps1" }
if (Test-Path "$Script:InfinityRoot\Axis_Doctrine.ps1") { . "$Script:InfinityRoot\Axis_Doctrine.ps1" }
# Assuming Axis_Pilot is loaded by caller or standard module paths, but we can verify later.

function GATE-BuildTreatyPacket {
    <#
    .SYNOPSIS
        Build a full autonomy treaty packet for a strategy invocation.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$StrategyId,
        [string]$RequestedMode = "execute", # execute | simulate | dry_run
        [string]$Caller = "unknown",
        [string]$RequestId = $null
    )

    $now = (Get-Date).ToUniversalTime().ToString("o")

    # Shadow / Bias
    $shadow = $null
    if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
        try {
            $shadow = Get-ShadowBiasState
        }
        catch {}
    }

    # Skill profile
    $skill = $null
    if (Get-Command SKILL-GetSkillProfile -ErrorAction SilentlyContinue) {
        try {
            $skill = SKILL-GetSkillProfile -StrategyId $StrategyId
        }
        catch {}
    }

    # Pilot context
    $pilotCtx = $null
    if (Get-Command Get-PilotContext -ErrorAction SilentlyContinue) {
        $pilotCtx = Get-PilotContext
    }

    # Treaty constraints (from Pilot registry)
    $constraints = @()
    $trustBand = $null
    if ($pilotCtx) {
        $constraints = $pilotCtx.constraints
        $trustBand = $pilotCtx.trust_band
    }

    # Anchor history
    $anchorLastVerdict = $null
    $anchorLastVerdictUtc = $null
    if ($skill -and $skill.outcome_history) {
        $failures = $skill.outcome_history | Where-Object { $_.result -eq "failure" } | Select-Object -Last 1
        if ($failures) {
            $anchorLastVerdict = "failure"
            $anchorLastVerdictUtc = $failures.timestamp_utc
        }
    }

    # Voice snapshot (Stub for now)
    $voice = $null

    $packetId = "ATP-{0}-{1}" -f (Get-Date -Format "yyyyMMddHHmmss"), ($StrategyId -replace "[^A-Za-z0-9]", "")

    $packet = [ordered]@{
        packet_id         = $packetId
        request_id        = $RequestId
        timestamp_utc     = $now
        strategy_id       = $StrategyId
        requested_mode    = $RequestedMode
        caller            = $Caller

        shadow            = if ($shadow) {
            [ordered]@{
                global_score = $shadow.risk_score
                global_mode  = $shadow.global_mode
                bands        = $shadow.bands
            }
        }
        else { $null }

        skill             = if ($skill) {
            [ordered]@{
                recommended_level = $skill.autonomy_calibrated.recommended_level
                confidence        = $skill.autonomy_calibrated.confidence
                runs_total        = $skill.stats.runs_total
                runs_failure      = $skill.stats.runs_failure
            }
        }
        else { $null }

        bias              = if ($shadow -and $shadow.bias) {
            $shadow.bias
        }
        else { $null }

        treaty            = [ordered]@{
            pilot_trust_band = $trustBand
            constraints      = $constraints
        }

        anchor_history    = [ordered]@{
            last_verdict     = $anchorLastVerdict
            last_verdict_utc = $anchorLastVerdictUtc
        }

        voice_snapshot    = $voice
        gate_decision     = $null
        reasons           = @()
        anchor_resolution = [ordered]@{
            status         = "pending"
            anchor_id      = $null
            anchor_comment = $null
            resolved_utc   = $null
        }
    }

    return $packet
}

function GATE-CheckConsensus {
    param([string]$StrategyId)
    
    $ledgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json"
    if (-not (Test-Path $ledgerPath)) { return "synchronized" }
    
    $ledger = Get-Content $ledgerPath -Raw | ConvertFrom-Json
    # Check if any pending or dissonance treaty relates to this strategy (via doctrine rule match)
    # For now, simplistic: if there are ANY unresolved treaties, we are cautious.
    $unresolved = $ledger.treaties | Where-Object { $_.status -ne "synchronized" }
    if ($unresolved) {
        return "dissonance"
    }
    return "synchronized"
}

function GATE-EvaluateTreatyPacket {
    <#
    .SYNOPSIS
        Decide auto_allow / escalate / deny for a treaty packet.
    #>
    param(
        [Parameter(Mandatory)]$Packet
    )

    $decision = "auto_allow"
    $reasons = @()

    $shadow = $Packet.shadow
    $skill = $Packet.skill
    $treaty = $Packet.treaty
    $anchorH = $Packet.anchor_history
    $mode = $Packet.requested_mode

    # --- Phase 84: Doctrine Pre-Check ---
    $docCtx = @{
        shadow_global_mode = if ($shadow) { $shadow.global_mode } else { "unknown" }
        channel_id         = if ($treaty -and $treaty.channel_id) { $treaty.channel_id } else { "unknown" }
        tags               = @()
    }

    if (Get-Command DOCTRINE-GetPolicyForStrategy -ErrorAction SilentlyContinue) {
        $policy = DOCTRINE-GetPolicyForStrategy -StrategyId $Packet.strategy_id -Context $docCtx
        
        # --- Phase 120: Consensus Check ---
        $consensus = GATE-CheckConsensus -StrategyId $Packet.strategy_id
        if ($consensus -eq "dissonance") {
            $decision = "escalate"
            $reasons += "federation_consensus_dissonance"
        }

        if ($policy) {
            switch ($policy.autonomy) {
                "deny" {
                    $decision = "deny"
                    $reasons += "doctrine_deny"
                }
                "manual_only" {
                    $decision = "escalate"
                    $reasons += "doctrine_manual_only"
                }
                "allow_auto" {
                    # Doctrine explicitly allows auto-execution, override typical checks?
                    # For safety, we treat it as a strong vote but maybe not override critical shadow?
                    # But the spec says "rules that constrain autonomy".
                    # Let's verify standard checks still apply unless we decide Doctrine is absolute.
                    # For now, simplistic: It adds a positive reason, but doesn't force decision unless we want it to.
                    # User prompt: "Doctrine tells the Gate what the standing orders are."
                    # If allow_auto, we probably shouldn't escalate for minor reasons.
                    $reasons += "doctrine_allow_auto"
                }
            }
        }
    }

    # If already decided by doctrine (deny/escalate), we might skip or continue to gather more reasons.
    # Continuation is better for full context logging.

    # If simulation/dry_run, we are usually permissive unless critical
    if ($mode -ne "execute") {
        if ($shadow -and $shadow.global_mode -eq "critical") {
            $decision = "escalate" # Or deny
            $reasons += "shadow_global_critical_blocks_all"
        }
        # Otherwise allow sims
    }
    else {
        # Execution Logic

        # 1. Shadow global gating
        if ($shadow -and $shadow.global_mode -in @("elevated", "critical")) {
            $decision = "escalate"
            $reasons += "shadow_global_${($shadow.global_mode)}"
        }

        # 2. Skill competence gating
        if ($skill -and $skill.recommended_level -eq "manual") {
            $decision = "escalate"
            $reasons += "skill_recommends_manual"
        }
        # If skill not found or no history, defaulting to allow currently? 
        # Or should we escalate new strategies? 
        # For now, let's trust default "auto" declared level unless calibrated says otherwise.
        
        # 3. Treaty constraints
        if ($treaty -and $treaty.constraints) {
            if ($treaty.constraints -contains "require_anchor_for_execution" -or
                $treaty.constraints -contains "require_anchor_for_$($Packet.strategy_id)") {
                $decision = "escalate"
                $reasons += "treaty_requires_anchor"
            }
        }
        
        # 4. Anchor history (Recent failure)
        # Check if failure was recent (e.g. < 24 hours)? 
        # For now, simply if last recorded outcome was failure, we escalate.
        if ($anchorH -and $anchorH.last_verdict -eq "failure") {
            $decision = "escalate"
            $reasons += "recent_anchor_failure"
        }
    }

    $Packet.gate_decision = $decision
    $Packet.reasons = $reasons

    return $Packet
}

function GATE-AppendPacketToLog {
    param([Parameter(Mandatory)]$Packet)

    $doc = @{
        version = 1
        log_id  = "AXIS-AUTONOMY-TREATY-2026-001"
        packets = @()
    }

    if (Test-Path $Script:AutonomyLogPath) {
        try { $doc = Get-Content -Raw -LiteralPath $Script:AutonomyLogPath | ConvertFrom-Json } catch {}
    }

    if (-not $doc.packets) { $doc.packets = @() }

    $doc.packets += $Packet
    if ($doc.packets.Count -gt 500) {
        $doc.packets = $doc.packets | Select-Object -Last 500
    }

    try {
        $doc | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Script:AutonomyLogPath -Encoding UTF8
    }
    catch {
        Write-Warning "GATE: Failed to save log. $_"
    }
}

function GATE-UpdateAutonomyInbox {
    param([Parameter(Mandatory)]$Packet)

    if ($Packet.gate_decision -ne "escalate") { return }

    $doc = @{
        version          = 1
        inbox_id         = "AXIS-AUTONOMY-REQUESTS-001"
        generated_at_utc = (Get-Date).ToUniversalTime().ToString("o")
        items            = @()
    }

    if (Test-Path $Script:AutonomyInboxPath) {
        try { $doc = Get-Content -Raw -LiteralPath $Script:AutonomyInboxPath | ConvertFrom-Json } catch {}
    }

    if (-not $doc.items) { $doc.items = @() }

    $reqId = if ($Packet.request_id) { $Packet.request_id } else { "REQ-{0}-{1}" -f (Get-Date -Format "yyyyMMddHHmmss"), ($Packet.strategy_id -replace "[^A-Za-z0-9]", "") }
    $summary = "Strategy $($Packet.strategy_id) requested in mode $($Packet.requested_mode)."

    $item = [ordered]@{
        request_id      = $reqId
        packet_id       = $Packet.packet_id
        strategy_id     = $Packet.strategy_id
        summary         = $summary
        proposed_action = $Packet.requested_mode
        shadow_mode     = if ($Packet.shadow) { $Packet.shadow.global_mode } else { "unknown" }
        skill_level     = if ($Packet.skill) { "$($Packet.skill.recommended_level) ($($Packet.skill.confidence))" } else { "unknown" }
        pilot_id        = if ($Packet.treaty) { $Packet.treaty.pilot_trust_band } else { "unknown" }
        reasons         = $Packet.reasons
        status          = "pending"
    }

    $doc.items += $item
    # Deduplication check? Simpler to append for now.
    
    if ($doc.items.Count -gt 200) {
        $doc.items = $doc.items | Select-Object -Last 200
    }

    $ts = (Get-Date).ToUniversalTime().ToString("o")
    if ($doc.PSObject.Properties.Match("generated_at_utc").Count) {
        $doc.generated_at_utc = $ts
    }
    else {
        $doc | Add-Member -MemberType NoteProperty -Name "generated_at_utc" -Value $ts
    }
    try {
        $doc | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Script:AutonomyInboxPath -Encoding UTF8
    }
    catch {
        Write-Warning "GATE: Failed to save inbox. $_"
    }
}

function GATE-CheckAutonomy {
    <#
    .SYNOPSIS
        Unified autonomy check for a strategy invocation.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$StrategyId,
        [string]$RequestedMode = "execute",
        [string]$Caller = "unknown",
        [string]$RequestId = $null
    )

    $packet = GATE-BuildTreatyPacket -StrategyId $StrategyId -RequestedMode $RequestedMode -Caller $Caller -RequestId $RequestId
    $packet = GATE-EvaluateTreatyPacket -Packet $packet

    GATE-AppendPacketToLog -Packet $packet
    GATE-UpdateAutonomyInbox -Packet $packet
    
    # Return simple object
    return [ordered]@{
        decision = $packet.gate_decision
        packet   = $packet
    }
}

function GATE-GetPendingRequests {
    if (-not (Test-Path $Script:AutonomyInboxPath)) { return @() }
    try {
        $data = Get-Content -Raw $Script:AutonomyInboxPath | ConvertFrom-Json
        return @($data.items) | Where-Object { $_.status -eq "pending" }
    }
    catch { return @() }
}


