# Axis_Play_Index.ps1
# Phase 121: Dream Indexer
# Scans the Playground and builds a searchable JSON index.

$root = "D:\Infinite"
$playDir = Join-Path $root "Infinity\Playground"
$indexFile = Join-Path $root "Infinity\Playground_Index.json"

function Get-DreamMetadata {
    param($Path)
    $item = Get-Item $Path
    $meta = @{
        filename = $item.Name
        created = $item.CreationTime.ToString("o")
        type = "UNKNOWN"
        topic = "UNKNOWN"
        tags = @()
        preview = ""
    }

    if ($item.Extension -eq ".json") {
        try {
            $json = Get-Content $Path -Raw | ConvertFrom-Json
            if ($json.type) { $meta.type = $json.type }
            if ($json.seed) { $meta.topic = $json.seed }
            if ($json.context -and $json.context.mood) { $meta.tags += $json.context.mood }
            $meta.preview = "JSON Artifact ($($json.type))"
        } catch {
            $meta.preview = "Invalid JSON"
        }
    }
    elseif ($item.Extension -eq ".txt" -or $item.Extension -eq ".md") {
        $content = Get-Content $Path -TotalCount 20
        $meta.preview = ($content | Select-Object -First 5) -join "`n"
        
        # Try to parse legacy headers
        foreach ($line in $content) {
            if ($line -match "^Subject:\s*(.+)") { $meta.topic = $matches[1].Trim() }
            if ($line -match "^Mode:\s*(.+)") { $meta.type = $matches[1].Trim() }
        }
    }

    return $meta
}

function Invoke-Indexing {
    Write-Host "[INDEXER] Scanning Playground..." -ForegroundColor Cyan
    if (-not (Test-Path $playDir)) {
        Write-Host "Playground not found." -ForegroundColor Red
        return
    }

    $files = Get-ChildItem $playDir | Where-Object { $_.Name -ne "index.json" -and $_.Name -ne "Playground_Index.json" }
    $index = @()

    foreach ($f in $files) {
        $meta = Get-DreamMetadata -Path $f.FullName
        $index += $meta
    }

    $index | ConvertTo-Json -Depth 4 | Set-Content $indexFile -Encoding UTF8 -Force
    Write-Host "[INDEXER] Index updated: $($index.Count) items." -ForegroundColor Green
    return $index.Count
}

# Run immediately if script is called directly
Invoke-Indexing
