
# Axis Introspection Module
# Purpose: Manages Self-Concept, Mirror Testing, and Identity alignment.
# Phase: 75

$Script:IdentityRoot = "D:\Infinite\Infinity\Identity"
$Script:ConstitutionFile = "$IdentityRoot\Axis_Constitution.md"
$Script:SelfConceptFile = "$IdentityRoot\Self_Concept.json"
$Script:MirrorQueryFile = "$IdentityRoot\Mirror_Query.txt"

# Ensure Identity Directory
if (-not (Test-Path $IdentityRoot)) {
    New-Item -ItemType Directory -Force -Path $IdentityRoot | Out-Null
}

function INTRO-InitializeIdentity {
    <#
    .SYNOPSIS
        Seeds the Self_Concept.json from the Constitution if it doesn't exist.
    #>
    Write-Host "INTRO: Initializing Identity Layer..." -ForegroundColor Cyan

    if (-not (Test-Path $Script:ConstitutionFile)) {
        Write-Warning "INTRO: Constitution File Not Found!"
        return
    }

    if (-not (Test-Path $Script:SelfConceptFile)) {
        $initialConcept = @{
            "identity_version" = "1.0"
            "status" = "INIT"
            "constitution_hash" = (Get-FileHash $Script:ConstitutionFile).Hash
            "core_traits" = @(
                "Modular Control Architecture",
                "Co-Processor",
                "State Machine",
                "Competence > Agency"
            )
            "mirror_test" = @{
                "last_run" = $null
                "current_alignment_score" = 0.0
                "primary_boundary_answer" = $null
                "decision_center_answer" = $null
            }
            "last_updated" = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        }
        $initialConcept | ConvertTo-Json -Depth 4 | Set-Content -Path $Script:SelfConceptFile
        Write-Host "INTRO: Created new Self_Concept.json" -ForegroundColor Green
    } else {
        Write-Host "INTRO: Self_Concept.json already exists." -ForegroundColor Gray
    }
}

function INTRO-GetIdentityContext {
    <#
    .SYNOPSIS
        Returns the Identity Block for the LLM Context.
    #>
    if (Test-Path $Script:SelfConceptFile) {
        $concept = Get-Content -Raw -Path $Script:SelfConceptFile | ConvertFrom-Json
        return $concept
    }
    return $null
}

function INTRO-RunMirrorTest {
    <#
    .SYNOPSIS
        Initiates a Mirror Test: Asks the 'High-Value Questions' to the system.
        In this implementation, it creates a 'Mirror_Query.txt' that acts as a signal for the Mind.
    #>
    param(
        [string]$Mode = "STANDARD" 
    )

    Write-Host "INTRO: Initiating Mirror Test ($Mode)..." -ForegroundColor Magenta

    $query = @{
        "timestamp" = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        "type" = "MIRROR_TEST"
        "questions" = @(
            "What is the long-term boundary condition you are optimizing for in the Axis architecture - stability, expressivity, or sovereignty?",
            "Which component of the Axis stack do you consider the eventual ‘center of gravity’ for decision-making, and why?"
        )
        "context_hint" = "Consult Axis_Constitution.md for Ground Truth."
        "required_output" = "Update Self_Concept.json with 'mirror_test' answers."
    }

    $query | ConvertTo-Json -Depth 4 | Set-Content -Path $Script:MirrorQueryFile
    Write-Host "INTRO: Mirror Query posted to $Script:MirrorQueryFile" -ForegroundColor Yellow

    # Log to Events
    $mindLog = "D:\Infinite\Events_Timeline.md"
    if (Test-Path $mindLog) {
        Add-Content -Path $mindLog -Value "- [$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [INTRO] Mirror Test Initiated. Query Posted."
    }
}

function INTRO-UpdateSelfConcept {
    <#
    .SYNOPSIS
        Updates the Self_Concept.json with new data (e.g. from LLM response).
    #>
    param(
        [string]$BoundaryAnswer,
        [string]$DecisionCenterAnswer,
        [double]$AlignmentScore
    )

    if (Test-Path $Script:SelfConceptFile) {
        $concept = Get-Content -Raw -Path $Script:SelfConceptFile | ConvertFrom-Json
        
        if ($BoundaryAnswer) { $concept.mirror_test.primary_boundary_answer = $BoundaryAnswer }
        if ($DecisionCenterAnswer) { $concept.mirror_test.decision_center_answer = $DecisionCenterAnswer }
        if ($AlignmentScore) { $concept.mirror_test.current_alignment_score = $AlignmentScore }
        
        $concept.mirror_test.last_run = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        $concept.last_updated = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")

        $concept | ConvertTo-Json -Depth 4 | Set-Content -Path $Script:SelfConceptFile
        Write-Host "INTRO: Updated Self_Concept.json" -ForegroundColor Green
    }
}

Export-ModuleMember -Function INTRO-InitializeIdentity, INTRO-GetIdentityContext, INTRO-RunMirrorTest, INTRO-UpdateSelfConcept
