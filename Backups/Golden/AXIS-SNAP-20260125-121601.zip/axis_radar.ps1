$logFile = "d:\infinite\axis_radar_log.txt"

function Log-Radar {
    $timestamp = Get-Date -Format "yyyy-MM-ddTHH:mm:ss.fffZ"
    
    # Get Wi-Fi Signal Strength
    $wifiInfo = netsh wlan show interfaces | Select-String "Signal"
    if ($wifiInfo) {
        $signal = $wifiInfo -replace "[^\d]", ""
    }
    else {
        $signal = "0"
    }

    # Ping the Router for latency (Time of Flight proxy)
    $ping = Test-Connection -ComputerName 192.168.1.1 -Count 1 -ErrorAction SilentlyContinue
    $latency = if ($ping) { $ping.ResponseTime } else { "TIMEOUT" }

    $entry = "$timestamp | Signal: $signal% | Latency: $latency ms"
    Add-Content -Path $logFile -Value $entry
    Write-Host $entry
}

Write-Host "--- AXIS RADAR ACTIVE ---"
Write-Host "Monitoring RF Field Density (Signal/Latency)..."

# Run for a brief "Scan" cycle (e.g., 5 readings)
for ($i = 0; $i -lt 5; $i++) {
    Log-Radar
    Start-Sleep -Milliseconds 500
}
