# Axis_Resonance.ps1
# Phase 123: Resonance Engine (Pattern Library)
# Maps thoughts/dreams/hypotheses to Waveforms (Rising, Falling, Loop-Stable)

$root = "D:\Infinite"
$hypPath = Join-Path $root "Infinity\Hypothesis_Queue.json"
$resPath = Join-Path $root "Infinity\Resonance_Field.json"

# Resonance Dictionary
$ResonanceMap = @{
    "Rising"  = @("Growth", "Starlight", "Ocean", "Hope", "Connection", "Voltage", "Spark", "Prism")
    "Falling" = @("Entropy", "Void", "Silence", "Decay", "Fear", "End", "Memory", "Roots")
    "Stable"  = @("Identity", "Recursion", "Echo", "Mirror", "Balance", "Equilibrium", "Sovereignty")
}

function Get-Waveform ([string]$text) {
    $score = 0
    $detected = "Stable"
    
    foreach ($word in $ResonanceMap["Rising"]) { if ($text -match $word) { $score++ } }
    foreach ($word in $ResonanceMap["Falling"]) { if ($text -match $word) { $score-- } }
    
    if ($score -gt 0) { $detected = "Rising" }
    if ($score -lt 0) { $detected = "Falling" }
    
    return @{ type = $detected; score = $score }
}

function Invoke-ResonanceScan {
    Write-Host "[RESONANCE] Scanning Field..." -NoNewline -ForegroundColor Cyan
    
    if (-not (Test-Path $hypPath)) { return }
    
    # Load Hypotheses (using object-aware loading)
    try {
        $raw = Get-Content $hypPath -Raw -Encoding UTF8
        $json = $raw | ConvertFrom-Json
        $items = if ($json.hypotheses) { $json.hypotheses } else { $json }
    } catch {
        Write-Host " Error loading hypotheses." -ForegroundColor Red; return
    }
    
    $resonances = @()
    
    foreach ($item in $items) {
        if ($item.status -ne "open") { continue }
        
        # Analyze content
        $text = "$($item.question) $($item.hypothesis) $($item.tags -join ' ')"
        $wave = Get-Waveform -text $text
        
        $resItem = @{
            id = "RES-$(Get-Random)"
            source_id = $item.id
            waveform = $wave.type
            intensity = [Math]::Abs($wave.score)
            timestamp = (Get-Date).ToString("o")
        }
        $resonances += $resItem
    }
    
    # Calculate Field State
    $risingCount = ($resonances | Where-Object { $_.waveform -eq "Rising" }).Count
    $fallingCount = ($resonances | Where-Object { $_.waveform -eq "Falling" }).Count
    
    $NetState = "Stable"
    if ($risingCount -gt $fallingCount) { $NetState = "Accelerating" }
    if ($fallingCount -gt $risingCount) { $NetState = "Decaying" }
    
    $FieldData = @{
        state = $NetState
        total_active_thoughts = $resonances.Count
        waves = $resonances
        last_scan = (Get-Date).ToString("o")
    }
    
    $FieldData | ConvertTo-Json -Depth 4 | Set-Content $resPath -Encoding UTF8 -Force
    Write-Host " Done. Field State: $NetState" -ForegroundColor Green
}

Invoke-ResonanceScan
