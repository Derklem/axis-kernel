# Axis_KillSwitch.ps1
# Phase 125: Emergency Shutdown
# "The Red Button."

$root = "D:\Infinite\Infinity"
$telemetryDir = "D:\Infinite\Infinity\Telemetry"

# Define Telemetry Helper (Embedded for Safety)
function Write-KillLog {
    param($msg)
    $path = Join-Path $telemetryDir "Axis_Events.json"
    $evt = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        source    = "Axis_KillSwitch"
        kind      = "kill"
        severity  = "critical"
        summary   = $msg
    }
    try {
        if (-not (Test-Path $path)) { New-Item -ItemType File -Path $path -Force | Out-Null }
        $json = $evt | ConvertTo-Json -Compress
        Add-Content -Path $path -Value $json -Encoding UTF8
    } catch {}
}

Write-Host ">>> AXIS KILL SWITCH ENGAGED <<<" -ForegroundColor Red

# 1. Stop Mind Loop
# Matches processes running Axis_Mind.ps1
Get-WmiObject Win32_Process | Where-Object { $_.CommandLine -like "*Axis_Mind.ps1*" } | ForEach-Object {
    Write-Host "Killing Process ID: $($_.ProcessId)" -ForegroundColor DarkRed
    Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
}

# 2. Force Autonomy Contract -> OBSERVE_ONLY
$contractPath = Join-Path $root "Autonomy_Contract.json"
if (Test-Path $contractPath) {
    try {
        $c = Get-Content $contractPath -Raw | ConvertFrom-Json
        $c.mode = "observe_only"
        $c | ConvertTo-Json -Depth 10 | Set-Content $contractPath -Encoding UTF8 -Force
        Write-Host "Autonomy Set: OBSERVE_ONLY" -ForegroundColor Yellow
    } catch {
        Write-Host "Error locking Autonomy Contract." -ForegroundColor Red
    }
}

# 3. Zero Risk Ledger
$ledgerPath = Join-Path $root "Telemetry\Risk_Ledger.json"
if (Test-Path $ledgerPath) {
    try {
        $l = Get-Content $ledgerPath -Raw | ConvertFrom-Json
        $l.current_instantaneous_risk = 0
        $l.active_actions = @()
        $l | ConvertTo-Json -Depth 10 | Set-Content $ledgerPath -Encoding UTF8 -Force
        Write-Host "Risk Ledger: ZEROED" -ForegroundColor Yellow
    } catch {
        Write-Host "Error zeroing Risk Ledger." -ForegroundColor Red
    }
}

# 4. Log Event
Write-KillLog "Emergency Kill Switch Activated by User."

Write-Host "SYSTEM IS IN PASSIVE STATE." -ForegroundColor Green
Write-Host "Verify with Axis_Vitals.ps1" -ForegroundColor Gray
