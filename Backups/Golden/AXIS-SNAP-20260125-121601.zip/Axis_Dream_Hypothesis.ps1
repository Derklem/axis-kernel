# Axis_Dream_Hypothesis.ps1
# Phase 122: Dream -> Hypothesis Bridge (The Entropy Check)
# "If you were entropy, how would this dream end?"

$root = "D:\Infinite"
$indexFile = Join-Path $root "Infinity\Playground_Index.json"
$queueFile = Join-Path $root "Infinity\Hypothesis_Queue.json"

function Invoke-EntropyBridge {
    Write-Host "[BRIDGE] Scanning dreams for entropy... " -NoNewline -ForegroundColor Cyan
    
    if (-not (Test-Path $indexFile)) { 
        Write-Host "No Index." -ForegroundColor Yellow
        return 
    }
    
    $index = Get-Content $indexFile -Raw | ConvertFrom-Json
    if (-not $index) { return }
    
    # Sort by creation desc
    $latest = $index | Sort-Object created -Descending | Select-Object -First 1
    
    if (-not $latest) { return }
    
    # Load or Init Queue
    $rootObj = @{ hypotheses = @() }
    
    if (Test-Path $queueFile) {
        try {
            $raw = Get-Content $queueFile -Raw -Encoding UTF8
            if ($raw) { 
                $loaded = $raw | ConvertFrom-Json
                # Handle both Array (Legacy) and Object (Current) formats
                if ($loaded -is [System.Array]) {
                    $rootObj.hypotheses = $loaded
                } elseif ($loaded.hypotheses) {
                    $rootObj = $loaded
                }
            }
        } catch {
            Write-Host "Error parsing queue: $_" -ForegroundColor Red
        }
    }
    
    # Check if already bridged
    $sourceRef = "Dream:$($latest.filename)"
    foreach ($h in $rootObj.hypotheses) {
        if ($h.source -eq $sourceRef) {
            Write-Host "Latest dream already bridged ($($latest.filename))." -ForegroundColor Gray
            return
        }
    }
    
    # Construct Entropy Hypothesis
    $topics = if ($latest.topic -is [array]) { $latest.topic -join ", " } else { $latest.topic }
    if (-not $topics) { $topics = "Unknown Content" }
    
    $hyp = @{
        id = "HYP-ENTROPY-$(Get-Random)"
        created_at = (Get-Date).ToString("o")
        source = $sourceRef
        hypothesis = "If you were entropy, how would specific concept '$topics' end? Projected Outcome -> [Simulate]"
        question = "Entropy Simulation: $topics"
        state = "OPEN"
        priority = "MED"
        tags = @("entropy", "dream_bridge")
        status = "open"
    }
    
    # Append to array (ensure array type)
    if (-not $rootObj.hypotheses) { $rootObj.hypotheses = @() }
    $rootObj.hypotheses += $hyp
    
    $rootObj | ConvertTo-Json -Depth 5 | Set-Content $queueFile -Encoding UTF8 -Force
    Write-Host "Bridged! ($($hyp.id))" -ForegroundColor Green
}

Invoke-EntropyBridge
