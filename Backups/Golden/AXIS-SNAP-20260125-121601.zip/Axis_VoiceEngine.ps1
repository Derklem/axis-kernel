<#
.SYNOPSIS
    Axis Voice Engine (SAPI Wrapper)
.DESCRIPTION
    Provides local text-to-speech capabilities using .NET System.Speech.
    Zero-cloud dependency.
#>

Add-Type -AssemblyName System.Speech

function Invoke-AxisVoice {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [string]$VoiceName = $null, # Optional: e.g. "Microsoft David Desktop"
        [int]$Rate = 0,             # -10 to 10
        [int]$Volume = 100          # 0 to 100
    )

    try {
        $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
        $synth.Rate = $Rate
        $synth.Volume = $Volume

        if ($VoiceName) {
            try {
                $synth.SelectVoice($VoiceName)
            }
            catch {
                Write-Warning "Voice '$VoiceName' not found. Using default."
            }
        }

        # Async speak to not block the thread (handling logic might need sync though, 
        # but for tool execution, sync is safer to ensure completion before return)
        $synth.Speak($Message)
        
        $synth.Dispose()
        return $true
    }
    catch {
        Write-Error "Voice Error: $_"
        return $false
    }
}

# Standalone execution support
if ($MyInvocation.InvocationName -ne ".") {
    # If run as script
    if ($args.Count -gt 0) {
        Invoke-AxisVoice -Message $args[0]
    }
}
