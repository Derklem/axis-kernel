<#
.SYNOPSIS
    Phase 121 - Shadow Orchestrator (Defensive Instinct)
.DESCRIPTION
    Analyzes internal system volatility (Governance Flux and Treaty Dissonance)
    to adjust the Shadow Global Mode predictively.
#>

param(
    [string] $GovHistoryPath = "D:\Infinite\Infinity\Governance_History.json",
    [string] $TreatyLedgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json",
    [string] $NeuralIndexPath = "D:\Infinite\Infinity\Neural\Neural_Event_Index.json",
    [string] $ShadowToolsScript = "D:\Infinite\Infinity\Shadow\Shadow_Tools.ps1"
)

$ErrorActionPreference = "Stop"

function Invoke-ShadowOrchestration {
    Write-Host "[SHADOW-ORCH] Assessing system volatility..." -ForegroundColor Cyan

    $now = (Get-Date).ToUniversalTime()
    $eventsToInject = @()

    # 1. Analyze Governance Flux (Last 60 mins)
    if (Test-Path $GovHistoryPath) {
        $history = Get-Content $GovHistoryPath -Raw | ConvertFrom-Json
        $cutoff = $now.AddMinutes(-65)
        
        $recentGov = @($history.history) | Where-Object { 
            try {
                $ts = [DateTime]::Parse($_.timestamp).ToUniversalTime()
                $ts -ge $cutoff
            }
            catch { $false }
        }
        
        if ($recentGov.Count -gt 0) {
            Write-Host "[SHADOW-ORCH] Detected $($recentGov.Count) recent governance events." -ForegroundColor Yellow
            $eventsToInject += [ordered]@{
                timestamp_utc = $now.ToString("o")
                channel_id    = "SHADOW-ORCH-GOV"
                type          = "governance_flux"
                event_count   = $recentGov.Count
                alerts        = @("legislative_volatility")
                source        = "Axis_Shadow_Orchestrator"
            }
        }
    }

    # 2. Analyze Treaty Dissonance
    if (Test-Path $TreatyLedgerPath) {
        $ledger = Get-Content $TreatyLedgerPath -Raw | ConvertFrom-Json
        $unresolved = @($ledger.treaties) | Where-Object { $_.status -ne "synchronized" }
        
        if (@($unresolved).Count -gt 0) {
            Write-Host "[SHADOW-ORCH] Detected $(@($unresolved).Count) unresolved treaties (Dissonance)." -ForegroundColor Red
            $eventsToInject += [ordered]@{
                timestamp_utc    = $now.ToString("o")
                channel_id       = "SHADOW-ORCH-FED"
                type             = "treaty_dissonance"
                unresolved_count = @($unresolved).Count
                alerts           = @("treaty_dissonance")
                source           = "Axis_Shadow_Orchestrator"
            }
        }
    }

    if ($eventsToInject.Count -gt 0) {
        # 3. Inject into Neural Event Index
        $idx = if (Test-Path $NeuralIndexPath) { Get-Content $NeuralIndexPath -Raw | ConvertFrom-Json } else { @{ version = 1; events = @() } }
        [System.Collections.ArrayList]$eList = @()
        if ($idx.events) { foreach ($e in $idx.events) { $eList.Add($e) | Out-Null } }
        foreach ($e in $eventsToInject) { $eList.Add($e) | Out-Null }
        
        # Prune index to last 500 events
        if ($eList.Count -gt 500) { $eList = $eList | Select-Object -Last 500 }
        
        $idx.events = $eList.ToArray()
        $idx | ConvertTo-Json -Depth 20 | Set-Content $NeuralIndexPath -Encoding UTF8

        # 4. Trigger Shadow Ingestion
        if (Test-Path $ShadowToolsScript) {
            . $ShadowToolsScript
            SHADOW-Ingest-NeuralEvents -LookbackMinutes 65
        }

        # 5. Trigger Neural Reflection (Self-Healing)
        # Load Risk to check threshold
        $riskScore = 0
        if (Test-Path "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json") {
            try {
                $r = Get-Content "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json" -Raw | ConvertFrom-Json
                $riskScore = $r.summary.global_risk_score
            }
            catch {}
        }
        
        $dissonanceCount = 0
        if (Test-Path $TreatyLedgerPath) {
            try {
                $l = Get-Content $TreatyLedgerPath -Raw | ConvertFrom-Json
                $dissonanceCount = (@($l.treaties) | Where-Object { $_.status -eq "dissonance" }).Count
            }
            catch {}
        }

        if ($riskScore -gt 0.6 -or $dissonanceCount -gt 0) {
            if (Test-Path "D:\Infinite\Axis_Neural_Reflection.ps1") {
                & "D:\Infinite\Axis_Neural_Reflection.ps1"
            }
        }
    }
    else {
        Write-Host "[SHADOW-ORCH] System state stable. No defensive escalation required." -ForegroundColor Green
    }
}

if ($MyInvocation.PSScriptRoot -ne "") {
    Invoke-ShadowOrchestration
}
