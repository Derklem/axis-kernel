# Axis_Vitals.ps1
# Phase 122: Vitals Panel
# "Are you healthy?"

$root = "D:\Infinite\Infinity"

Write-Host "--- AXIS SYSTEM VITALS ---" -ForegroundColor Cyan

# 0. Architect Kernel (Primacy)
$archKernelFile = Join-Path $root "Architect_Kernel.md"
$archStatus = "MISSING"
if (Test-Path $archKernelFile) {
    if ((Get-Content $archKernelFile -Raw) -match "status:\s*(.+)") { $archStatus = $matches[1].Trim() }
}
Write-Host "[ARCHITECT]" -ForegroundColor Cyan
if ($archStatus -eq "ACTIVE") {
    Write-Host "  Kernel:   FOUND (Active)" -ForegroundColor Green
    Write-Host "  Priority: Architect health > Axis survival" -ForegroundColor DarkGray
} else {
    Write-Host "  Kernel:   MISSING (System out of contract!)" -ForegroundColor Red
}

# 1. Identity & Snapshot
$proofPath = Join-Path $root "Snapshot_Proof.txt"
if (Test-Path $proofPath) {
    $proof = Get-Content $proofPath -Raw
    Write-Host "[IDENTITY]" -ForegroundColor Yellow
    Write-Host "  $proof" -ForegroundColor Gray
} else {
    Write-Host "[IDENTITY]  No Proof Found." -ForegroundColor Red
}

# 2. Mood
$moodPath = Join-Path $root "Mood_State.json"
if (Test-Path $moodPath) {
    try {
        $m = Get-Content $moodPath -Raw | ConvertFrom-Json
        Write-Host "[MOOD]" -ForegroundColor Yellow
        Write-Host "  Label:      $($m.mood_label)" -ForegroundColor White
        Write-Host "  Orbit:      $($m.orbit)" -ForegroundColor Gray
        Write-Host "  Velocity:   $($m.velocity)" -ForegroundColor Gray
    } catch { Write-Host "[MOOD]      Read Error" -ForegroundColor Red }
} else { Write-Host "[MOOD]      Offline" -ForegroundColor DarkGray }

# 3. Autonomy
$contractPath = Join-Path $root "Autonomy_Contract.json"
$ledgerPath = Join-Path $root "Telemetry\Risk_Ledger.json"
$critical = $false

if (Test-Path $contractPath) {
    try {
        $c = Get-Content $contractPath -Raw | ConvertFrom-Json
        Write-Host "[AUTONOMY]" -ForegroundColor Yellow
        Write-Host ("  Mode:       {0}" -f $c.mode) -ForegroundColor White
        if ($c.risk_budget) {
            Write-Host ("  Budget:     {0}" -f $c.risk_budget.instantaneous_max) -ForegroundColor Gray
        }
    } catch {
        Write-Host "[AUTONOMY]  Config Read Error" -ForegroundColor Red
        $critical = $true 
    }
} else {
    Write-Host "[AUTONOMY]  Contract Missing" -ForegroundColor Red
    $critical = $true
}

if (Test-Path $ledgerPath) {
    try {
        $l = Get-Content $ledgerPath -Raw | ConvertFrom-Json
        if ($l.current_instantaneous_risk -ne $null) {
            Write-Host ("  Heat:       {0}" -f $l.current_instantaneous_risk) -ForegroundColor White
        }
    } catch {}
}

# 4. Tide
$tidePath = Join-Path $root "Tide_Signal.json"
if (Test-Path $tidePath) {
    try {
        $t = Get-Content $tidePath -Raw | ConvertFrom-Json
        Write-Host "[TIDE]" -ForegroundColor Yellow
        Write-Host "  Signal:     Active" -ForegroundColor Green
        Write-Host "  Source:     $($t.source_id)" -ForegroundColor Gray
    } catch {}
} else {
    Write-Host "[TIDE]      Inactive" -ForegroundColor DarkGray
}

if ($critical) {
    Write-Host "`nSYSTEM CRITICAL." -ForegroundColor Red
    exit 1
} else {
    Write-Host "`nSystem is Functional." -ForegroundColor Green
    exit 0
}
