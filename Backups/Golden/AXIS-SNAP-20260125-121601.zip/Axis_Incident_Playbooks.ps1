<#
.SYNOPSIS
    Phase 115 - Incident Playbooks & Root-Cause Bridge

.DESCRIPTION
    Processes active incidents in Axis_State.json, applies Incident_Playbooks.json,
    and spawns linked hypotheses and recommendations. Optionally generates
    haptic_alert UI intents for critical / flagged playbooks.

.NOTES
    - Idempotent per (incident_id, playbook_id) via incident.playbook_links.
    - Designed to be called periodically by Axis_Mind / scheduler.
#>

param(
    [string] $AxisStatePath = "D:\Infinite\Infinity\Axis_State.json",
    [string] $IncidentPlaybookPath = "D:\Infinite\Infinity\Incident_Playbooks.json",
    [string] $HypothesisQueuePath = "D:\Infinite\Infinity\Hypothesis_Queue.json",
    [string] $RecommendationQueuePath = "D:\Infinite\Infinity\Recommendation_Queue.json",
    [string] $UiInboxPath = "D:\Infinite\Infinity\UI_Inbox"
)

$ErrorActionPreference = "Stop"

function New-RandomIdSuffix {
    param(
        [int] $Length = 4
    )
    $chars = (48..57 + 65..90) # 0-9, A-Z
    -join (1..$Length | ForEach-Object { [char]($chars | Get-Random) })
}

function New-HypothesisId {
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $rand = New-RandomIdSuffix
    "HYP-$stamp-$rand"
}

function New-RecommendationId {
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $rand = New-RandomIdSuffix
    "REC-$stamp-$rand"
}

function New-HapticIntentFile {
    param(
        [string] $UiInboxPath,
        [string] $IncidentId,
        [string] $Severity,
        [string] $Summary,
        [string] $Source = "Axis_IncidentEngine"
    )

    if (-not (Test-Path $UiInboxPath)) {
        New-Item -ItemType Directory -Path $UiInboxPath -Force | Out-Null
    }

    $intent = @{
        type       = "ui_intent"
        verb       = "haptic_alert"
        source     = $Source
        parameters = @{
            incident_id = $IncidentId
            severity    = $Severity
            summary     = $Summary
            created_at  = (Get-Date).ToString("o")
        }
    } | ConvertTo-Json -Depth 5

    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss-fff")
    $file = Join-Path $UiInboxPath "Haptic_Alert_$stamp.json"
    $intent | Set-Content -Path $file -Encoding UTF8
}

function Get-OrInitHypothesisQueue {
    param([string] $Path)

    if (Test-Path $Path) {
        return (Get-Content $Path -Raw | ConvertFrom-Json)
    }
    else {
        return [pscustomobject]@{
            hypotheses = @()
        }
    }
}

function Get-OrInitRecommendationQueue {
    param([string] $Path)

    if (Test-Path $Path) {
        return (Get-Content $Path -Raw | ConvertFrom-Json)
    }
    else {
        return [pscustomobject]@{
            recommendations = @()
        }
    }
}

function Get-SeverityDefaultPriority {
    param([string] $Severity)

    switch ($Severity.ToLowerInvariant()) {
        "critical" { "high" }
        "high" { "high" }
        "medium" { "medium" }
        "low" { "low" }
        default { "medium" }
    }
}

function Get-SeverityDefaultRiskLevel {
    param([string] $Severity)

    switch ($Severity.ToLowerInvariant()) {
        "critical" { "high" }
        "high" { "high" }
        "medium" { "medium" }
        "low" { "low" }
        default { "medium" }
    }
}

function Process-IncidentPlaybooks {
    param(
        [string] $AxisStatePath,
        [string] $IncidentPlaybookPath,
        [string] $HypothesisQueuePath,
        [string] $RecommendationQueuePath,
        [string] $UiInboxPath
    )

    if (-not (Test-Path $AxisStatePath)) {
        throw "Axis state file not found at '$AxisStatePath'"
    }
    if (-not (Test-Path $IncidentPlaybookPath)) {
        throw "Incident playbook config not found at '$IncidentPlaybookPath'"
    }

    # Load state & playbooks
    $state = Get-Content $AxisStatePath -Raw | ConvertFrom-Json
    $pbConfig = Get-Content $IncidentPlaybookPath -Raw | ConvertFrom-Json

    if (-not $pbConfig.playbooks) {
        Write-Host "[IncidentPlaybooks] No playbooks defined, nothing to do." -ForegroundColor Yellow
        return @{
            incidents_processed   = 0
            playbooks_applied     = 0
            hypotheses_created    = 0
            recommendations_added = 0
            haptic_alerts         = 0
        }
    }

    $hypoQueue = Get-OrInitHypothesisQueue -Path $HypothesisQueuePath
    $recQueue = Get-OrInitRecommendationQueue -Path $RecommendationQueuePath

    if (-not $state.security) {
        $state | Add-Member -NotePropertyName security -NotePropertyValue (@{})
    }
    if (-not $state.security.incidents) {
        $state.security | Add-Member -NotePropertyName incidents -NotePropertyValue @()
    }
    if ($state.security.incidents -isnot [Array]) {
        $state.security.incidents = @($state.security.incidents)
    }

    $incidents = $state.security.incidents | Where-Object { $_.status -eq "active" }

    $stats = @{
        incidents_processed   = 0
        playbooks_applied     = 0
        hypotheses_created    = 0
        recommendations_added = 0
        haptic_alerts         = 0
    }

    foreach ($inc in $incidents) {
        $stats.incidents_processed++

        # Ensure playbook_links exists and is an array
        if (-not $inc.PSObject.Properties.Match('playbook_links').Count) {
            # Use Add-Member to safely add property to the PSCustomObject/Hashtable wrapper
            $inc | Add-Member -NotePropertyName playbook_links -NotePropertyValue @()
        }
        
        # Re-check after potential addition
        if ($inc.playbook_links -isnot [Array]) {
            $inc.playbook_links = @($inc.playbook_links)
        }

        $incType = $inc.type
        $incSeverity = $inc.severity

        $matchingPlaybooks = $pbConfig.playbooks | Where-Object {
            ($_.match.type -eq $incType -or [string]::IsNullOrEmpty($_.match.type)) -and
            ($_.match.severity -eq $incSeverity -or [string]::IsNullOrEmpty($_.match.severity))
        }

        foreach ($pb in $matchingPlaybooks) {
            $pbId = $pb.id

            # Idempotency: skip if playbook already linked to this incident
            $existingLink = $inc.playbook_links | Where-Object { $_.playbook_id -eq $pbId }
            if ($existingLink) {
                continue
            }

            $stats.playbooks_applied++

            $linkedHypothesisId = $null

            # 1) Hypothesis handling
            if ($pb.hypothesis -and $pb.hypothesis.auto_open) {
                $hypId = New-HypothesisId

                if (-not $hypoQueue.hypotheses) {
                    $hypoQueue | Add-Member -NotePropertyName hypotheses -NotePropertyValue @()
                }
                elseif ($hypoQueue.hypotheses -isnot [Array]) {
                    $hypoQueue.hypotheses = @($hypoQueue.hypotheses)
                }

                $priority = if ($pb.hypothesis.priority) {
                    $pb.hypothesis.priority
                }
                else {
                    Get-SeverityDefaultPriority -Severity $incSeverity
                }

                $hObj = [ordered]@{
                    id              = $hypId
                    question        = $pb.hypothesis.question
                    hypothesis      = $pb.hypothesis.hypothesis
                    status          = "open"
                    priority        = $priority
                    created_at      = (Get-Date).ToString("o")
                    source          = "Incident_Playbook"
                    source_incident = $inc.id
                    playbook_id     = $pbId
                    tags            = @($incType, $incSeverity, "incident", "playbook")
                }

                $hypoQueue.hypotheses += [pscustomobject]$hObj
                $linkedHypothesisId = $hypId
                $stats.hypotheses_created++
            }

            # 2) Recommendations
            if ($pb.recommendations) {
                if (-not $recQueue.recommendations) {
                    $recQueue | Add-Member -NotePropertyName recommendations -NotePropertyValue @()
                }
                elseif ($recQueue.recommendations -isnot [Array]) {
                    $recQueue.recommendations = @($recQueue.recommendations)
                }

                foreach ($rTpl in $pb.recommendations) {
                    if (-not $rTpl.auto_enqueue) { continue }

                    $recId = New-RecommendationId

                    $riskLevel = if ($rTpl.risk_level) {
                        $rTpl.risk_level
                    }
                    else {
                        Get-SeverityDefaultRiskLevel -Severity $incSeverity
                    }

                    $rObj = [ordered]@{
                        id                   = $recId
                        name                 = $rTpl.name
                        summary              = $rTpl.summary
                        risk_level           = $riskLevel
                        status               = "pending"
                        created_at           = (Get-Date).ToString("o")
                        source               = "Incident_Playbook"
                        source_incident      = $inc.id
                        playbook_id          = $pbId
                        linked_hypothesis_id = $linkedHypothesisId
                    }

                    $recQueue.recommendations += [pscustomobject]$rObj
                    $stats.recommendations_added++
                }
            }

            # 3) Alerts (haptic)
            if ($pb.alerts -and $pb.alerts.haptic_ping) {
                New-HapticIntentFile -UiInboxPath $UiInboxPath `
                    -IncidentId   $inc.id `
                    -Severity     $incSeverity `
                    -Summary      $inc.summary `
                    -Source       "Incident_Playbook"
                $stats.haptic_alerts++
            }

            # 4) Record playbook link on incident
            $linkObj = [ordered]@{
                playbook_id   = $pbId
                hypothesis_id = $linkedHypothesisId
                linked_at     = (Get-Date).ToString("o")
            }
            $inc.playbook_links += [pscustomobject]$linkObj
        }
    }

    # Persist updated state & queues
    $state     | ConvertTo-Json -Depth 20 | Set-Content -Path $AxisStatePath           -Encoding UTF8
    $hypoQueue | ConvertTo-Json -Depth 20 | Set-Content -Path $HypothesisQueuePath     -Encoding UTF8
    $recQueue  | ConvertTo-Json -Depth 20 | Set-Content -Path $RecommendationQueuePath -Encoding UTF8

    return $stats
}

# Entry point if the script is run directly
if ($MyInvocation.PSScriptRoot -ne "") {
    try {
        $result = Process-IncidentPlaybooks `
            -AxisStatePath           $AxisStatePath `
            -IncidentPlaybookPath    $IncidentPlaybookPath `
            -HypothesisQueuePath     $HypothesisQueuePath `
            -RecommendationQueuePath $RecommendationQueuePath `
            -UiInboxPath             $UiInboxPath

        Write-Host "[IncidentPlaybooks] Completed:" -ForegroundColor Cyan
        $result.GetEnumerator() | ForEach-Object {
            Write-Host ("  {0} = {1}" -f $_.Key, $_.Value)
        }
    }
    catch {
        Write-Error "[IncidentPlaybooks] Failed: $_"
    }
}
