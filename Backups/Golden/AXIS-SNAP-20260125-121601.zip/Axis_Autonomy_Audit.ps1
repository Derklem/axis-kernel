# Axis_Autonomy_Audit.ps1
# Phase 88.1: Autonomy Audit Aggregator (Hardened)
# Generates Infinity\Autonomy\Autonomy_Audit_State.json

$root = "D:\Infinite"
$autonomyDir = Join-Path $root "Infinity\Autonomy"
$auditPath = Join-Path $autonomyDir "Autonomy_Audit_State.json"

# Input Paths (aligned with Axis_Skills / Gate)
$skillRegPath = Join-Path $root "Infinity\Skills\Skill_Registry.json"
$gateLogPath = Join-Path $autonomyDir "Autonomy_Treaty_Packets.json"
$inboxPath = Join-Path $autonomyDir "Autonomy_Requests_Inbox.json"

if (-not (Test-Path $autonomyDir)) {
    New-Item -ItemType Directory -Path $autonomyDir -Force | Out-Null
}

Write-Host "Starting Autonomy Audit..." -ForegroundColor Cyan

# 1. Skills Summary (based on autonomy_calibrated.recommended_level)
$skillsSummary = @{
    total     = 0
    auto      = 0
    manual    = 0
    recommend = 0
}

if (Test-Path $skillRegPath) {
    try {
        $reg = Get-Content $skillRegPath -Raw | ConvertFrom-Json
        $skills = @($reg.skills)
        $skillsSummary.total = $skills.Count

        foreach ($s in $skills) {
            $level = $null
            if ($s.autonomy_calibrated) {
                $level = $s.autonomy_calibrated.recommended_level
            }

            if ([string]::IsNullOrWhiteSpace($level)) { continue }

            if (-not $skillsSummary.ContainsKey($level)) {
                $skillsSummary[$level] = 0
            }

            $skillsSummary[$level]++
        }
    }
    catch {
        Write-Warning "AUTONOMY-AUDIT: Failed to parse Skill Registry: $($_.Exception.Message)"
    }
}
else {
    Write-Warning "AUTONOMY-AUDIT: Skill Registry not found at $skillRegPath"
}

# 2. Gate Decisions (lightweight summary over recent packets)
$gateSummary = @{
    recent_decisions       = @{ auto_allow = 0; escalate = 0; deny = 0 }
    top_escalation_reasons = @()
}

if (Test-Path $gateLogPath) {
    try {
        $gateDoc = Get-Content $gateLogPath -Raw | ConvertFrom-Json
        $packets = @($gateDoc.packets)

        # Consider last N packets (e.g., 100) to avoid unbounded growth
        $recent = $packets | Select-Object -Last 100

        $reasonCounts = @{}

        foreach ($p in $recent) {
            $dec = $p.gate_decision
            if ($dec -and $gateSummary.recent_decisions.ContainsKey($dec)) {
                $gateSummary.recent_decisions[$dec]++
            }

            if ($p.reasons) {
                foreach ($r in $p.reasons) {
                    if (-not $reasonCounts.ContainsKey($r)) {
                        $reasonCounts[$r] = 0
                    }
                    $reasonCounts[$r]++
                }
            }
        }

        # Top 5 escalation reasons by frequency
        $gateSummary.top_escalation_reasons =
        $reasonCounts.GetEnumerator() |
        Sort-Object -Property Value -Descending |
        Select-Object -First 5 |
        ForEach-Object { $_.Key }
    }
    catch {
        Write-Warning "AUTONOMY-AUDIT: Failed to parse Gate log: $($_.Exception.Message)"
    }
}

# 3. Inbox State (robust to missing per-item timestamps)
$inboxSummary = @{ pending_total = 0; stale_over_2h = 0 }

if (Test-Path $inboxPath) {
    try {
        $inboxDoc = Get-Content $inboxPath -Raw | ConvertFrom-Json
        $items = if ($inboxDoc.items) { @($inboxDoc.items) } else { @($inboxDoc) }

        if ($items) {
            $pendingItems = $items | Where-Object { $_.status -eq "pending" }
            $inboxSummary.pending_total = $pendingItems.Count

            $now = Get-Date
            $stale = @()

            foreach ($it in $pendingItems) {
                # Prefer per-item timestamp if present
                $ts = $null
                if ($it.generated_at) {
                    $ts = [datetime]$it.generated_at
                }
                elseif ($it.generated_at_utc) {
                    $ts = [datetime]$it.generated_at_utc
                }

                if ($ts) {
                    $ageHours = ($now - $ts).TotalHours
                    if ($ageHours -gt 2) {
                        $stale += $it
                    }
                }
            }

            $inboxSummary.stale_over_2h = $stale.Count
        }
    }
    catch {
        Write-Warning "AUTONOMY-AUDIT: Failed to parse Autonomy Inbox: $($_.Exception.Message)"
    }
}
else {
    Write-Host "AUTONOMY-AUDIT: No Autonomy Inbox found; treating as empty." -ForegroundColor Gray
}

# 4. Construct Snapshot
$snapshot = @{
    generated_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    summary          = @{
        skills = $skillsSummary
        gate   = $gateSummary
        inbox  = $inboxSummary
    }
    hotspots         = @()  # Future: high-failure / high-escalation strategies
}

$json = $snapshot | ConvertTo-Json -Depth 10
Set-Content -Path $auditPath -Value $json -Encoding UTF8

Write-Host "Audit Snapshot Generated: $auditPath" -ForegroundColor Green
$json | Write-Host
