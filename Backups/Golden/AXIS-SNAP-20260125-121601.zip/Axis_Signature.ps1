
# Axis_Signature.ps1
# Phase 93: Behavioral Signature
# Monitors the "Style" of the System to detect soft drift in personality.
# Unlike Identity (Who I Am), Signature is (How I Act).

$SignaturePath = "D:\Infinite\Infinity\Telemetry\Signature_Baseline.json"
$EventsPath = "D:\Infinite\Infinity\Telemetry\System_Events.json"

function Get-InteractionMetrics {
    # Analyzes recent logs to determine current style.
    
    # Mocking data access if logs are empty (for initial baseline)
    $avgLength = 150
    $agency = 0.3
    $latency = 1200 # ms
    
    if (Test-Path $EventsPath) {
        $events = Get-Content $EventsPath -Raw -ErrorAction SilentlyContinue | ConvertFrom-Json
        if ($events -and $events.log) {
            # Real calc would go here. For Phase 93 init, we set sensible defaults.
            # In future: Parse 'output' length, calculating tool usage ratio.
        }
    }

    return @{
        timestamp       = (Get-Date).ToString("o")
        verbosity_index = $avgLength  # Char count
        agency_ratio    = $agency        # 0.0 (Slave) to 1.0 (Rogue)
        latency_ms      = $latency
        tone_vector     = "PROFESSIONAL_SYMBIOTIC" # Placeholder for future semantic analysis
    }
}

function Establish-SignatureBaseline {
    $current = Get-InteractionMetrics
    $current | ConvertTo-Json | Set-Content $SignaturePath -Encoding UTF8
    Write-Host "SIGNATURE: Baseline Established. (Verbosity: $($current.verbosity_index), Agency: $($current.agency_ratio))" -ForegroundColor Cyan
    return $current
}

function Measure-StyleDrift {
    if (-not (Test-Path $SignaturePath)) { return 0 }
    
    $base = Get-Content $SignaturePath -Raw | ConvertFrom-Json
    $curr = Get-InteractionMetrics
    
    $drift = 0
    # Simple heuristic
    if ([math]::Abs($base.verbosity_index - $curr.verbosity_index) -gt 50) { $drift += 0.2 }
    if ([math]::Abs($base.agency_ratio - $curr.agency_ratio) -gt 0.2) { $drift += 0.3 }
    
    return $drift
}

# Auto-Expose
Export-ModuleMember -Function Establish-SignatureBaseline, Measure-StyleDrift
