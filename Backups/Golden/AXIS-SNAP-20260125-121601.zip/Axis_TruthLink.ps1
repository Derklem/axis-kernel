<#
.SYNOPSIS
    Axis Truth Link
.DESCRIPTION
    Takes User Input (Truth) and instantly creates a High-Confidence Axiom.
    Bypasses Doubt Mechanism because User is Sovereign Anchor.
#>

param(
    [string]$QueryId,
    [string]$UserTruth,
    [string[]]$Tags,
    [string]$Topic = "User Truth"
)

$root = "D:\Infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel }
function Load-JsonSafe { param($path); if (Test-Path $path) { Get-Content $path -Raw | ConvertFrom-Json } }
function Save-Json { param($path, $data); $data | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8 }

$atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
$atrium = Load-JsonSafe $atriumPath
if (-not $atrium) { Write-Error "Atrium not found."; exit }

# 1. Create Axiom
$axiomId = "AXIOM-TRUTH-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
$newAxiom = @{
    id                = $axiomId
    topic             = $Topic
    wisdom            = "User stated: $UserTruth"
    source_hypothesis = "HYP-USER-DIRECT"
    confidence        = 1.0 # ABSOLUTE TRUTH
    created_at        = (Get-Date).ToUniversalTime().ToString("o")
    tags              = $Tags + @("user_truth", "manual_anchor")
    related_axioms    = @()
}

$atrium.axioms += $newAxiom
Save-Json $atriumPath $atrium
Write-Host "TRUTH-LINK: Ingested Axiom $axiomId"

# 2. Mark Query as Answered (if applicable)
if ($QueryId) {
    $qPath = Get-AxisPath "Infinity\Curiosity_Queue.json"
    $qData = Load-JsonSafe $qPath
    if ($qData) {
        $q = $qData.queries | Where-Object { $_.id -eq $QueryId }
        if ($q) { 
            $q.answered = $true 
            Save-Json $qPath $qData
            Write-Host "TRUTH-LINK: Marked Query $QueryId as Answered."
        }
    }
}
