<#
.SYNOPSIS
    Phase 127 - Axis Horizon (Predictive Defense)
.DESCRIPTION
    Analyzes historical risk data to forecast future stability.
    If the trend indicates a critical breach within 1 hour, triggers preemptive defense.
#>

param(
    [string]$RiskHistoryPath = "D:\Infinite\Infinity\Shadow\Risk_Trend_Log.json",
    [string]$NeuralEngine = "D:\Infinite\Axis_Neural_Reflection.ps1"
)

$ErrorActionPreference = "Stop"

function Get-RiskForecast {
    if (-not (Test-Path $RiskHistoryPath)) { return 0 }
    
    try {
        $log = Get-Content $RiskHistoryPath -Raw | ConvertFrom-Json
        $data = @($log.history) | Sort-Object timestamp -Descending | Select-Object -First 10
        if ($data.Count -lt 3) { return 0 } # Not enough data
        
        # Simple Linear Regression (y = mx + b)
        # x = index (reversed time), y = risk score
        $n = $data.Count
        $sumX = 0; $sumY = 0; $sumXY = 0; $sumXX = 0
        
        for ($i = 0; $i -lt $n; $i++) {
            $x = $n - 1 - $i # 0 is oldest in this window
            $y = $data[$i].score
            $sumX += $x
            $sumY += $y
            $sumXY += ($x * $y)
            $sumXX += ($x * $x)
        }
        
        $slope = (($n * $sumXY) - ($sumX * $sumY)) / (($n * $sumXX) - ($sumX * $sumX))
        $intercept = ($sumY - ($slope * $sumX)) / $n
        
        # Predict 1 step into the future
        $nextX = $n
        $prediction = ($slope * $nextX) + $intercept
        
        return $prediction
    }
    catch {
        return 0
    }
}

function Invoke-HorizonScan {
    Write-Host "[HORIZON] Scanning future timelines..." -F Cyan
    
    $prediction = Get-RiskForecast
    Write-Host "  > Predicted Risk (1h): $prediction" -F Gray
    
    if ($prediction -ge 0.9) {
        Write-Host "  > [WARNING] Critical instability forecasted. Triggering Preemptive Defense." -F Yellow
        
        if (Test-Path $NeuralEngine) {
            . $NeuralEngine
            New-ReflectionProposal -Type "predictive_defense" -Target "global_system" -Reason "Horizon forecasts risk > 0.9 within 1 hour." -Severity "critical" -Explanation "Linear regression on risk history indicates a localized collapse event is imminent."
        }
    }
    else {
        Write-Host "  > Forecast stable." -F Green
    }
}

# Helper to log current risk (called by Mind)
function Log-RiskPoint {
    param($Score)
    $entry = @{ timestamp = (Get-Date).ToUniversalTime().ToString("o"); score = $Score }
    
    $log = @{ history = @() }
    if (Test-Path $RiskHistoryPath) {
        try { $log = Get-Content $RiskHistoryPath -Raw | ConvertFrom-Json } catch {}
    }
    
    $log.history += $entry
    # Keep last 50 points
    $log.history = $log.history | Sort-Object timestamp | Select-Object -Last 50
    
    $dir = Split-Path $RiskHistoryPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    
    $log | ConvertTo-Json -Depth 4 | Set-Content $RiskHistoryPath -Encoding UTF8
}

if ($MyInvocation.PSScriptRoot -ne "") {
    # Standalone mode
    # Invoke-HorizonScan
}
