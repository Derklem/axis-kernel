<#
.SYNOPSIS
    Phase 119 - Doctrine Evolution (Amendment Engine)
.DESCRIPTION
    Analyzes Incident Log for False Positives related to Doctrine rules.
    Proposes amendments to loosen rules that are trigger-happy.
#>

param(
    [string] $IncidentLogPath = "D:\Infinite\Infinity\Incident_Log.json",
    [string] $PoliciesPath = "D:\Infinite\Infinity\Incident_Doctrine_Policies.json",
    [string] $DoctrinePath = "D:\Infinite\Infinity\Doctrine\Doctrine_Rules.json",
    [string] $QueuePath = "D:\Infinite\Infinity\AutoTune_Queue.json",
    [string] $JournalPath = "D:\Infinite\Infinity\Autonomy_Journal.md"
)

$ErrorActionPreference = "Stop"

function Invoke-DoctrineAmendment {
    if (-not (Test-Path $PoliciesPath)) { return }
    if (-not (Test-Path $IncidentLogPath)) { return }
    if (-not (Test-Path $DoctrinePath)) { return }

    $log = Get-Content $IncidentLogPath -Raw | ConvertFrom-Json
    $policies = Get-Content $PoliciesPath -Raw | ConvertFrom-Json
    $doctrine = Get-Content $DoctrinePath -Raw | ConvertFrom-Json
    $queue = if (Test-Path $QueuePath) { Get-Content $QueuePath -Raw | ConvertFrom-Json } else { @{ proposals = @() } }
    if ($queue -is [Array]) { $queue = @{ proposals = $queue } }

    $now = Get-Date

    foreach ($policy in $policies.policies) {
        # 1. Gather relevant incidents in window
        $windowStart = $now.AddHours(-$policy.metric_window.hours)
        
        $relevantIncidents = $log.incidents | Where-Object {
            $_.type -eq $policy.match.incident_type -and
            ([DateTime]$_.timestamp) -ge $windowStart
        }

        if ($relevantIncidents.Count -lt $policy.metric_window.min_incidents) { continue }

        # 2. Group by Rule ID (assumed to be in context.rule_id if available, otherwise we skip for now)
        $groups = $relevantIncidents | Group-Object { $_.context.rule_id }

        foreach ($group in $groups) {
            $ruleId = $group.Name
            if (-not $ruleId) { continue }

            $total = $group.Count
            $fpCount = ($group.Group | Where-Object { $_.tags -contains "false_positive" -or $_.classification -eq "false_positive" }).Count
            $ratio = $fpCount / $total

            if ($ratio -ge $policy.metric_window.min_false_positive_ratio) {
                # 3. Candidate for Amendment
                # Check if already in queue
                $existing = $queue.proposals | Where-Object { 
                    $_.scope -eq "doctrine" -and 
                    $_.target.rule_id -eq $ruleId -and 
                    $_.status -eq "open" 
                }
                if ($existing) { continue }

                # Load current rule state
                $rule = $doctrine.rules | Where-Object { $_.rule_id -eq $ruleId }
                if (-not $rule) { continue }

                # 4. Create Proposal
                $proposalId = "AT-DOCTRINE-$($now.ToString('yyyyMMdd'))-$(-join((48..57+65..90 | Get-Random -Count 4 | ForEach-Object {[char]$_})))"
                
                $proposal = [ordered]@{
                    id              = $proposalId
                    scope           = "doctrine"
                    status          = "open"
                    source          = "Incident_Doctrine_Evolution"
                    created_at      = $now.ToString("o")
                    target          = @{
                        rule_id    = $ruleId
                        rule_scope = $rule.scope
                        file       = "Doctrine_Rules.json"
                    }
                    proposed_change = @{
                        action = $policy.amendment_template.action
                        before = @{
                            severity = $rule.policy.severity # Note: adjusting to match likely schema
                            autonomy = $rule.policy.autonomy
                        }
                        after  = @{
                            severity = $policy.amendment_template.suggestion.new_severity
                            autonomy = "low_risk_only" # Example loosening
                        }
                    }
                    metric_basis    = @{
                        window_hours   = $policy.metric_window.hours
                        incident_count = $total
                        fp_count       = $fpCount
                        fp_ratio       = $ratio
                        incident_ids   = $group.Group.id
                    }
                    reason          = $policy.amendment_template.suggestion.notes
                }

                $queue.proposals += $proposal
                Write-Host "[AMEND] Proposed amendment for $ruleId (FP Ratio: $ratio)" -ForegroundColor Cyan

                # 5. Journal
                $journalNote = "`n> [Phase 119] Proposed Doctrine Amendment: $ruleId. Reason: $total incidents, $fpCount False Positives ($($ratio*100)%). Suggest $($policy.amendment_template.suggestion.new_severity)."
                Add-Content $JournalPath $journalNote
            }
        }
    }

    $queue | ConvertTo-Json -Depth 20 | Set-Content $QueuePath -Encoding UTF8
}

if ($MyInvocation.PSScriptRoot -ne "") {
    Invoke-DoctrineAmendment
}
