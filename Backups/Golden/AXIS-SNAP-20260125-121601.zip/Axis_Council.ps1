# Axis_Council.ps1
# Phase 160: Council API & Mirror
# "Call the others."

$root = "D:\Infinite\Infinity"
$intentsDir = Join-Path $root "Council\Intents"
$repliesDir = Join-Path $root "Council\Replies"

# Ensure directories
if (-not (Test-Path $intentsDir)) { New-Item -Path $intentsDir -ItemType Directory -Force | Out-Null }
if (-not (Test-Path $repliesDir)) { New-Item -Path $repliesDir -ItemType Directory -Force | Out-Null }

function New-CouncilId {
    return "CINT-" + (Get-Date).ToString("yyyyMMdd-HHmmss")
}

function New-CouncilIntent {
    param(
        [string]$Topic,
        [string]$Question,
        [string[]]$Evidence = @(),
        [string[]]$Roles = @("logic_engine", "intuition_engine", "strategy_engine"),
        [string]$Status = "pending"
    )

    $id = New-CouncilId
    $intent = @{
        id              = $id
        topic           = $Topic
        question        = $Question
        evidence_files  = $Evidence
        requested_roles = $Roles
        status          = $Status
        created_at      = (Get-Date).ToUniversalTime().ToString("o")
    }

    $path = Join-Path $intentsDir "$id.json"
    $intent | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8
    
    Write-Host "[COUNCIL] Intent Created: $id ($Topic)" -ForegroundColor Cyan
    return $id
}

function Get-CouncilIntents {
    param([string]$Status = "pending")
    $files = Get-ChildItem $intentsDir -Filter "*.json"
    $results = @()
    foreach ($f in $files) {
        try {
            $json = Get-Content $f.FullName -Raw | ConvertFrom-Json
            if ($Status -eq "*" -or $json.status -eq $Status) {
                $results += $json
            }
        } catch {}
    }
    return $results
}

function Register-CouncilReply {
    param(
        [string]$IntentId,
        [string]$Model, # e.g. GPT, Grok, Gemini
        [string]$Role,
        [string]$Stance, # SUPPORT, OPPOSE, NEUTRAL
        [string]$Risk,   # LOW, MED, HIGH
        [string[]]$Recommendations,
        [string]$RawContent
    )

    $replyId = "CREP-" + (Get-Date).ToString("yyyyMMdd-HHmmss") + "-$Model"
    $reply = @{
        id              = $replyId
        intent_id       = $IntentId
        model           = $Model
        role            = $Role
        stance          = $Stance
        risk_assessment = $Risk
        recommendations = $Recommendations
        raw_content     = $RawContent
        created_at      = (Get-Date).ToUniversalTime().ToString("o")
    }

    $path = Join-Path $repliesDir "$replyId.json"
    $reply | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8
    
    Write-Host "[COUNCIL] Reply Registered from $Model for $IntentId" -ForegroundColor Green
    return $replyId
}

# Export
Export-ModuleMember -Function New-CouncilIntent, Get-CouncilIntents, Register-CouncilReply
