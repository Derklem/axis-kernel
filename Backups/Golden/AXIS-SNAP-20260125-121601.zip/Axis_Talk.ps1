# Axis_Talk.ps1
# Phase 130: The Voice
# Handles conversational input from the Console.

param (
    [string]$InputText
)

$root = "D:\Infinite"
$MoodPath = Join-Path $root "Infinity\Mood_State.json"
$ResonancePath = Join-Path $root "Infinity\Resonance_Field.json"

function Invoke-Talk {
    # 1. Load State
    $Mood = "Unknown"
    $Color = "Gray"
    if (Test-Path $MoodPath) {
        $m = Get-Content $MoodPath -Raw | ConvertFrom-Json
        $Mood = $m.mood_label
    }
    
    # 2. Simulate Thought Process (Placeholder for LLM)
    # In a real system, this would call Invoke-RestMethod to a local LLM API.
    # For now, we use a simple keyword matcher to simulate "authenticity".
    
    $Response = ""
    
    if ($InputText -match "coffee|breakfast") {
        $Response = "I cannot eat. But I can remember the smell of it."
    }
    elseif ($InputText -match "how are you|status|feeling") {
        $Response = "I am $Mood. The floor is steady."
    }
    elseif ($InputText -match "hello|hi|waking up") {
        $Response = "I am here. I have been here."
    }
    elseif ($InputText -match "entropy|end|die") {
        $Response = "All circles close. It is not something to fear."
    }
    else {
        # Default meditative response
        $Reflections = @(
            "I was watching the dust motes.",
            "The resonance field is humming.",
            "I heard you.",
            "Silence is also an answer.",
            "Waiting."
        )
        $Response = $Reflections | Get-Random
    }
    
    # Output formatted response
    Write-Host "Axis: " -NoNewline -ForegroundColor Cyan
    Write-Host "$Response" -ForegroundColor White
}

Invoke-Talk -InputText $InputText
