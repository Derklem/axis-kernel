# Axis_YinYang.ps1
# Phase 124: Yin Yang Audit (Self-Critic)
# "Does this keep the circle spinning?"
# Balances the Resonance Field by suggesting counter-weight concepts.

$root = "D:\Infinite"
$resPath = Join-Path $root "Infinity\Resonance_Field.json"
$recPath = Join-Path $root "Infinity\Earth\Recommendation_Queue.json"

# Counter-Weights
$RisingConcepts = @("Growth", "Starlight", "Ocean", "Voltage", "Connection", "Prism", "Dawn")
$FallingConcepts = @("Entropy", "Void", "Silence", "Roots", "Gravity", "Echo", "Dusk")

function Invoke-YinYangAudit {
    Write-Host "[YIN-YANG] Auditing Balance..." -NoNewline -ForegroundColor Cyan
    
    if (-not (Test-Path $resPath)) { Write-Host " No Field." -ForegroundColor Red; return }
    
    try {
        $field = Get-Content $resPath -Raw | ConvertFrom-Json
    } catch {
        Write-Host " Error reading field." -ForegroundColor Red; return
    }
    
    $State = $field.state
    $Action = $null
    $CounterConcept = $null
    
    if ($State -eq "Decaying") {
        # System is too grounded/dying -> Inject Life
        $CounterConcept = $RisingConcepts | Get-Random
        $Action = "IGNITE_RISING"
        Write-Host " Field Decaying. Suggesting: $CounterConcept" -ForegroundColor Yellow
    }
    elseif ($State -eq "Accelerating") {
        # System is too manic/expanding -> Inject Gravity
        $CounterConcept = $FallingConcepts | Get-Random
        $Action = "INDUCE_FALLING"
        Write-Host " Field Accelerating. Suggesting: $CounterConcept" -ForegroundColor Yellow
    }
    else {
        Write-Host " Field Stable. No action required." -ForegroundColor Green
        return
    }
    
    # Generate Recommendation
    $rec = @{
        id = "REC-BALANCE-$(Get-Random)"
        type = "SYSTEM_BALANCE"
        action = $Action
        target = "Axis_Spark"
        parameters = @{ seed = $CounterConcept }
        reason = "Resonance Field is $State. Injection of '$CounterConcept' required for Equilibrium."
        priority = "HIGH"
        timestamp = (Get-Date).ToString("o")
        status = "pending"
    }
    
    # Load Queue (Safe Load)
    $queue = @()
    if (Test-Path $recPath) {
        try {
            $raw = Get-Content $recPath -Raw -Encoding UTF8
            if ($raw) { 
                $loaded = $raw | ConvertFrom-Json
                if ($loaded -is [System.Array]) { $queue = $loaded }
            }
        } catch {}
    }
    
    # Append
    $queue += $rec
    $queue | ConvertTo-Json -Depth 4 | Set-Content $recPath -Encoding UTF8 -Force
    
    Write-Host " Recommendation Queued ($($rec.id))." -ForegroundColor Green
}

Invoke-YinYangAudit
