<#
.SYNOPSIS
    Axis Resident Engine - Phase 200 (Expansion)

.DESCRIPTION
    Hosts long-lived "resident agents" on top of the Sovereign OS.

    v1 Scope:
      - Loads Resident_Agents.json
      - Exposes: Get-ResidentAgents, Invoke-ResidentAgent
      - Implements AGENT-RESEARCHER-001 as a low-risk, read-only Researcher:
          * Scans Neural_Inbox
          * Writes a structured report to Neural_Reports
          * Appends an intel entry to Neural_Intel_Index.json
          * Emits telemetry as JSONL

    NOTE:
      This is intentionally conservative: no external calls, no config writes,
      no tool execution. It only reads documents and writes its own logs/reports.
#>

param(
    [string] $Root = "D:\Infinite",
    [string] $AgentId = "AGENT-RESEARCHER-001"
)

$ErrorActionPreference = "Stop"

# --- Paths -------------------------------------------------------------

$InfinityRoot = Join-Path $Root "Infinity"
$ResidentConfigPath = Join-Path $InfinityRoot "Resident_Agents.json"
$NeuralIndexPath = Join-Path $InfinityRoot "Neural_Intel_Index.json"
$ResidentLogPath = Join-Path $InfinityRoot "Logs\Resident_Engine.log"
$ResidentTelemetry = Join-Path $InfinityRoot "Logs\Resident_Engine.jsonl"

# --- Helpers -----------------------------------------------------------

function Write-ResidentLog {
    param(
        [string] $Message,
        [string] $Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $line = "[$ts] [$Level] $Message"

    $logDir = Split-Path $ResidentLogPath -Parent
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }

    Add-Content -Path $ResidentLogPath -Value $line

    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARN" { "Yellow" }
        default { "Gray" }
    }

    Write-Host $line -ForegroundColor $color
}

function Write-ResidentTelemetry {
    param(
        [hashtable] $Event
    )

    $Event.timestamp = (Get-Date).ToString("o")

    $teleDir = Split-Path $ResidentTelemetry -Parent
    if (-not (Test-Path $teleDir)) {
        New-Item -ItemType Directory -Path $teleDir -Force | Out-Null
    }

    $line = $Event | ConvertTo-Json -Compress
    Add-Content -Path $ResidentTelemetry -Value $line
}

function Load-ResidentConfig {
    param(
        [string] $Path
    )

    if (-not (Test-Path $Path)) {
        throw "Resident configuration not found at '$Path'. Expected Resident_Agents.json."
    }

    try {
        $cfg = Get-Content $Path -Raw | ConvertFrom-Json
        if (-not $cfg.agents) {
            throw "Resident configuration missing 'agents' array."
        }
        return $cfg
    }
    catch {
        throw "Failed to parse Resident_Agents.json: $_"
    }
}

function Get-ResidentAgents {
    param(
        [string] $Path = $ResidentConfigPath
    )
    $cfg = Load-ResidentConfig -Path $Path
    return $cfg.agents
}

function Get-ResidentAgent {
    param(
        [string] $Id,
        [string] $Path = $ResidentConfigPath
    )

    $agents = Get-ResidentAgents -Path $Path
    $agent = $agents | Where-Object { $_.id -eq $Id } | Select-Object -First 1

    if (-not $agent) {
        throw "Resident agent '$Id' not found in config."
    }

    return $agent
}

function Ensure-NeuralIndex {
    param(
        [string] $Path = $NeuralIndexPath
    )

    if (-not (Test-Path $Path)) {
        $dir = Split-Path $Path -Parent
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }

        $obj = @{
            version = 1
            entries = @()
        }
        $obj | ConvertTo-Json -Depth 5 | Set-Content $Path -Encoding UTF8
        return [pscustomobject]$obj
    }

    try {
        $idx = Get-Content $Path -Raw | ConvertFrom-Json
        if (-not $idx.PSObject.Properties.Match('entries')) {
            $idx | Add-Member -NotePropertyName entries -NotePropertyValue @()
        }
        elseif ($idx.entries -isnot [Array]) {
            $idx.entries = @($idx.entries)
        }
        return $idx
    }
    catch {
        Write-ResidentLog "Neural_Intel_Index.json corrupt: $_" "WARN"
        $bak = "$Path.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
        Move-Item $Path $bak -Force
        Write-ResidentLog "Backed up corrupt Neural_Intel_Index to $bak" "WARN"

        $obj = @{
            version = 1
            entries = @()
        }
        $obj | ConvertTo-Json -Depth 5 | Set-Content $Path -Encoding UTF8
        return [pscustomobject]$obj
    }
}

function New-ResidentIntelId {
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $rand = -join (1..4 | ForEach-Object { [char](Get-Random -InputObject (48..57 + 65..90)) })
    return "INTEL-$stamp-$rand"
}

function New-ResidentReportId {
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $rand = -join (1..4 | ForEach-Object { [char](Get-Random -InputObject (48..57 + 65..90)) })
    return "REPORT-RESEARCH-$stamp-$rand"
}

# --- Agent Implementation: Researcher ---------------------------------

function Invoke-ResidentResearcher {
    param(
        [pscustomobject] $Agent,
        [string]         $RootPath = $Root
    )

    Write-ResidentLog "Invoking Resident Agent: $($Agent.id) ($($Agent.name))"

    if (-not $Agent.enabled) {
        Write-ResidentLog "Agent is disabled. Exiting." "WARN"
        Write-ResidentTelemetry @{
            event    = "agent_disabled"
            agent_id = $Agent.id
            name     = $Agent.name
        }
        return
    }

    $inboxPath = $Agent.mounts.inbox
    $reportsPath = $Agent.mounts.reports

    if (-not $inboxPath) {
        throw "Agent '$($Agent.id)' is missing 'mounts.inbox'."
    }
    if (-not $reportsPath) {
        throw "Agent '$($Agent.id)' is missing 'mounts.reports'."
    }

    if (-not (Test-Path $inboxPath)) {
        Write-ResidentLog "Inbox path '$inboxPath' does not exist. Creating." "WARN"
        New-Item -ItemType Directory -Path $inboxPath -Force | Out-Null
    }
    if (-not (Test-Path $reportsPath)) {
        New-Item -ItemType Directory -Path $reportsPath -Force | Out-Null
    }

    # Scan inbox (read-only)
    $files = Get-ChildItem -Path $inboxPath -File -ErrorAction SilentlyContinue

    $totalFiles = $files.Count
    if ($totalFiles -eq 0) {
        Write-ResidentLog "No files found in Neural_Inbox. Nothing to do."
        Write-ResidentTelemetry @{
            event    = "agent_run"
            agent_id = $Agent.id
            name     = $Agent.name
            files    = 0
            outcome  = "no_work"
        }
        return
    }

    $byExt = $files | Group-Object Extension
    $extSummary = $byExt | ForEach-Object {
        [pscustomobject]@{
            extension = $_.Name
            count     = $_.Count
        }
    }

    $oldest = ($files | Sort-Object LastWriteTime | Select-Object -First 1).LastWriteTime
    $newest = ($files | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime

    # Build report
    $reportId = New-ResidentReportId
    $reportPath = Join-Path $reportsPath "$reportId.json"

    $report = [ordered]@{
        id              = $reportId
        agent_id        = $Agent.id
        agent_name      = $Agent.name
        generated_at    = (Get-Date).ToString("o")
        inbox_path      = $inboxPath
        files_scanned   = $totalFiles
        file_extensions = $extSummary
        time_window     = @{
            oldest = $oldest.ToString("o")
            newest = $newest.ToString("o")
        }
        sample_files    = ($files | Select-Object -First 10 | ForEach-Object {
                @{
                    name       = $_.Name
                    extension  = $_.Extension
                    last_write = $_.LastWriteTime.ToString("o")
                    size_bytes = $_.Length
                }
            })
        notes           = @(
            "This is a scaffold report produced by AGENT-RESEARCHER-001.",
            "No external research calls were executed.",
            "Future versions may call Anti-Gravity / Neural fetchers under governance control."
        )
    }

    $report | ConvertTo-Json -Depth 8 | Set-Content $reportPath -Encoding UTF8
    Write-ResidentLog "Wrote research report: $reportPath"

    # Update Neural_Intel_Index.json
    $index = Ensure-NeuralIndex -Path $NeuralIndexPath

    $intelId = New-ResidentIntelId

    if (-not $index.entries) {
        $index | Add-Member -NotePropertyName entries -NotePropertyValue @()
    }
    elseif ($index.entries -isnot [Array]) {
        $index.entries = @($index.entries)
    }

    $entry = [ordered]@{
        id          = $intelId
        timestamp   = (Get-Date).ToString("o")
        source      = $Agent.id
        type        = "research_scan"
        files       = $totalFiles
        report_path = $reportPath
        summary     = "Scanned $totalFiles files in Neural_Inbox; report at $reportPath."
        tags        = @("resident_agent", "research", "neural_inbox")
    }

    $index.entries += [pscustomobject]$entry

    $index | ConvertTo-Json -Depth 10 | Set-Content $NeuralIndexPath -Encoding UTF8
    Write-ResidentLog "Appended intel entry $intelId to Neural_Intel_Index.json"

    # Telemetry
    Write-ResidentTelemetry @{
        event       = "agent_run"
        agent_id    = $Agent.id
        name        = $Agent.name
        files       = $totalFiles
        report_path = $reportPath
        intel_id    = $intelId
        outcome     = "success"
    }
}

function Invoke-ResidentAgent {
    param(
        [string] $Id
    )

    $agent = Get-ResidentAgent -Id $Id -Path $ResidentConfigPath

    switch ($agent.id) {
        "AGENT-RESEARCHER-001" {
            Invoke-ResidentResearcher -Agent $agent -RootPath $Root
        }
        default {
            throw "No implementation bound for resident agent '$($agent.id)'."
        }
    }
}

# --- Entry Point -------------------------------------------------------

Write-ResidentLog "Axis_Resident_Engine starting. Root = $Root, AgentId = $AgentId"

try {
    Invoke-ResidentAgent -Id $AgentId
    Write-ResidentLog "Axis_Resident_Engine completed for AgentId = $AgentId"
}
catch {
    Write-ResidentLog "Resident engine failed: $_" "ERROR"
    Write-ResidentTelemetry @{
        event    = "engine_error"
        agent_id = $AgentId
        error    = "$_"
    }
    throw
}
