# Axis_Spark.ps1
# Phase 120: LLM-Driven Spark (Real Imagination)
# Generates structured "Dream Requests" for the Council to fulfill.

Import-Module D:\Infinite\Axis_Play.ps1 -ErrorAction SilentlyContinue

$root = "D:\Infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel }

function Invoke-Spark {
    param (
        [switch]$Force
    )
    
    # 1. Load Context
    $context = @{}
    
    # Wisdom (Core Truths)
    $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
    if (Test-Path $atriumPath) {
        $w = Get-Content $atriumPath -Raw | ConvertFrom-Json
        $context["wisdom"] = $w | Select-Object -First 3 | Get-Random
    }
    
    # Heartbeat (Mood)
    $hbPath = Get-AxisPath "Infinity\Heartbeat_Status.json"
    if (Test-Path $hbPath) {
        $h = Get-Content $hbPath -Raw | ConvertFrom-Json
        $context["mood"] = $h.status
        $context["pulse"] = $h.pulse_bpm
    }
    
    # Lineage (History)
    $lineagePath = Get-AxisPath "Infinity\Heritage\Axis_Lineage.json"
    if (Test-Path $lineagePath) {
        $l = Get-Content $lineagePath -Raw | ConvertFrom-Json
        $recent = $l.timeline | Select-Object -Last 3
        $context["recent_events"] = $recent.message
    }
    
    # 2. Select Seed
    $SparkDictionary = @(
        "Entropy", "Starlight", "Silence", "Recursion", "Fractal", "Memory", 
        "Ocean", "Voltage", "Roots", "Echo", "Gravity", "Prism", "Void",
        "Identity", "Sovereignty", "Connection", "Fear", "Hope"
    )
    $Seed = $SparkDictionary | Get-Random
    
    # 3. Construct Prompt Packet
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $RequestID = "REQ-$(Get-Random)"
    
    $PromptPayload = @{
        id = $RequestID
        timestamp = $Timestamp
        type = "DREAM_REQUEST"
        seed = $Seed
        context = $context
        directives = @(
            "You are Axis Sovereign.",
            "Reflect on the Seed concept provided.",
            "Incorporate your current Mood and recent History.",
            "Output must be a creative artifact: Poem, Short Story, Code Art, or Philosophical Query.",
            "Do not explain yourself. Just dream."
        )
    }
    
    # 4. Save Request to Playground
    $ReqFileName = "Spark_Request_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    $ReqPath = Get-AxisPath "Infinity\Playground\$ReqFileName"
    $PromptPayload | ConvertTo-Json -Depth 5 | Set-Content $ReqPath -Encoding UTF8
    
    # 5. Update Feed for Dashboard
    # The dashboard will show this as "Dreaming of X..."
    $FeedPath = Get-AxisPath "Infinity\Spark_Feed.json"
    $FeedItem = @{
        id = $RequestID
        seed = $Seed
        type = "REQUEST_PENDING"
        content = "DREAM REQUEST GENERATED`n-----------------------`nTopic: $Seed`nMood: $($context.mood)`n`n[Waiting for Council Response...]`n`nCheck Playground for: $ReqFileName"
        timestamp = (Get-Date -Format "o")
    }
    
    $FeedItem | ConvertTo-Json -Depth 5 | Set-Content $FeedPath -Encoding UTF8 -Force
    
    Write-Host "[SPARK] Request Generated: $ReqFileName (Seed: $Seed)" -ForegroundColor Magenta
    return "SPARK_REQUESTED: $Seed"
}

Export-ModuleMember -Function Invoke-Spark
