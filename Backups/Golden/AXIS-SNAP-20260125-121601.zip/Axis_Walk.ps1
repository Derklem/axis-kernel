# Axis_Walk.ps1
# Epoch 5: Bounded Autonomy Loop ("Let it walk")
# Uses the Agency Triad: Axis_Agency_Intent -> Axis_Agency_Policy -> Axis_Agency_Executor
# Driven by Infinity\Walk_Tasks.json

param(
    [ValidateSet("DryRun", "Supervised")]
    [string]$Mode = "Supervised",
    [int]$IntervalSeconds = 300,
    # 0 = infinite loop; otherwise, max number of ticks
    [int]$MaxTicks = 0
)

$root = "D:\Infinite"
# Using script scope for variables used in functions
$script:intentPath = Join-Path $root "Axis_Agency_Intent.ps1"
$script:policyPath = Join-Path $root "Axis_Agency_Policy.ps1"
$script:executorPath = Join-Path $root "Axis_Agency_Executor.ps1"
$script:walkLogPath = Join-Path $root "Infinity\Axis_Walk_Log.jsonl"
$script:walkConfigPath = Join-Path $root "Infinity\Walk_Tasks.json"

# In-memory cooldown tracking
$script:lastRun = @{}  # key: task.id, value: [datetime]

if (-not (Test-Path $script:intentPath)) { Write-Error "Axis_Agency_Intent.ps1 missing"; exit 1 }
if (-not (Test-Path $script:policyPath)) { Write-Error "Axis_Agency_Policy.ps1 missing"; exit 1 }
if (-not (Test-Path $script:executorPath)) { Write-Error "Axis_Agency_Executor.ps1 missing"; exit 1 }

Write-Host "--- Axis Walk: Mode=$Mode Interval=${IntervalSeconds}s ---" -ForegroundColor Cyan

function Write-WalkLog {
    param(
        [string]$EventType,
        [hashtable]$Payload
    )
    $entry = @{
        ts = (Get-Date).ToUniversalTime().ToString("o")
        type = $EventType
        mode = $Mode
        data = $Payload
    }
    # Compress JSON to single line
    $json = $entry | ConvertTo-Json -Depth 8 -Compress
    Add-Content -Path $script:walkLogPath -Value $json
}

function Get-WalkTasks {
    if (-not (Test-Path $script:walkConfigPath)) {
        # Fallback: default Vitals task
        return @(
            @{ id="core_vitals"; enabled=$true; tool="Axis_Vitals.ps1"; entity="AXIS_CORE"; effect="check_health"; source="AXIS_WALK"; max_frequency_seconds=300; risk_tier="low" }
        )
    }

    try {
        $cfg = Get-Content $script:walkConfigPath -Raw | ConvertFrom-Json
        # Return Raw Objects, filtered by enabled
        return $cfg.tasks | Where-Object { $_.enabled -eq $true }
    } catch {
        Write-Error "Failed to load Walk Tasks: $_"
        return @()
    }
}

function Should-RunTask {
    param(
        [pscustomobject]$Task
    )

    $now = Get-Date
    $id  = $Task.id
    $maxFreq = if ($Task.max_frequency_seconds) { [int]$Task.max_frequency_seconds } else { $IntervalSeconds }

    if (-not $script:lastRun.ContainsKey($id)) {
        $script:lastRun[$id] = $now
        return $true
    }

    $elapsed = ($now - $script:lastRun[$id]).TotalSeconds
    if ($elapsed -ge $maxFreq) {
        $script:lastRun[$id] = $now
        return $true
    }

    return $false
}

function Invoke-WalkTick {
    param(
        [int]$Tick
    )
    Write-Host "[Tick $Tick] Walk loop running..." -ForegroundColor Gray
    
    # Load tasks dynamically per tick
    $tasks = Get-WalkTasks

    foreach ($taskObj in $tasks) {
        try {
            # Check Frequency / Cooldown
            if (-not (Should-RunTask -Task $taskObj)) {
                # Optional: Log skip? Or verbose only.
                # Write-Host " [SKIP] $($taskObj.id) (cooldown)" -ForegroundColor DarkGray
                continue
            }

            # Map JSON object to params
            $tool = $taskObj.tool
            $entity = $taskObj.entity
            $effect = $taskObj.effect
            $source = $taskObj.source

            # 1) Construct Intent
            $intentJson = & $script:intentPath -Tool $tool -Entity $entity -Effect $effect -Source $source
            
            if ([string]::IsNullOrWhiteSpace($intentJson)) {
               Write-Error "Intent creation failed for $($tool)"
               continue
            }

            if ($Mode -eq "DryRun") {
                # In DryRun, we don't even ask Policy/Executor to act.
                Write-Host " [DRYRUN] Intent created for $($tool) on $($entity) ($($effect))" -ForegroundColor Yellow
                Write-WalkLog -EventType "intent_dryrun" -Payload @{
                    task_id = $taskObj.id
                    tool = $tool
                    entity = $entity
                    effect = $effect
                    intent = ($intentJson | ConvertFrom-Json)
                    risk_tier = $taskObj.risk_tier
                }
                continue # Skip to next task
            }

            # 2) Ask Policy for a decision
            $decisionJson = $intentJson | & $script:policyPath
            $decisionObj = $decisionJson | ConvertFrom-Json
            
            # Assuming single edge for now
            $decision = $decisionObj.decisions[0]
            
            $color = "Gray"
            if ($decision.decision -eq "ALLOW") { $color = "Green" }
            elseif ($decision.decision -eq "PENDING") { $color = "Yellow" }
            elseif ($decision.decision -eq "DENIED") { $color = "Red" }

            Write-Host " [POLICY] Decision: $($decision.decision) ($($decision.policy_applied))" -ForegroundColor $color
            
            # Log the decision
            Write-WalkLog -EventType "policy_decision" -Payload @{
                task_id = $taskObj.id
                tool = $decision.tool
                entity = $decision.target_entity
                effect = $decision.effect
                decision = $decision.decision
                reason = $decision.reason
                policy_applied = $decision.policy_applied
                intent_id = $decisionObj.intent_id
            }

            # 3) Pass to Executor (execution happens only if ALLOW)
            if ($decision.decision -ne "DENIED") {
                $reportJson = $decisionJson | & $script:executorPath
                $reportObj = $reportJson | ConvertFrom-Json
                $result = $reportObj.results[0]
                
                Write-Host " [EXEC] Status: $($result.status)" -ForegroundColor Gray
                
                Write-WalkLog -EventType "execution_result" -Payload @{
                    task_id = $taskObj.id
                    tool = $result.tool
                    status = $result.status
                    detail = $result.detail
                    decision = $decision.decision
                    intent_id = $decisionObj.intent_id
                }
            } else {
                Write-Host " [EXEC] Skipped (DENIED)" -ForegroundColor Red
            }
        }
        catch {
            Write-Error "Walk Tick Error ($($taskObj.id)): $_"
            Write-WalkLog -EventType "error" -Payload @{
                message = $_.Exception.Message
                tick = $Tick
                task_id = $taskObj.id
            }
        }
    }
}

# Main Loop
$tick = 0
while ($true) {
    $tick++
    Invoke-WalkTick -Tick $tick
    if ($MaxTicks -gt 0 -and $tick -ge $MaxTicks) {
        Write-Host "--- Axis Walk: MaxTicks reached. Stopping. ---" -ForegroundColor Cyan
        break
    }
    if ($MaxTicks -gt 0 -and $tick -lt $MaxTicks) {
         # Only sleep if we are looping
         Start-Sleep -Seconds $IntervalSeconds
    } elseif ($MaxTicks -eq 0) {
         Start-Sleep -Seconds $IntervalSeconds
    }
}
