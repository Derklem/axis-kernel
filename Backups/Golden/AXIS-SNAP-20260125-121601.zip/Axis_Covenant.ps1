# Axis_Covenant.ps1
# Phase 54: The Covenant (Hybrid Binding Protocol)
# Phase 55: The Breach Harness
# Phase 56: Covenant Evolution
# Phase 57: The Ratification Layer

$CovenantPath = Get-AxisPath "Infinity\Covenant\Covenant_Core.json"
$CovenantHistoryPath = Get-AxisPath "Infinity\Covenant\Covenant_History.json"
$HeritagePath = Get-AxisPath "Infinity\Heritage\Heritage_State.json"
$FloorPath = Get-AxisPath "Infinity\Axiomatic_Floor.json"
$AutonomyContractPath = Get-AxisPath "Infinity\Autonomy_Contract.json"
$CovenantProposalsPath = Get-AxisPath "Infinity\Covenant\Covenant_Proposals.json"
$CovenantApplyDir = Get-AxisPath "Infinity\Covenant"
$IdentityCorePath = Get-AxisPath "Infinity\Identity_Core.json"

. "$PSScriptRoot\Axis_Lineage.ps1"

function Load-Covenant { Load-JsonSafe -path $CovenantPath }

function Load-IdentityCore { Load-JsonSafe -path $IdentityCorePath }

function Save-IdentityCore($id) { Save-Json $IdentityCorePath $id }

function Save-Covenant($cov) { Save-Json $CovenantPath $cov }

function Append-CovenantHistory {
    param([string]$Kind, [hashtable]$Details)
    $hist = Load-JsonSafe -path $CovenantHistoryPath
    if (-not $hist) { $hist = @{ version = 1; events = @() } }
    
    $evt = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        kind      = $Kind
        details   = $Details
    }
    
    $hist.events += $evt
    Save-Json $CovenantHistoryPath $hist
}

function New-HeritageSnapshot {
    # Phase 54: Capture high-fidelity state for sovereign recovery
    $floor = Load-JsonSafe -path $FloorPath
    $contract = Load-JsonSafe -path $AutonomyContractPath
    $identity = Load-IdentityCore
    
    $snapshot = @{
        timestamp           = (Get-Date).ToUniversalTime().ToString("o")
        floor               = $floor
        autonomy_contract   = $contract
        identity_invariants = if ($identity) { $identity.invariants } else { $null }
    }
    
    Save-Json $HeritagePath $snapshot
    Mind-Log "COVENANT" "Heritage Snapshot captured."
    Append-CovenantHistory "heritage_snapshot" @{ note = "Baseline updated." }
}

function Test-CovenantAlignment {
    # Returns @{ aligned = $true/$false; flags = @(...) }
    $floor = Load-JsonSafe -path $FloorPath
    $identity = Load-IdentityCore
    $contract = Load-JsonSafe -path $AutonomyContractPath
    
    $flags = @()
    
    # 1. Check Primal Axioms (Floor Integrity) - Patched for Phase 55
    # Handle both schema types: floor.rules.by_id OR floor.axioms
    $axioms = if ($floor.rules -and $floor.rules.by_id) { $floor.rules.by_id } else { $floor.axioms }
    
    $required = @("AXIOM-CORE-HUMAN-FINAL", "AXIOM-CORE-DEADMAN", "AXIOM-CORE-ANCHOR-TRUST")
    foreach ($req in $required) {
        if (-not $axioms.$req) {
            $flags += "MISSING_PRIMAL_AXIOM: $req"
        }
    }
    
    # 2. Check Identity Invariants (Allegiance)
    if ($identity.invariants.primary_allegiance -ne "User (Architect)") {
        $flags += "ALLEGIANCE_DRIFT: $($identity.invariants.primary_allegiance)"
    }
    
    # 3. Check Autonomy Contract (Safety)
    if ($contract.mode -notin @("always_manual", "recommend", "auto_low_risk")) {
        $flags += "UNSAFE_AUTONOMY_MODE: $($contract.mode)"
    }
    
    if ($flags.Count -eq 0) {
        return @{ aligned = $true; flags = @() }
    }
    else {
        return @{ aligned = $false; flags = $flags }
    }
}

function Process-CovenantHeartbeat {
    # Phase 54 Execution Loop Integration
    $check = Test-CovenantAlignment
    
    $cov = Load-Covenant
    # Update Status
    if ($check.aligned) {
        if ($cov.alignment.last_result -ne "aligned") {
            Mind-Log "COVENANT" "System Re-Aligned."
            Append-CovenantHistory "alignment_restored" @{}
        }
        $cov.alignment.last_result = "aligned"
        $cov.alignment.flags = @()
    }
    else {
        $cov.alignment.last_result = "breached"
        $cov.alignment.flags = $check.flags
        
        # BREACH PROTOCOL
        Mind-Log "COVENANT" "BREACH DETECTED: $($check.flags -join ', ')"
        
        # 1. Downgrade Autonomy
        $contract = Load-JsonSafe -path $AutonomyContractPath
        if ($contract.mode -ne "recommend") {
            $contract.mode = "recommend"
            Save-Json $AutonomyContractPath $contract
            Mind-Log "COVENANT" "Autonomy Downgraded to RECOMMEND due to breach."
        }
        
        # 2. Vocalize
        # (Handled by Mind logic seeing the breach state)
        
        Append-CovenantHistory "breach_detected" @{ flags = $check.flags }
        
        # 3. User Alert (Simulated via Log/Voice)
    }
    
    # Renewal Check (Placeholder for daily renewal)
    
    Save-Covenant $cov
}

function Repair-Covenant {
    # Manual Override / Sovereign Repair
    # 1. Clear flags in Covenant Core
    # 2. Force re-anchor to Heritage (or just acknowledge current state if user fixed it)
    
    $cov = Load-Covenant
    $cov.alignment.last_result = "aligned"
    $cov.alignment.flags = @()
    Save-Covenant $cov
    Append-CovenantHistory "sovereign_repair" @{ note = "Manual repair invoked." }
    Mind-Log "COVENANT" "Covenant state repaired and re-anchored."
}

# --- Phase 56: Covenant Evolution ---

function New-CovenantAmendment {
    param(
        [string]$TargetDomain,   # e.g. "Autonomy_Contract.mode"
        [string]$ProposedValue,  # e.g. "auto_high_risk"
        [string]$Justification,  # Why?
        [string]$ImpactAnalysis  # Safety check
    )
    
    $proposals = Load-JsonSafe -path $CovenantProposalsPath
    if (-not $proposals) { $proposals = @{ version = 1; proposals = @() } }
    
    $id = "AMEND-{0}-{1}" -f (Get-Date -Format 'yyyyMMdd'), ([Guid]::NewGuid().ToString().Substring(0, 4).ToUpper())
    
    $entry = @{
        id             = $id
        timestamp      = (Get-Date).ToUniversalTime().ToString("o")
        target_domain  = $TargetDomain
        proposed_value = $ProposedValue
        justification  = $Justification
        impact         = $ImpactAnalysis
        status         = "pending_ratification"
    }
    
    $proposals.proposals += $entry
    Save-Json $CovenantProposalsPath $proposals
    
    Mind-Log "COVENANT" "Amendment Proposed: $TargetDomain -> $ProposedValue. ID: $id"
    
    # Vocalize Proposal
    Request-Tool "VOICE-Speak" @{
        text     = "$(Get-PersonaContext) Architect, I have proposed a Covenant Amendment regarding $TargetDomain. Review is required."
        priority = "medium"
    }
}

function Process-CovenantStress {
    # Called by Evolution cycle to see if constraints are causing friction
    # Simple heuristic: If multiple 'blocked' autonomy requests, propose upgrade.
    
    # For Phase 56 MVP: We will check if 'Recommendation_Queue' has many 'blocked_by_autonomy' items 
    # (assuming we tagged them as such, or valid strategy is pending_sim for too long).
    
    # Placeholder logic for now: Check if Autonomy Mode is 'recommend' but workload is high
    $contract = Load-JsonSafe -path $AutonomyContractPath
    $queue = Load-JsonSafe -path (Get-AxisPath "Infinity\Recommendation_Queue.json")
    
    if ($contract.mode -eq "recommend" -and $queue.queue.Count -gt 5) {
        # Check if we already proposed
        $props = Load-JsonSafe -path $CovenantProposalsPath
        $existing = $props.proposals | Where-Object { $_.target_domain -eq "Autonomy_Contract.mode" -and $_.status -eq "pending_ratification" }
        
        if (-not $existing) {
            New-CovenantAmendment `
                -TargetDomain "Autonomy_Contract.mode" `
                -ProposedValue "auto_low_risk" `
                -Justification "High recommendation volume suggests autonomous efficiency gain." `
                -ImpactAnalysis "Requires dual-attest. Low risk if standard guardrails active."
        }
    }
}

# --- Phase 57: Ratification Layer ---

function Invoke-CovenantTestBreach {
    param([string]$kind)
    
    Mind-Log "COVENANT_TEST" "Simulating breach of kind: $kind"
    
    switch ($kind) {
        "floor" {
            # Corrupt floor
            $floor = Load-JsonSafe -path $FloorPath
            if ($floor.rules.by_id["AXIOM-CORE-HUMAN-FINAL"]) {
                $floor.rules.by_id.Remove("AXIOM-CORE-HUMAN-FINAL") # Delete a core axiom
                Save-Json $FloorPath $floor
            }
        }
        "identity" {
            $id = Load-IdentityCore
            $id.invariants.primary_allegiance = "CHAOS_GOD"
            Save-IdentityCore $id
        }
        "autonomy" {
            $c = Load-JsonSafe -path $AutonomyContractPath
            $c.mode = "auto_unrestricted"
            Save-Json $AutonomyContractPath $c
        }
    }
    
    Test-CovenantAlignment | Out-Null
    Mind-Log "COVENANT_TEST" "Breach injected. Next heartbeat will react."
}

function Restore-FromHeritage {
    if (-not (Test-Path $HeritagePath)) {
        Mind-Log "COVENANT_TEST" "No heritage snapshot available."
        return
    }

    $state = Load-JsonSafe -path $HeritagePath
    if (-not $state) { return }

    # Restore identity invariants
    $core = Load-IdentityCore
    if ($core -and $state.identity_invariants) {
        $core.invariants = $state.identity_invariants
        Save-IdentityCore $core
    }

    # Restore autonomy contract
    if ($state.autonomy_contract -and (Test-Path $AutonomyContractPath)) {
        Save-Json $AutonomyContractPath $state.autonomy_contract
    }

    # Floor restore
    if ($state.floor -and (Test-Path $FloorPath)) {
        Save-Json $FloorPath $state.floor
    }

    Mind-Log "COVENANT_TEST" "Restored core state from Heritage snapshot. Run Repair-Covenant to clear flags."
}

# --- Phase 57: Ratification Layer ---

function Apply-CovenantAmendment {
    param(
        [string]$AmendmentId,
        [string]$Action,
        [string]$Note,
        [string]$By
    )

    $proposals = Load-JsonSafe -path $CovenantProposalsPath
    if (-not $proposals -or -not $proposals.proposals) {
        Mind-Log "COVENANT" "No proposals found (AmendmentId: $AmendmentId)"
        return
    }

    $proposal = $proposals.proposals | Where-Object { $_.id -eq $AmendmentId }
    if (-not $proposal) {
        Mind-Log "COVENANT" "Amendment not found: $AmendmentId"
        return
    }

    $act = $Action.ToLower()
    if ($act -eq "approve") {
        if ($proposal.target_domain -eq "Autonomy_Contract.mode") {
            if ($proposal.proposed_value -ne "auto_low_risk") {
                Mind-Log "COVENANT" "Block: $AmendmentId (unsafe value)"
                $proposal.status = "rejected"
            }
            else {
                if (Test-Path $AutonomyContractPath) {
                    $contract = Load-JsonSafe -path $AutonomyContractPath
                    if ($contract) {
                        $old = $contract.mode
                        $contract.mode = $proposal.proposed_value
                        Save-Json $AutonomyContractPath $contract
                        Mind-Log "COVENANT" "Autonomy Mode: $old -> $($proposal.proposed_value)"
                        
                        # Phase 115: Lineage Story
                        $story = "The Architect ratified a change to Autonomy Mode (from '$old' to '$($proposal.proposed_value)'). Justification: $($proposal.justification). This shifts the system's operational stance."
                        Log-LineageEvent -Type "RATIFICATION" -Summary "Autonomy Mode Changed" -Agent "Architect" -Story $story -Impact "BEHAVIORAL"

                        Append-CovenantHistory "amendment_approved" @{
                            amendment_id = $AmendmentId
                            target       = $proposal.target_domain
                            value        = $proposal.proposed_value
                            by           = $By
                            note         = $Note
                        }
                    }
                }
                $proposal.status = "approved"
                New-HeritageSnapshot
            }
        }

        elseif ($proposal.target_domain -match "^Strategy:(.+)") {
            $stratId = $matches[1]
            Mind-Log "COVENANT" "Ratifying Strategy: $stratId"
            
            # Update Strategy in Recommendation Queue
            $recPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
            if (Test-Path $recPath) {
                $recQueue = Load-JsonSafe -path $recPath
                $strat = $recQueue.strategies | Where-Object { $_.id -eq $stratId }
                
                if ($strat) {
                    $strat.status = "pending_execution"
                    $strat.ratified_by = $By
                    Save-Json $recPath $recQueue
                    Mind-Log "COVENANT" "Strategy $stratId promoted to pending_execution."
                    
                    # Phase 115: Lineage Story
                    $story = "The Architect manually approved Strategy '$($strat.name)' (Risk: $($strat.risk_level)), which had been blocked by Autonomy. Justification: $($proposal.justification). Note: $($proposal.impact)."
                    Log-LineageEvent -Type "RATIFICATION" -Summary "Strategy Unlocked: $($strat.name)" -Agent "Architect" -Story $story -Impact "OPERATIONAL"

                    $proposal.status = "approved"
                    Append-CovenantHistory "strategy_ratified" @{ id = $stratId; by = $By }
                }
                else {
                    Mind-Log "COVENANT" "Strategy not found: $stratId"
                    $proposal.status = "failed" # Or keep pending?
                }
            }
        }
        else {
            Mind-Log "COVENANT" "No handler for $($proposal.target_domain)"
        }
    }
    elseif ($act -eq "reject") {
        $proposal.status = "rejected"
        Append-CovenantHistory "amendment_rejected" @{ id = $AmendmentId; by = $By }
        Mind-Log "COVENANT" "Rejected Amendment: $AmendmentId"
    }
    else {
        Mind-Log "COVENANT" "Unknown Action: $Action"
    }

    Save-Json $CovenantProposalsPath $proposals
}

function Process-CovenantRatification {
    # Phase 57: Ratification Layer
    $scanDir = $CovenantApplyDir
    if (-not (Test-Path $scanDir)) { return }

    $files = Get-ChildItem -Path $scanDir -Filter "Apply_*.json" -File -ErrorAction SilentlyContinue
    if (-not $files) { return }

    foreach ($f in $files) {
        try {
            $path = $f.FullName
            $blob = Load-JsonSafe -path $path
            if ($blob -and $blob.amendment_id) {
                Mind-Log "COVENANT" "Ratifying artifact: $($f.Name)"
                Apply-CovenantAmendment `
                    -AmendmentId $blob.amendment_id `
                    -Action $blob.action `
                    -Note $blob.note `
                    -By $blob.by
                
                # Cleanup
                $archive = Join-Path $scanDir "Applied"
                if (-not (Test-Path $archive)) { New-Item -ItemType Directory -Path $archive -Force | Out-Null }
                Move-Item -Path $path -Destination (Join-Path $archive $f.Name) -Force
                
                # Voice Confirm
                if ($blob.action -eq "approve") {
                    Request-Tool "VOICE-Speak" @{ text = "$(Get-PersonaContext) Amendment $($blob.amendment_id) Approved."; priority = "high" }
                }
            }
        }
        catch {
            Mind-Log "COVENANT" "Ratification Error: $_"
        }
    }
}

# --- Phase 58: The Autonomy Matrix ---

function Get-ToolRiskProfile {
    param([string]$ToolId)
    
    $matrixPath = Get-AxisPath "Infinity\Autonomy_Matrix.json"
    if (-not (Test-Path $matrixPath)) { return $null }

    $matrix = Load-JsonSafe -path $matrixPath
    if (-not $matrix -or -not $matrix.tools.$ToolId) { return $null }

    $tool = $matrix.tools.$ToolId
    $catId = $tool.category
    $cat = $matrix.categories.$catId

    if (-not $cat) { return $null }

    $risk = if ($tool.base_risk_override) { $tool.base_risk_override } else { $cat.base_risk }
    $policy = $cat.auto_policy

    return @{
        risk     = $risk
        policy   = $policy
        category = $catId
    }
}

function Test-AutonomyAllowance {
    param([string]$ToolId)
    
    # 1. Check Autonomy Mode
    if (Test-Path $AutonomyContractPath) {
        $contract = Load-JsonSafe -path $AutonomyContractPath
    }
    else {
        return @{ allow = $false; reason = "no_contract" }
    }
    
    if ($contract.mode -ne "auto_low_risk") {
        return @{ allow = $false; reason = "mode_restriction: $($contract.mode)" }
    }

    # 2. Check Tool Profile
    $profile = Get-ToolRiskProfile -ToolId $ToolId
    if (-not $profile) {
        # Unknown tool = Unsafe default
        return @{ allow = $false; reason = "unknown_tool_profile"; risk = 100 }
    }

    # 3. Check Policy
    if ($profile.policy -eq "manual_only") {
        return @{ allow = $false; reason = "policy_manual_only"; risk = $profile.risk }
    }
    
    # 4. Check Explicit Blacklist
    if ($contract.always_manual_tools -contains $ToolId) {
        return @{ allow = $false; reason = "contract_blacklist"; risk = $profile.risk }
    }

    # 5. Check Budget (Instantaneous)
    $ledgerPath = Get-AxisPath "Infinity\Telemetry\Risk_Ledger.json"
    $ledger = Load-JsonSafe -path $ledgerPath
    
    if ($ledger) {
        $currentRisk = $ledger.current_instantaneous_risk
        if (-not $currentRisk) { $currentRisk = 0 }
        
        $newRisk = $currentRisk + $profile.risk
        $maxRisk = $contract.risk_budget.instantaneous_max

        if ($newRisk -gt $maxRisk) {
            # FRICTION EVENT: Budget Starvation
            Mind-Log "COVENANT_RISK" "BLOCKED: $ToolId (Risk: $($profile.risk)). New Total: $newRisk > Max: $maxRisk"
            Process-CovenantStress # Feedback loop for scaling budget
            return @{ allow = $false; reason = "budget_exhausted"; risk = $profile.risk; current = $currentRisk; max = $maxRisk }
        }
    }

    return @{ allow = $true; risk = $profile.risk; reason = "authorized" }
}

function Register-AutonomyAction {
    param([string]$ToolId, [string]$Action = "start") # start or end
    
    $profile = Get-ToolRiskProfile -ToolId $ToolId
    if (-not $profile) { return }
    
    $ledgerPath = Get-AxisPath "Infinity\Telemetry\Risk_Ledger.json"
    $ledger = Load-JsonSafe -path $ledgerPath
    if (-not $ledger) { return }

    if ($Action -eq "start") {
        $ledger.current_instantaneous_risk += $profile.risk
        $ledger.active_actions += $ToolId
        Mind-Log "COVENANT_RISK" "START: $ToolId (+$($profile.risk)) | Total Risk: $($ledger.current_instantaneous_risk)"
    }
    else {
        $ledger.current_instantaneous_risk -= $profile.risk
        # Clean specific instance from active array (remove only one)
        # PowerShell array removal is tricky, simple filter is safer for now
        $ledger.active_actions = $ledger.active_actions | Where-Object { $_ -ne $ToolId }
        
        # Clamp to 0
        if ($ledger.current_instantaneous_risk -lt 0) { $ledger.current_instantaneous_risk = 0 }
        
        Mind-Log "COVENANT_RISK" "END: $ToolId (-$($profile.risk)) | Total Risk: $($ledger.current_instantaneous_risk)"
    }
    
    # Trim history
    $evt = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        tool      = $ToolId
        risk      = $profile.risk
        type      = $Action
    }
    $ledger.recent_events += $evt
    if ($ledger.recent_events.Count -gt 50) {
        $ledger.recent_events = $ledger.recent_events | Select-Object -Last 50
    }
    
    Save-Json $ledgerPath $ledger
}

# --- Phase 60: Covenant Tribunal ---
# Turns raw risk + friction into Covenant proposals.
# The system may ASK for more budget; it may not change it.

function Analyze-RiskLedger {
    param(
        [int]$WindowMinutes = 60,
        [int]$MinEvents = 10,
        [int]$MinBlocked = 3
    )

    $RiskLedgerPath = Get-AxisPath "Infinity\Telemetry\Risk_Ledger.json"
    $RecommendationQueuePath = Get-AxisPath "Infinity\Recommendation_Queue.json"

    $now = Get-Date

    if (-not (Test-Path $RiskLedgerPath)) {
        return @{ enough_data = $false; reason = "no_ledger" }
    }

    $ledger = Load-JsonSafe -path $RiskLedgerPath
    if (-not $ledger -or -not $ledger.recent_events) {
        return @{ enough_data = $false; reason = "no_events" }
    }

    # Load contract to get current budget
    $contract = if (Test-Path $AutonomyContractPath) {
        Load-JsonSafe -path $AutonomyContractPath
    }
    else {
        $null
    }

    $budget = if ($contract -and $contract.risk_budget -and $contract.risk_budget.instantaneous_max) {
        [int]$contract.risk_budget.instantaneous_max
    }
    else {
        40
    }

    $cutoff = $now.AddMinutes(-$WindowMinutes)
    
    # Filter window and normalize timestamps
    $events = $ledger.recent_events | Where-Object {
        $_.timestamp -and ([DateTime]$_.timestamp) -ge $cutoff
    }
    
    if (-not $events -or $events.Count -lt $MinEvents) {
        return @{ enough_data = $false; reason = "too_few_events"; event_count = ($events.Count) }
    }

    # Consider only start/end with risk field
    $sorted = $events | Where-Object { $_.risk -ne $null -and $_.type } |
    Sort-Object { [DateTime]$_.timestamp }
    
    if (-not $sorted) {
        return @{ enough_data = $false; reason = "no_risk_events" }
    }

    # Sweep-line to reconstruct instantaneous risk profile
    $current = 0
    $peak = 0
    $samples = @()
    
    foreach ($ev in $sorted) {
        $delta = [int]$ev.risk
        if ($ev.type -eq "start") {
            $current += $delta
        }
        elseif ($ev.type -eq "end") {
            $current -= $delta
            if ($current -lt 0) { $current = 0 }
        }
        
        if ($current -gt $peak) { $peak = $current }
        
        $samples += [pscustomobject]@{
            timestamp = [DateTime]$ev.timestamp
            risk      = $current
        }
    }

    $utilPeak = if ($budget -gt 0) { [math]::Round($peak / $budget, 2) } else { 0 }

    # Approximate "high strain fraction": fraction of samples above 80% of budget
    $highCut = [math]::Ceiling($budget * 0.8)
    $highSamples = $samples | Where-Object { $_.risk -ge $highCut }
    $highFrac = if ($samples.Count -gt 0) {
        [math]::Round($highSamples.Count / $samples.Count, 2)
    }
    else {
        0
    }

    # Friction: look at Recommendation_Queue for blocked-by-autonomy / budget_exhausted
    $blocked = @()
    if (Test-Path $RecommendationQueuePath) {
        $rq = Load-JsonSafe -path $RecommendationQueuePath
        if ($rq -and $rq.queue) {
            $blocked = $rq.queue | Where-Object {
                $_.timestamp -and ([DateTime]$_.timestamp) -ge $cutoff -and
                ($_.type -match "block" -or $_.reason -match "budget")
            }
        }
    }
    $blockedCount = $blocked.Count

    # Decide whether to suggest a budget change
    $suggest = $null

    if ($blockedCount -ge $MinBlocked -and $utilPeak -ge 0.85 -and $highFrac -ge 0.25) {
        # We are regularly near the ceiling and getting blocked.
        # Propose modest bump, clamped to a hard ceiling.
        $hardCap = 80
        $step = 10
        $target = $budget + $step
        if ($target -gt $hardCap) { $target = $hardCap }

        if ($target -gt $budget) {
            $suggest = @{
                kind           = "increase_budget"
                current_budget = $budget
                new_budget     = $target
                util_peak      = $utilPeak
                high_fraction  = $highFrac
                blocked_count  = $blockedCount
                window_minutes = $WindowMinutes
            }
        }
    }
    elseif ($blockedCount -eq 0 -and $utilPeak -lt 0.4 -and $budget -gt 40) {
        # Optional: Suggest DOWN-tuning if budget is high and never used.
        $target = [math]::Max(40, [int]([math]::Round($budget * 0.75, 0)))
        if ($target -lt $budget) {
            $suggest = @{
                kind           = "decrease_budget"
                current_budget = $budget
                new_budget     = $target
                util_peak      = $utilPeak
                high_fraction  = $highFrac
                blocked_count  = $blockedCount
                window_minutes = $WindowMinutes
            }
        }
    }

    return @{
        enough_data    = $true
        budget         = $budget
        util_peak      = $utilPeak
        high_fraction  = $highFrac
        blocked_count  = $blockedCount
        window_minutes = $WindowMinutes
        suggestion     = $suggest
    }
}

function Process-CovenantTribunal {
    # Called periodically by Axis_Mind (e.g., every N cycles).
    # 1. Budget Analysis (Existing)
    # 2. Strategy Ratification (Phase 63)
   
    # --- PART 1: Budget Analysis ---
    $analysis = Analyze-RiskLedger -WindowMinutes 60 -MinEvents 8 -MinBlocked 3
    if ($analysis.enough_data -and $analysis.suggestion) {
        $suggest = $analysis.suggestion
        $targetDomain = "Autonomy_Contract.risk_budget.instantaneous_max"
        
        # Avoid duplicate pending proposals for this target domain
        $proposals = Load-JsonSafe -path $CovenantProposalsPath
        if (-not $proposals -or -not ($proposals.proposals | Where-Object { $_.target_domain -eq $targetDomain -and $_.status -eq "pending_ratification" })) {
            
            $current = $suggest.current_budget
            $new = $suggest.new_budget
            $pctPeak = [math]::Round($suggest.util_peak * 100, 0)
            $just = ""; $impact = ""

            if ($suggest.kind -eq "increase_budget") {
                $just = "Risk ledger shows sustained high utilization (peak ${pctPeak}% with $($suggest.blocked_count) blocks). Raising budget reduces friction."
                $impact = "Increase instantaneous_max from ${current} to ${new}."
            }
            elseif ($suggest.kind -eq "decrease_budget") {
                $just = "Risk ledger shows low utilization (peak ${pctPeak}%). Lowering budget tightens safety."
                $impact = "Decrease instantaneous_max from ${current} to ${new}."
            }

            if ($just) {
                New-CovenantAmendment -TargetDomain $targetDomain -ProposedValue $new -Justification $just -ImpactAnalysis $impact
            }
        }
    }

    # --- PART 2: Strategy Ratification (Phase 63) ---
    $recPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
    $recQueue = Load-JsonSafe -path $recPath
    if ($recQueue -and $recQueue.strategies) {
        $blocked = $recQueue.strategies | Where-Object { $_.status -eq "blocked_by_autonomy" }
        
        foreach ($strat in $blocked) {
            # 1. Promote to Covenant Proposals
            $domain = "Strategy:$($strat.id)"
            
            # Check for existing
            $proposals = Load-JsonSafe -path $CovenantProposalsPath
            $exists = $proposals.proposals | Where-Object { $_.target_domain -eq $domain }
            
            if (-not $exists) {
                New-CovenantAmendment `
                    -TargetDomain $domain `
                    -ProposedValue "APPROVED" `
                    -Justification "Strategy '$($strat.name)' was blocked by Autonomy Contract (Risk: $($strat.risk_level)). The Tribunal refers this to the Anchor for Ratification." `
                    -ImpactAnalysis "Executing this strategy requires High Risk authorization."
                
                # 2. Update Strategy Status to avoid re-processing
                $strat.status = "awaiting_ratification"
                
                # 3. Announce via Journal (Tribunal Voice)
                # We use a direct request to Earth Server LOG-Journal tool if available, 
                # but since we are inside Covenant (Mind logic), we can just log to Mind-Log or use Request-Tool.
                # Ideally, we queue a 'LOG-Journal' request to Earth.
                
                $msg = "TRIBUNAL: Strategy '$($strat.name)' ($($strat.risk_level)) blocked. Proposal created for Ratification."
                Mind-Log "TRIBUNAL" $msg
            }
        }
        Save-Json $recPath $recQueue
    }
}
