param(
    [ValidateSet("DryRun", "Enforce")]
    [string]$Mode = "Enforce"
)

$root = "D:\Infinite"
$configPath = Join-Path $root "Infinity\Keeper_Config.json"
$keeperLogPath = Join-Path $root "Infinity\Axis_Keeper_Log.jsonl"

if (-not (Test-Path $configPath)) {
    Write-Error "Keeper config not found: $configPath"
    exit 1
}

try {
    $cfg = Get-Content $configPath -Raw | ConvertFrom-Json
} catch {
    Write-Error "Failed to parse Keeper config: $_"
    exit 1
}

function Write-KeeperLog {
    param(
        [string]$EventType,
        [hashtable]$Payload
    )
    $entry = @{
        ts   = (Get-Date).ToUniversalTime().ToString("o")
        type = $EventType
        mode = $Mode
        data = $Payload
    }
    $json = $entry | ConvertTo-Json -Depth 8 -Compress
    Add-Content -Path $keeperLogPath -Value $json
}

function Rotate-Logs {
    param(
        [pscustomobject]$Config
    )

    if (-not $Config.enabled) { return }

    $maxBytes   = [int64]($Config.max_size_mb * 1MB)
    $archiveDir = $Config.archive_dir

    if (-not (Test-Path $archiveDir)) {
        New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null
    }

    foreach ($filePath in $Config.files) {
        if (-not (Test-Path $filePath)) { continue }

        $fi = Get-Item $filePath
        if ($fi.Length -lt $maxBytes) { continue }

        $ts = (Get-Date).ToUniversalTime().ToString("yyyyMMdd-HHmmss")
        $base = [System.IO.Path]::GetFileNameWithoutExtension($fi.Name)
        $ext  = [System.IO.Path]::GetExtension($fi.Name)
        $archiveName = "$base-$ts$ext"
        $archivePath = Join-Path $archiveDir $archiveName

        Write-Host "Rotating log: $filePath -> $archivePath" -ForegroundColor Yellow

        Write-KeeperLog -EventType "log_rotation" -Payload @{
            original_path = $filePath
            archive_path  = $archivePath
            size_bytes    = $fi.Length
        }

        if ($Mode -eq "Enforce") {
            try {
                Move-Item -Path $filePath -Destination $archivePath -Force
                # Recreate empty file
                New-Item -ItemType File -Path $filePath -Force | Out-Null
            } catch {
                Write-Error "Failed to rotate $($filePath): $_"
                Write-KeeperLog -EventType "error" -Payload @{
                    operation = "rotate_log"
                    path      = $filePath
                    error     = $_.Exception.Message
                }
            }
        }
    }
}

function Cleanup-Rule {
    param(
        [pscustomobject]$Rule
    )

    if (-not $Rule.enabled) { return }

    $root   = $Rule.root
    $pattern = $Rule.pattern
    $maxAgeDays = [int]$Rule.max_age_days
    $maxTotalMb = [int]$Rule.max_total_mb

    if (-not (Test-Path $root)) { return }

    $now = Get-Date
    $files = Get-ChildItem -Path $root -Filter $pattern -File -Recurse -ErrorAction SilentlyContinue

    if (-not $files) { return }

    # Age-based deletes
    $ageCutoff = $now.AddDays(-$maxAgeDays)
    $toDeleteByAge = @($files | Where-Object { $_.LastWriteTime -lt $ageCutoff })

    # Size-based deletes
    $totalBytes = ($files | Measure-Object Length -Sum).Sum
    $maxBytes = $maxTotalMb * 1MB

    $toDeleteBySize = @()
    if ($totalBytes -gt $maxBytes) {
        $over = $totalBytes - $maxBytes
        # Oldest-first deletion
        $ordered = $files | Sort-Object LastWriteTime
        $acc = 0L
        foreach ($f in $ordered) {
            $acc += $f.Length
            $toDeleteBySize += $f
            if ($acc -ge $over) { break }
        }
    }

    # Combine sets
    $toDelete = @{}
    foreach ($f in $toDeleteByAge + $toDeleteBySize) {
        $toDelete[$f.FullName] = $f
    }
    $final = $toDelete.Values

    foreach ($f in $final) {
        Write-Host "Cleanup candidate: $($f.FullName)" -ForegroundColor Yellow
        Write-KeeperLog -EventType "cleanup_candidate" -Payload @{
            rule_id    = $Rule.id
            path       = $f.FullName
            size_bytes = $f.Length
            last_write = $f.LastWriteTime.ToString("o")
        }

        if ($Mode -eq "Enforce" -and $Rule.safe_delete) {
            try {
                Remove-Item -Path $f.FullName -Force
                Write-KeeperLog -EventType "cleanup_deleted" -Payload @{
                    rule_id    = $Rule.id
                    path       = $f.FullName
                    size_bytes = $f.Length
                }
            } catch {
                Write-Error "Failed to delete $($f.FullName): $_"
                Write-KeeperLog -EventType "error" -Payload @{
                    operation = "cleanup_delete"
                    rule_id   = $Rule.id
                    path      = $f.FullName
                    error     = $_.Exception.Message
                }
            }
        }
    }
}

Write-Host "--- Axis Keeper: Mode=$Mode ---" -ForegroundColor Cyan

Rotate-Logs -Config $cfg.log_rotation

if ($cfg.cleanup_rules) {
    foreach ($rule in $cfg.cleanup_rules) {
        Cleanup-Rule -Rule $rule
    }
}

Write-KeeperLog -EventType "keeper_pulse" -Payload @{
    status = "ok"
    rotation_checked = $true
    cleanup_checked = $true
}

Write-Host "--- Axis Keeper: Complete ---" -ForegroundColor Cyan
