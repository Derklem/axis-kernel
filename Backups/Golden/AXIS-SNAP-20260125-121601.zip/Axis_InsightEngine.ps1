param(
    [string]$TargetFile = "D:\Infinite\Infinity\Insights_Snapshot.json"
)

$root = "D:\infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel }

$chroniclePath = Get-AxisPath "Infinity\Chronicle_Index.json"
if (-not (Test-Path $chroniclePath)) {
    Write-Error "Chronicle Index missing. Cannot compute insights."
    exit 1
}

$chronicle = Get-Content $chroniclePath -Raw | ConvertFrom-Json
$events = $chronicle.events

$now = [DateTime]::UtcNow

# 1. Tool Reliability Heatmap
$toolStats = @{}
$resultsDir = Get-AxisPath "Infinity\Earth\Results"
if (Test-Path $resultsDir) {
    Get-ChildItem $resultsDir -Filter *.json | ForEach-Object {
        try {
            $res = Get-Content $_.FullName -Raw | ConvertFrom-Json
            $t = $res.tool
            if (-not $toolStats.ContainsKey($t)) { $toolStats[$t] = @{ success = 0; fail = 0; total = 0 } }
            $toolStats[$t].total++
            if ($res.status -eq "success") { $toolStats[$t].success++ } else { $toolStats[$t].fail++ }
        }
        catch { }
    }
}

$reliability = @{}
foreach ($t in $toolStats.Keys) {
    $s = $toolStats[$t]
    $reliability[$t] = @{
        pass_rate = [math]::Round(($s.success / $s.total) * 100, 1)
        fail_rate = [math]::Round(($s.fail / $s.total) * 100, 1)
        volume    = $s.total
    }
}

# 2. Operational Pulse (Thought vs Action)
$thoughtCount = ($events | Where-Object { $_.src -eq "Axis_Mind" -and $_.kind -eq "CYCLE_COMPLETE" }).Count
$actionCount = ($events | Where-Object { $_.src -eq "Earth_Server" -and $_.kind -eq "RESULT" }).Count
$pulse = @{
    thoughts = $thoughtCount
    actions  = $actionCount
    ratio    = if ($actionCount -gt 0) { [math]::Round($thoughtCount / $actionCount, 2) } else { $thoughtCount }
    status   = if ($thoughtCount -gt ($actionCount * 10)) { "Hyper-Reflective" } elseif ($actionCount -gt $thoughtCount) { "Hyper-Active" } else { "Balanced" }
}

# 3. Risk/Benefit (Simulations)
$simEvents = $events | Where-Object { $_.kind -eq "SIMULATION" }
$simPass = ($simEvents | Where-Object { $_.msg -match "pass" }).Count
$simFail = ($simEvents | Where-Object { $_.msg -match "fail" }).Count
$riskBenefit = @{
    sim_pass_rate = if (($simPass + $simFail) -gt 0) { [math]::Round(($simPass / ($simPass + $simFail)) * 100, 1) } else { 0 }
    total_sims    = $simPass + $simFail
    confidence    = if ($simPass -gt $simFail) { "High" } else { "Caution" }
}

# 4. Correlation Synapse
$correlations = @()
# Example: RF vs Warlord
$rfTriggers = ($events | Where-Object { $_.kind -eq "RF_SPIKE" }).Count
$warlordScans = ($events | Where-Object { $_.kind -eq "RECON" }).Count
if ($rfTriggers -gt 0) {
    $correlations += @{ trigger = "RF_SPIKE"; response = "RECON"; correlation = [math]::Round($warlordScans / $rfTriggers, 2) }
}

# Finalize
$insights = @{
    version             = 1
    generated_at        = $now.ToString("yyyy-MM-ddTHH:mm:ssZ")
    reliability_heatmap = $reliability
    operational_pulse   = $pulse
    risk_benefit        = $riskBenefit
    correlations        = $correlations
}

$insights | ConvertTo-Json -Depth 10 | Set-Content $TargetFile -Encoding UTF8
Write-Host "Insights Computed: $TargetFile"
