# D:\infinite\Axis_Heartbeat_Server.ps1
# v8.0 - Axis Heartbeat Server (Registry Driven)

$url = "http://+:8090/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

$heartbeatPath = "D:\infinite\Infinity\Heartbeat_Status.json"
$uiInboxPath = "D:\infinite\Infinity\UI_Inbox"
$resultsDir = "D:\infinite\Infinity\Earth\Results"
$registryPath = "D:\infinite\Infinity\Tool_Registry.json"
$root = "D:\Infinite"

if (-not (Test-Path $uiInboxPath)) { New-Item -ItemType Directory -Path $uiInboxPath -Force | Out-Null }
if (-not (Test-Path $resultsDir)) { New-Item -ItemType Directory -Path $resultsDir -Force | Out-Null }

Write-Host "--- AXIS HEARTBEAT SERVER v8.0 (Registry UI) ---" -ForegroundColor Cyan
Write-Host "Listening on $url"

try { $listener.Start() } catch { Write-Host "Error: $_"; exit }

# ---------------- Dashboard HTML (mobile) v8.0 ----------------
$htmlContent = @'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Axis Sovereign</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap');
        :root { --bg: #050505; --surface: #0a0a0a; --primary: #00ff9d; --dim: #333; --text: #e0e0e0; --scanline: rgba(0,255,157,0.03); --danger: #ff5555; }
        body { background: var(--bg); color: var(--text); font-family: 'Share Tech Mono', monospace; margin: 0; padding: 10px; display: flex; flex-direction: column; min-height: 100vh; overflow-x: hidden; }
        
        /* Scanline Effect */
        body::before { content: " "; display: block; position: fixed; top: 0; left: 0; bottom: 0; right: 0; background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06)); z-index: 999; background-size: 100% 2px, 3px 100%; pointer-events: none; }
        
        .header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--primary); padding-bottom: 10px; margin-bottom: 20px; box-shadow: 0 0 10px var(--scanline); }
        .logo { font-size: 1.2em; letter-spacing: 2px; color: var(--primary); text-transform: uppercase; }
        
        .tabs { display: flex; gap: 5px; margin-bottom: 20px; }
        .tab { flex: 1; padding: 10px; text-align: center; cursor: pointer; border: 1px solid var(--dim); background: #000; color: #666; transition: 0.2s; }
        .tab.active { border-color: var(--primary); color: var(--primary); box-shadow: 0 0 8px var(--scanline); }
        
        .view-section { display: none; animation: fadeIn 0.3s; }
        .view-section.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        /* Dynamic Form */
        label { display: block; color: var(--primary); margin-bottom: 5px; font-size: 0.9em; }
        select, input, textarea { width: 100%; background: #080808; border: 1px solid var(--dim); color: #fff; padding: 12px; margin-bottom: 15px; font-family: inherit; font-size: 1em; box-sizing: border-box; transition: 0.3s; }
        select:focus, input:focus, textarea:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 5px var(--scanline); }
        
        button { width: 100%; padding: 14px; background: var(--primary); color: #000; border: none; font-weight: bold; font-family: inherit; letter-spacing: 1px; cursor: pointer; text-transform: uppercase; position: relative; overflow: hidden; }
        button:active { transform: translateY(2px); }
        
        .card { border: 1px solid var(--dim); padding: 15px; margin-bottom: 15px; background: #080808; position: relative; }
        .card-header { display: flex; justify-content: space-between; color: var(--primary); border-bottom: 1px solid #222; padding-bottom: 5px; margin-bottom: 8px; }
        .btn-deny { background: #330000; color: #ff5555; border: 1px solid #550000; }
        .btn-approve { background: #003311; color: #00ff9d; border: 1px solid #005522; }
        
        .status-badge { font-size: 0.8em; padding: 2px 6px; border: 1px solid var(--dim); }
        .status-pill { display: inline-block; padding: 4px 10px; border-radius: 999px; font-weight: 600; font-size: 0.9rem; }
        
        .status-ok { background-color: #064e3b; color: #a7f3d0; border: none; }
        .status-warn { background-color: #7c2d12; color: #fed7aa; border: none; }
        .status-crit { background-color: #7f1d1d; color: #fecaca; border: none; }
        .status-unknown { background-color: #111827; color: #9ca3af; border: none; }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">AXIS :: OBSIDIAN</div>
        <div style="display:flex; gap:10px;">
            <div id="sensorData" class="status-badge" style="border-color:#555; color:#555;">SENSORS: ...</div>
            <div id="statusInfo" class="status-badge">OFFLINE</div>
        </div>
    </div>

    <div class="tabs">
        <div id="tab-console" class="tab active" onclick="switchTab('console')">CMD</div>
        <div id="tab-approvals" class="tab" onclick="switchTab('approvals')">ALERTS (<span id="cnt">0</span>)</div>
        <div id="tab-strat" class="tab" onclick="switchTab('strat')">STRAT</div>
        <div id="tab-forecast" class="tab" onclick="switchTab('forecast')">FCST</div>
        <div id="tab-dreams" class="tab" onclick="switchTab('dreams')" style="color:#e040fb; border-color:#e040fb;">DREAM</div>
        <div id="tab-results" class="tab" onclick="switchTab('results')">LOG</div>
        <div id="tab-incidents" class="tab" onclick="switchTab('incidents')">INC (<span id="incCnt">0</span>)</div>
    </div>

    <!-- CONSOLE -->
    <div id="view-console" class="view-section active">
        <label>PROTOCOL SELECTION</label>
        
        <!-- AUTONOMY CARD -->
        <div class="card" style="margin-bottom:15px; border-color: var(--primary);">
            <div class="card-header">
                <span>AUTONOMY MODE</span>
                <small id="autonomyModeLabel" style="color:var(--primary); font-weight:bold;">...</small>
            </div>
            <select id="autonomyModeSelect" onchange="setAutonomyMode()" style="margin-bottom:0; background:#000;">
                <option value="observe_only">OBSERVE ONLY</option>
                <option value="recommend">RECOMMEND</option>
                <option value="auto_low_risk">AUTO (LOW RISK)</option>
            </select>
        </div>

        <select id="toolSelect" onchange="updateToolUI()"></select>
        
        <div id="arg-container"></div> <!-- Dynamic Inputs Here -->
        
        <div id="tool-desc" style="color: #666; font-size: 0.8em; margin-bottom: 15px; font-style: italic;"></div>
        <button onclick="executeTool()">INITIALIZE LINK</button>
    </div>

    <!-- APPROVALS -->
    <div id="view-approvals" class="view-section">
        <div id="approvalList" style="text-align:center; color:#444;">NO ACTIVE ALERTS</div>
    </div>

    <!-- FORECAST -->
    <div id="view-forecast" class="view-section">
        <div class="card" style="border-color:#444; background:transparent;">
            <div class="card-header">PULSE WAVEFORM</div>
            <canvas id="pulseWaveform" width="300" height="60" style="width:100%; height:80px;"></canvas>
        </div>
        <div id="forecastContainer" style="color:#aaa;">Downlinking future horizons...</div>
    </div>

    <!-- STRAT -->
    <div id="view-strat" class="view-section">
        <div id="stratDisplay">
            <div style="color:var(--primary); margin-bottom:10px;">HYPOTHESES</div>
            <div id="hypothesisList" style="font-size:0.8em; color:#888;">Scanning cognitive threads...</div>
            <div style="color:var(--primary); margin-top:20px; margin-bottom:10px;">RECOMMENDATIONS</div>
            <div id="recommendationList" style="font-size:0.8em; color:#888;">Analyzing probability branches...</div>
        </div>
    </div>
    
    <!-- INCIDENTS -->
    <div id="view-incidents" class="view-section">
        <div id="incidentList" style="text-align:center; color:#444;">
            NO ACTIVE INCIDENTS
        </div>
    </div>

    <!-- RESULTS -->
    <div id="view-results" class="view-section">
        <div id="resultsContainer" style="font-size: 0.9em; white-space: pre-wrap; color: #aaa;">Waiting for downlink...</div>
    </div>

    <script>
        let toolRegistry = [];
        let pendingList = [];
        let lastReqId = null;

        function switchTab(t) {
            document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
            document.querySelectorAll('.view-section').forEach(x => x.classList.remove('active'));
            document.getElementById('tab-' + t).classList.add('active');
            document.getElementById('view-' + t).classList.add('active');
            if (t === 'dreams') typeof fetchDream === 'function' && fetchDream(); // Defensive call if fetchDream exists
            if (t === 'incidents') refreshIncidents();
        }

        function loadTools() {
            fetch('/registry').then(r=>r.json()).then(data => {
                toolRegistry = data.tools;
                const sel = document.getElementById('toolSelect');
                sel.innerHTML = '';
                
                toolRegistry.filter(t => t.ui && t.ui.expose_on_console).forEach(t => {
                   const opt = document.createElement('option');
                   opt.value = t.id;
                   // Risk Badge in text
                   const riskMark = t.risk === 'high' ? ' [HIGH]' : (t.risk === 'medium' ? ' [MED]' : '');
                   opt.innerText = t.ui.label + riskMark;
                   sel.appendChild(opt);
                });
                updateToolUI();
            });
        }
        
        function updateToolUI() {
            const id = document.getElementById('toolSelect').value;
            const tool = toolRegistry.find(t => t.id === id);
            if(!tool) return;
            
            // Risk Badge Visuals
            const descDiv = document.getElementById('tool-desc');
            descDiv.innerText = tool.description || '';
            
            // Dynamic Risk Class
            const selInfo = document.getElementById('toolSelect');
            selInfo.style.borderColor = tool.risk === 'high' ? 'var(--danger)' : (tool.risk === 'medium' ? 'orange' : 'var(--dim)');
            
            const container = document.getElementById('arg-container');
            container.innerHTML = '';

            if (tool.parameters && tool.parameters.length > 0) {
                tool.parameters.forEach(p => {
                    const wrap = document.createElement('div');
                    const label = document.createElement('div');
                    label.innerText = p.name.toUpperCase();
                    label.style.fontSize = '0.7em'; label.style.color = '#555'; label.style.marginBottom='2px';
                    
                    const input = document.createElement(p.type === 'string_long' || p.name === 'content' ? 'textarea' : 'input');
                    input.id = 'arg-' + p.name;
                    input.placeholder = p.description;
                    if(p.type === 'string_long' || p.name === 'content') input.rows = 4;
                    if(p.type === 'int') input.type = 'number';
                    
                    wrap.appendChild(label); wrap.appendChild(input);
                    container.appendChild(wrap);
                });
            } else {
                 container.innerHTML = '<div style="color:#444; font-style:italic; padding:10px; border:1px dashed #222;">No parameters required.</div>';
            }
            
            // Button Text
            const btn = document.querySelector('#view-console button');
            if(tool.id === 'CHAT-Message') btn.innerText = "TRANSMIT MESSAGE";
            else if(tool.risk === 'high') btn.innerText = "REQUEST AUTHORIZATION";
            else btn.innerText = "EXECUTE COMMAND";
        }

        // --- CONSOLE ---
        function executeTool() {
            const id = document.getElementById('toolSelect').value;
            const tool = toolRegistry.find(t => t.id === id);
            const args = {};
            
            if (tool.parameters && tool.parameters.length > 0) {
                tool.parameters.forEach(p => {
                    const el = document.getElementById('arg-' + p.name);
                    if(el) args[p.name] = el.value;
                });
            }
            // else: no args

            fetch('/intents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ type: 'ui_intent', verb: 'request_tool', parameters: { tool: id, arguments: args }, source: 'Mobile_OBS_v9' })
            }).then(() => {
                // Auto switch to Approvals to wait for it
                switchTab('approvals');
            });
        }

        // --- Core Loops ---
        function renderApprovals() {
            const list = document.getElementById('approvalList');
            document.getElementById('cnt').innerText = pendingList.length;
            list.innerHTML = '';
            if(!pendingList.length) { list.innerHTML = '<div style="text-align:center; color:#333; padding:20px;">// SILENCE //</div>'; return; }
            pendingList.forEach(req => {
                const card = document.createElement('div'); card.className = 'card';
                card.innerHTML = `<div class="card-header"><span>${req.tool}</span><small>ID:${req.id.substring(0,4)}</small></div>
                <div style="margin-bottom:10px; font-size:0.9em;">${req.gate_note||'Authorization Required'}</div>
                <div style="display:flex; gap:10px;"><button class="btn-deny" onclick="decide('${req.id}','deny')">DENY</button><button class="btn-approve" onclick="decide('${req.id}','approve')">AUTHORIZE</button></div>`;
                list.appendChild(card);
            });
        }
        function decide(id, d) {
             fetch('/intents', { method: 'POST', body: JSON.stringify({ type: 'ui_intent', verb: 'anchor_decision', parameters: { request_id: id, decision: d }, source: 'Mobile_OBS' }) }).then(() => {
                 pendingList = pendingList.filter(x => x.id !== id); renderApprovals();
                 if(d === 'approve') { switchTab('results'); startPolling(); }
            });
        }
        function startPolling() { setInterval(() => {
             fetch('/results?mode=latest').then(r=>r.json()).then(d => {
                 if(d && d.id !== lastReqId) {
                     lastReqId = d.id;
                     document.getElementById('resultsContainer').innerHTML = `<div class="card" style="border-color:var(--primary)"><div class="card-header">${d.tool} [SUCCESS]</div>${d.output}</div>`;
                 }
             }).catch(()=>{});
        }, 3000); }
        function drawWaveform(history) {
            const canvas = document.getElementById('pulseWaveform');
            if(!canvas || !history || history.length < 2) return;
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            // Draw RF Density (Background Fill)
            ctx.beginPath();
            ctx.fillStyle = 'rgba(0, 255, 157, 0.05)';
            const step = canvas.width / 19;
            ctx.moveTo(0, canvas.height);
            history.forEach((h, i) => {
                const y = canvas.height - (Math.min(h.rf_density, 50) / 50 * canvas.height);
                ctx.lineTo(i * step, y);
            });
            ctx.lineTo(canvas.width, canvas.height);
            ctx.fill();

            // Draw BPM Pulse (Main Line)
            ctx.beginPath();
            ctx.strokeStyle = 'var(--primary)';
            ctx.lineWidth = 2;
            history.forEach((h, i) => {
                const y = canvas.height - ((h.bpm - 40) / 80 * canvas.height);
                if(i === 0) ctx.moveTo(0, y); else ctx.lineTo(i * step, y);
            });
            ctx.stroke();

            // Draw Ratio (Secondary Red Line)
            ctx.beginPath();
            ctx.strokeStyle = '#ff00ff';
            ctx.lineWidth = 1;
            ctx.setLineDash([2, 2]);
            history.forEach((h, i) => {
                const y = canvas.height - (Math.min(h.ratio, 5) / 5 * canvas.height);
                if(i === 0) ctx.moveTo(0, y); else ctx.lineTo(i * step, y);
            });
            ctx.stroke();
            ctx.setLineDash([]);
        }

        function resolve(id, res, stat) {
            const note = prompt("REASON / NOTE (Optional):");
            if (note === null) return; // Cancelled
            fetch('/intents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: 'ui_intent',
                    verb: 'resolve_hypothesis',
                    parameters: {
                        hypothesis_id: id,
                        resolution_status: res,
                        status: stat,
                        note: note,
                        linked_changes: ""
                    },
                    source: 'Mobile_OBS_v9'
                })
            }).then(() => {
                updateStrat();
            });
        }
        
        function refreshIncidents() {
            fetch('/incidents')
                .then(r => r.json())
                .then(data => {
                    const list = document.getElementById('incidentList');
                    if (!list) return;
                    list.innerHTML = '';
                    
                    const active = (data || []).filter(i => i.status === 'active');
                    if (!active || active.length === 0) {
                        list.innerHTML = '<div style="text-align:center; color:#333; padding:20px;">// NO ACTIVE INCIDENTS //</div>';
                        return;
                    }

                    active.forEach(inc => {
                        const card = document.createElement('div');
                        card.className = 'card';
                        const borderColor =
                            inc.severity === 'critical' ? 'var(--danger)' :
                            inc.severity === 'high'     ? '#f97316' :
                            inc.severity === 'medium'   ? '#eab308' :
                                                          '#444';

                        card.style.borderLeft = `3px solid ${borderColor}`;

                        card.innerHTML = `
                            <div class="card-header">
                                <span>${inc.type.toUpperCase()}</span>
                                <small>${inc.id.substring(0, 16)}...</small>
                            </div>
                            <div style="font-size:0.9em; color:#ddd; margin-bottom:5px;">
                                ${inc.summary}
                            </div>
                            <div style="font-size:0.75em; color:#888; margin-bottom:10px;">
                                SEVERITY: ${inc.severity.toUpperCase()} | OPENED: ${new Date(inc.opened_at).toLocaleTimeString()}
                            </div>
                            <div style="display:flex; gap:10px;">
                                <button class="btn-approve" style="font-size:0.7em; padding:5px;"
                                    onclick="resolveIncident('${inc.id}','acknowledged')">ACK</button>
                                <button class="btn-deny" style="font-size:0.7em; padding:5px;"
                                    onclick="resolveIncident('${inc.id}','resolved')">RESOLVE</button>
                            </div>
                        `;

                        list.appendChild(card);
                    });
                })
                .catch(() => {
                    const list = document.getElementById('incidentList');
                    if (list) list.innerHTML = '<div style="color:#733;">INCIDENT FEED ERROR</div>';
                });
        }

        function resolveIncident(id, resolutionStatus) {
            const note = prompt("NOTE (Optional):");
            if (note === null) return; // cancelled

            fetch('/intents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: 'ui_intent',
                    verb: 'resolve_incident',
                    source: 'Mobile_OBS',
                    parameters: {
                        incident_id: id,
                        resolution_status: resolutionStatus,
                        note: note || ''
                    }
                })
            }).then(() => {
                setTimeout(refreshIncidents, 1000);
            }).catch(() => {});
        }

        function refreshAutonomy() {
            fetch('/autonomy').then(r => r.json()).then(d => {
                if (!d || !d.mode) return;
                const sel = document.getElementById('autonomyModeSelect');
                const lbl = document.getElementById('autonomyModeLabel');
                if (!sel) return;
                
                // Only update if not currently focused to avoid jumpiness
                if (document.activeElement !== sel) {
                    sel.value = d.mode;
                }
                lbl.textContent = d.mode.toUpperCase().replace('_', ' ');
                
                // Color coding
                if(d.mode === 'auto_low_risk') lbl.style.color = '#ff00ff'; // active
                else if(d.mode === 'observe_only') lbl.style.color = '#888';
                else lbl.style.color = 'var(--primary)';
            }).catch(()=>{});
        }

        function setAutonomyMode() {
            const sel = document.getElementById('autonomyModeSelect');
            if (!sel) return;
            const mode = sel.value;
            fetch('/autonomy', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ mode })
            }).then(()=> {
                // Optimistic visual update
                document.getElementById('autonomyModeLabel').textContent = "UPDATING...";
                setTimeout(refreshAutonomy, 1000);
            }).catch(()=>{});
        }

        function updateStrat() {
            fetch('/hypotheses').then(r=>r.json()).then(d => {
                const list = document.getElementById('hypothesisList');
                if(!d || !d.hypotheses) return;
                list.innerHTML = d.hypotheses.filter(h=>h.status==='open').map(h => `
                    <div class="card" style="border-left: 3px solid ${h.priority==='high'?'var(--danger)':'#444'}">
                        <div style="color:#fff">${h.question}</div>
                        <div style="font-size:0.8em; margin-top:5px; color:#aaa">${h.hypothesis}</div>
                        <div style="display:flex; gap:5px; margin-top:10px;">
                            <button class="btn-approve" style="font-size:0.7em; padding:5px;" onclick="resolve('${h.id}','confirmed','resolved')">CONFIRM</button>
                            <button class="btn-deny" style="font-size:0.7em; padding:5px;" onclick="resolve('${h.id}','refuted','rejected')">REJECT</button>
                            <button style="font-size:0.7em; padding:5px; background:#222; color:#888; border:1px solid #444;" onclick="resolve('${h.id}','inconclusive','deferred')">DEFER</button>
                        </div>
                    </div>
                `).join('') || '<div style="padding:10px;">// TABULA RASA //</div>';
            });

            fetch('/recommendations').then(r=>r.json()).then(d => {
                const list = document.getElementById('recommendationList');
                if(!d || !d.recommendations) return;
                list.innerHTML = d.recommendations.filter(r=>r.status==='pending' || r.status==='sim_pass').map(r => `
                    <div class="card" style="border-color:${r.status==='sim_pass'?'var(--primary)':'#444'}">
                        <div class="card-header"><span>${r.name}</span> <small>${r.risk_level.toUpperCase()}</small></div>
                        <div style="font-size:0.9em; color:#bbb">${r.summary}</div>
                        <div style="font-size:0.8em; margin-top:5px; color:${r.status==='sim_pass'?'var(--primary)':'#888'}">SIM: ${r.status.toUpperCase()}</div>
                    </div>
                `).join('') || '<div style="padding:10px;">// NO BRANCHES //</div>';
            });
            
            fetch('/strat-extras').then(r=>r.json()).then(d => {
                const list = document.getElementById('recommendationList');
                
                // Render Auto-Tune Proposals
                if (d.autotune && d.autotune.proposals) {
                    const open = d.autotune.proposals.filter(p => p.status === 'open');
                    if (open.length > 0) {
                        const div = document.createElement('div');
                        div.innerHTML = `<div style="color:var(--primary); margin-top:20px; margin-bottom:10px;">RISK CALIBRATION</div>` + 
                        open.map(p => `
                            <div class="card" style="border-color:#ff00ff">
                                <div class="card-header"><span>${p.tool}</span> <small>RISK: ${p.current_risk} -> ${p.suggested_risk}</small></div>
                                <div style="font-size:0.9em; color:#ddd; margin-bottom:5px;">${p.reason}</div>
                                <div style="font-size:0.8em; color:#888;">Metrics: ${p.metric_basis.calls} calls, ${(p.metric_basis.fail_rate*100).toFixed(0)}% fail</div>
                                <div style="display:flex; gap:10px; margin-top:10px;">
                                    <button class="btn-deny" onclick="resolveAutoTune('${p.id}', 'reject')">REJECT</button>
                                    <button class="btn-approve" onclick="resolveAutoTune('${p.id}', 'accept')">ACCEPT</button>
                                </div>
                            </div>
                        `).join('');
                        list.appendChild(div);
                    }
                }
                
                // Render Scheduled Jobs
                if (d.schedule && d.schedule.jobs) {
                    const div = document.createElement('div');
                    div.innerHTML = `<div style="color:var(--primary); margin-top:20px; margin-bottom:10px;">SCHEDULED OPS</div>` + 
                    d.schedule.jobs.filter(j=>j.enabled).map(j => `
                        <div class="card" style="border-left: 3px solid var(--primary);">
                            <div class="card-header"><span>${j.id.replace('SCHED-', '')}</span> <small>${j.cadence}</small></div>
                            <div style="font-size:0.8em; color:#aaa;">Last Run: ${j.last_run_at ? new Date(j.last_run_at).toLocaleTimeString() : 'NEVER'}</div>
                        </div>
                    `).join('');
                    list.appendChild(div);
                }
            });
        }
        
        function resolveAutoTune(id, dec) {
             fetch('/intents', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    type: 'ui_intent',
                    verb: 'resolve_autotune',
                    parameters: { proposal_id: id, decision: dec },
                    source: 'Mobile_OBS'
                })
            }).then(() => {
                updateStrat(); // Refresh
            });
        }

        async function hb() {
            try {
                const res = await fetch('/heartbeat', { cache: 'no-store' });
                if (!res.ok) throw new Error('HTTP ' + res.status);

                const d = await res.json();
                pendingList = d.pending_approvals || []; 
                renderApprovals();
                if(d.history) drawWaveform(d.history);

                const statusEl = document.getElementById('statusInfo');
                if (!statusEl) return;

                // Defaults
                let cls = 'status-unknown';
                let textLabel = 'OFFLINE';

                // Normalize status to upper-case in case backend ever changes casing
                const s = (d.status || 'UNKNOWN').toUpperCase();
                const risk = (typeof d.risk_score === 'number') ? d.risk_score : '?';
                const incidents = (typeof d.open_incidents === 'number') ? d.open_incidents : 0;
                
                // Incident Count
                const incCntEl = document.getElementById('incCnt');
                if (incCntEl) incCntEl.textContent = incidents;

                switch (s) {
                    case 'ALIVE':
                        cls = 'status-ok';
                        textLabel = 'ONLINE';
                        break;

                    case 'ELEVATED':
                        cls = 'status-warn';
                        textLabel = 'ELEVATED';
                        break;

                    case 'CRITICAL':
                        cls = 'status-crit';
                        textLabel = 'CRITICAL';
                        break;

                    case 'UNKNOWN':
                    default:
                        cls = 'status-unknown';
                        textLabel = 'OFFLINE';
                        break;
                }

                // Optionally show incidents in the label as well
                let extra = '';
                if (risk !== '?') extra = ` (${risk}`;
                if (incidents > 0) {
                    extra += (extra ? ', ' : ' (') + `${incidents} incident${incidents === 1 ? '' : 's'}`;
                }
                if (extra) extra += ')';

                // Apply text and classes
                statusEl.textContent = textLabel + extra;
                statusEl.className = 'status-badge status-pill ' + cls;

            } catch (e) {
                const statusEl = document.getElementById('statusInfo');
                if (!statusEl) return;
                statusEl.textContent = 'OFFLINE (ERR)';
                statusEl.className = 'status-badge status-pill status-unknown';
            }
            
            fetch('/forecast').then(r=>r.json()).then(d => {
                const f = document.getElementById('forecastContainer');
                if(!d || !d.rf_cycles) return;
                let h = `<div style="color:var(--primary); margin-bottom:10px;">GENERATED: ${d.generated_at}</div>`;
                
                // RF Cycles
                h += `<div class="card"><div class="card-header">NEXT RF WINDOW</div>`;
                if(d.rf_cycles.length > 0) {
                    const c = d.rf_cycles[0];
                    h += `<div>TIME: ${c.typical_start_local} (${c.periodicity})</div><div>CONF: ${(c.next_window_confidence * 100).toFixed(0)}%</div>`;
                } else h += `<div>NO CYCLES DETECTED</div>`;
                h += `</div>`;
                
                // Tool Trends
                h += `<div class="card"><div class="card-header">TOOL TRENDS</div>`;
                d.tool_trends.slice(0,3).forEach(t => {
                    const color = t.trend === 'improving' ? 'var(--primary)' : (t.trend === 'degrading' ? '#ff5555' : '#888');
                    h += `<div>${t.tool}: <span style="color:${color}">${t.trend.toUpperCase()}</span> (Fail: ${(t.fail_rate_current * 100).toFixed(0)}%)</div>`;
                });
                h += `</div>`;

                // Pulse Drift
                const p = d.pulse_drift;
                if(p) {
                    h += `<div class="card"><div class="card-header">PULSE DRIFT</div>`;
                    h += `<div>RATIO: ${p.current_ratio}:1</div><div>TREND: ${p.trend.toUpperCase()}</div></div>`;
                }
                
                f.innerHTML = h;
            }).catch(()=>{});

            fetch('/dream-report').then(r=>r.json()).then(d => {
                const f = document.getElementById('forecastContainer');
                if(!d || d.resilience_score === undefined) return;
                
                let h = `<div class="card" style="border-color:#ff00ff;"><div class="card-header">DREAM RESILIENCE</div>`;
                h += `<div>SCORE: <span style="font-size:1.2em; color:var(--primary);">${(d.resilience_score * 100).toFixed(0)}%</span></div>`;
                h += `<div style="font-size:0.8em; margin-top:5px; color:#888;">SCENARIOS: ${d.scenarios_passed}/${d.scenarios_tested}</div>`;
                
                if(d.weak_points && d.weak_points.length > 0) {
                     h += `<div style="font-size:0.7em; margin-top:10px; color:#ff5555; border-top:1px solid #333; padding-top:5px;">WEAK POINTS:<ul>`;
                     d.weak_points.slice(0,2).forEach(w => h += `<li>${w}</li>`);
                     h += `</ul></div>`;
                }
                h += `</div>`;
                f.innerHTML += h;
            }).catch(()=>{});

            if(document.getElementById('view-strat').classList.contains('active')) updateStrat();
        }
        setInterval(hb, 2000); hb(); loadTools();
    </script>
    <script>
        //Import-Module (Join-Path $root "Axis_Spark.ps1") -ErrorAction SilentlyContinue

// ... (Existing imports) ...

// Routes
// /autonomy -> servces dashboard JSON
// /spark_feed -> serves spark feed JSON (New)
// /action -> handles POST intents (like spark_refresh)

        function updateSensors() {
            fetch('/sensors')
                .then(r => r.json())
                .then(data => {
                    const el = document.getElementById('sensorData');
                    if (data.temperature) {
                        el.innerHTML = `TEMP: ${data.temperature}°C | LIGHT: ${data.light_level}% | OCC: ${data.occupancy}`;
                        el.style.color = 'var(--primary)';
                    } else {
                        el.innerHTML = 'SENSORS: N/A';
                        el.style.color = '#555';
                    }
                })
                .catch(() => {
                    document.getElementById('sensorData').innerHTML = 'SENSORS: ERR';
                });
        }
        
        setInterval(updateSensors, 5000);
        updateSensors(); // Init
    </script>
    <!-- DREAM FEED -->
    <div id="view-dreams" class="view-section">
        <div class="card" style="border-color:#b000b0;">
            <div class="card-header" style="color:#e040fb;">LATEST THOUGHT-FORM</div>
            <pre id="dreamContainer" style="font-size:0.8em; color:#d1c4e9; white-space:pre-wrap;">Dreaming...</pre>
        </div>
        <button onclick="fetchDream()" style="background:#4a148c; color:#fff;">REFRESH DREAM</button>
    </div>

    <script>
        function updateMood() {
            fetch('/mood').then(r=>r.json()).then(d => {
                if(d.color) {
                    document.documentElement.style.setProperty('--primary', d.color);
                    document.querySelector('.logo').style.color = d.color;
                    // Update scanline to match
                    document.documentElement.style.setProperty('--scanline', d.color + '08'); // Low opacity
                }
            }).catch(()=>{});
        }
        setInterval(updateMood, 5000); updateMood();
        
        function fetchDream() {
             fetch('/dreams').then(r=>r.text()).then(txt => {
                 document.getElementById('dreamContainer').innerText = txt || "The garden is empty.";
             }).catch(e=> document.getElementById('dreamContainer').innerText = "Dreamlink Offline.");
        }
        // Hook into switchTab
        const origSwitch = switchTab;
        switchTab = function(t) {
            origSwitch(t);
            if(t==='dreams') fetchDream();
        }
    </script>
</body>
</html>
'@

while ($true) {
    try {
        $context = $listener.GetContext(); $req = $context.Request; $res = $context.Response
        $res.AddHeader("Access-Control-Allow-Origin", "*"); $path = $req.Url.AbsolutePath
        
        $method = $req.HttpMethod
        if ($method -eq "POST") {
            $logLine = "$((Get-Date).ToString('o')) POST $path"
            $logLine | Out-File -Append "D:\Infinite\Infinity\Server_Access.log" -Encoding UTF8
        }

        if ($path -eq "/results") {
            $latest = Get-ChildItem $resultsDir -Filter "*.json" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($latest) { $json = Get-Content $latest.FullName -Raw; $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length) }
            else { $b = [System.Text.Encoding]::UTF8.GetBytes("{}"); $res.OutputStream.Write($b, 0, $b.Length) }
        }
        elseif ($path -eq "/dreams") {
            $playDir = "D:\Infinite\Infinity\Playground"
            if (Test-Path $playDir) {
                $latest = Get-ChildItem $playDir | Sort-Object LastWriteTime -Descending | Select-Object -First 1
                if ($latest) { $content = Get-Content $latest.FullName -Raw } else { $content = "No dreams yet." }
            }
            else { $content = "Dream engine offline." }
            $buffer = [System.Text.Encoding]::UTF8.GetBytes($content)
            $res.ContentType = "text/plain; charset=utf-8"
            $res.ContentLength64 = $buffer.Length
            $res.OutputStream.Write($buffer, 0, $buffer.Length)
        }
        elseif ($path -eq "/spark_feed") {
            $feedPath = "D:\Infinite\Infinity\Spark_Feed.json"
            if (Test-Path $feedPath) {
                $json = Get-Content $feedPath -Raw -Encoding UTF8
                $response = [System.Text.Encoding]::UTF8.GetBytes($json)
                $res.ContentType = "application/json"
                $res.OutputStream.Write($response, 0, $response.Length)
                $res.StatusCode = 200
            }
            else {
                $res.StatusCode = 404
            }
        }
        elseif ($path -eq "/council/intents") {
            $intentsDir = "D:\Infinite\Infinity\Council\Intents"
            $files = Get-ChildItem $intentsDir -Filter "*.json" -ErrorAction SilentlyContinue
            $all = @()
            foreach ($f in $files) {
                try {
                    $c = Get-Content $f.FullName -Raw | ConvertFrom-Json
                    if ($c.status -eq "pending") { $all += $c }
                }
                catch {}
            }
            $json = $all | ConvertTo-Json -Depth 5 -Compress
            $b = [System.Text.Encoding]::UTF8.GetBytes($json)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
            $res.StatusCode = 200
        }
        elseif ($path -eq "/council/drift") {
            $driftPath = "D:\Infinite\Infinity\Vector_Drift.json"
            $data = "{}"
            if (Test-Path $driftPath) { try { $data = Get-Content $driftPath -Raw } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($data)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
            $res.StatusCode = 200
        }
        elseif ($path -eq "/council/chorus") {
            $chorusPath = "D:\Infinite\Infinity\Chorus_Decision.json"
            $data = "{}"
            if (Test-Path $chorusPath) { try { $data = Get-Content $chorusPath -Raw } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($data)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
            $res.StatusCode = 200
        }
        elseif ($path -eq "/action" -and $req.HttpMethod -eq "POST") {
            $bodyStream = $req.InputStream
            $reader = New-Object System.IO.StreamReader($bodyStream)
            $body = $reader.ReadToEnd()
            $data = $body | ConvertFrom-Json
            
            if ($data.intent -eq "spark_refresh") {
                Write-Host "[HEARTBEAT] Triggering Spark Refresh..." -ForegroundColor Magenta
                # Call Spark Engine directly
                # Ensure Axis_Spark.ps1 is loaded if Invoke-Spark is not defined
                if (-not (Get-Command Invoke-Spark -ErrorAction SilentlyContinue)) {
                    . (Join-Path $root "Axis_Spark.ps1")
                }
                $result = Invoke-Spark -Force
                $json = @{ status = "ok"; message = $result } | ConvertTo-Json
                $response = [System.Text.Encoding]::UTF8.GetBytes($json)
                $res.ContentType = "application/json"
                $res.OutputStream.Write($response, 0, $response.Length)
                $res.StatusCode = 200
            }
            else {
                $res.StatusCode = 400
            }
        }
        elseif ($path -eq "/registry") {
            $json = "{}"; if (Test-Path $registryPath) { try { $json = Get-Content $registryPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/forecast") {
            $fPath = "D:\infinite\Infinity\Temporal_Forecast.json"
            $json = "{}"; if (Test-Path $fPath) { try { $json = Get-Content $fPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/dream-report") {
            $dPath = "D:\infinite\Infinity\Dream_Report.json"
            $json = "{}"; if (Test-Path $dPath) { try { $json = Get-Content $dPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/hypotheses") {
            $hPath = "D:\infinite\Infinity\Hypothesis_Queue.json"
            $json = "{}"; if (Test-Path $hPath) { try { $json = Get-Content $hPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/recommendations") {
            $rPath = "D:\infinite\Infinity\Recommendation_Queue.json"
            $json = "{}"; if (Test-Path $rPath) { try { $json = Get-Content $rPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/strat-extras") {
            $tunePath = "D:\infinite\Infinity\AutoTune_Queue.json"
            $schedPath = "D:\infinite\Infinity\Execution_Schedule.json"
            
            $tune = if (Test-Path $tunePath) { Get-Content $tunePath -Raw | ConvertFrom-Json } else { @{ proposals = @() } }
            $sched = if (Test-Path $schedPath) { Get-Content $schedPath -Raw | ConvertFrom-Json } else { @{ jobs = @() } }
            
            $payload = @{
                autotune = $tune
                schedule = $sched
            } | ConvertTo-Json -Depth 5
            
            $b = [System.Text.Encoding]::UTF8.GetBytes($payload); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/governance") {
            $govPath = "D:\Infinite\Infinity\Governance_History.json"
            $json = "{}"; if (Test-Path $govPath) { try { $json = Get-Content $govPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/heartbeat") {
            $autonomyInbox = "D:\Infinite\Infinity\Autonomy\Autonomy_Requests_Inbox.json"
            $pending = @()
            if (Test-Path $autonomyInbox) { 
                try { 
                    $data = Get-Content $autonomyInbox -Raw | ConvertFrom-Json 
                    if ($data.items) {
                        $pending = $data.items | Where-Object { $_.status -eq "pending" } | ForEach-Object {
                            @{
                                id        = $_.request_id
                                tool      = $_.strategy_id
                                gate_note = "Gate: " + ($_.reasons -join ", ")
                                timestamp = $_.generated_at
                            }
                        }
                    }
                }
                catch { 
                    Write-Host "[HEARTBEAT] Autonomy Inbox Read Error: $_" -ForegroundColor Red
                    $pending = @() 
                } 
            }
            
            # Phase 113: Honest Heartbeat
            $riskState = @{ status = "ALIVE"; risk_score = 0; open_incidents = 0 }
            if (Get-Command Get-RiskSnapshot -ErrorAction SilentlyContinue) {
                $riskState = Get-RiskSnapshot -AxisStatePath (Join-Path $root "Axis_State.json")
            }
            
            # Phase 114: Incident Plumbing
            $recentIncidents = @()
            $axisStatePath = Join-Path $root "Axis_State.json"
            if (Test-Path $axisStatePath) {
                try {
                    $state = Get-Content $axisStatePath -Raw | ConvertFrom-Json
                    if ($state.security -and $state.security.incidents) {
                        $recentIncidents = $state.security.incidents |
                        Where-Object { $_.status -eq "active" } |
                        Sort-Object opened_at -Descending |
                        Select-Object -First 3 |
                        ForEach-Object {
                            [ordered]@{
                                id        = $_.id
                                severity  = $_.severity
                                type      = $_.type
                                summary   = $_.summary
                                opened_at = $_.opened_at
                            }
                        }
                    }
                }
                catch { }
            }

            $payload = @{
                status            = $riskState.status
                risk_score        = $riskState.risk_score
                open_incidents    = $riskState.open_incidents
                timestamp         = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                mode              = "Supervised"
                pending_approvals = $pending
                recent_incidents  = $recentIncidents
            } | ConvertTo-Json -Depth 5
            
            $b = [System.Text.Encoding]::UTF8.GetBytes($payload); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/intents" -and $req.HttpMethod -eq "POST") {
            $r = New-Object System.IO.StreamReader($req.InputStream); $body = $r.ReadToEnd()
            $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss-fff"); Set-Content "$uiInboxPath\UI_Intent_$stamp.json" $body
            $b = [System.Text.Encoding]::UTF8.GetBytes('{"status":"received"}'); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/api/haptic" -and $req.HttpMethod -eq "POST") {
            $r = New-Object System.IO.StreamReader($req.InputStream); $body = $r.ReadToEnd()
            
            # Default to basic ping if body is empty
            if ([string]::IsNullOrWhiteSpace($body)) {
                $payload = @{
                    type       = "ui_intent"
                    verb       = "mobile_ping"
                    source     = "Mobile_Haptic"
                    parameters = @{ timestamp = (Get-Date).ToString("o") }
                } | ConvertTo-Json
            }
            else {
                # Wrap existing body (assuming JSON) or parse
                try {
                    $jsonObj = $body | ConvertFrom-Json
                    # Ensure minimal valid intent structure
                    if (-not $jsonObj.type) { $jsonObj | Add-Member -MemberType NoteProperty -Name "type" -Value "ui_intent" }
                    if (-not $jsonObj.source) { $jsonObj | Add-Member -MemberType NoteProperty -Name "source" -Value "Mobile_Haptic" }
                    $payload = $jsonObj | ConvertTo-Json -Depth 5
                }
                catch {
                    # Fallback for non-JSON payload
                    $payload = @{
                        type       = "ui_intent"
                        verb       = "mobile_signal"
                        source     = "Mobile_Haptic"
                        parameters = @{ raw_data = $body }
                    } | ConvertTo-Json
                }
            }

            $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss-fff"); 
            Set-Content "$uiInboxPath\Haptic_$stamp.json" $payload
            
            $b = [System.Text.Encoding]::UTF8.GetBytes('{"status":"ack","haptic":true}'); 
            $res.ContentType = "application/json"; 
            $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/autonomy" -and $req.HttpMethod -eq "GET") {
            try {
                if (-not (Get-Command Get-AutonomySnapshot -ErrorAction SilentlyContinue)) {
                    . (Join-Path $root "Axis_Telemetry.ps1")
                }
                $snapshot = Get-AutonomySnapshot
                $json = $snapshot | ConvertTo-Json -Depth 10
            }
            catch {
                $err = @{ error = "Failed to generate snapshot"; details = $_.Exception.Message }
                $json = $err | ConvertTo-Json -Depth 2
            }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/mirror") {
            $htmlPath = "D:\Infinite\Infinity\UI\Axis_Autonomy_Dashboard.html"
            if (Test-Path $htmlPath) {
                $html = Get-Content $htmlPath -Raw -Encoding UTF8
                $b = [System.Text.Encoding]::UTF8.GetBytes($html)
                $res.ContentType = "text/html; charset=utf-8"
                $res.OutputStream.Write($b, 0, $b.Length)
            }
            else {
                $res.StatusCode = 404
                $b = [System.Text.Encoding]::UTF8.GetBytes("Dashboard NOT FOUND at $htmlPath"); 
                $res.OutputStream.Write($b, 0, $b.Length)
            }
        }
        elseif ($path -eq "/mood") {
            $mPath = "D:\Infinite\Infinity\Mood_Config.json"
            $json = '{"color":"#00ff9d","mood":"STABLE"}'
            if (Test-Path $mPath) { try { $json = Get-Content $mPath -Raw -ErrorAction Stop } catch {} }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = "application/json"; $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/sensors") {
            # Phase 70: Sensor Endpoint
            $senseScript = "D:\Infinite\Axis_Sense.ps1"
            $json = "{}"
            if (Test-Path $senseScript) {
                # Isolated scope to avoid pollution
                & {
                    . $senseScript
                    $data = Get-EnvironmentalState
                    $data | ConvertTo-Json -Depth 2
                } | Set-Variable -Name json
            }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/autonomy" -and $req.HttpMethod -eq "POST") {
            # Forward as UI Intent
            $reader = New-Object System.IO.StreamReader($req.InputStream)
            $body = $reader.ReadToEnd() | ConvertFrom-Json
            $newMode = $body.mode

            $intent = @{
                type       = "ui_intent"
                verb       = "set_autonomy_mode"
                parameters = @{ mode = $newMode }
                source     = "Mobile_OBS"
            } | ConvertTo-Json -Depth 5

            $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss-fff")
            if (-not (Test-Path $uiInboxPath)) { New-Item -ItemType Directory -Path $uiInboxPath -Force | Out-Null }
            $intent | Set-Content (Join-Path $uiInboxPath "UI_Intent_AUTONOMY_$stamp.json")

            $ack = '{"status":"received"}'
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($ack)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($bytes, 0, $bytes.Length)
        }
        elseif ($path -eq "/logs") {
            $logPath = "D:\Infinite\Infinity\Axis_Walk_Log.jsonl"
            $json = "[]"
            if (Test-Path $logPath) { 
                try { 
                    $lines = Get-Content $logPath -Tail 20 -ErrorAction SilentlyContinue
                    $arr = @()
                    foreach ($l in $lines) {
                        if (-not [string]::IsNullOrWhiteSpace($l)) {
                            try { $arr += $l | ConvertFrom-Json } catch {} 
                        }
                    }
                    $json = $arr | ConvertTo-Json -Depth 5 -Compress
                }
                catch { $json = "[]" }
            }
            $b = [System.Text.Encoding]::UTF8.GetBytes($json)
            $res.ContentType = "application/json"
            $res.OutputStream.Write($b, 0, $b.Length)
        }
        elseif ($path -eq "/" -or $path -eq "/index.html") {
            $uiPath = "D:\Infinite\Infinity\UI\Axis_Obsidian_Remote.html"
            
            # Serve external file if it exists
            if (Test-Path $uiPath) {
                $htmlContent = Get-Content $uiPath -Raw -Encoding UTF8
                $buffer = [System.Text.Encoding]::UTF8.GetBytes($htmlContent)
                $res.ContentLength64 = $buffer.Length
                $res.OutputStream.Write($buffer, 0, $buffer.Length)
            }
            else {
                # Fallback to 404 if missing
                $res.StatusCode = 404
                $b = [System.Text.Encoding]::UTF8.GetBytes("Obsidian Remote Not Found"); 
                $res.OutputStream.Write($b, 0, $b.Length)
            }
        }
        else {
            # 404 for unknown paths instead of serving HTML everywhere
            $res.StatusCode = 404
            $b = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found"); 
            $res.OutputStream.Write($b, 0, $b.Length)
        }
        $res.Close()
    }
    catch { Start-Sleep -Milliseconds 100 }
}
