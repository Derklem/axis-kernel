# Axis_Agency_Executor.ps1
# Phase 303: The Execution Engine

param(
    [Parameter(ValueFromPipeline = $true)]
    [string]$DecisionJson
)

$root = "D:\Infinite"
$telemetryPath = Join-Path $root "Axis_Telemetry.ps1"
$pendingPath = Join-Path $root "Infinity\Agency\Pending_Reviews.json"
$agencyDir = Join-Path $root "Infinity\Agency"

if (-not (Test-Path $agencyDir)) { New-Item -ItemType Directory -Path $agencyDir -Force | Out-Null }
if (-not (Test-Path $telemetryPath)) { Write-Error "Telemetry Missing"; exit 1 }

# Import Telemetry for logging
if (Test-Path $telemetryPath) { . $telemetryPath }

function Log-Event {
    param($Kind, $Summary, $Data)
    
    if (Get-Command -Name Write-AxisEvent -ErrorAction SilentlyContinue) {
        $severity = "info"
        if ($Kind -eq "blocked" -or $Kind -eq "error") { $severity = "warn" }
        
        Write-AxisEvent -Source "Agency_Executor" -Kind $Kind -Summary $Summary -Severity $severity -Details $Data
    }
    else {
        # Fallback
        $color = "Green"
        if ($Kind -eq "blocked") { $color = "Red" }
        elseif ($Kind -eq "queued") { $color = "Yellow" }
        Write-Host "[$Kind] $Summary" -ForegroundColor $color
    }
}

if ([string]::IsNullOrWhiteSpace($DecisionJson)) { Write-Error "No Decision Object"; exit 1 }
$decisionObj = $DecisionJson | ConvertFrom-Json

$results = @()

foreach ($d in $decisionObj.decisions) {
    $res = @{
        tool   = $d.tool
        target = $d.target_entity
        status = "unknown"
        output = $null
    }

    if ($d.decision -eq "ALLOW") {
        # Execution
        $toolName = $d.tool
        $toolPath = Join-Path $root $toolName
        
        if (-not (Test-Path $toolPath) -and (Test-Path "$toolPath.ps1")) {
            $toolPath = "$toolPath.ps1"
        }

        if (Test-Path $toolPath) {
            Log-Event -Kind "executing" -Summary "Executing $toolName on $($d.target_entity)"
            try {
                # Convert args object to hashtable for splatting
                $toolArgs = @{}
                if ($d.args) {
                    $d.args.PSObject.Properties | ForEach-Object {
                        $toolArgs[$_.Name] = $_.Value
                    }
                }
                
                # EXECUTE
                # Using Invoke-Expression or & is tricky with complex args.
                # Ideally: & $toolPath @toolArgs
                # We will try basic invocation.
                
                $output = & $toolPath @toolArgs 2>&1
                $res.status = "success"
                $res.output = "$output"
                Log-Event -Kind "complete" -Summary "Execution Success"
            }
            catch {
                $res.status = "error"
                $res.output = $_.Exception.Message
                Log-Event -Kind "error" -Summary "Execution Failed: $($_.Exception.Message)"
            }
        }
        else {
            $res.status = "error"
            $res.output = "Tool not found: $toolName"
            Log-Event -Kind "error" -Summary "Tool Missing"
        }
    }
    elseif ($d.decision -eq "PENDING") {
        # Queue to Modern Autonomy Inbox (Unified Channel)
        $inboxPath = "D:\Infinite\Infinity\Autonomy\Autonomy_Requests_Inbox.json"
        
        $item = @{
            request_id    = $decisionObj.intent_id
            strategy_id   = $d.tool
            generated_at  = (Get-Date).ToUniversalTime().ToString("o")
            reasons       = @($d.reason)
            status        = "pending"
            source        = "Agency_Executor"
            original_data = $d
        }
        
        $data = @{ items = @() }
        if (Test-Path $inboxPath) {
            try {
                $content = Get-Content $inboxPath -Raw
                if ($content) { $data = $content | ConvertFrom-Json }
                if (-not $data.items) { 
                    # Migration: If it was an array (old style), wrap it? 
                    # Or assume it is correct structure.
                    if ($data -is [Array]) { $data = @{ items = $data } }
                    else { $data = @{ items = @() } }
                }
            }
            catch {
                # Fallback if corrupt
                $data = @{ items = @() }
            }
        }
        
        $data.items += $item
        $data | ConvertTo-Json -Depth 10 | Set-Content $inboxPath -Encoding UTF8
        
        $res.status = "queued"
        $res.output = "Added to Autonomy Inbox."
        Log-Event -Kind "queued" -Summary "Action Queued for Review: $($d.reason)"
    }
    elseif ($d.decision -eq "DENIED") {
        # Block
        $res.status = "blocked"
        $res.output = "Policy Forbidden: $($d.reason)"
        Log-Event -Kind "blocked" -Summary "Action Blocked: $($d.reason)"
    }

    $results += $res
}

$report = @{
    intent_id   = $decisionObj.intent_id
    executed_at = (Get-Date).ToUniversalTime().ToString("o")
    results     = $results
}

$report | ConvertTo-Json -Depth 5
