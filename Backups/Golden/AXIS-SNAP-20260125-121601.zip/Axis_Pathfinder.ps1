# Axis_Pathfinder.ps1
# Phase 150: The Pathfinder Engine
# "The Strategist."

$pfRoot = "D:\Infinite\Infinity"
$goalsPath = Join-Path $pfRoot "Pathfinder_Goals.json"
$plansDir = Join-Path $pfRoot "Pathfinder_Plans"

function Initialize-Pathfinder {
    if (-not (Test-Path $plansDir)) {
        New-Item -ItemType Directory -Path $plansDir -Force | Out-Null
    }
    if (-not (Test-Path $goalsPath)) {
        $g = @{ version = 1; goals = @() }
        $g | ConvertTo-Json -Depth 10 | Set-Content $goalsPath -Encoding UTF8
    }
}

function Get-Goals {
    Initialize-Pathfinder
    Get-Content $goalsPath -Raw | ConvertFrom-Json
}

function Add-Goal {
    param(
        [string]$Label,
        [string]$Priority = "medium",
        [string]$Origin = "system",
        [hashtable]$Context = @{}
    )
    $g = Get-Goals
    $id = "GOAL-" + (Get-Date).ToString("yyyyMMdd-HHmmss")
    $goal = @{
        id          = $id
        priority    = $Priority
        status      = "open"
        label       = $Label
        constraints = if ($Context.constraints) { $Context.constraints } else { @() }
        deadline    = if ($Context.deadline) { $Context.deadline } else { $null }
        created_at  = (Get-Date).ToUniversalTime().ToString("o")
        origin      = $Origin
        context     = $Context
    }
    # Handle PSObject vs Hashtable array issue
    if ($g.goals -isnot [Array]) { $g.goals = @($g.goals) }
    $g.goals += $goal
    
    $g | ConvertTo-Json -Depth 10 | Set-Content $goalsPath -Encoding UTF8
    Write-Host "[PATHFINDER] Goal Added: $Label ($id)" -ForegroundColor Cyan
    return $goal
}

function New-PlanForGoal {
    param(
        [string]$GoalId,
        [hashtable[]]$Steps
    )

    Initialize-Pathfinder

    $planId = "PLAN-$GoalId"
    $planPath = Join-Path $plansDir "$planId.json"

    $plan = @{
        plan_id    = $planId
        goal_id    = $GoalId
        created_at = (Get-Date).ToUniversalTime().ToString("o")
        status     = "open"
        steps      = @()
    }

    $i = 1
    foreach ($s in $Steps) {
        $plan.steps += @{
            id     = "STEP-$i"
            label  = $s.label
            tool   = $s.tool
            params = $s.params
            status = "pending"
        }
        $i++
    }

    $plan | ConvertTo-Json -Depth 10 | Set-Content $planPath -Encoding UTF8
    Write-Host "[PATHFINDER] Plan Created: $planId ($($Steps.Count) steps)" -ForegroundColor Green
    return $plan
}

function Get-Plan {
    param([string]$PlanId)
    $planPath = Join-Path $plansDir "$PlanId.json"
    if (-not (Test-Path $planPath)) { return $null }
    Get-Content $planPath -Raw | ConvertFrom-Json
}

function Update-StepStatus {
    param(
        [string]$PlanId,
        [string]$StepId,
        [string]$Status
    )
    $planPath = Join-Path $plansDir "$PlanId.json"
    if (-not (Test-Path $planPath)) { return $null }

    $plan = Get-Content $planPath -Raw | ConvertFrom-Json
    
    # Locate step
    $found = $false
    foreach ($step in $plan.steps) {
        if ($step.id -eq $StepId) {
            $step.status = $Status
            $found = $true
            break
        }
    }
    
    if (-not $found) { return $plan }

    # Check for plan completion
    $allDone = $true
    foreach ($s in $plan.steps) {
        if ($s.status -eq "pending" -or $s.status -eq "running") {
            $allDone = $false
            break
        }
    }
    
    if ($allDone) { $plan.status = "completed" }

    $plan | ConvertTo-Json -Depth 10 | Set-Content $planPath -Encoding UTF8
    return $plan
}

# Export-ModuleMember -Function Initialize-Pathfinder, Get-Goals, Add-Goal, New-PlanForGoal, Get-Plan, Update-StepStatus
