# Axis_Explain.ps1
# Phase 121: The "Why" Engine
# "Why did you do that?"

param (
    [Parameter(Mandatory=$true)]
    [string]$Id
)

$TelemetryDir = "D:\Infinite\Infinity\Telemetry"
$EventLogPath = Join-Path $TelemetryDir "Axis_Events.json"

if (-not (Test-Path $EventLogPath)) {
    Write-Host "Error: No telemetry found at $EventLogPath" -ForegroundColor Red
    exit 1
}

Write-Host "--- AXIS EXPLAINER ---" -ForegroundColor Cyan
Write-Host "Query: $Id" -ForegroundColor Gray

# Read NDJSON (Line by Line)
$found = $null

foreach ($line in (Get-Content $EventLogPath)) {
    try {
        $evt = $line | ConvertFrom-Json
        if ($evt.id -eq $Id) {
            $found = $evt
            break
        }
    } catch {}
}

if ($found) {
    Write-Host "EVENT FOUND" -ForegroundColor Green
    Write-Host "Time:   $($found.timestamp)"
    Write-Host "Source: $($found.source)"
    Write-Host "Kind:   $($found.kind)"
    Write-Host "Summary: $($found.summary)"
    
    if ($found.details) {
        Write-Host "`nDetails:" -ForegroundColor Yellow
        $found.details | ConvertTo-Json -Depth 5 | Write-Host
    }
} else {
    Write-Host "Event ID '$Id' not found." -ForegroundColor Red
}
