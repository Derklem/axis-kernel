# Axis_GraphManager.ps1
# Memory Cartographer: Graph Manager v2.0
# Spec: D:\Infinite\Infinity\Memory_Lattice_Spec.md (Authoritative v2.0)

$root = "D:\Infinite"
$latticePath = Join-Path $root "Infinity\Memory_Lattice_Index.json"
$registryPath = Join-Path $root "Infinity\Memory_Lattice_Registry.json"
$nodesDir = Join-Path $root "Infinity\Memory_Lattice_Nodes"

# Ensure Dirs
if (-not (Test-Path $nodesDir)) { New-Item -ItemType Directory -Path $nodesDir -Force | Out-Null }

function Get-SHA256Hash([string]$content) {
    if ([string]::IsNullOrEmpty($content)) { return "000000000000" }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $hash = [BitConverter]::ToString($sha.ComputeHash($bytes)).Replace("-", "").ToLower()
    return $hash.Substring(0, 12)
}

function New-LatticeNode {
    param(
        [string]$Summary,
        [string]$RawContent = $null,
        [string]$Kind = "chronicle_event",
        [hashtable]$Source, # { system, path, position, timestamp }
        [string[]]$Tags = @()
    )

    # ID Derivation: SHA256(summary + source.path + source.position) truncated
    $idKey = $Summary + $Source.path + $Source.position
    $idHash = Get-SHA256Hash -content $idKey
    $id = "MEM-$idHash"

    return @{
        id = $id
        schema = "2.0"
        kind = $Kind
        content = @{
            summary = $Summary
            raw = $RawContent
        }
        tags = $Tags
        source = $Source
        links = @{ out = @(); in = @() }
        confidence = 1.0
        created_at = (Get-Date).ToUniversalTime().ToString("o")
    }
}

function New-LatticeEdge {
    param($SourceId, $TargetId, $Relation, $Weight = 1.0)
    return @{
        source = $SourceId
        target = $TargetId
        relation = $Relation
        weight = $Weight
        created_at = (Get-Date).ToUniversalTime().ToString("o")
    }
}

function Load-Lattice {
    if (-not (Test-Path $latticePath)) {
        return @{ 
            version = 2
            generated_at = (Get-Date).ToUniversalTime().ToString("o")
            nodes = @()
            edges = @() 
        }
    }
    return Get-Content $latticePath -Raw | ConvertFrom-Json
}

function Save-Lattice {
    param($Graph)
    $Graph.generated_at = (Get-Date).ToUniversalTime().ToString("o")
    $Graph | ConvertTo-Json -Depth 10 | Set-Content $latticePath -Encoding UTF8
}

function Load-Registry {
    if (-not (Test-Path $registryPath)) {
        return @{ sources = @{} }
    }
    $reg = Get-Content $registryPath -Raw | ConvertFrom-Json
    
    # Normalize sources to a hashtable
    if ($reg.sources -isnot [hashtable]) {
        $ht = @{}
        if ($reg.sources) {
            $reg.sources.PSObject.Properties | ForEach-Object {
                $ht[$_.Name] = $_.Value
            }
        }
        $reg.sources = $ht
    }
    return $reg
}

function Save-Registry {
    param($Registry)
    $Registry | ConvertTo-Json -Depth 5 | Set-Content $registryPath -Encoding UTF8
}

function Add-NodeToLattice {
    param($Graph, $Node)
    # Check if exists (Idempotent)
    $exists = $Graph.nodes | Where-Object { $_.id -eq $Node.id }
    if ($exists) { return $Graph }
    
    $Graph.nodes += $Node
    
    # Auto-save node fragment (Optional, but good for large graphs)
    $nodePath = Join-Path $nodesDir "$($Node.id).json"
    $Node | ConvertTo-Json -Depth 5 | Set-Content $nodePath -Encoding UTF8
    
    return $Graph
}

function Add-EdgeToLattice {
    param($Graph, $Edge)
    # Dedup
    $exists = $Graph.edges | Where-Object { $_.source -eq $Edge.source -and $_.target -eq $Edge.target -and $_.relation -eq $Edge.relation }
    if ($exists) { return $Graph }
    
    $Graph.edges += $Edge
    
    # Update node.links
    $srcNode = $Graph.nodes | Where-Object { $_.id -eq $Edge.source } | Select-Object -First 1
    $tgtNode = $Graph.nodes | Where-Object { $_.id -eq $Edge.target } | Select-Object -First 1

    if ($srcNode) {
        if ($srcNode.links.out -isnot [System.Array]) { $srcNode.links.out = @($srcNode.links.out) }
        if ($srcNode.links.out -notcontains $Edge.target) {
            $srcNode.links.out += $Edge.target
        }
    }

    if ($tgtNode) {
        if ($tgtNode.links.in -isnot [System.Array]) { $tgtNode.links.in = @($tgtNode.links.in) }
        if ($tgtNode.links.in -notcontains $Edge.source) {
            $tgtNode.links.in += $Edge.source
        }
    }
    
    return $Graph
}

# Deterministic Edge Rules
function Add-DeterministicEdges {
    param($Graph, $NewNode, $Entities) # Entities from Horizon
    
    # Rule 2: Entity Mentions
    if ($Entities) {
        $text = $NewNode.content.summary + " " + $NewNode.content.raw
        foreach ($ent in $Entities.entities) {
            # Simple substring match
            if ($text -match [Regex]::Escape($ent.name)) { 
                # Create Mentions Edge (Does entity have a MEM ID? Or do we treat Entity as a Node?)
                # Spec implies entities are Nodes of type 'entity_record'.
                # We need to find or create the Entity Node first.
                # Ideally, Ingestion creates Entity Nodes.
                # Here we assume we just link if we find a Node for that Entity.
                
                # Finding Entity Node by tag or content
                $entNode = $Graph.nodes | Where-Object { $_.kind -eq "entity_record" -and $_.content.summary -eq $ent.name }
                if ($entNode) {
                    $edge = New-LatticeEdge -SourceId $NewNode.id -TargetId $entNode.id -Relation "mentions"
                    $Graph = Add-EdgeToLattice -Graph $Graph -Edge $edge
                }
            }
        }
    }

    # Rule 1: Chronicle Temporal (handled by Ingestor usually, but helper here?)
    # Only if we pass Previous Node.
    
    return $Graph
}


# Module Export (Removed for Script Compatibility)
# Export-ModuleMember -Function *
