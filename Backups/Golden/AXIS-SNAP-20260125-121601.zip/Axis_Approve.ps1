# Axis_Approve.ps1
# Interactive Approval Tool for Agency Pending Review Queue

param(
    [string]$Id, # Index or ID of item to approve
    [switch]$List,
    [switch]$Force, # Execute without prompting (if already specifying ID)
    [switch]$Remember # Update Action Policy to ALLOW this pattern in future
)

$root = "D:\Infinite"
$pendingPath = Join-Path $root "Infinity\Agency\Pending_Reviews.json"
$policyPath = Join-Path $root "Infinity\Action_Policy.json"
$executorPath = Join-Path $root "Axis_Agency_Executor.ps1"

if (-not (Test-Path $pendingPath)) {
    Write-Host "No Pending Reviews." -ForegroundColor Green
    exit
}

$queue = Get-Content $pendingPath -Raw | ConvertFrom-Json
if ($queue -is [PSCustomObject]) { $queue = @($queue) }

if ($queue.Count -eq 0) {
    Write-Host "Queue is empty." -ForegroundColor Green
    exit
}

# LIST MODE
if ($List -or ([string]::IsNullOrWhiteSpace($Id))) {
    Write-Host "--- Pending Reviews ---" -ForegroundColor Cyan
    $i = 0
    foreach ($item in $queue) {
        Write-Host "[$i] Tool: $($item.tool) | Target: $($item.target_entity) | Effect: $($item.effect)" -ForegroundColor Yellow
        Write-Host "    Reason: $($item.reason)" -ForegroundColor Gray
        Write-Host "    Time:   $($item.queued_at)" -ForegroundColor DarkGray
        $i++
    }
    Write-Host "`nUse 'Axis_Approve.ps1 -Id <Index>' to approve." -ForegroundColor Gray
    exit
}

# APPROVE MODE
$index = -1
if ($Id -match "^\d+$") {
    $index = [int]$Id
} else {
    # Try ID match
    for ($i=0; $i -lt $queue.Count; $i++) {
        if ($queue[$i].intent_id -eq $Id) { $index = $i; break }
    }
}

if ($index -lt 0 -or $index -ge $queue.Count) {
    Write-Error "Invalid ID or Index."
    exit
}

$item = $queue[$index]
Write-Host "Approving: $($item.tool) on $($item.target_entity)" -ForegroundColor Cyan

# 1. Update Policy (Optional)
if ($Remember) {
    $policy = Get-Content $policyPath -Raw | ConvertFrom-Json
    # Check duplicate
    $exists = $false
    foreach ($r in $policy.rules) {
        if ($r.tool -eq $item.tool -and $r.target_entity -eq $item.target_entity -and $r.effect -eq $item.effect) {
            $exists = $true
            break
        }
    }
    
    if (-not $exists) {
        $newRule = @{
            tool = $item.tool
            target_entity = $item.target_entity
            effect = $item.effect
            policy = "auto"
            kernel_refs = @("USER_APPROVED")
        }
        $policy.rules += $newRule
        $policy | ConvertTo-Json -Depth 5 | Set-Content $policyPath -Encoding UTF8
        Write-Host " [POLICY] Rule added: Auto-Allow $($item.tool) -> $($item.target_entity)" -ForegroundColor Green
    } else {
         Write-Host " [POLICY] Rule already exists (skipping update)." -ForegroundColor Yellow
    }
}

# 2. Execute
# Construct Decision Object mimicking Policy Output but with ALLOW
$decisionObj = @{
    intent_id = $item.intent_id
    decisions = @(
        @{
            tool = $item.tool
            target_entity = $item.target_entity
            effect = $item.effect
            args = $item.args
            decision = "ALLOW"
            reason = "Approved by Architect via Axis_Approve"
            policy_applied = "manual_override"
        }
    )
}

$decisionJson = $decisionObj | ConvertTo-Json -Depth 5 -Compress
# Invoke Executor
Write-Host " [EXEC] Handoff to Executor..." -ForegroundColor Gray
$decisionJson | & $executorPath

# 3. Remove from Queue
# In PS array removal is rebuilt
$newQueue = @()
for ($i=0; $i -lt $queue.Count; $i++) {
    if ($i -ne $index) { $newQueue += $queue[$i] }
}
$newQueue | ConvertTo-Json -Depth 5 | Set-Content $pendingPath -Encoding UTF8
Write-Host " [QUEUE] Item removed." -ForegroundColor Green
