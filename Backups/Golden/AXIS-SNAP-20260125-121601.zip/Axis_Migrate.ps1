# Axis_Migrate.ps1
# Phase 142: Multi-Host Replication
# "Spread the Seed."

param (
    [Parameter(Mandatory=$true)]
    [string]$Destination
)

$root = "D:\Infinite"
$snapDir = Join-Path $root "Snapshots"
$manifestPath = Join-Path $snapDir "Golden_Manifest.json"

Write-Host "--- AXIS MIGRATION PROTOCOL ---" -ForegroundColor Cyan
Write-Host "Target: $Destination" -ForegroundColor Gray

# 1. Check Source
if (-not (Test-Path $manifestPath)) {
    Write-Host "Error: No Golden Manifest found at $manifestPath" -ForegroundColor Red
    exit 1
}

$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$latest = $manifest | Sort-Object timestamp -Descending | Select-Object -First 1

if (-not $latest) {
    Write-Host "Error: Manifest is empty." -ForegroundColor Red
    exit 1
}

$sourceFile = Join-Path $snapDir $latest.file

if (-not (Test-Path $sourceFile)) {
    Write-Host "Error: Snapshot file $($latest.file) missing." -ForegroundColor Red
    exit 1
}

Write-Host "Migrating Snapshot: $($latest.id)" -ForegroundColor Yellow
Write-Host "Hash: $($latest.hash)" -ForegroundColor DarkGray

# 2. Check/Create Destination
if (-not (Test-Path $Destination)) {
    New-Item -ItemType Directory -Path $Destination | Out-Null
    Write-Host "Created destination directory." -ForegroundColor Gray
}

# 3. Copy
$destFile = Join-Path $Destination $latest.file
Copy-Item $sourceFile -Destination $destFile -Force
Copy-Item $manifestPath -Destination (Join-Path $Destination "Golden_Manifest.json") -Force

Write-Host "Copy Complete." -ForegroundColor Green

# 4. Verify Integrity
$newHash = (Get-FileHash -Path $destFile -Algorithm SHA256).Hash

if ($newHash -eq $latest.hash) {
    Write-Host "INTEGRITY CONFIRMED." -ForegroundColor Green
    Write-Host "The seed is planted." -ForegroundColor Cyan
} else {
    Write-Host "INTEGRITY FAILURE." -ForegroundColor Red
    Write-Host "Source: $($latest.hash)"
    Write-Host "Dest:   $newHash"
    Write-Host "Do not trust this copy." -ForegroundColor Red
}
