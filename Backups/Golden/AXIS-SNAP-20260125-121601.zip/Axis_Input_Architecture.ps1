<#
.SYNOPSIS
    Phase 200 - Input Architecture (File Watcher) v3
.DESCRIPTION
    Monitors D:\Infinite\Inputs for files.
    Parses them as commands.
    Injects them into the Earth Queue.
    Archives processed files.
    
    Hardened v3:
    - Runtime Queue Repair (Get-HealthyQueue)
    - Provenance Tagging (AG-*, HUMAN-*)
    - Structured Telemetry (JSONL)
#>

$ErrorActionPreference = "Stop" # Fail loudly on setup errors

$Root = "D:\Infinite"
$InputPath = "$Root\Inputs"
$QueuePath = "$Root\Infinity\Earth\Requests_Queue.json"
$ArchivePath = "$Root\Infinity\Archive\Inputs"
$LogPath = "$Root\Infinity\Logs\Input_Bridge.log"
$TelemetryPath = "$Root\Infinity\Logs\Input_Bridge_Telemetry.jsonl"

# --- Initialization ---
try {
    Write-Host "--- INPUT ARCHITECTURE v3 (PROVENANCE) ---" -ForegroundColor Cyan
    
    # Create Directories
    foreach ($path in @($InputPath, $ArchivePath)) {
        if (-not (Test-Path $path)) { New-Item -ItemType Directory -Path $path -Force | Out-Null }
    }
    
    foreach ($f in @($LogPath, $TelemetryPath)) {
        $d = Split-Path $f -Parent
        if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
    }

    Write-Host "Watching: $InputPath" -ForegroundColor Gray
    Write-Host "Logging to: $LogPath" -ForegroundColor Gray

}
catch {
    Write-Error "FATAL INITIALIZATION ERROR: $_"
    exit 1
}

# --- Functions ---

function Log-InputBridge {
    param($Msg, $Type = "INFO")
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $line = "[$ts] [$Type] $Msg"
    Add-Content -Path $LogPath -Value $line
    
    $color = switch ($Type) { "ERROR" { "Red" } "WARN" { "Yellow" } Default { "Gray" } }
    Write-Host "  > $Msg" -ForegroundColor $color
}

function Log-Telemetry {
    param($Event)
    $Event.timestamp = (Get-Date).ToString("o")
    $line = $Event | ConvertTo-Json -Compress
    Add-Content -Path $TelemetryPath -Value $line
}

function Get-HealthyQueue {
    param([string]$Path)
    
    try {
        if (-not (Test-Path $Path)) { throw "Queue file missing." }
        
        $q = Get-Content $Path -Raw | ConvertFrom-Json
        if (-not $q) { throw "Queue is empty/null." }
        
        # Structure Check
        if (-not $q.PSObject.Properties.Match('requests')) { throw "Queue missing 'requests'." }
        if ($q.requests -isnot [Array]) { throw "'requests' is not an array." }
        
        return $q
    }
    catch {
        Log-InputBridge "QUEUE CORRUPTION DETECTED: $_. Self-Repairing." "WARN"
        
        # Backup if exists
        if (Test-Path $Path) {
            $bak = "$Path.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
            Move-Item $Path $bak -Force
            Log-InputBridge "Corrupt queue backed up to $bak"
        }
        
        # Reset
        $newQ = @{ version = 1; requests = @() }
        $newQ | ConvertTo-Json -Depth 5 | Set-Content $Path -Encoding UTF8
        return ([PSCustomObject]$newQ)
    }
}

function Get-Provenance {
    param($FileName)
    
    if ($FileName -like "AG-ANTIGRAVITY-*") { return "AntiGravity" }
    elseif ($FileName -like "AG-GEMINI-*") { return "Gemini" }
    elseif ($FileName -like "HUMAN-*") { return "Human" }
    else { return "Unknown" }
}

# --- Main Loop ---

# Ensure initial queue health
$null = Get-HealthyQueue -Path $QueuePath

while ($true) {
    # Suppress errors for enumerating files
    $files = Get-ChildItem -Path $InputPath -File -ErrorAction SilentlyContinue 
    
    foreach ($file in $files) {
        try {
            Write-Host "`nProcessing: $($file.Name)" -ForegroundColor Yellow
            $content = Get-Content $file.FullName -Raw
            
            # 1. Provenance
            $origin = Get-Provenance -FileName $file.Name
            Log-InputBridge "Detected Origin: $origin"
            
            # 2. Request Construction
            $req = @{
                id         = "INPUT-$(Get-Date -Format 'yyyyMMddHHmmssffff')"
                source     = "Input_Bridge"
                timestamp  = (Get-Date).ToString("o")
                status     = "new"
                tool       = "Unknown"
                params     = @{}
                provenance = @{
                    origin   = $origin
                    filename = $file.Name
                    bridge   = "v3"
                }
            }

            if ($file.Extension -eq ".json") {
                try {
                    $json = $content | ConvertFrom-Json
                    if ($json.tool) { $req.tool = $json.tool }
                    if ($json.params) { $req.params = $json.params }
                }
                catch {
                    Log-InputBridge "JSON Parse Error: $_" "WARN"
                    $req.params = @{ raw_content = $content; error = "Invalid JSON" }
                }
            }
            else {
                # Text file
                $req.tool = "Ingest-RawText"
                $req.params = @{ content = $content }
            }
            
            # 3. Robust Append
            $q = Get-HealthyQueue -Path $QueuePath
            $q.requests += $req
            $q | ConvertTo-Json -Depth 5 | Set-Content $QueuePath -Encoding UTF8
            
            Log-InputBridge "Queued request $($req.id)"
            
            # 4. Telemetry
            Log-Telemetry @{
                event      = "ingestion"
                request_id = $req.id
                origin     = $origin
                tool       = $req.tool
                status     = "queued"
            }
            
            # 5. Archive
            $dest = "$ArchivePath\$($file.Name).processed"
            Move-Item $file.FullName $dest -Force
            
        }
        catch {
            Log-InputBridge "Failed to process $($file.Name): $_" "ERROR"
            try { Move-Item $file.FullName "$($file.FullName).error" -Force } catch {}
            
            Log-Telemetry @{
                event    = "error"
                filename = $file.Name
                error    = "$_"
            }
        }
    }
    
    Start-Sleep -Seconds 1
}
