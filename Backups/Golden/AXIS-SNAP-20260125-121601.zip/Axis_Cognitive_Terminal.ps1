<#
.SYNOPSIS
    Phase 122 - Axis Cognitive Terminal (The Throne)
.DESCRIPTION
    Interactive REPL for direct Mind communication and state inspection.
#>

$root = "D:\Infinite"
. (Join-Path $root "Axis_State.ps1")
. (Join-Path $root "Axis_Telemetry.ps1")
. (Join-Path $root "Axis_AutonomyGate.ps1") # For treaty/consensue checks

function Show-Header {
    Clear-Host
    Write-Host "==========================================================" -ForegroundColor Magenta
    Write-Host "             AXIS COGNITIVE TERMINAL (v122)               " -ForegroundColor Yellow
    Write-Host "             Mode: FEDERATED SOVEREIGNTY                 " -ForegroundColor Cyan
    Write-Host "==========================================================" -ForegroundColor Magenta
}

function Show-Status {
    $sys = Get-AxisState
    if (-not $sys) { Write-Host "ERR: System State Offline" -F Red; return }

    Write-Host "`n--- SYSTEM STATUS ---" -ForegroundColor Yellow
    Write-Host "Identity:   $($sys.identity.archetype.name) ($($sys.identity.archetype.role))"
    Write-Host "Mode:       $($sys.identity.awareness.autonomy_mode)" -ForegroundColor Cyan
    Write-Host "Uptime:     $($sys.identity.awareness.uptime_seconds)s"
    Write-Host "Timestamp:  $($sys.timestamp)"
}

function Show-Risk {
    $riskPath = "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json"
    if (Test-Path $riskPath) {
        $risk = Get-Content $riskPath -Raw | ConvertFrom-Json
        Write-Host "`n--- SHADOW RISK INDEX ---" -ForegroundColor Yellow
        $color = if ($risk.summary.global_risk_score -gt 0.5) { "Red" } else { "Green" }
        Write-Host "Global Score: $($risk.summary.global_risk_score)" -ForegroundColor $color
        Write-Host "Bands:"
        foreach ($p in $risk.summary.bands.PSObject.Properties) {
            Write-Host "  $($p.Name): $($p.Value)"
        }
    }
    else {
        Write-Host "Shadow Risk Index not found." -ForegroundColor Gray
    }
}

function Show-Treaty {
    $ledgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json"
    if (Test-Path $ledgerPath) {
        $ledger = Get-Content $ledgerPath -Raw | ConvertFrom-Json
        Write-Host "`n--- TREATY LEDGER ---" -ForegroundColor Yellow
        if (@($ledger.treaties).Count -eq 0) { Write-Host "No treaties in ledger." -F Gray }
        foreach ($t in $ledger.treaties) {
            $color = if ($t.status -eq "synchronized") { "Green" } elseif ($t.status -eq "dissonance") { "Red" } else { "Yellow" }
            Write-Host "[$($t.rule_id)] Status: $($t.status)" -ForegroundColor $color
        }
    }
}


function Invoke-Reflect {
    Write-Host "`n--- NEURAL REFLECTION ---" -ForegroundColor Cyan
    if (Test-Path "D:\Infinite\Axis_Neural_Reflection.ps1") {
        & "D:\Infinite\Axis_Neural_Reflection.ps1"
    }
    else {
        Write-Host "Reflection Engine not found." -F Red
    }
}

function Show-Proposals {
    $propPath = "D:\Infinite\Infinity\Governance\Neural_Proposals.json"
    if (Test-Path $propPath) {
        $data = Get-Content $propPath -Raw | ConvertFrom-Json
        Write-Host "`n--- NEURAL PROPOSALS (SELF-HEALING) ---" -ForegroundColor Yellow
        if (@($data.proposals).Count -eq 0) { Write-Host "No active proposals." -F Gray; return }
        
        foreach ($p in $data.proposals) {
            Write-Host "ID: $($p.id)" -F Magenta
            Write-Host "  Type:     $($p.type)"
            Write-Host "  Target:   $($p.target)"
            
            $sev = if ($p.severity) { $p.severity } else { "unknown" }
            $sevColor = switch ($sev.ToLower()) {
                "critical" { "Red" }
                "high" { "Yellow" }
                "medium" { "Cyan" }
                "low" { "Gray" }
                default { "DarkGray" }
            }
            Write-Host ("  Severity: {0}" -f $sev) -ForegroundColor $sevColor
            Write-Host "  Reason:   $($p.reason)"
            if ($p.explanation) {
                Write-Host "  Explanation: $($p.explanation)" -ForegroundColor Gray
            }
            Write-Host ""
        }
    }
    else {
        Write-Host "No proposal registry found." -F Gray
    }
}

function Show-Story {
    Write-Host "`n--- SYSTEM NARRATIVE (Last 24h) ---" -ForegroundColor Cyan
    if (Test-Path "D:\Infinite\Axis_Narrative_Engine.ps1") {
        . "D:\Infinite\Axis_Narrative_Engine.ps1"
        $story = Get-AxisStory
        Write-Host $story
    }
    else {
        Write-Host "Narrative Engine not found." -F Red
    }
}

function Show-Why {
    param($Id)
    if (-not $Id) { Write-Host "Usage: WHY [Proposal-ID]" -F Red; return }
    
    # Sanitize ID
    $Id = $Id.Trim("[]")

    if (Test-Path "D:\Infinite\Axis_Narrative_Engine.ps1") {
        . "D:\Infinite\Axis_Narrative_Engine.ps1"
        $reasoning = Get-ProposalReasoning -Id $Id
        Write-Host "`n--- PROPOSAL ANALYSIS ---" -ForegroundColor Cyan
        Write-Host $reasoning
    }
    else {
        Write-Host "Narrative Engine not found." -F Red
    }
}

function Show-Scenarios {
    Write-Host "`n--- AVAILABLE SCENARIOS (RED TEAMING) ---" -ForegroundColor Cyan
    if (Test-Path "D:\Infinite\Axis_Scenario_Engine.ps1") {
        . "D:\Infinite\Axis_Scenario_Engine.ps1"
        $list = Get-Scenarios
        foreach ($s in $list) {
            Write-Host "ID: $($s.id)" -F Magenta
            Write-Host "  Name: $($s.name)"
            Write-Host "  Desc: $($s.description)"
            Write-Host ""
        }
    }
    else { Write-Host "Scenario Engine not found." -F Red }
}

function Run-ScenarioCommand {
    param($Id)
    if (-not $Id) { Write-Host "Usage: RUN SCENARIO <ID>" -F Red; return }
    $Id = $Id.Trim("[]") # Sanitize

    if (Test-Path "D:\Infinite\Axis_Scenario_Engine.ps1") {
        . "D:\Infinite\Axis_Scenario_Engine.ps1"
        Invoke-AxisScenario -Id $Id
    }
    else { Write-Host "Scenario Engine not found." -F Red }
}

function Show-Diplomacy {
    Write-Host "`n--- DIPLOMATIC RELATIONS ---" -ForegroundColor Cyan
    if (Test-Path "D:\Infinite\Axis_Diplomat.ps1") {
        . "D:\Infinite\Axis_Diplomat.ps1"
        $status = Get-DiplomaticStatus
        
        $keys = if ($status.agents.PSObject) { $status.agents.PSObject.Properties.Name } else { $status.agents.Keys }
        
        foreach ($name in $keys) {
            $a = $status.agents.$name
            Write-Host "Agent: $name" -NoNewline
            if ($name -eq "Anti-Gravity") { Write-Host " [PEER]" -F Green } else { Write-Host "" }
            Write-Host "  Role:  $($a.role)" -F Gray
            $trustColor = if ($a.trust_score -ge 0.8) { 'Green' } else { 'Red' }
            Write-Host "  Trust: $($a.trust_score)" -ForegroundColor $trustColor
            Write-Host ""
        }
    }
    else { Write-Host "Diplomat not online." -F Red }
}

function Stream-Logs {
    Write-Host "`n--- TELEMETRY STREAM (Press Ctrl+C to Stop) ---" -ForegroundColor Cyan
    try {
        Read-AxisEventStream -Count 5 -Tail
    }
    catch {
        Write-Host "`nExiting stream." -F Gray
    }
}

# Main Loop
Show-Header
$running = $true

while ($running) {
    $input = Read-Host "`n[AXIS]>"
    $parts = $input.Split(" ", [StringSplitOptions]::RemoveEmptyEntries)
    if ($parts.Count -eq 0) { continue }
    
    $cmd = $parts[0].ToUpper()
    
    # improved args parsing
    $args = if ($parts.Count -gt 1) { $parts[1..($parts.Count - 1)] -join " " } else { "" }

    switch ($cmd) {
        "STATUS" { Show-Status }
        "RISK" { Show-Risk }
        "TREATY" { Show-Treaty }
        "REFLECT" { Invoke-Reflect }
        "PROPOSALS" { Show-Proposals }
        "STORY" { Show-Story }
        "WHY" { Show-Why -Id $args }
        "SCENARIOS" { Show-Scenarios }
        "DIPLOMACY" { Show-Diplomacy }
        "RUN" {
            if ($args.ToUpper().StartsWith("SCENARIO")) {
                $scenId = $args.Substring(8).Trim() # remove "SCENARIO "
                Run-ScenarioCommand -Id $scenId
            }
            else {
                Write-Host "Unknown RUN target. Try: RUN SCENARIO <ID>" -F Gray
            }
        }
        "LOG" { Stream-Logs }
        "ID" { 
            $sys = Get-AxisState
            $sys.identity.archetype | Format-List | Out-Host
        }
        "CLS" { Show-Header }
        "EXIT" { $running = $false }
        "HELP" {
            Write-Host "Available Commands:"
            Write-Host "  STATUS    - Show system health and mode"
            Write-Host "  RISK      - Inspect shadow risk scores"
            Write-Host "  TREATY    - View federated legal state"
            Write-Host "  REFLECT   - Trigger neural reflection (Self-Healing)"
            Write-Host "  PROPOSALS - View generated self-healing proposals"
            Write-Host "  STORY     - View 24h system narrative"
            Write-Host "  WHY [ID]  - Explain reasoning for a proposal"
            Write-Host "  SCENARIOS - List experimental red-team scenarios"
            Write-Host "  RUN ...   - Execute a scenario (RUN SCENARIO <ID>)"
            Write-Host "  DIPLOMACY - View foreign agent relations"
            Write-Host "  LOG       - Start real-time telemetry stream"
            Write-Host "  STATUS    - Show system health and mode"
            Write-Host "  RISK      - Inspect shadow risk scores"
            Write-Host "  TREATY    - View federated legal state"
            Write-Host "  REFLECT   - Trigger neural reflection (Self-Healing)"
            Write-Host "  PROPOSALS - View generated self-healing proposals"
            Write-Host "  STORY     - View 24h system narrative"
            Write-Host "  WHY [ID]  - Explain reasoning for a proposal"
            Write-Host "  LOG       - Start real-time telemetry stream"
            Write-Host "  ID        - Inspect Mind identity architecture"
            Write-Host "  CLS       - Clear terminal"
            Write-Host "  EXIT      - Close terminal"
        }
        "" { continue }
        default { Write-Host "Unknown command: $cmd" -ForegroundColor Gray }
    }
}
