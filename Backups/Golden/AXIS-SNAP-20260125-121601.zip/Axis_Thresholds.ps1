# Axis_Thresholds.ps1
# Phase 140: Central Thresholds
# "The Rules."

$root = "D:\Infinite\Infinity"
$archKernelPath = Join-Path $root "Architect_Kernel.md"
$identKernelPath = Join-Path $root "Covenant\Identity_Kernel.json"
$backupMapPath = Join-Path $root "Axis_Backup_Map.json"
$telemetryScript = "D:\Infinite\Axis_Telemetry.ps1"

function Get-AxisThresholdConfig {
    if (Test-Path $backupMapPath) { return Get-Content $backupMapPath -Raw | ConvertFrom-Json }
    return $null
}

function Test-AxisThresholds {
    param(
        [string]$Context, # e.g., "godseed", "replication"
        [string]$Target = $null
    )

    Write-Host "[THRESHOLDS] Testing Context: $Context" -ForegroundColor Cyan

    # 1. ARCHITECT KERNEL CHECK (Primacy)
    if (-not (Test-Path $archKernelPath)) {
        Write-Host "[BLOCK] Architect Kernel MISSING. Operation Aborted." -ForegroundColor Red
        return $false
    }
    $archContent = Get-Content $archKernelPath -Raw
    if ($archContent -notmatch "status:\s*ACTIVE") {
        Write-Host "[BLOCK] Architect Kernel NOT ACTIVE. Operation Aborted." -ForegroundColor Red
        return $false
    }

    # 2. IDENTITY KERNEL CHECK
    if (-not (Test-Path $identKernelPath)) {
        Write-Host "[BLOCK] Identity Kernel MISSING. Operation Aborted." -ForegroundColor Red
        return $false
    }

    # 3. CONTEXT SPECIFIC CHECKS
    if ($Context -eq "godseed") {
        # Check Backup Map
        $map = Get-AxisThresholdConfig
        if (-not $map) {
             Write-Host "[BLOCK] Backup Map Missing." -ForegroundColor Red
             return $false
        }
        
        # Validate Target if provided
        if ($Target) {
            $allowed = $false
            foreach ($t in $map.allowed_targets) {
                if ($Target.StartsWith($t.path)) { $allowed = $true; break }
            }
            if (-not $allowed) {
                Write-Host "[BLOCK] Target '$Target' NOT in Allowed List." -ForegroundColor Red
                return $false
            }
            
            # Check Forbidden
            foreach ($p in $map.forbidden_patterns) {
                if ($Target -like $p) {
                    Write-Host "[BLOCK] Target matches Forbidden Pattern '$p'." -ForegroundColor Red
                    return $false
                }
            }
        }
        
        # Check Disk Space / Count caps (Stub)
        # Assuming OK for now.
    }

    Write-Host "[THRESHOLDS] Check Passed." -ForegroundColor Green
    return $true
}

Export-ModuleMember -Function Test-AxisThresholds, Get-AxisThresholdConfig
