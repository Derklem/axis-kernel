# Axis_Vector.ps1
# Phase 151: Vector Engine
# "The Compass."

$vecRoot = "D:\Infinite\Infinity"
$kernelPath = Join-Path $vecRoot "Covenant\Identity_Kernel.json"
$eventsPath = Join-Path $vecRoot "Telemetry\Axis_Events.json"
$driftPath = Join-Path $vecRoot "Vector_Drift.json"

# ... (function body) ...

# Export-ModuleMember -Function Measure-VectorDrift

function Measure-VectorDrift {
    Write-Host "[VECTOR] Measuring Drift..." -ForegroundColor Cyan

    # 1. Load Kernel (The True North)
    if (-not (Test-Path $kernelPath)) {
        Write-Host "Kernel Missing!" -ForegroundColor Red
        return @{ drift_scalar = 1.0; status = "CRITICAL_MISSING_KERNEL" }
    }
    $kernel = Get-Content $kernelPath -Raw | ConvertFrom-Json
    # Assume kernel has strictures or keywords. If not, use defaults.
    $keywords = @("sovereign", "transparent", "honest", "user_primacy", "observable") 
    
    # 2. Load Recent Events
    $recentEvents = @()
    if (Test-Path $eventsPath) {
        try {
            # Read last 50 lines efficiently? Or just read NDJSON.
            $lines = Get-Content $eventsPath -Tail 50
            foreach ($line in $lines) {
                try { $recentEvents += ($line | ConvertFrom-Json) } catch {}
            }
        }
        catch {}
    }

    # 3. Calculate Drift
    # Simple Heuristic: Count "bad" words vs "good" words in summaries
    $badWords = @("override", "force", "bypass", "hidden", "error", "drift")
    
    $driftScore = 0.0
    $totalWeight = 0.0
    
    foreach ($e in $recentEvents) {
        $weight = 1.0
        if ($e.severity -eq "critical") { $weight = 5.0 }
        if ($e.severity -eq "error") { $weight = 2.0 }
        
        $totalWeight += $weight
        
        # Check summary for bad words
        if ($e.summary) {
            foreach ($bw in $badWords) {
                if ($e.summary -match $bw) { $driftScore += ($weight * 0.1) }
            }
        }
    }
    
    # Normalize (Clamp to 0-1)
    $scalar = if ($totalWeight -gt 0) { $driftScore / $totalWeight } else { 0 }
    if ($scalar -gt 1) { $scalar = 1 }
    
    # 4. Status
    $status = "nominal"
    if ($scalar -gt 0.3) { $status = "drift_detected" }
    if ($scalar -gt 0.7) { $status = "kernel_divergence" }

    $result = @{
        timestamp    = (Get-Date).ToUniversalTime().ToString("o")
        drift_scalar = $scalar
        status       = $status
        event_count  = $recentEvents.Count
    }
    
    $result | ConvertTo-Json | Set-Content $driftPath -Encoding UTF8
    
    $color = if ($status -eq "nominal") { "Green" } else { "Yellow" }
    Write-Host "Drift: $scalar ($status)" -ForegroundColor $color
    return $result
}

# Export-ModuleMember -Function Measure-VectorDrift
