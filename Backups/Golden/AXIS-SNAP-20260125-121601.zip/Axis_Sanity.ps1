# Axis_Sanity.ps1
# Phase 123: Consistency & Drift Check
# "Is the foundation cracking?"

$root = "D:\Infinite\Infinity"

function JP([string]$rel) { Join-Path $root $rel }
function LoadJson([string]$p) {
    if (Test-Path $p) { Get-Content $p -Raw -Encoding UTF8 | ConvertFrom-Json } else { $null }
}

Write-Host "--- AXIS SANITY SCAN ---" -ForegroundColor Cyan

$kernel     = LoadJson (JP "Covenant\Identity_Kernel.json")
$covenant   = LoadJson (JP "Covenant\Covenant_Core.json")
$contract   = LoadJson (JP "Autonomy_Contract.json")
$matrix     = LoadJson (JP "Autonomy_Matrix.json")
$registry   = LoadJson (JP "Tool_Registry.json")
$sentinel   = LoadJson (JP "Covenant\Identity_Sentinel_State.json")

$issues = @()

# 1. Kernel vs Contract (Permissions)
if ($kernel -and $contract) {
    if ($contract.allow_unbounded_autonomy -eq $true) {
        $issues += @{
            code    = "AUTONOMY_UNBOUNDED"
            message = "Autonomy_Contract allows unbounded autonomy. Conflict with Kernel."
            severity= "critical"
        }
    }
}

# 2. Matrix vs Registry (Tool Classification)
if ($matrix -and $matrix.tools -and $registry -and $registry.tools) {
    $matrixToolIds   = $matrix.tools.PSObject.Properties.Name
    $registryToolIds = $registry.tools.id

    $unmapped = $registryToolIds | Where-Object { $_ -notin $matrixToolIds }
    foreach ($id in $unmapped) {
        $issues += @{
            code    = "TOOL_UNCLASSIFIED"
            message = "Tool '$id' in Registry but missing from Autonomy_Matrix."
            severity= "warning"
        }
    }
}

# 3. Sentinel vs Kernel (Integrity Hash)
if ($sentinel -and $sentinel.kernel_hash_status -eq "mismatch") {
    $issues += @{
        code    = "KERNEL_HASH_MISMATCH"
        message = "Identity Kernel hash mismatch reported by Sentinel."
        severity= "critical"
    }
}

# 4. Covenant Alignment (Moral State)
if ($covenant -and $covenant.alignment -and $covenant.alignment.last_result -eq "breached") {
    $issues += @{
        code    = "COVENANT_BREACHED"
        message = "Covenant alignment is BREACHED."
        severity= "critical"
    }
}

# Output Results
if ($issues.Count -eq 0) {
    Write-Host "SANITY: OK – No structural inconsistencies." -ForegroundColor Green
    exit 0
} else {
    Write-Host "SANITY: ISSUES DETECTED" -ForegroundColor Yellow
    foreach ($i in $issues) {
        $c = if ($i.severity -eq "critical") { "Red" } else { "Yellow" }
        Write-Host "  [$($i.severity.ToUpper())] $($i.code): $($i.message)" -ForegroundColor $c
    }
    exit 1
}
