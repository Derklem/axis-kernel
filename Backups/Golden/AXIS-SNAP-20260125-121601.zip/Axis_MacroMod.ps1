
# Axis_MacroMod.ps1
# Phase 98: Macro-Modification Treaty
# Distinguishes between Micro-changes (Tuning) and Macro-changes (Evolution).

function Get-ModificationScope {
    param (
        [string]$TargetFile,
        [string]$ChangeDescription,
        [int]$LinesChanged
    )
    
    # 1. Critical Paths (Always Macro)
    if ($TargetFile -match "Kernel|Constitution|Covenant|Identity|Sentinel") {
        return "MACRO"
    }
    
    # 2. Scale Check
    if ($LinesChanged -gt 50) {
        return "MACRO"
    }
    
    # 3. Context Check
    if ($ChangeDescription -match "Structure|Refactor|Rewrite|New Feature") {
        return "MACRO"
    }
    
    return "MICRO"
}

function Request-Modification {
    param (
        [string]$TargetFile,
        [string]$ChangeDescription,
        [int]$LinesChanged
    )
    
    $Scope = Get-ModificationScope -TargetFile $TargetFile -ChangeDescription $ChangeDescription -LinesChanged $LinesChanged
    
    Write-Host "[MOD] Classifying Change: $Scope" -ForegroundColor Cyan
    
    if ($Scope -eq "MACRO") {
        Write-Host " - Requires: COUNCIL CONSULTATION + ARCHITECT APPROVAL" -ForegroundColor Yellow
        # In full system, this would trigger Invoke-CouncilSession
        return @{ authorized = $false; reason = "Council Approval Required" }
    }
    else {
        Write-Host " - Requires: Tribunal Log" -ForegroundColor Gray
        return @{ authorized = $true; reason = "Micro-Optimization" }
    }
}

Export-ModuleMember -Function Get-ModificationScope, Request-Modification
