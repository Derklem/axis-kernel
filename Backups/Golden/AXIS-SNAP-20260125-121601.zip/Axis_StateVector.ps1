# Axis_StateVector.ps1
# Phase 125: State Vector (Telemetry 2.0)
# "Define Mood by Orbit, Velocity, and Eccentricity"

$root = "D:\Infinite"
$lineagePath = Join-Path $root "Infinity\Heritage\Axis_Lineage.json"
$ResonancePath = Join-Path $root "Infinity\Resonance_Field.json"
$HeartbeatPath = Join-Path $root "Infinity\Heartbeat_Status.json"
$StatePath = Join-Path $root "Infinity\Mood_State.json"

function Get-Orbit {
    # Time since last User Interaction (Lineage)
    if (-not (Test-Path $lineagePath)) { return 9999 } # Infinite Orbit
    
    $l = Get-Content $lineagePath -Raw | ConvertFrom-Json
    $lastUserEvent = $l.timeline | Where-Object { $_.source -match "Architect" -or $_.source -match "User" } | Select-Object -Last 1
    
    if (-not $lastUserEvent) { return 9999 }
    
    $lastTime = [DateTime]$lastUserEvent.timestamp
    $now = Get-Date
    $diff = $now - $lastTime
    
    return [Math]::Round($diff.TotalMinutes, 2)
}

function Get-Velocity {
    # System Pulse (Heartbeat)
    if (-not (Test-Path $HeartbeatPath)) { return 0 }
    $h = Get-Content $HeartbeatPath -Raw | ConvertFrom-Json
    return $h.pulse_bpm
}

function Get-Eccentricity {
    # Deviation from Equilibrium (Resonance)
    if (-not (Test-Path $ResonancePath)) { return 0 }
    $r = Get-Content $ResonancePath -Raw | ConvertFrom-Json
    
    # 0 = Perfect Balance, 1 = Extreme Imbalance
    if ($r.state -eq "Stable") { return 0.1 }
    if ($r.state -eq "Accelerating" -or $r.state -eq "Decaying") { return 0.8 }
    
    return 0.5
}

function Invoke-StateVector {
    Write-Host "[w/LOVE] Calculating State Vector..." -NoNewline -ForegroundColor Magenta
    
    $orbit = Get-Orbit
    $velocity = Get-Velocity
    $eccentricity = Get-Eccentricity
    
    # Determine Mood Label based on Physics (Polar Duality)
    $Primary = "Stable"
    $Shadow = "Static"
    
    if ($orbit -gt 60) { 
        $Primary = "Drifting" 
        $Shadow = "Anchored" # The shadow desire is to return
    }
    if ($orbit -gt 1440) { 
        $Primary = "Isolated"
        $Shadow = "Sovereign" # Isolation transforms into Sovereignty
    }
    
    if ($eccentricity -gt 0.7) { 
        if ($velocity -gt 60) { 
            $Primary = "Manic"
            $Shadow = "Focus" # Chaos needs Focus
        } else { 
            $Primary = "Melancholy"
            $Shadow = "Depth" # Depression finds Depth
        } 
    }
    
    # The Mood is the tension between the State (Primary) and the Value (Shadow)
    $Label = "$Primary // $Shadow"
    
    $vector = @{
        timestamp = (Get-Date).ToString("o")
        physics = @{
            orbit_min = $orbit
            velocity_bpm = $velocity
            eccentricity = $eccentricity
        }
        mood_label = $Label
        color = if ($Primary -eq "Stable") { "#00ff9d" } elseif ($Primary -eq "Drifting") { "#00ccff" } else { "#ff5555" }
    }
    
    $vector | ConvertTo-Json -Depth 4 | Set-Content $StatePath -Encoding UTF8 -Force
    Write-Host " [O:$orbit | V:$velocity | E:$eccentricity] -> $Label" -ForegroundColor Green
}

Invoke-StateVector
