# Axis_Agency_Inbox.ps1
# Epoch 6: Governance Surface - The Inbox
# Reads the Pending Queue and displays a structured summary of blocked actions.

$root = "D:\Infinite"
$pendingPath = Join-Path $root "Infinity\Agency\Pending_Reviews.json"

if (-not (Test-Path $pendingPath)) {
    Write-Host "--- Agency Inbox ---" -ForegroundColor Cyan
    Write-Host "Queue Empty. No pending actions." -ForegroundColor Green
    exit
}

try {
    $queue = Get-Content $pendingPath -Raw | ConvertFrom-Json
    if ($queue -is [PSCustomObject]) { $queue = @($queue) }
} catch {
    Write-Error "Failed to read Pending Queue: $_"
    exit 1
}

if ($queue.Count -eq 0) {
    Write-Host "--- Agency Inbox ---" -ForegroundColor Cyan
    Write-Host "Queue Empty. No pending actions." -ForegroundColor Green
    exit
}

# Group by Tool and Effect
$grouped = $queue | Group-Object -Property tool, effect, target_entity

Write-Host "--- Agency Inbox: $($queue.Count) Pending item(s) ---" -ForegroundColor Cyan
Write-Host "Generated: $(Get-Date)" -ForegroundColor DarkGray
Write-Host ""

foreach ($g in $grouped) {
    # Parse Group Names
    # Group-Object name is comma separated values of properties
    $props = $g.Name -split ", "
    $tool = $props[0]
    $effect = $props[1]
    $target = $props[2]
    
    $count = $g.Count
    $first = ($g.Group | Sort-Object queued_at | Select-Object -First 1).queued_at
    $last = ($g.Group | Sort-Object queued_at | Select-Object -Last 1).queued_at
    
    Write-Host "[$count] Request(s): $tool -> $effect on $target" -ForegroundColor Yellow
    Write-Host "    First Seen: $first" -ForegroundColor Gray
    Write-Host "    Last Seen:  $last" -ForegroundColor Gray
    Write-Host "    Reason:     $($g.Group[0].reason)" -ForegroundColor DarkGray
    
    # List IDs for review
    $ids = $g.Group.intent_id -join ", "
    Write-Host "    IDs:        $ids" -ForegroundColor White
    Write-Host ""
}

Write-Host "To Review:" -ForegroundColor Cyan
Write-Host "  pwsh .\Axis_Agency_Review.ps1 -Id <IntentID> -Decision Allow/Deny" -ForegroundColor Gray
