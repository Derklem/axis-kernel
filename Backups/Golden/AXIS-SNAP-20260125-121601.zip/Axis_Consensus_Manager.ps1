<#
.SYNOPSIS
    Phase 120 - Federation Consensus Manager (Reconciliation Loop)
.DESCRIPTION
    Processes Treaty Packets in the Autonomy Inbox.
    Attempts to synchronize remote amendments into the local doctrine.
#>

param(
    [string] $AutonomyInboxPath = "D:\Infinite\Infinity\Autonomy\Autonomy_Requests_Inbox.json",
    [string] $TreatyLedgerPath = "D:\Infinite\Infinity\Governance\Treaty_Ledger.json",
    [string] $DoctrineRulesPath = "D:\Infinite\Infinity\Doctrine\Doctrine_Rules.json"
)

$ErrorActionPreference = "Stop"

function Invoke-ConsensusReconciliation {
    if (-not (Test-Path $AutonomyInboxPath)) { return }
    if (-not (Test-Path $TreatyLedgerPath)) { return }

    $inbox = Get-Content $AutonomyInboxPath -Raw | ConvertFrom-Json
    $ledger = Get-Content $TreatyLedgerPath -Raw | ConvertFrom-Json
    
    # Filter for treaty proposals
    $items = if ($inbox.items) { @($inbox.items) } else { @() }
    $treatyItems = $items | Where-Object { $_.type -eq "treaty_proposal" -and $_.status -eq "pending" }
    
    if ($treatyItems.Count -eq 0) { return }

    foreach ($item in $treatyItems) {
        $ruleId = $item.details.rule_id
        Write-Host "[RECONCILE] Processing Treaty: $ruleId" -ForegroundColor Cyan
        
        # 1. Verification / "Silent Sim"
        $passSim = $true 
        
        if ($passSim) {
            # 2. Update Ledger status
            $ledgerEntry = $ledger.treaties | Where-Object { $_.rule_id -eq $ruleId -and $_.status -eq "pending_consensus" }
            if ($ledgerEntry) {
                $ledgerEntry.status = "synchronized"
                if (-not $ledgerEntry.PSObject.Properties.Match('reconciled_at').Count) {
                    $ledgerEntry | Add-Member -NotePropertyName reconciled_at -NotePropertyValue ((Get-Date).ToUniversalTime().ToString("o")) -Force
                }
                else {
                    $ledgerEntry.reconciled_at = (Get-Date).ToUniversalTime().ToString("o")
                }
            }

            # 3. Mark Inbox item as handled
            $item.status = "resolved"
            if (-not $item.PSObject.Properties.Match('resolution').Count) {
                $item | Add-Member -NotePropertyName resolution -NotePropertyValue "synchronized" -Force
            }
            else {
                $item.resolution = "synchronized"
            }
            
            Write-Host "[RECONCILE] $ruleId synchronized successfully." -ForegroundColor Green
        }
        else {
            # Dissonance
            $ledgerEntry.status = "dissonance"
            $item.status = "failed"
            Write-Host "[RECONCILE] $ruleId rejected. Dissonance logged." -ForegroundColor Red
        }
    }

    # Save changes
    $ledger | ConvertTo-Json -Depth 20 | Set-Content $TreatyLedgerPath -Encoding UTF8
    $inbox | ConvertTo-Json -Depth 20 | Set-Content $AutonomyInboxPath -Encoding UTF8
}

if ($MyInvocation.PSScriptRoot -ne "") {
    Invoke-ConsensusReconciliation
}
