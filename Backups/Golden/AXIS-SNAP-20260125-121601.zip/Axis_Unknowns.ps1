# Axis_Unknowns.ps1
# Phase 153: Unknowns Engine
# "The Explorer."

$root = "D:\Infinite\Infinity"
$hypPath = Join-Path $root "Hypothesis_Queue.json"
$reportPath = Join-Path $root "Unknowns_Report.json"

function New-UnknownsReport {
    Write-Host "[UNKNOWNS] Mapping Blind Spots..." -ForegroundColor Cyan

    $blindSpots = @()

    # 1. Check Hypothesis Queue
    if (Test-Path $hypPath) {
        try {
            $q = Get-Content $hypPath -Raw | ConvertFrom-Json
            if ($q.hypotheses) {
                foreach ($h in $q.hypotheses) {
                    if ($h.status -eq "open") {
                        $blindSpots += @{
                            type     = "hypothesis"
                            id       = $h.id
                            desc     = $h.question
                            priority = $h.priority
                        }
                    }
                }
            }
        }
        catch {}
    }

    # 2. Check for "Unknown" errors in recent logs (Stub)
    # Ideally checking Axis_Events.json for "unhandled_exception"

    $report = @{
        version      = 1
        generated_at = (Get-Date).ToUniversalTime().ToString("o")
        count        = $blindSpots.Count
        blind_spots  = $blindSpots
    }

    $report | ConvertTo-Json -Depth 5 | Set-Content $reportPath -Encoding UTF8
    Write-Host "Unknowns Mapped: $($blindSpots.Count)" -ForegroundColor Green
    return $report
}

# Export-ModuleMember -Function New-UnknownsReport
