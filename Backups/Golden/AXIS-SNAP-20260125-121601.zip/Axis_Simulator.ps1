<#
.SYNOPSIS
    Axis Simulator (v2.0)
    Runs Axis Sovereign components in a sandboxed environment ($env:AXIS_ROOT)
    to test scenarios without affecting production data.
    Supports structured checking against Events_Timeline.json.
.DESCRIPTION
    1. Sets $env:AXIS_ROOT to D:\infinite\Sim
    2. Cleans/Prepares Sim Directory.
    3. Seeds data from Scenario JSON (Requests, RF, Intents).
    4. Runs Axis_Mind.ps1 and Earth_Server.ps1 (Once).
    5. Validates outputs (Logs + Timeline Events).
.PARAMETER ScenarioFile
    Path to the JSON scenario file.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$ScenarioFile
)

$ProdRoot = "D:\infinite"
$SimRoot = "D:\infinite\Sim"

Write-Host "--- AXIS SIMULATOR v2.0 ---" -ForegroundColor Cyan
Write-Host "Scenario: $ScenarioFile" -ForegroundColor Gray

# 1. Load Scenario
if (-not (Test-Path $ScenarioFile)) { throw "Scenario file not found: $ScenarioFile" }
$scenario = Get-Content $ScenarioFile -Raw -Encoding UTF8 | ConvertFrom-Json

# 2. Prepare Sandbox
Write-Host "[1/5] Preparing Sandbox at $SimRoot..." -ForegroundColor Green
$env:AXIS_ROOT = $SimRoot
$env:AXIS_MODE = "sim"

if (Test-Path $SimRoot) { Remove-Item $SimRoot -Recurse -Force | Out-Null }
New-Item -ItemType Directory -Path "$SimRoot\Infinity\Earth" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Infinity\RF" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Infinity\UI_Inbox" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Mind_Prompts" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Retina" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Infinity\Outreach\Reports" -Force | Out-Null
New-Item -ItemType Directory -Path "$SimRoot\Infinity\Outreach\Drafts" -Force | Out-Null

# 3. Mirror Configurations (Production -> Sim)
Write-Host "[2/5] Mirroring Production Configs..."
Copy-Item "$ProdRoot\Infinity\Tool_Registry.json" "$SimRoot\Infinity\Tool_Registry.json"
Copy-Item "$ProdRoot\Axis_Config.json" "$SimRoot\Axis_Config.json" -ErrorAction SilentlyContinue
Copy-Item "$ProdRoot\Infinity\Autonomy_Contract.json" "$SimRoot\Infinity\Autonomy_Contract.json" -ErrorAction SilentlyContinue
Copy-Item "$ProdRoot\Sim_Engine.ps1" "$SimRoot\Sim_Engine.ps1" -ErrorAction SilentlyContinue

# 4. Seed Scenario Data
Write-Host "[3/5] Seeding Scenario Data..."

# Seed: Requests Queue
if ($scenario.seed.requests) {
    $q = @{ version = 1; requests = $scenario.seed.requests }
    $q | ConvertTo-Json -Depth 10 | Set-Content "$SimRoot\Infinity\Earth\Requests_Queue.json" -Encoding UTF8
}

# Seed: Intent Queue
if ($scenario.seed.intents) {
    $iq = @{ version = 1; intents = $scenario.seed.intents }
    $iq | ConvertTo-Json -Depth 10 | Set-Content "$SimRoot\Infinity\Intent_Queue.json" -Encoding UTF8
}

# Seed: RF History (Corrected Path: Infinity\RF\RF_History.jsonl OR Infinity\RF_History.jsonl depending on Prod)
# Checking Prod Ref: Earth_Server uses "Infinity\RF_History.jsonl" (Line 330 in refactor). 
# Wait, user prompt said "If prod actually is Infinity\RF_History.jsonl, then keep it".
# My refactor Step 1573 used `Get-AxisPath "Infinity\RF_History.jsonl"`.
# So it IS at the root of Infinity, NOT in RF subdir?
# Let's verify Earth_Server line 330 from Step 1573 diff...
# `+ $rfLogPath = Get-AxisPath "Infinity\RF_History.jsonl"`
# So checking explicitly.
# HOWEVER, the USER explicitly asked to "Align RF file paths with production... If production uses Infinity\RF\RF_History.jsonl..."
# Sim consistency is key. I will stick to what Earth_Server uses: `Infinity\RF_History.jsonl`.
# Actually, wait. I should double check where Earth_Server thinks it is.
# Ref Step 1591: `$devPath = Get-AxisPath "Infinity\RF\RF_Devices.json"`.
# But `net_rf_scan` log path (Step 1573) is `Infinity\RF_History.jsonl`.
# So they are in different places? Log is in Infinity root, Devices in RF subdir?
# This seems inconsistent but that's what the code says.
# I will write RF History to `Infinity\RF_History.jsonl` to match Earth_Server.
if ($scenario.seed.rf_history) {
    foreach ($row in $scenario.seed.rf_history) {
        $row | ConvertTo-Json -Compress | Add-Content "$SimRoot\Infinity\RF_History.jsonl" -Encoding UTF8
    }
}

# 5. Execute Core Components
Write-Host "[4/5] Executing Core Loop (Simulated)..."

# Run Mind (One Pass)
Write-Host "  > Running Axis_Mind.ps1..."
& "D:\infinite\Axis_Mind.ps1" | Out-Null

# Run Earth (One Pass)
Write-Host "  > Running Earth_Server.ps1 (-Once)..."
& "D:\infinite\Earth_Server.ps1" -Once | Out-Null


# 6. Validation (V2 - Structured)
Write-Host "[5/5] Validating Output..."
$failures = 0

# A) Load Timeline (Ground Truth)
$timelinePath = "$SimRoot\Infinity\Events_Timeline.json"
if (-not (Test-Path $timelinePath)) {
    @{ version = 1; events = @() } | ConvertTo-Json | Set-Content $timelinePath -Encoding UTF8
}
$timeline = Get-Content $timelinePath -Raw -Encoding UTF8 | ConvertFrom-Json

# B) Structured Event Checks
if ($scenario.expect.events -and $timeline) {
    foreach ($evExp in $scenario.expect.events) {
        $matches = $timeline.events | Where-Object {
            (-not $evExp.source -or $_.source -eq $evExp.source) -and
            (-not $evExp.type -or $_.type -eq $evExp.type)
        }

        $minCount = if ($evExp.min_count) { [int]$evExp.min_count } else { 1 }

        if ($matches.Count -lt $minCount) {
            Write-Host "  [FAIL] Expected at least $minCount event(s) of type '$($evExp.type)' from '$($evExp.source)'." -ForegroundColor Red
            $failures++
        }
        else {
            Write-Host "  [PASS] Found $($matches.Count) event(s) of type '$($evExp.type)' from '$($evExp.source)'." -ForegroundColor Green
        }
    }
}

if ($scenario.expect.forbid_events -and $timeline) {
    foreach ($f in $scenario.expect.forbid_events) {
        $matches = $timeline.events | Where-Object {
            (-not $f.source -or $_.source -eq $f.source) -and
            (-not $f.type -or $_.type -eq $f.type)
        }

        if ($matches.Count -gt 0) {
            Write-Host "  [FAIL] Forbidden event(s) found: type='$($f.type)' source='$($f.source)'." -ForegroundColor Red
            $failures++
        }
        else {
            Write-Host "  [PASS] No forbidden events of type '$($f.type)' from '$($f.source)'." -ForegroundColor Green
        }
    }
}

# C) Legacy Log Checks (with fail-fast)
if ($scenario.expect.earth_actions) {
    $earthLogPath = "$SimRoot\Infinity\Earth\Earth_Server.log"
    if (-not (Test-Path $earthLogPath)) {
        Write-Host "  [WARN] Earth_Server.log not found; skipping text matches." -ForegroundColor Yellow
        # Only fail if we expected matches? 
        # Actually if we expect matches, and log is missing, that's a fail.
        $failures++ 
    }
    else {
        $log = Get-Content $earthLogPath -Raw
        foreach ($exp in $scenario.expect.earth_actions) {
            if ($log -notmatch $exp.match) {
                Write-Host "  [FAIL] Expected log match: '$($exp.match)'" -ForegroundColor Red
                $failures++
            }
            else {
                Write-Host "  [PASS] Log matched: '$($exp.match)'" -ForegroundColor Green
            }
        }
    }
}

if ($scenario.expect.mind_log) {
    $mindLogPath = "$SimRoot\mind_log.txt"
    if (-not (Test-Path $mindLogPath)) {
        Write-Host "  [WARN] mind_log.txt not found!" -ForegroundColor Yellow
        $failures++
    }
    else {
        $mlog = Get-Content $mindLogPath -Raw
        foreach ($m in $scenario.expect.mind_log) {
            if ($mlog -notmatch $m) {
                Write-Host "  [FAIL] Mind log missing: '$m'" -ForegroundColor Red
                $failures++
            }
            else {
                Write-Host "  [PASS] Mind log matched: '$m'" -ForegroundColor Green
            }
        }
    }
}

if ($failures -eq 0) {
    Write-Host "SIMULATION SUCCESS" -ForegroundColor Green
}
else {
    Write-Host "SIMULATION FAILED ($failures errors)" -ForegroundColor Red
}
