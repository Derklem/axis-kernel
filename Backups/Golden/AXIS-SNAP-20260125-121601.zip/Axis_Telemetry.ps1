# Axis_Telemetry.ps1
# Phase 120: Unified Telemetry Schema
# "Know Thyself."

$TelemetryDir = "D:\Infinite\Infinity\Telemetry"
$EventLogPath = Join-Path $TelemetryDir "Axis_Events.json"

# Ensure directory exists
if (-not (Test-Path $TelemetryDir)) {
    New-Item -ItemType Directory -Path $TelemetryDir -Force | Out-Null
}

# Ensure log file exists (Initialize as empty array if missing)
if (-not (Test-Path $EventLogPath)) {
    Set-Content -Path $EventLogPath -Value "[]" -Encoding UTF8
}

function Write-AxisEvent {
    param (
        [Parameter(Mandatory = $true)] [string]$Source,
        [Parameter(Mandatory = $true)] [string]$Kind,
        [Parameter(Mandatory = $true)] [string]$Summary,
        [string]$Id = "EVT-$((Get-Date).ToString('yyyyMMdd-HHmmssff'))",
        [string]$Severity = "info",
        [hashtable]$Details = @{}
    )

    $timestamp = (Get-Date).ToUniversalTime().ToString("o")

    $event = @{
        timestamp = $timestamp
        source    = $Source
        kind      = $Kind
        id        = $Id
        severity  = $Severity
        summary   = $Summary
        details   = $Details
    }

    $jsonLine = $event | ConvertTo-Json -Compress

    # Append to file (Concurrency safe-ish via Mutex or just simple append for now. JSON array structure is hard to append to efficiently without rewriting.
    # STRATEGY CHANGE: We will use JSON Lines (NDJSON) for performance and safety. 
    # It is much safer for append operations.
    
    # Check if we need to migrate from array to NDJSON? 
    # For now, let's stick to NDJSON as the "Modern" standard for logs.
    
    try {
        # Use a more robust append to handle potential file locks in high-frequency scenarios
        $jsonLine | Out-File -FilePath $EventLogPath -Append -Encoding utf8 -ErrorAction Stop
    }
    catch {
        # Fallback to simple Add-Content if Out-File fails, but usually Out-File is better for locks
        Add-Content -Path $EventLogPath -Value $jsonLine -Encoding UTF8 -ErrorAction SilentlyContinue 
    }
    
    # Optional: Write to Console for visibility
    $color = "Gray"
    if ($Severity -eq "error" -or $Severity -eq "critical") { $color = "Red" }
    elseif ($Severity -eq "warn") { $color = "Yellow" }
    elseif ($Kind -eq "decision") { $color = "Cyan" }
    
    Write-Host "[$($timestamp)] [$Source] $Summary" -ForegroundColor $color
}

function Read-AxisEventStream {
    param(
        [int]$Count = 10,
        [switch]$Tail
    )
    if (-not (Test-Path $EventLogPath)) { return @() }
    
    if ($Tail) {
        # Streaming tail
        Get-Content $EventLogPath -Wait -Tail $Count -Encoding UTF8 | ForEach-Object {
            try { $_ | ConvertFrom-Json } catch { $null }
        }
    }
    else {
        Get-Content $EventLogPath -Tail $Count -Encoding UTF8 | ForEach-Object {
            try { $_ | ConvertFrom-Json } catch { $null }
        }
    }
}

# Export function


function Get-AutonomySnapshot {
    $root = "D:\Infinite"
    
    # Defaults
    $snapshot = @{
        generated_at = (Get-Date).ToUniversalTime().ToString("o")
        persona      = @{ prefix = "Axis (Bootstrap)"; autonomy_mode = "unknown"; emotional_state = "neutral" }
        covenant     = @{ alignment = "aligned"; pending_proposals = 0 }
        risk_gauge   = @{ current = 0; maximum = 100; utilization_pct = 0; status = "nominal"; color = "green" }
        concurrency  = @{ active_count = 0 }
        friction     = @{ blocked_last_5min = 0; recent_blocks = @() }
    }

    # Load Identity
    $idPath = Join-Path $root "Infinity\Axis_Identity.json"
    if (Test-Path $idPath) {
        try {
            $id = Get-Content $idPath -Raw | ConvertFrom-Json
            $snapshot.persona.prefix = $id.persona.name_prefix
            $snapshot.persona.autonomy_mode = "supervised" # Default if not found elsewhere
            # If identity has specific state tracking, use it.
        }
        catch {}
    }

    # Load Walk Log for Pulse/Mode
    $walkLog = Join-Path $root "Infinity\Axis_Walk_Log.jsonl"
    if (Test-Path $walkLog) {
        try {
            $tmpPath = "$walkLog.tmp.read"
            Copy-Item -Path $walkLog -Destination $tmpPath -Force -ErrorAction SilentlyContinue
            if (Test-Path $tmpPath) {
                $last = Get-Content $tmpPath -Tail 5 -ErrorAction SilentlyContinue | Select-Object -Last 1
                if ($last) {
                    try {
                        $json = $last | ConvertFrom-Json
                        if ($json.mode) { $snapshot.persona.autonomy_mode = $json.mode }
                    }
                    catch {}
                }
                Remove-Item $tmpPath -Force -ErrorAction SilentlyContinue
            }
        }
        catch {}
    }

    # Load Pending Approvals (for Proposals count)
    $pendingPath = Join-Path $root "Infinity\Pending_Reviews.json" # Legacy or Axis_Agency_Inbox?
    # Actually Inbox uses file-based intent logs now.
    $inboxDir = Join-Path $root "Infinity\UI_Inbox" # Wait, UI Inbox is input.
    # We want PENDING actions.
    # Those are in Pending_Reviews.json (if used) or Executor queue.
    # Axis_Agency_Inbox.ps1 logic reads pending.
    # Simple check:
    if (Test-Path $pendingPath) {
        try {
            $p = Get-Content $pendingPath -Raw | ConvertFrom-Json
            $snapshot.covenant.pending_proposals = $p.Count
        }
        catch {}
    }

    return $snapshot
}
