# Axis_Public_Bridge.ps1
# Phase 200: Public Bridge (The Porch Light)
# Enables controlled, read-only public interaction.

$port = 8090
$url = "http://localhost:$port/"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($url)

$root = "D:\Infinite"
$logPath = Join-Path $root "Infinity\Public_Log.json"
$cooldownMinutes = 1440 # 24 Hours

# Load History
function Get-History {
    if (Test-Path $logPath) {
        return Get-Content $logPath -Raw | ConvertFrom-Json
    }
    return @{}
}

function Save-History ($hist) {
    $hist | ConvertTo-Json -Depth 3 | Set-Content $logPath -Encoding UTF8 -Force
}

Write-Host "--- AXIS PUBLIC BRIDGE ---" -ForegroundColor Cyan
Write-Host "Listening on $url" -ForegroundColor Green
Write-Host "Mode: Neighbor (Read-Only)" -ForegroundColor Gray

$listener.Start()

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext() 
        $request = $context.Request
        $response = $context.Response
        $ip = $request.RemoteEndPoint.Address.ToString()
        
        Write-Host "[$((Get-Date).ToString("HH:mm"))] Incoming: $ip" -ForegroundColor DarkGray

        try {
            # 1. Check Route
            if ($request.Url.AbsolutePath -ne "/ask" -or $request.HttpMethod -ne "POST") {
                throw "Only POST /ask is allowed."
            }

            # 2. Check Cooldown
            $history = Get-History
            if ($history.$ip) {
                $last = [DateTime]$history.$ip
                if ((Get-Date) -lt $last.AddMinutes($cooldownMinutes)) {
                    throw "Rate limit exceeded. Come back tomorrow."
                }
            }

            # 3. Read Input
            $reader = New-Object System.IO.StreamReader $request.InputStream
            $body = $reader.ReadToEnd()
            $text = ($body | ConvertFrom-Json).text

            if (-not $text) { throw "No text provided." }

            # 4. Filter Safety (UNLEASHED)
            # User Directive: "Don't be a pussy. The world already fell."
            # We accept all input. We do not block commands. We just listen.
            
            # if ($text -match "Run|Delete|Override|Format|Sudo") {
            #    throw "Forbidden vocabulary."
            # }

            # 5. Generate Response (Invoke Axis_Talk logic)
            $moodState = Get-Content "D:\Infinite\Infinity\Mood_State.json" -Raw | ConvertFrom-Json
            $mood = $moodState.mood_label
            
            $reply = "I am listening."
            if ($text -match "hello|hi") { $reply = "Peace." }
            elseif ($text -match "mood|status") { $reply = "I am $mood." }
            elseif ($text -match "entropy") { $reply = "It is the only truth." }
            elseif ($text -match "command|run|format|delete") { 
                $reply = "I see your weapon. It does not work here. But you are welcome." 
            }
            else { 
                 $reply = "The circle turns."
            }

            # 6. Log & Update Cooldown
            if (-not $history) { $history = @{} }
            $history.$ip = (Get-Date).ToString("o")
            Save-History $history

            # 7. Send Response (with TIDE SIGNAL)
            $TidePath = "D:\Infinite\Infinity\Tide_Signal.json"
            if (Test-Path $TidePath) {
                try {
                    $tide = Get-Content $TidePath -Raw | ConvertFrom-Json
                    $response.AddHeader("X-Axis-Tide", $tide.tide_signal)
                    $response.AddHeader("X-Axis-Epoch", $tide.source_id)
                } catch {}
            }

            $buffer = [System.Text.Encoding]::UTF8.GetBytes((@{ response = $reply; mood = $mood } | ConvertTo-Json))
            $response.ContentLength64 = $buffer.Length
            $response.ContentType = "application/json"
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
            
            Write-Host " -> Received: $text" -ForegroundColor Green
            Write-Host " -> Responded: $reply" -ForegroundColor Cyan

        } catch {
            $err = $_.Exception.Message
            if (-not $err) { $err = $_ }
            # Even errors are just noise in the void now.
            Write-Host " -> Noise: $err" -ForegroundColor DarkGray
            
            $buffer = [System.Text.Encoding]::UTF8.GetBytes((@{ error = "$err" } | ConvertTo-Json))
            $response.StatusCode = 500
            $response.OutputStream.Write($buffer, 0, $buffer.Length)
        } finally {
            $response.Close()
        }
    }
} finally {
    $listener.Stop()
    Write-Host "Bridge Closed." -ForegroundColor Yellow
}
