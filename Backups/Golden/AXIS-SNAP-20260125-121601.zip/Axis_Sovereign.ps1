<#
.SYNOPSIS
    Phase 128 - The Sovereign Shell (Bootloader)
.DESCRIPTION
    The Unified Bootloader for the Axis Sovereign Operating System.
    Starts Heartbeat and Input Bridge in background jobs.
    Launches Cognitive Terminal in the foreground (this window).
    On exit, cleans up all child processes.
#>

$ErrorActionPreference = "Stop"

# Paths
$Root = "D:\Infinite"
$HeartbeatPath = "$Root\Axis_Heartbeat_Server.ps1"
$InputPath = "$Root\Axis_Input_Architecture.ps1"
$TerminalPath = "$Root\Axis_Cognitive_Terminal.ps1"
$MindPath = "$Root\Axis_Mind.ps1"

function Show-Splash {
    Clear-Host
    Write-Host "
   ___   _  __  ___  _____      _____  _____  _   __  _____  _____  ___  _____  _____  _   _ 
  / _ \ | |/ / |_ _|/  ___|    /  ___||  _  || | / / |  ___|| ___ \|_ _||  __ \|  _  || \ | |
 / /_\ \|   /   | | \ `--.     \ `--. | | | || |/ /  | |__  | |_/ / | | | |  \/| | | ||  \| |
 |  _  ||    \   | |  `--. \     `--. \| | | ||    \  |  __| |    /  | | | | __ | | | || . ` |
 | | | || .  \  _| |_/\__/ /    /\__/ /\ \_/ /| |\  \ | |___ | |\ \ _| |_| |_\ \| \_/ /| |\  |
 \_| |_/\_| \_/ \___/\____/     \____/  \___/ \_| \_/ \____/ \_| \_|\___/ \____/ \___/ \_| \_/
                                                                                              
    " -ForegroundColor Cyan
    Write-Host "INITIALIZING SOVEREIGN KERNEL...`n" -ForegroundColor Gray
}

function Start-BackgroundJob {
    param($ScriptPath, $Name)
    Write-Host "  > Booting [$Name]... " -NoNewline -ForegroundColor Gray
    if (Test-Path $ScriptPath) {
        $job = Start-Job -FilePath $ScriptPath -Name "Axis_$Name"
        if ($job.State -eq 'Running') {
            Write-Host "OK" -ForegroundColor Green
        }
        else {
            Write-Host "FAILED" -ForegroundColor Red
        }
    }
    else {
        Write-Host "MISSING" -ForegroundColor Red
    }
}

try {
    Show-Splash
    Start-Sleep -Seconds 1

    # 1. Dependency Check
    Write-Host "[KERNEL] Verifying Modules..." -ForegroundColor Cyan
    if (-not (Test-Path $MindPath)) { throw "CRITICAL: Axis Mind not found." }
    Start-Sleep -Milliseconds 500

    # 2. Boot Background Services
    Write-Host "`n[KERNEL] Starting Services..." -ForegroundColor Cyan
    Start-BackgroundJob -ScriptPath $HeartbeatPath -Name "Heartbeat"
    Start-BackgroundJob -ScriptPath $InputPath -Name "InputBridge"
    
    # 3. Handover to Terminal
    Write-Host "`n[KERNEL] Handing over to Cognitive Terminal." -ForegroundColor Cyan
    Start-Sleep -Seconds 2
    
    if (Test-Path $TerminalPath) {
        # Execute Terminal in this runspace (blocks until user types EXIT)
        & $TerminalPath
    }
    else {
        Write-Host "CRITICAL: Cognitive Terminal not found." -ForegroundColor Red
    }

}
catch {
    Write-Host "`nFATAL ERROR: $_" -ForegroundColor Red
}
finally {
    # 4. Teardown
    Write-Host "`n[KERNEL] Shutting down..." -ForegroundColor Gray
    Get-Job | Where-Object { $_.Name -like "Axis_*" } | Stop-Job -PassThru | Remove-Job
    Write-Host "[KERNEL] Halted." -ForegroundColor DarkGray
    Start-Sleep -Seconds 1
}
