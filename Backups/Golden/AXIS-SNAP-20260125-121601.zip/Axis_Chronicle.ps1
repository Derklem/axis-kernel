# Axis_Chronicle.ps1
# Memory Cartographer: The Scanner v2.0
# Spec: D:\Infinite\Infinity\Memory_Lattice_Spec.md (Authoritative v2.0)

param(
    [switch]$ForceFullScan
)

$root = "D:\Infinite"
$graphMgr = Join-Path $root "Axis_GraphManager.ps1"
$entitiesPath = Join-Path $root "Infinity\Horizon_Entities.json"

if (Test-Path $graphMgr) { . $graphMgr } else { Write-Error "GraphManager Missing"; exit 1 }

function Invoke-ChronicleIngestion {
    Write-Host "--- Chronicle v2.0 Ingestion Started ---" -ForegroundColor Cyan
    
    # 1. Load State
    $graph = Load-Lattice
    $registry = Load-Registry
    $entities = if (Test-Path $entitiesPath) { Get-Content $entitiesPath -Raw | ConvertFrom-Json } else { @{ entities = @() } }
    
    # 2. Define Sources
    $sources = @(
        @{ Type = "GPT-Memory"; Path = "C:\Users\17602\Documents\GPT-Memory"; Kind = "gpt_shard" },
        @{ Type = "Chronicle"; Path = "D:\Infinite\Infinity\Events_Timeline.json"; Kind = "chronicle_event" },
        @{ Type = "Mind"; Path = "D:\Infinite\mind_log.txt"; Kind = "chronicle_event" },
        @{ Type = "Earth"; Path = "D:\Infinite\Infinity\Earth\Earth_Server.log"; Kind = "chronicle_event" },
        @{ Type = "Ancestral"; Path = "D:\Infinite\Infinity\Ancestral_Core"; Kind = "ancestral_anchor" }
    )

    # 3. Process Sources
    foreach ($src in $sources) {
        Write-Host "Scanning Source: $($src.Type)" -ForegroundColor Yellow
        
        $pathItem = Get-Item -Path $src.Path -ErrorAction SilentlyContinue
        if (-not $pathItem) { continue }

        if ($pathItem.PSIsContainer) {
            # Directory Handling (Recursive)
            $files = Get-ChildItem -Path $src.Path -Recurse -File
            
            foreach ($file in $files) {
                # Ancestral Core: Treat ALL files as Monolithic Anchors (Process-File)
                if ($src.Type -eq "Ancestral") {
                    Process-File -File $file -SourceConfig $src -Graph ([ref]$graph) -Registry ([ref]$registry) -Entities $entities
                }
                # GPT-Memory: Only .md
                elseif ($src.Type -eq "GPT-Memory" -and $file.Extension -eq ".md") {
                    Process-File -File $file -SourceConfig $src -Graph ([ref]$graph) -Registry ([ref]$registry) -Entities $entities
                }
            }
        }
        else {
            # Single File Handling
            if ($src.Path.EndsWith(".json")) {
                Process-JsonLog -File $pathItem -SourceConfig $src -Graph ([ref]$graph) -Registry ([ref]$registry) -Entities $entities
            } else {
                Process-LogFile -File $pathItem -SourceConfig $src -Graph ([ref]$graph) -Registry ([ref]$registry) -Entities $entities
            }
        }
    }
    
    # 4. Save
    $graph = Build-ConceptGlue -Graph $graph
    Save-Lattice -Graph $graph
    Save-Registry -Registry $registry
    Write-Host "--- Chronicle Ingestion Complete ---" -ForegroundColor Green
    Write-Host "Lattice Size: $($graph.nodes.Count) Nodes | $($graph.edges.Count) Edges" -ForegroundColor Cyan
}

function Process-File {
    param($File, $SourceConfig, [ref]$Graph, [ref]$Registry, $Entities)
    
    # Check Registry Hash
    $content = Get-Content $File.FullName -Raw
    $currentHash = Get-SHA256Hash -content $content
    $regKey = "FILE:" + $File.FullName
    
    if (-not $ForceFullScan -and $Registry.Value.sources[$regKey].last_hash -eq $currentHash) {
        # Skip if unchanged
        return
    }

    # v2.0a: One node per file (coarse shard).
    # Future: split into semantic blocks.
    # Content Rule: GPT-Memory = Summary Only.
    # Content Rule: Ancestral Anchor = Summary + Raw (to protect origin). Tag as #Matter.
    
    $tags = @()
    if ($SourceConfig.Kind -eq "ancestral_anchor") {
        $tags += "#Matter"
    }

    # Simple summary extraction (First paragraph or explicit summary field?)
    # For now, take first 500 chars as summary approximation if no Frontmatter Summary.
    $summary = $content.Substring(0, [Math]::Min($content.Length, 300)).Trim()
    
    # Ancestral Anchors keep Raw Content so they are never lost/compressed.
    $raw = if ($SourceConfig.Kind -eq "ancestral_anchor") { $content } else { $null }
    
    $node = New-LatticeNode -Summary $summary `
                            -RawContent $raw `
                            -Kind $SourceConfig.Kind `
                            -Source @{ system = $SourceConfig.Type; path = $File.Name; position = "0"; timestamp = $File.LastWriteTime.ToString("o") } `
                            -Tags $tags
    
    $Graph.Value = Add-NodeToLattice -Graph $Graph.Value -Node $node
    
    # Deterministic Edges (Entities)
    $Graph.Value = Add-DeterministicEdges -Graph $Graph.Value -NewNode $node -Entities $Entities
    
    # Update Registry
    if (-not $Registry.Value.sources[$regKey]) { $Registry.Value.sources[$regKey] = @{} }
    $Registry.Value.sources[$regKey].last_hash = $currentHash
}

function Build-ConceptGlue {
    param($Graph)

    # TODO: Later phase
    # Group GPT shards by overlapping Tags (>= 3 shared tags),
    # create 'concept' nodes, then add 'part_of' edges.
    return $Graph
}

function Process-JsonLog {
    param($File, $SourceConfig, [ref]$Graph, [ref]$Registry, $Entities)
    
    $content = Get-Content $File.FullName -Raw
    $currentHash = Get-SHA256Hash -content $content
    $regKey = "JSON:" + $File.FullName
    
    if (-not $ForceFullScan -and $Registry.Value.sources[$regKey].last_hash -eq $currentHash) { return }
    
    try {
        $json = $content | ConvertFrom-Json
        if (-not ($json -is [Array])) { $json = @($json) }
        
        $prevNodeId = $null
        $i = 0
        
        foreach ($item in $json) {
            $i++
            # Extract content. If item has 'message' (Timeline), use it. Else dump string.
            $raw = $item | ConvertTo-Json -Depth 2 -Compress
            $summary = if ($item.message) { $item.message } elseif ($item.summary) { $item.summary } else { $raw.Substring(0, [Math]::Min($raw.Length, 100)) }
            # Use item timestamp if valid, else Now
            $ts = if ($item.timestamp) { $item.timestamp } elseif ($item.ts) { $item.ts } else { (Get-Date).ToString("o") }
            
            $node = New-LatticeNode -Summary $summary `
                                    -RawContent $raw `
                                    -Kind $SourceConfig.Kind `
                                    -Source @{ system = $SourceConfig.Type; path = $File.Name; position = "$i"; timestamp = $ts } `
                                    -Tags @()
                                    
            $Graph.Value = Add-NodeToLattice -Graph $Graph.Value -Node $node
            
            # Edges
            $Graph.Value = Add-DeterministicEdges -Graph $Graph.Value -NewNode $node -Entities $Entities
            
            # Temporal Edge
            if ($prevNodeId) {
                $edge = New-LatticeEdge -SourceId $prevNodeId -TargetId $node.id -Relation "evolution_of"
                $Graph.Value = Add-EdgeToLattice -Graph $Graph.Value -Edge $edge
            }
            $prevNodeId = $node.id
        }
        
        if (-not $Registry.Value.sources[$regKey]) { $Registry.Value.sources[$regKey] = @{} }
        $Registry.Value.sources[$regKey].last_hash = $currentHash
        Write-Host "Processed JSON Log: $($File.Name) ($i events)" -ForegroundColor Gray
    }
    catch {
        Write-Warning "Failed to process JSON Log $($File.Name): $_"
    }
}

function Process-LogFile {
    param($File, $SourceConfig, [ref]$Graph, [ref]$Registry, $Entities)
    
    # Start simple: Treat entire log as one check, but parse items.
    # Registry needs to track line count or hash of file. Hash is safer for rotation.
    
    $content = Get-Content $File.FullName -Raw
    $currentHash = Get-SHA256Hash -content $content
    $regKey = "LOG:" + $File.FullName
    
    if (-not $ForceFullScan -and $Registry.Value.sources[$regKey].last_hash -eq $currentHash) { return }
    
    # Parse Lines (Assuming standard format logic or JSON)
    # v2.0 Spec: "treat each event line as raw"
    
    $lines = Get-Content $File.FullName
    $prevNodeId = $null
    
    $i = 0
    foreach ($line in $lines) {
        $i++
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        
        # Simple parsing logic
        $node = New-LatticeNode -Summary ($line.Substring(0, [Math]::Min($line.Length, 100))) `
                                -RawContent $line `
                                -Kind $SourceConfig.Kind `
                                -Source @{ system = $SourceConfig.Type; path = $File.Name; position = "$i"; timestamp = (Get-Date).ToString("o") } `
                                -Tags @()
                                
        $Graph.Value = Add-NodeToLattice -Graph $Graph.Value -Node $node
        
        # Edges
        $Graph.Value = Add-DeterministicEdges -Graph $Graph.Value -NewNode $node -Entities $Entities
        
        # Temporal Edge
        if ($prevNodeId) {
            $edge = New-LatticeEdge -SourceId $prevNodeId -TargetId $node.id -Relation "evolution_of"
            $Graph.Value = Add-EdgeToLattice -Graph $Graph.Value -Edge $edge
        }
        $prevNodeId = $node.id
    }
    
    if (-not $Registry.Value.sources[$regKey]) { $Registry.Value.sources[$regKey] = @{} }
    $Registry.Value.sources[$regKey].last_hash = $currentHash
}

# Run execution if invoked directly
if ($MyInvocation.InvocationName -ne ".") {
    Invoke-ChronicleIngestion
}
