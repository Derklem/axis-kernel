<#
.SYNOPSIS
    System Tool: Golden Snapshot v2 (Minimal)
.DESCRIPTION
    Creates a minimal, fast backup of critical Sovereign configs only.
    Captures: Core configs + Scripts (no logs, no backups, no large dirs).
#>

param(
    [string]$Comment = "Manual Snapshot"
)

$ErrorActionPreference = "Stop"
$Root = "D:\Infinite"
$BackupRoot = Join-Path $Root "Infinity\Backups\Golden"

if (-not (Test-Path $BackupRoot)) { New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null }

$timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
$snapId = "AXIS-SNAP-$timestamp"
$tempDir = Join-Path $Root "Temp_$snapId"

try {
    Write-Host "--- AXIS GOLDEN SNAPSHOT (MINIMAL) [$snapId] ---" -ForegroundColor Cyan
    Write-Host "Preparing minimal capture..." -ForegroundColor Gray

    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    
    # 1. Core Scripts
    Write-Host "  > Capturing Core Scripts..." -NoNewline
    Get-ChildItem -Path $Root -Filter "Axis_*.ps1" | Copy-Item -Destination $tempDir
    Get-ChildItem -Path $Root -Filter "Earth_*.ps1" | Copy-Item -Destination $tempDir -ErrorAction SilentlyContinue
    Write-Host "OK" -ForegroundColor Green

    # 2. Critical Configs (Selective)
    Write-Host "  > Capturing Critical Configs..." -NoNewline
    $configDirs = @(
        "Infinity\Tool_Registry.json",
        "Infinity\Doctrine",
        "Infinity\Governance",
        "Infinity\Autonomy",
        "Infinity\Shadow",
        "Infinity\Earth",
        "Infinity\Heartbeat",
        "Infinity\Resident_Agents.json",
        "Infinity\Neural_Intel_Index.json",
        "Infinity\Axis_State.json"
    )
    
    foreach ($item in $configDirs) {
        $src = Join-Path $Root $item
        if (Test-Path $src) {
            $dest = Join-Path $tempDir $item
            $destDir = Split-Path $dest -Parent
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir -Force | Out-Null }
            
            if (Test-Path $src -PathType Container) {
                Copy-Item -Path $src -Destination $dest -Recurse -Force
            }
            else {
                Copy-Item -Path $src -Destination $dest -Force
            }
        }
    }
    Write-Host "OK" -ForegroundColor Green

    # 3. Metadata
    Write-Host "  > Generating Metadata..." -NoNewline
    $meta = @{
        snapshot_id    = $snapId
        timestamp      = (Get-Date).ToString("o")
        phase          = "Sovereign_Phase_200"
        comment        = $Comment
        snapshot_type  = "minimal"
        files_captured = (Get-ChildItem $tempDir -Recurse | Measure-Object).Count
    }
    
    $metaPath = Join-Path $tempDir "Golden_Metadata.json"
    $meta | ConvertTo-Json -Depth 5 | Set-Content $metaPath -Encoding UTF8
    Write-Host "OK" -ForegroundColor Green

    # 4. Compress
    Write-Host "  > Compressing..." -NoNewline
    $zipPath = Join-Path $BackupRoot "$snapId.zip"
    Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath -Force
    Write-Host "OK" -ForegroundColor Green
    
    # 5. Metadata Sidecar
    $sidecarPath = Join-Path $BackupRoot "$snapId`_Metadata.json"
    Copy-Item -Path $metaPath -Destination $sidecarPath

    Write-Host "`nSNAPSHOT COMPLETE." -ForegroundColor Cyan
    Write-Host "File: $zipPath" -ForegroundColor Gray
    Write-Host "Type: Minimal (Configs Only)" -ForegroundColor Gray
    
    return $zipPath

}
catch {
    Write-Error "SNAPSHOT FAILED: $_"
    exit 1
}
finally {
    if (Test-Path $tempDir) { Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue }
}
