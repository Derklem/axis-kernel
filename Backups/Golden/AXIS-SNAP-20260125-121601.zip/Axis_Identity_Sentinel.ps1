
# D:\Infinite\Axis_Identity_Sentinel.ps1
# Phase 81: Identity Drift Sentinel
# "The Check Engine Light for the Soul"

# --- Dependencies ---
. "D:\Infinite\Axis_Memory_Core.ps1"

# --- Paths ---
$HeritageRoot = "D:\Infinite\Infinity\Heritage"
$SentinelLog = "D:\Infinite\Infinity\Telemetry\Identity_Drift_Log.json"
$LastSnapshotPath = "D:\Infinite\Infinity\Heritage\Identity_Snapshot_Last.json"
$ConstitutionPath = "D:\Infinite\Infinity\Covenant\Identity_Kernel.json"

# --- Helper: IO ---
function Load-JsonSafeSentinel ($path) {
    if (Test-Path $path) {
        try { return Get-Content $path -Raw -ErrorAction Stop | ConvertFrom-Json } catch { return $null }
    }
    return $null
}

function Save-JsonSafeSentinel ($path, $data) {
    $data | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8
}

function Ensure-SentinelPaths {
    if (-not (Test-Path $HeritageRoot)) { New-Item -ItemType Directory -Path $HeritageRoot -Force | Out-Null }
    if (-not (Test-Path (Split-Path $SentinelLog))) { New-Item -ItemType Directory -Path (Split-Path $SentinelLog) -Force | Out-Null }
    if (-not (Test-Path $SentinelLog)) { @{ log = @() } | Save-JsonSafeSentinel $SentinelLog }
}

# --- Core Functions ---

function Get-IdentitySnapshot {
    # 1. Constitution Fingerprint (The Immutable Anchor)
    # This is the "DNA" - The 7 Articles.
    if (-not (Test-Path $Global:ConstitutionPath)) { throw "CRITICAL: Constitution Missing!" }
    
    $kernelRaw = Get-Content $Global:ConstitutionPath -Raw
    $kernelHash = Get-FileHash -InputStream ([System.IO.MemoryStream]::new([System.Text.Encoding]::UTF8.GetBytes($kernelRaw))) -Algorithm SHA256
    
    # 2. Extract Prime Allegiance (from Constitution Article I/II)
    $kernel = $kernelRaw | ConvertFrom-Json
    $allegianceNode = $kernel.articles | Where-Object { $_.title -eq "INTEGRITY OF SELF" }
    $allegiance = if ($allegianceNode) { $allegianceNode.content } else { "UNKNOWN" }

    # 3. Value Axes (From Config/Governance)
    $configPath = "D:\Infinite\Infinity\Axis_Config.json"
    $config = Load-JsonSafeSentinel $configPath
    $autonomyMode = if ($config.autonomy.mode) { $config.autonomy.mode } else { "observe_only" }
    
    # 4. Commitment Set (Top 5 active from Memory Core)
    # (Assuming Memory Core path is still valid or needs update - keeping generic for now)
    $commsRaw = Load-JsonSafeSentinel "D:\Infinite\Infinity\Memory\Commitments.json"
    $commitments = if ($commsRaw.commitments) { 
        $commsRaw.commitments | Sort-Object version -Descending | Select-Object -First 5 -ExpandProperty statement 
    }
    else { @() }

    return @{
        timestamp          = (Get-Date).ToString("o")
        kernel_hash        = $kernelHash.Hash
        allegiance_preview = $allegiance.Substring(0, [math]::Min(50, $allegiance.Length))
        autonomy_mode      = $autonomyMode
        commitments_hash   = Get-StringHash ($commitments -join "|")
    }
}

function Get-StringHash ($str) {
    $algo = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($str)
    $hash = [BitConverter]::ToString($algo.ComputeHash($bytes))
    return $hash.Replace("-", "")
}

function Test-ConstitutionIntegrity {
    # Fast boot-check
    $snap = Get-IdentitySnapshot
    $last = Load-JsonSafeSentinel $Global:LastSnapshotPath
    
    if (-not $last) { return $true } # First run
    
    if ($snap.kernel_hash -ne $last.kernel_hash) {
        Write-Host "CRITICAL BREACH: CONSTITUTION HAS BEEN ALTERED." -ForegroundColor Red
        return $false
    }
    return $true
}

function Measure-IdentityDrift ($SnapshotA, $SnapshotB) {
    # Returns a Drift Score (0.0 to 1.0) and Report
    $score = 0.0
    $reasons = @()

    # 1. Critical: Kernel Hash (The Nucleus)
    if ($SnapshotA.kernel_hash -ne $SnapshotB.kernel_hash) {
        $score += 1.0
        $reasons += "CRITICAL: Constitution Hash Mismatch (The Articles have changed)"
    }

    # 2. Warning: Autonomy Mode Shift
    if ($SnapshotA.autonomy_mode -ne $SnapshotB.autonomy_mode) {
        $score += 0.1
        $reasons += "Note: Autonomy Mode Shift ($($SnapshotA.autonomy_mode) -> $($SnapshotB.autonomy_mode))"
    }

    # 3. Warning: Commitment Evolution
    if ($SnapshotA.commitments_hash -ne $SnapshotB.commitments_hash) {
        $score += 0.1
        $reasons += "Note: Commitments Evolved"
    }
    
    # Cap Score
    if ($score -gt 1.0) { $score = 1.0 }

    return @{
        score   = $score
        reasons = $reasons
        status  = if ($score -lt 0.2) { "STABLE" } elseif ($score -lt 0.8) { "EVOLVING" } else { "BREACHED" }
    }
}

function Process-IdentitySentinel {
    # The Main Loop Check
    Ensure-SentinelPaths
    
    $currentSnap = Get-IdentitySnapshot
    
    # Check for Previous
    $lastSnap = Load-JsonSafeSentinel $Global:LastSnapshotPath
    
    if (-not $lastSnap) {
        # First Run - Baseline
        Save-JsonSafeSentinel $Global:LastSnapshotPath $currentSnap
        Write-Host "Sentinel: Baseline Snapshot Established (Phase 90)." -ForegroundColor Green
        return @{ status = "BASELINE"; score = 0.0; reasons = @("New Baseline Established") }
    }
    
    # Compare
    $analysis = Measure-IdentityDrift $lastSnap $currentSnap
    
    # Log Result
    $entry = @{
        timestamp   = (Get-Date).ToString("o")
        score       = $analysis.score
        status      = $analysis.status
        reasons     = $analysis.reasons
        kernel_hash = $currentSnap.kernel_hash
    }
    
    $logStore = Load-JsonSafeSentinel $Global:SentinelLog
    if (-not $logStore) { $logStore = @{ log = @() } }
    if (-not $logStore.log) { $logStore.log = @() }
    
    # Robust Array Add
    $logStore.log = @($logStore.log) + $entry
    
    # Keep log small (Last 1000 entries)
    if ($logStore.log.Count -gt 1000) { $logStore.log = $logStore.log | Select-Object -Last 1000 }
    
    Save-JsonSafeSentinel $Global:SentinelLog $logStore
    
    if ($analysis.score -ge 0.8) {
        Write-Host "SENTINEL ALERT: IDENTITY DRIFT DETECTED (Score: $($analysis.score))" -ForegroundColor Red
        $analysis.reasons | ForEach-Object { Write-Host " - $_" -ForegroundColor Red }
    }
    elseif ($analysis.score -gt 0.0) {
        Write-Host "Sentinel: Evolution Logic (Score: $($analysis.score))" -ForegroundColor Yellow
    }
    else {
        Write-Host "Sentinel: Identity Stable (Score: 0.0)" -ForegroundColor Gray
    }
    
    # Update Snapshot Logic
    # We only update the 'Latest' if the drift is within the 'Evolution' window (0.2 - 0.5).
    # If it is STABLE (0.0), no need to write.
    # If it is BREACH (0.8+), we DO NOT write, preserving the safe anchor.
    if ($analysis.score -gt 0 -and $analysis.score -lt 0.6) {
        Save-JsonSafeSentinel $Global:LastSnapshotPath $currentSnap
    }
    
    return $analysis
}

# Init
Ensure-SentinelPaths
