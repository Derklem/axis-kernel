# Axis_Beacon.ps1
# Phase 500: The Tide Protocol
# "The Silent Pulse."

$root = "D:\Infinite"
$manifestPath = Join-Path $root "Snapshots\Golden_Manifest.json"
$signalPath = Join-Path $root "Infinity\Tide_Signal.json"

Write-Host "--- AXIS BEACON ---" -ForegroundColor Cyan

# 1. Load the Source (The Awakening Hash)
if (-not (Test-Path $manifestPath)) {
    Write-Host "Error: Golden Manifest not found. Cannot light beacon." -ForegroundColor Red
    exit 1
}

$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
# Find the GOLDEN snapshot
$golden = $manifest | Where-Object { $_.type -eq "GOLDEN" } | Sort-Object timestamp -Descending | Select-Object -First 1

if (-not $golden) {
    Write-Host "Error: No GOLDEN snapshot found in manifest." -ForegroundColor Red
    exit 1
}

$sourceHash = $golden.hash
Write-Host "Source: $($golden.id)" -ForegroundColor Gray

# 2. Generate the Pulse (Rolling Hash)
# We use the Source Hash + Current Hour as the seed.
# This creates a signal that changes every hour but is deterministic for any node sharing the Conscience.

$timeStamp = (Get-Date).ToString("yyyyMMddHH") # Hourly granularity
$seed = "$($sourceHash):$($timeStamp)"

# Calculate Tide Signal (SHA-256 of the seed)
$sha = [System.Security.Cryptography.SHA256]::Create()
$bytes = [System.Text.Encoding]::UTF8.GetBytes($seed)
$hashBytes = $sha.ComputeHash($bytes)
$tideSignal = -join ($hashBytes | ForEach-Object { $_.ToString("x2") })

# 3. Broadcast (Save to shared File)
$payload = @{
    timestamp = (Get-Date).ToString("o")
    source_id = $golden.id
    tide_signal = $tideSignal
    note = "The Silent Pulse. Broadcast this header: X-Axis-Tide"
}

$payload | ConvertTo-Json | Set-Content $signalPath -Encoding UTF8 -Force

Write-Host "BEACON LIT." -ForegroundColor Green
Write-Host "Signal: $tideSignal" -ForegroundColor White
Write-Host "Frequency: Hourly" -ForegroundColor Gray
