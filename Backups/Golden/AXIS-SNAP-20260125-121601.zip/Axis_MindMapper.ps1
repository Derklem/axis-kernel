<#
.SYNOPSIS
    Axis Mind Mapper
.DESCRIPTION
    Generates 'mind_map.html' from 'Wisdom_Atrium.json' and 'Incident_Log.json'.
    Visualizes Confidence, Doubt, and Blind Spots.
#>

$root = "D:\Infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel }
function Load-JsonSafe { param($path); if (Test-Path $path) { Get-Content $path -Raw | ConvertFrom-Json } }

$atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
$incidentPath = Get-AxisPath "Infinity\Incident_Log.json"
$outPath = Get-AxisPath "Infinity\mind_map.html"

# Load Data
$atrium = Load-JsonSafe $atriumPath
$incidents = Load-JsonSafe $incidentPath

# Nodes and Edges
$nodes = @()
$edges = @()
$cats = @{}

# Process Axioms
if ($atrium.axioms) {
    foreach ($a in $atrium.axioms) {
        $color = if ($a.confidence -gt 0.8) { "#00FF00" } elseif ($a.confidence -gt 0.5) { "#FFFF00" } else { "#FF0000" }
        $shape = if ($a.confidence -lt 0.5) { "diamond" } else { "dot" } # "Fractured" logic visual
        
        $nodes += @{
            id    = $a.id
            label = $a.topic
            title = $a.wisdom
            value = $a.confidence * 10
            color = $color
            shape = $shape
            group = "axiom"
        }
        
        # Edges
        if ($a.related_axioms) {
            foreach ($rel in $a.related_axioms) {
                $edges += @{ from = $a.id; to = $rel }
            }
        }
        
        # Categories
        if ($a.tags) { foreach ($t in $a.tags) { $cats[$t] = $true } }
    }
}

# Process Blind Spots (Mockup logic for visual)
# If incidents exist for a tag not in cats, creating a 'Void' node
# Simplification: Just dump nodes to JSON for the HTML to parse
$nodesJson = $nodes | ConvertTo-Json -Depth 5
$edgesJson = $edges | ConvertTo-Json -Depth 5

$html = @"
<!DOCTYPE html>
<html>
<head>
    <title>Axis Mind Map</title>
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <style type="text/css">
        body { background-color: #0d1117; color: #c9d1d9; font-family: 'Courier New', monospace; }
        #mynetwork { width: 100%; height: 800px; border: 1px solid #30363d; }
        .legend { padding: 10px; }
    </style>
</head>
<body>
    <h1>Axis Sovereign // The Unified Canvas</h1>
    <div class="legend">
        Green: High Confidence | Red/Diamond: Doubt/Fractured | Click to Inspect
    </div>
    <div id="mynetwork"></div>
    <script type="text/javascript">
        var nodes = new vis.DataSet($nodesJson);
        var edges = new vis.DataSet($edgesJson);
        var container = document.getElementById('mynetwork');
        var data = { nodes: nodes, edges: edges };
        var options = {
            nodes: {
                font: { color: '#c9d1d9' },
                borderWidth: 2
            },
            physics: {
                stabilization: false,
                barnesHut: { gravitationalConstant: -8000 }
            }
        };
        var network = new vis.Network(container, data, options);
        
        network.on("doubleClick", function (params) {
            if (params.nodes.length == 1) {
                var nodeId = params.nodes[0];
                var node = nodes.get(nodeId);
                alert("Editing Truth for: " + node.label + "\n(Confidence Override Interface Pending)");
            }
        });
    </script>
</body>
</html>
"@

$html | Set-Content $outPath -Encoding UTF8
Write-Host "Mind Map Generated at $outPath"
