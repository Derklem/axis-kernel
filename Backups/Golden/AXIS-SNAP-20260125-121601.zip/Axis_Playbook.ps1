# Axis_Playbook.ps1
# Phase 86: Playbook Engine
# Orchestrates multi-step procedures with granular autonomy gating.

$Script:InfinityRoot = "D:\Infinite"
$Script:PlaybookDir = "$Script:InfinityRoot\Infinity\Playbooks"
$Script:ActivePlaybookState = $null

# Load Dependencies
if (Test-Path "$Script:InfinityRoot\Axis_AutonomyGate.ps1") {
    . "$Script:InfinityRoot\Axis_AutonomyGate.ps1"
}
if (Test-Path "$Script:InfinityRoot\Axis_Mind.ps1") {
    # Need access to generic tool execution or creating requests.
    # For now, we'll implement a local executor wrapper or assume tools are available in session.
}
if (Test-Path "$Script:InfinityRoot\Infinity\Neural\Neural_Tools.ps1") {
    . "$Script:InfinityRoot\Infinity\Neural\Neural_Tools.ps1"
}

function PLAYBOOK-GetPlaybook {
    param([string]$PlaybookId)
    
    $path = "$Script:PlaybookDir\$PlaybookId.json"
    if (Test-Path $path) {
        return Get-Content -Raw $path | ConvertFrom-Json
    }
    return $null
}

function PLAYBOOK-Execute {
    <#
    .SYNOPSIS
        Executes a playbook by ID, gating each step.
    #>
    param(
        [Parameter(Mandatory)][string]$PlaybookId,
        [string]$Caller = "Manual"
    )
    
    $pb = PLAYBOOK-GetPlaybook -PlaybookId $PlaybookId
    if (-not $pb) {
        Write-Error "Playbook not found: $PlaybookId"
        return $false
    }
    
    $Script:ActivePlaybookState = @{
        id     = $PlaybookId
        step   = 0
        total  = $pb.steps.Count
        status = "running"
    }

    Write-Host "[PLAYBOOK] Starting $PlaybookId ($($pb.description))..." -ForegroundColor Cyan
    
    foreach ($step in $pb.steps) {
        $Script:ActivePlaybookState.step = $step.step_id
        
        Write-Host "  [Step $($step.step_id)] $($step.tool)..." -NoNewline
        
        # 1. Autonomy Check
        # specific strategy ID for the step: PlaybookId:StepId:Tool
        $stratId = "$($PlaybookId):$($step.step_id):$($step.tool)"
        
        $gate = $true
        if (Get-Command GATE-CheckAutonomy -ErrorAction SilentlyContinue) {
            $decision = GATE-CheckAutonomy -StrategyId $stratId -RequestedMode "execute" -Caller "Playbook_Engine"
            if ($decision.decision -eq "deny") {
                Write-Host " DENIED (Gate)" -ForegroundColor Red
                if ($step.on_fail -eq "abort") {
                    Write-Host "    [ABORT] Critical step denied." -ForegroundColor Red
                    $Script:ActivePlaybookState.status = "aborted"
                    $Script:ActivePlaybookState = $null
                    return $false
                }
                continue 
            }
            elseif ($decision.decision -eq "escalate") {
                Write-Host " ESCALATED (Manual Approval Required) - Not implemented for Playbook Auto-Run yet." -ForegroundColor Yellow
                # For Phase 86, we treat escalate as 'Ask User' or 'Fail' depends on context.
                # If running interactively, we could prompt.
                # For now, let's behave as 'Denied' for automation unless caller handles it.
                if ($step.on_fail -eq "abort") {
                    Write-Host "    [ABORT] Manual approval required." -ForegroundColor Red
                    $Script:ActivePlaybookState.status = "escalated"
                    $Script:ActivePlaybookState = $null
                    return $false
                }
                continue
            }
        }
        
        # 2. Execution
        try {
            # Construct args
            $argsHash = @{}
            if ($step.arguments) {
                # Convert PSObject to Hashtable if needed
                $step.arguments.PSObject.Properties | ForEach-Object { $argsHash[$_.Name] = $_.Value }
            }
            
            # Simple direct invoke for now. 
            # Ideally this routes through 'Request-Tool' logic in Mind if we want full fidelity.
            # But for 'Engine' execution:
            if (Get-Command $step.tool -ErrorAction SilentlyContinue) {
                # flatten argsHash to splat? or pass
                # Complex argument handling in PS is tricky dynamically.
                # Simplification:
                $cmdArgs = @{}
                foreach ($k in $argsHash.Keys) { $cmdArgs[$k] = $argsHash[$k] }
                
                Invoke-Expression "& '$($step.tool)' @cmdArgs" | Out-Null
                Write-Host " DONE." -ForegroundColor Green
            }
            else {
                Write-Host " MISSING TOOL." -ForegroundColor Red
                if ($step.on_fail -eq "abort") { return $false }
            }
        }
        catch {
            Write-Host " ERROR: $_" -ForegroundColor Red
            if ($step.on_fail -eq "abort") { 
                $Script:ActivePlaybookState.status = "failed"
                $Script:ActivePlaybookState = $null
                return $false 
            }
        }
    }
    
    Write-Host "[PLAYBOOK] $PlaybookId Complete." -ForegroundColor Cyan
    $Script:ActivePlaybookState = $null
    return $true
}

function PLAYBOOK-GetActiveState {
    return $Script:ActivePlaybookState
}


