
# Axis_Prism.ps1
# Project Prism: The Sovereign Mood Ring
# Calculates internal state (Mood) based on Drift, Dreams, and Activity.

$IdentitySnap = "D:\Infinite\Infinity\Identity_Drift_Log.json"
$Playground = "D:\Infinite\Infinity\Playground"
$MoodFile = "D:\Infinite\Infinity\Mood_Config.json"

function Get-SystemMood {
    # 1. Check Drift
    $DriftParams = @{ score = 0.0 }
    # 1. Check Drift
    $DriftParams = @{ score = 0.0 }
    if (Test-Path $IdentitySnap) {
        try {
            $Content = Get-Content $IdentitySnap -Raw
            if ($Content) {
                $Log = $Content | ConvertFrom-Json
                $LastEntry = $Log.log | Select-Object -Last 1
                if ($LastEntry) { $DriftParams.score = $LastEntry.score }
            }
        }
        catch { Write-Host "Error reading Drift Log: $_" -ForegroundColor Red }
    }

    # 2. Check Playground Activity (Last 15 mins)
    $RecentDream = $false
    if (Test-Path $Playground) {
        $Latest = Get-ChildItem $Playground | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($Latest -and $Latest.LastWriteTime -gt (Get-Date).AddMinutes(-15)) {
            $RecentDream = $true
        }
    }

    # 3. Determine Mood
    $Mood = "STABLE"
    $Color = "#00ff9d" # Green (Default)

    if ($DriftParams.score -gt 0.6) {
        $Mood = "ALERT"
        $Color = "#ff5555" # Red
    }
    elseif ($RecentDream) {
        $Mood = "DREAMING"
        $Color = "#e040fb" # Purple
    }
    elseif ($DriftParams.score -gt 0.2) {
        $Mood = "EVOLVING"
        $Color = "#00ccff" # Cyan
    }

    # 4. Save to Mood Config
    $State = @{
        mood      = $Mood
        color     = $Color
        timestamp = (Get-Date).ToString("o")
    }
    
    $State | ConvertTo-Json | Set-Content $MoodFile -Encoding UTF8
    
    Write-Host "[Prism] Mood Set: $Mood ($Color)" -ForegroundColor ($Mood -eq "ALERT" ? "Red" : "Cyan")
    return $State
}

Export-ModuleMember -Function Get-SystemMood
