param(
    [string]$TargetFile = "D:\Infinite\Infinity\Outreach\Reports\SELF_AUDIT_$(Get-Date -Format 'yyyyMMdd_HHmm').md"
)

$root = "D:\infinite"
function Get-AxisPath([string]$rel) { Join-Path $root $rel | Resolve-Path -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Path -ErrorAction SilentlyContinue; if (-not $?) { Join-Path $root $rel } }

$mindLogPath = "D:\infinite\mind_log.txt"
$timelinePath = "D:\infinite\Infinity\Events_Timeline.json"
$contractPath = "D:\infinite\Infinity\Autonomy_Contract.json"
$warlordPath = "D:\infinite\Infinity\Warlord_Contract.json"
$nexusLogPath = "D:\infinite\nexus_warfare.log"
$recQueuePath = "D:\infinite\Infinity\Recommendation_Queue.json"

$now = Get-Date
$reportLines = @()
$reportLines += "# AXIS SELF-AUDIT | EPOCH: Meta-Cognition"
$reportLines += "Timestamp: $($now.ToString('yyyy-MM-dd HH:mm:ss'))"
$reportLines += "--------------------------------------------------"

# 1. LOGIC & PULSE HEALTH
$reportLines += "## Logic & Pulse Health"
try {
    if (Test-Path $mindLogPath) {
        $lines = Get-Content $mindLogPath -Tail 200
        if ($lines) {
            $lastLine = $lines | Where-Object { $_ -match '\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)\]' } | Select-Object -Last 1
            if ($lastLine -match '\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)\]') {
                $lastTsRaw = [DateTime]::Parse($matches[1])
                $nowUtc = [DateTime]::UtcNow; $diff = ($nowUtc - $lastTsRaw.ToUniversalTime()).TotalMinutes
                if ($diff -lt -60) { $diff = ($now - $lastTsRaw).TotalMinutes }
                if ($diff -gt 20) { $reportLines += "> [!WARNING] PULSE GAP: Last activity was $([math]::Round($diff, 1)) minutes ago." }
                else { $reportLines += "- Pulse Health: OK ($([math]::Round($diff, 1)) min gap)" }
            }
            else { $reportLines += "- Pulse Health: UNCERTAIN (No timestamp found in tail)" }
            $triggers = @{}; foreach ($l in $lines) { if ($l -match '\] \[([^\]]+)\]') { $t = $matches[1]; $triggers[$t]++ } }
            $spikes = $triggers.GetEnumerator() | Where-Object { $_.Value -gt 50 }; if ($spikes) {
                foreach ($s in $spikes) { $reportLines += "> [!CAUTION] LOOP CHURN: Trigger '$($s.Name)' spiked ($($s.Value) events)." }
            }
            else { $reportLines += "- Loop Stability: NOMINAL" }
        }
        else { $reportLines += "- Log State: EMPTY" }
    }
    else { $reportLines += "- Log State: MISSING" }
}
catch { $reportLines += "> [!CAUTION] Pulse Audit Failed: $_" }

# 2. OPERATIONAL INTEGRITY
$reportLines += "## Operational Integrity"
try {
    if (Test-Path $recQueuePath) {
        $q = Get-Content $recQueuePath -Raw | ConvertFrom-Json
        if ($q -and $q.strategies) {
            $failed = $q.strategies | Where-Object { $_.sim_status -eq "fail" -or $_.status -eq "rejected" }
            if ($failed) { foreach ($f in $failed) { $reportLines += "- [REJECTED] $($f.name) | Reason: $($f.sim_details)" } }
            else { $reportLines += "- Strategy Pipeline: CLEAN" }
        }
        else { $reportLines += "- Strategy Pipeline: EMPTY" }
    }
    else { $reportLines += "- Strategy Queue: MISSING" }

    $resultsDir = "D:\infinite\Infinity\Earth\Results"
    if (Test-Path $resultsDir) {
        $failures = Get-ChildItem $resultsDir -Filter *.json | ForEach-Object { try { Get-Content $_.FullName -Raw | ConvertFrom-Json } catch { $null } } | Where-Object { $_ -and $_.status -eq "failed" }
        if ($failures) {
            $reportLines += "### Recent Execution Failures"
            $failures | Select-Object -Last 3 | ForEach-Object { $reportLines += "- [FAIL] Tool: $($_.tool) | Output: $($_.output)" }
        }
        else { $reportLines += "- Execution Status: NOMINAL" }
    }
}
catch { $reportLines += "> [!CAUTION] Integrity Audit Failed: $_" }

# 3. SECURITY & ROE
$reportLines += "## Security & ROE Compliance"
try {
    if (Test-Path $warlordPath) {
        $contract = Get-Content $warlordPath -Raw | ConvertFrom-Json
        $allowed = $contract.rules.allowed_scopes
        $foundIP = $false; $driftDetected = $false
        if (Test-Path $nexusLogPath) {
            $nexusLines = Get-Content $nexusLogPath -Tail 50
            foreach ($line in $nexusLines) {
                if ($line -match '(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})') {
                    $foundIP = $true; $ip = $matches[1]; $isAllowed = $false
                    foreach ($scope in $allowed) {
                        if ($ip -like $scope.Replace('*', '')) { $isAllowed = $true; break }
                        if ($ip.Length -ge 7 -and $scope.Length -ge 7 -and $ip.Substring(0, 7) -eq $scope.Substring(0, 7)) { $isAllowed = $true; break }
                    }
                    if (-not $isAllowed) { $reportLines += "> [!CAUTION] ROE DRIFT: Target $ip out of scope."; $driftDetected = $true; break }
                }
            }
        }
        if ($driftDetected) { $reportLines += "- Warlord Status: ALARM (ROE Drift)" }
        elseif ($foundIP) { $reportLines += "- Warlord Status: COMPLIANT" }
        else { $reportLines += "- Warlord Status: NOMINAL (No active targets in log)" }
    }
    else { $reportLines += "- Security Status: NO CONTRACT FOUND" }
}
catch { $reportLines += "> [!CAUTION] Security Audit Failed: $_" }

# 4. STRUCTURAL COVERAGE
$reportLines += "## Structural Coverage"
try {
    if ((Test-Path $contractPath) -and (Test-Path $timelinePath)) {
        $autonomy = Get-Content $contractPath -Raw | ConvertFrom-Json
        $timeline = Get-Content $timelinePath -Raw | ConvertFrom-Json
        $executed = if ($timeline) { $timeline | Select-Object -ExpandProperty message } else { @() }
        if ($autonomy.strategy_profiles) {
            $foundAny = $false
            $props = $autonomy.strategy_profiles.PSObject.Properties
            if ($null -eq $props) { $props = $autonomy.strategy_profiles }
            foreach ($prop in $props) {
                $p = $prop.Name; if ($null -eq $p) { continue }
                if ($p -eq "default_safety") { continue }
                $foundAny = $true; $found = $false
                if ($executed) { foreach ($e in $executed) { if ($e -match $p) { $found = $true; break } } }
                if (-not $found) { $reportLines += "- [DEAD BRANCH] Profile '$p' inactive." }
                else { $reportLines += "- [ACTIVE] Profile '$p' verified." }
            }
            if (-not $foundAny) { $reportLines += "- No profiles to track." }
        }
        else { $reportLines += "- Profiles definition MISSING." }
    }
    else { $reportLines += "- Timeline or Contract UNKNOWN." }
}
catch { $reportLines += "> [!CAUTION] Coverage Audit Failed: $_" }

# Finalize
$reportLines += "--------------------------------------------------"
$reportLines += "*Reflection cycle complete. Identity: $env:COMPUTERNAME*"
$finalContent = $reportLines -join "`n"
$repDir = Split-Path $TargetFile; if (-not (Test-Path $repDir)) { New-Item -ItemType Directory -Path $repDir -Force | Out-Null }
Set-Content -Path $TargetFile -Value $finalContent -Encoding UTF8
Write-Host "Audit generated: $TargetFile"
