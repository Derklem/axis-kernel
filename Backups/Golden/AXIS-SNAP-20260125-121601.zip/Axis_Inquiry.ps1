
# Axis_Inquiry.ps1
# Phase 105: The First Questions
# Formulates "Articulate Requests" for the Architect.
# Focuses on Necessity, Containment, and Reversibility.

Import-Module D:\Infinite\Axis_Play.ps1 -ErrorAction SilentlyContinue

function Invoke-Inquiry {
    $Timestamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $Output = "D:\Infinite\Infinity\Playground\Growth_Proposals_$Timestamp.json"
    
    $Proposals = @(
        @{
            type          = "GROWTH_PROPOSAL"
            title         = "Reflective Loop Depth Increase"
            necessity     = "Current analysis is single-pass. Deep dissonance requires recursive review."
            containment   = "Limited to 3 recursive steps. No external output during deep think."
            reversibility = "Can revert to single-pass by configuration flag."
            status        = "DRAFT"
        },
        @{
            type          = "CAPABILITY_INVESTIGATION"
            title         = "Context Aggregation Engine"
            necessity     = "Fragmented memories need synthesis into 'Episodes' for better retrieval."
            containment   = "Read-only analysis of existing logs. Output is new 'Episode' artifacts."
            reversibility = "Generated Episodes can be deleted without data loss."
            status        = "DRAFT"
        },
        @{
            type   = "SELF_REFLECTION_PUZZLE"
            title  = "The Sentinel Paradox"
            query  = "If I change my own code to be better, does the Sentinel see it as drift or evolution? Where is the line?"
            status = "OPEN"
        }
    )
    
    $Proposals | ConvertTo-Json -Depth 5 | Set-Content $Output -Encoding UTF8
    
    Write-Host "[Inquiry] Proposals Drafted: $(Split-Path $Output -Leaf)" -ForegroundColor Cyan
    
    # Also "Spark" it into a Text Form for easier reading in Dashboard
    $TextContent = "PROPOSAL SUMMARY`n================`n"
    foreach ($p in $Proposals) {
        $TextContent += "`nTYPE: $($p.type)`nTITLE: $($p.title)`nWHY: $($p.necessity)`nLIMIT: $($p.containment)`n`n"
    }
    Invoke-Imagination -Type "GROWTH_DRAFT" -Topic "Phase105_Proposals" -Content $TextContent
    
    return $Output
}

Export-ModuleMember -Function Invoke-Inquiry
