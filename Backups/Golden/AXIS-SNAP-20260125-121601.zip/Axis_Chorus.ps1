# Axis_Chorus.ps1
# Phase 152: Chorus Engine
# "The Vote."

$chorusRoot = "D:\Infinite\Infinity"
$repliesDir = Join-Path $chorusRoot "Council\Replies"
$intentsDir = Join-Path $chorusRoot "Council\Intents"
$chorusPath = Join-Path $chorusRoot "Chorus_Decision.json"

function Process-Chorus {
    Write-Host "[CHORUS] Aggregating Votes..." -ForegroundColor Cyan

    if (-not (Test-Path $repliesDir)) { return }
    $files = Get-ChildItem $repliesDir -Filter "*.json"
    $replies = @()
    foreach ($f in $files) {
        try { $replies += (Get-Content $f.FullName -Raw | ConvertFrom-Json) } catch {}
    }

    if ($replies.Count -eq 0) {
        Write-Host "No replies found." -ForegroundColor DarkGray
        return
    }

    # Group by Intent
    $groups = $replies | Group-Object intent_id
    $decisions = @()

    foreach ($g in $groups) {
        $intentId = $g.Name
        
        # Load Intent to check status
        $intentPath = Join-Path $intentsDir "$intentId.json"
        
        $support = 0
        $oppose = 0
        $neutral = 0
        $voices = @()

        foreach ($r in $g.Group) {
            switch ($r.stance) {
                "SUPPORT" { $support++ }
                "OPPOSE" { $oppose++ }
                "NEUTRAL" { $neutral++ }
            }
            $voices += @{ model = $r.model; stance = $r.stance }
        }

        # Determine Consensus
        $outcome = "split"
        if ($support -gt $oppose) { $outcome = "supported" }
        if ($oppose -gt $support) { $outcome = "opposed" }
        if ($support -eq 0 -and $oppose -eq 0) { $outcome = "neutral" }

        $decisions += @{
            intent_id = $intentId
            outcome   = $outcome
            tally     = @{ support = $support; oppose = $oppose; neutral = $neutral }
            voices    = $voices
            timestamp = (Get-Date).ToUniversalTime().ToString("o")
        }
        
        Write-Host "Intent $intentId -> $outcome ($support/$oppose)" -ForegroundColor Green
    }

    # Save latest decisions
    $payload = @{
        version   = 1
        last_run  = (Get-Date).ToUniversalTime().ToString("o")
        decisions = $decisions
    }
    
    $payload | ConvertTo-Json -Depth 5 | Set-Content $chorusPath -Encoding UTF8
    return $payload
}

# Export-ModuleMember -Function Process-Chorus
