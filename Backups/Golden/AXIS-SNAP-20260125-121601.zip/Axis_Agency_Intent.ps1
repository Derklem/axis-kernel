# Axis_Agency_Intent.ps1
# Phase 301: The Intention Engine

param(
    [string]$Tool,
    [string]$Entity,
    [string]$Effect,
    [hashtable]$Arguments = @{},
    [string]$Source = "AXIS_CORE",
    [string]$GoalId = $null
)

$root = "D:\Infinite"
$entPath = Join-Path $root "Infinity\Horizon_Entities.json"
$invPath = Join-Path $root "Infinity\Subsystem_Inventory.json"

# 1. Validation
if (-not (Test-Path $entPath)) { Write-Error "Horizon Entities Missing"; exit 1 }
if (-not (Test-Path $invPath)) { Write-Error "Inventory Missing"; exit 1 }

$entities = Get-Content $entPath -Raw | ConvertFrom-Json
$inventory = Get-Content $invPath -Raw | ConvertFrom-Json

# Validate Entity
$validEntity = $entities.entities | Where-Object { $_.id -eq $Entity }
if (-not $validEntity) {
    Write-Warning "Entity '$Entity' not found in Horizon Map. Intent will be created but may be rejected by Policy."
}

# Validate Tool
$validTool = $inventory.subsystems | Where-Object { $_.name -like "*$Tool*" }
if (-not $validTool) {
    Write-Warning "Tool '$Tool' not found in Inventory."
}

# 2. Construct Intent
$intentId = "AINT-" + [Guid]::NewGuid().ToString().Substring(0,8).ToUpper()
$ts = (Get-Date).ToUniversalTime().ToString("o")

$intent = @{
    id = $intentId
    created_at = $ts
    source = $Source
    goal_id = $GoalId
    proposed_edges = @(
        @{
            tool = $Tool
            target_entity = $Entity
            effect = $Effect
            args = $Arguments
        }
    )
}

# 3. Output
$intent | ConvertTo-Json -Depth 5
