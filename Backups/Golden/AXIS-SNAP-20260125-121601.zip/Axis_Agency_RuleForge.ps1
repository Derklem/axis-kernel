# Axis_Agency_RuleForge.ps1
# Epoch 7: Policy Analytics & Suggestions
# Analyzes Action History (Walk Log) to propose Policy Updates.
# Does NOT modify Action_Policy.json directly.

$root = "D:\Infinite"
$policyPath = Join-Path $root "Infinity\Action_Policy.json"
$walkLogPath = Join-Path $root "Infinity\Axis_Walk_Log.jsonl"
$suggestionsPath = Join-Path $root "Infinity\Agency\Policy_Suggestions.json"

if (-not (Test-Path $policyPath)) { Write-Error "Policy file missing."; exit 1 }
if (-not (Test-Path $walkLogPath)) { Write-Error "Walk log missing."; exit 1 }

$policy = Get-Content $policyPath -Raw | ConvertFrom-Json

# 1. Parse log lines
$lines = Get-Content $walkLogPath
$events = @()
foreach ($line in $lines) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    try {
        $events += ($line | ConvertFrom-Json)
    } catch {
        # ignore malformed lines
    }
}

# 2. Aggregate stats
# Keys: "$tool|$effect|$target"
$stats = @{}  

foreach ($ev in $events) {
    if (-not $ev.data) { continue }
    
    $t = $ev.data.tool
    $effect = $ev.data.effect
    $target = $ev.data.entity # 'entity' field in walk log data
    # Some events use 'target_entity' or 'entity' depending on source, normalizing:
    if (-not $target -and $ev.data.target_entity) { $target = $ev.data.target_entity }

    if (-not $t -or -not $effect -or -not $target) { continue }

    $key = "$t|$effect|$target"
    if (-not $stats.ContainsKey($key)) {
        $stats[$key] = [ordered]@{
            tool            = $t
            effect          = $effect
            target_entity   = $target
            allow_count     = 0
            pending_count   = 0
            denied_count    = 0
            manual_denials  = 0
            executions      = 0
            failures        = 0
        }
    }

    $s = $stats[$key]

    switch ($ev.type) {
        "policy_decision" {
            switch ($ev.data.decision) {
                "ALLOW"   { $s.allow_count++ }
                "PENDING" { $s.pending_count++ }
                "DENIED"  { $s.denied_count++ }
            }
        }
        "execution_result" {
            $s.executions++
            if ($ev.data.status -ne "success" -and $ev.data.status -ne "ok") {
                $s.failures++
            }
        }
        "manual_denial" {
            $s.manual_denials++
        }
    }
}

# 3. Generate suggestions
$suggestions = @()

foreach ($entry in $stats.Values) {
    $tool   = $entry.tool
    $effect = $entry.effect
    $target = $entry.target_entity

    # Find existing rule if any
    $existing = $policy.rules | Where-Object {
        $_.tool -eq $tool -and $_.target_entity -eq $target -and $_.effect -eq $effect
    } | Select-Object -First 1

    # Heuristic A: Candidate for Auto (Safe Pattern)
    # Condition: No existing rule (or non-auto), No Denials, But seen Pending (or Manual Allows implied if we tracked them better)
    # Actually, if pending_count > 0 and manual_denials == 0, it means blocked. If allow_count > 0, it works.
    # Refined: If something is PENDING significantly but NEVER denied, user might want to AUTO it.
    if (-not $existing -and $entry.manual_denials -eq 0 -and $entry.denied_count -eq 0 -and $entry.pending_count -gt 0) {
        $suggestions += @{
            id = "SUG-AUTO-$tool-$effect-$target"
            tool = $tool
            target_entity = $target
            effect = $effect
            current_policy = "none"
            observed = $entry
            recommendation = "add_auto_rule"
            reason = "Blocked actions observed, but never explicitly denied. Consider monitoring or auto if trusted."
        }
    }
    
    # Heuristic A2: Promote from Review (Example: LogPulse was Pending, now maybe we want Auto if we didn't have it)
    # If existing rule is 'review_monitor' and failures == 0 and allow_count > 5
    if ($existing -and ($existing.policy -eq "review_monitor" -or $existing.policy -eq "manual_consent_required") -and $entry.failures -eq 0 -and $entry.allow_count -gt 5 -and $entry.manual_denials -eq 0) {
        $suggestions += @{
            id = "SUG-PROMOTE-$tool-$effect-$target"
            tool = $tool
            target_entity = $target
            effect = $effect
            current_policy = $existing.policy
            observed = $entry
            recommendation = "promote_to_auto"
            reason = "Consistently allowed and successful. Consider relaxing to AUTO."
        }
    }

    # Heuristic B: Candidate for Deny (Blocked Pattern)
    if ($entry.manual_denials -gt 0 -and (-not $existing -or $existing.policy -ne "manual_review_only")) {
        $suggestions += @{
            id = "SUG-DENY-$tool-$effect-$target"
            tool = $tool
            target_entity = $target
            effect = $effect
            current_policy = if ($existing) { $existing.policy } else { "none" }
            observed = $entry
            recommendation = "add_deny_rule"
            reason = "Manual denials observed. Consider explicit RESTRICTION."
        }
    }
}

$out = @{
    generated_at = (Get-Date).ToUniversalTime().ToString("o")
    schema_version = 1
    suggestions = $suggestions
}

$out | ConvertTo-Json -Depth 10 | Set-Content $suggestionsPath -Encoding UTF8

Write-Host "--- RuleForge Suggestions ---" -ForegroundColor Cyan
Write-Host "Generated: $($out.generated_at)" -ForegroundColor Gray
Write-Host "Count: $($suggestions.Count)" -ForegroundColor Gray

foreach ($sug in $suggestions) {
    if ($sug.recommendation -match "auto") { $color = "Green" } else { $color = "Yellow" }
    Write-Host "* [$($sug.recommendation)] $($sug.tool) -> $($sug.effect) on $($sug.target_entity)" -ForegroundColor $color
    Write-Host "   Reason: $($sug.reason)" -ForegroundColor DarkGray
    Write-Host "   Stats:  Pending=$($sug.observed.pending_count) Denied=$($sug.observed.manual_denials) Allowed=$($sug.observed.allow_count)" -ForegroundColor DarkGray
    Write-Host ""
}
