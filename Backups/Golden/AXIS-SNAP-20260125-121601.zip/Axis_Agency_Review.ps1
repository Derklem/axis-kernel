# Axis_Agency_Review.ps1
# Epoch 6: Governance Surface - The Gavel
# Usage:
#   .\Axis_Agency_Review.ps1 -Id <IntentID> -Decision Allow [-Remember]
#   .\Axis_Agency_Review.ps1 -Id <IntentID> -Decision Deny

param(
    [Parameter(Mandatory = $true)]
    [string]$Id,
    
    [Parameter(Mandatory = $true)]
    [ValidateSet("Allow", "Deny")]
    [string]$Decision,
    
    [switch]$Remember # Only valid for Decision=Allow
)

$root = "D:\Infinite"
$pendingPath = Join-Path $root "Infinity\Autonomy\Autonomy_Requests_Inbox.json"
$policyPath = Join-Path $root "Infinity\Action_Policy.json"
$executorPath = Join-Path $root "Axis_Agency_Executor.ps1"
$walkLogPath = Join-Path $root "Infinity\Axis_Walk_Log.jsonl" 

if (-not (Test-Path $pendingPath)) {
    Write-Error "No Autonomy Inbox found."
    exit
}

$raw = Get-Content $pendingPath -Raw
# Handle wrapped object structure { items: [...] } vs old array
try {
    $data = $raw | ConvertFrom-Json
}
catch {
    Write-Error "Invalid Inbox JSON"
    exit
}

$queue = if ($data.items) { $data.items } else { $data } # Fallback if raw array
if ($queue -is [PSCustomObject]) { $queue = @($queue) }

# Find Item by request_id (not intent_id)
$index = -1
for ($i = 0; $i -lt $queue.Count; $i++) {
    # Check both request_id (new) and intent_id (legacy)
    $qId = if ($queue[$i].request_id) { $queue[$i].request_id } else { $queue[$i].intent_id }
    if ($qId -eq $Id) { $index = $i; break }
}

if ($index -lt 0) {
    Write-Error "Request ID '$Id' not found in inbox."
    exit
}

$item = $queue[$index]
# Map fields if legacy
$toolName = if ($item.strategy_id) { $item.strategy_id } else { $item.tool }
Write-Host "Reviewing: $toolName -> $Decision" -ForegroundColor Cyan

if ($Decision -eq "Allow") {
    # 2. Execute
    # Reconstruct Decision Object
    $decisionObj = @{
        intent_id = $Id
        decisions = @(
            @{
                tool           = $toolName
                target_entity  = "AXIS_CORE" # Default if missing
                effect         = "manual_run"
                decision       = "ALLOW"
                reason         = "Manually Approved by Architect"
                policy_applied = "manual_override"
            }
        )
    }
    
    # If original data preserved, use it
    if ($item.original_data) {
        $od = $item.original_data
        $decisionObj.decisions[0].target_entity = $od.target_entity
        $decisionObj.decisions[0].effect = $od.effect
        if ($od.args) { $decisionObj.decisions[0].args = $od.args }
    }

    $decisionJson = $decisionObj | ConvertTo-Json -Depth 5 -Compress
    Write-Host " [EXEC] Handoff to Executor..." -ForegroundColor Gray
    $decisionJson | & $executorPath
}
elseif ($Decision -eq "Deny") {
    Write-Host " [DENY] Action rejected." -ForegroundColor Red
}

# 3. Update Status in Queue (Don't delete, mark resolved)
# UI filters for status='pending', so 'resolved' clears the alert.
if ($data.items) {
    $data.items[$index].status = ($Decision.ToLower() + "ed") # allowed or denied
    $data.items[$index] | Add-Member -MemberType NoteProperty -Name "reviewed_at" -Value ((Get-Date).ToString("o")) -Force
    $data | ConvertTo-Json -Depth 10 | Set-Content $pendingPath -Encoding UTF8
}
else {
    # Legacy array mode - remove it
    $newQueue = @()
    for ($i = 0; $i -lt $queue.Count; $i++) {
        if ($i -ne $index) { $newQueue += $queue[$i] }
    }
    $newQueue | ConvertTo-Json -Depth 5 | Set-Content $pendingPath -Encoding UTF8
}

Write-Host " [INBOX] Item updated/cleared." -ForegroundColor Green
