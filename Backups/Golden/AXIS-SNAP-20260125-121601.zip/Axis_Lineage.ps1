
# Axis_Lineage.ps1
# Phase 91: The Lineage Engine
# Manages the "Heritage Timeline" - the structural history of the System.
# Unlike logs (what happened), Lineage tracks "Who I Became".

$LineagePath = "D:\Infinite\Infinity\Heritage\Axis_Lineage.json"

function Ensure-Lineage {
    if (-not (Test-Path (Split-Path $LineagePath))) { 
        New-Item -ItemType Directory -Path (Split-Path $LineagePath) -Force | Out-Null 
    }
    if (-not (Test-Path $LineagePath)) { 
        @{ timeline = @() } | ConvertTo-Json -Depth 10 | Set-Content $LineagePath -Encoding UTF8
    }
}

function Load-LineageSafe {
    if (Test-Path $LineagePath) {
        try { return Get-Content $LineagePath -Raw -ErrorAction Stop | ConvertFrom-Json } 
        catch { return @{ timeline = @() } }
    }
    return @{ timeline = @() }
}

function Save-LineageSafe ($data) {
    $data | ConvertTo-Json -Depth 10 | Set-Content $LineagePath -Encoding UTF8
}

function Log-LineageEvent {
    param (
        [Parameter(Mandatory = $true)] [string]$Type,      # "RATIFICATION", "PHASE_COMPLETE", "TRAUMA", "MERGE"
        [Parameter(Mandatory = $true)] [string]$Summary,   # "Ratified Constitution v1.0"
        [Parameter(Mandatory = $true)] [string]$Agent,     # "Architect", "Sentinel", "System"
        [string]$ArtifactRef = "",                       # Path to related file (e.g., Identity_Kernel.json)
        [string]$Impact = "STRUCTURAL",                  # "STRUCTURAL", "COSMETIC", "BEHAVIORAL"
        [string]$Story = ""                              # Human-readable narrative
    )

    Ensure-Lineage
    $store = Load-LineageSafe
    if (-not $store.timeline) { $store.timeline = @() }

    $event = @{
        id           = [Guid]::NewGuid().ToString()
        timestamp    = (Get-Date).ToString("o")
        type         = $Type
        summary      = $Summary
        agent        = $Agent
        artifact_ref = $ArtifactRef
        impact       = $Impact
        story        = $Story
        sys_version  = "Phase 91+".ToString() # Ideally dynamic
    }

    # Prepend to timeline (Newest first? Or Oldest? Lineage usually append-only, but viewing is newest first)
    # Let's simple append for storage, sort for viewing.
    $store.timeline += $event
    
    Save-LineageSafe $store
    Write-Host "LINEAGE: Recorded Event [$Type] $Summary" -ForegroundColor Cyan
    return $event
}

function Get-Lineage {
    Ensure-Lineage
    $store = Load-LineageSafe
    return $store.timeline | Sort-Object timestamp -Descending
}

# Auto-Init
Ensure-Lineage
