
# Axis_Symbiosis.ps1
# Phase 65+: Symbiosis & Self-Model Integration
# Implements 'SYM-*' tools and Context Generators.

$SymbiosisRoot = "D:\Infinite"
$MetricsPath = "$SymbiosisRoot\Infinity\Neural\Heartbeat_Metrics.json"
$JournalPath = "$SymbiosisRoot\Infinity\Symbiosis_Journal.json"

# Phase 72: Bias Functions
$Script:InfinityRoot = $SymbiosisRoot
if (Test-Path "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1") {
    . "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1"
}
if (Test-Path "$Script:InfinityRoot\Axis_Outcome.ps1") {
    . "$Script:InfinityRoot\Axis_Outcome.ps1"
}
if (Test-Path "$Script:InfinityRoot\Infinity\Anchor\Axis_Anchor.ps1") {
    . "$Script:InfinityRoot\Infinity\Anchor\Axis_Anchor.ps1"
}
if (Test-Path "$Script:InfinityRoot\Infinity\Skills\Axis_Curriculum.ps1") {
    . "$Script:InfinityRoot\Infinity\Skills\Axis_Curriculum.ps1"
}
if (Test-Path "$Script:InfinityRoot\Axis_AutonomyGate.ps1") {
    . "$Script:InfinityRoot\Axis_AutonomyGate.ps1"
}
if (Test-Path "$Script:InfinityRoot\Axis_Doctrine.ps1") {
    . "$Script:InfinityRoot\Axis_Doctrine.ps1"
}
if (Test-Path "$Script:InfinityRoot\Axis_Playbook.ps1") {
    . "$Script:InfinityRoot\Axis_Playbook.ps1"
}

# --- Context Helper ---
function Get-SymbiosisContext {
    <#
    .SYNOPSIS
        Returns a formatted string block of Neural/Symbiosis state for LLM Prompts.
    #>
    $block = "## NEURAL_HEARTBEAT`n"
    
    if (Test-Path $MetricsPath) {
        try {
            $m = Get-Content $MetricsPath -Raw | ConvertFrom-Json
            $block += "Status: $($m.status.ToUpper()) | BPM: $($m.current_bpm) | Load: $($m.load_avg_1m)`n"
            $block += "Last Updated: $($m.last_updated_utc)`n"
            
            # Add recent history trend if available
            if ($m.history -and $m.history.Count -gt 5) {
                $recent = $m.history | Select-Object -Last 5
                $trend = ($recent | ForEach-Object { "$($_.bpm)" }) -join " -> "
                $block += "Trend (BPM): $trend`n"
            }
        }
        catch {
            $block += "Status: UNKNOWN (Read Error)`n"
        }
    }
    else {
        $block += "Status: OFFLINE (No Metrics)`n"
    }

    $block += "`n## ENVIRONMENT_WEATHER`n"
    $WMetricsPath = "$SymbiosisRoot\Infinity\Neural\Weather_Metrics.json"
    if (Test-Path $WMetricsPath) {
        try {
            $w = Get-Content $WMetricsPath -Raw | ConvertFrom-Json
            $block += "Location: $($w.location) | Status: $($w.status.ToUpper())`n"
            $block += "Temp: $($w.current_temp_c)C | Cond: $($w.current_condition)`n"
            $block += "Alerts: $(if($w.alerts){$w.alerts -join ', '}else{'None'})`n"
        }
        catch {
            $block += "Status: UNKNOWN (Read Error)`n"
        }
    }
    else {
        $block += "Status: PENDING_INTAKE`n"
    }

    $block += "`n## NETWORK_ROUTER`n"
    $RMetricsPath = "$SymbiosisRoot\Infinity\Neural\Router_Metrics.json"
    if (Test-Path $RMetricsPath) {
        try {
            $r = Get-Content $RMetricsPath -Raw | ConvertFrom-Json
            $block += "Status: $($r.status.ToUpper()) | WAN: $($r.identity.wan_ip) | Clients: $($r.traffic.active_clients)`n"
            $block += "Alerts: $(if($r.alerts){$r.alerts -join ', '}else{'None'})`n"
        }
        catch {
            $block += "Status: UNKNOWN (Read Error)`n"
        }
    }
    else {
        $block += "Status: OFFLINE (No Metrics)`n"
    }

    $block += "`n## VISUAL_RETINA`n"
    $RetinaMetricsPath = "$SymbiosisRoot\Infinity\Neural\Retina_Metrics.json"
    if (Test-Path $RetinaMetricsPath) {
        try {
            $r = Get-Content $RetinaMetricsPath -Raw | ConvertFrom-Json
            $block += "Frames Total: $($r.frames_total) | Highlighted: $($r.frames_highlighted)`n"
            $block += "Last Source: $($r.last_source) `n"
            $block += "Last Tags: $(if($r.last_frame_tags){$r.last_frame_tags -join ', '}else{'None'})`n"
            $block += "Status: $($r.status.ToUpper()) | Alerts: $(if($r.alerts){$r.alerts -join ', '}else{'None'})`n"
        }
        catch {
            $block += "Status: UNKNOWN (Read Error)`n"
        }
    }
    else {
        $block += "Status: PENDING_INTAKE`n"
    }
    
    # Get Pilot Context
    . "$Script:InfinityRoot\Axis_Pilot.ps1"
    $pilotCtx = Get-PilotContext

    # Get Voice
    . "$Script:InfinityRoot\Axis_Voice.ps1"
    $voice = AXIS-Voice-Resonate

    $block += "`n## SYSTEM STATUS`n"
    $block += "Time: $(Get-Date)`n"
    $block += "Heartbeat: UNKNOWN`n" # Placeholder as heartbeat logic is above scope
    $block += "Pilot: $(if($pilotCtx){"$($pilotCtx.current_pilot_id) [$($pilotCtx.role)]"}else{"NONE"})`n"
    
    # Phase 79/80: Pending Reviews
    if (Get-Command ANCHOR-GetPendingReviewCount -ErrorAction SilentlyContinue) {
        $pending = ANCHOR-GetPendingReviewCount
        if ($pending -gt 0) {
            $block += "Pending Outcome Reviews: $pending (Waiting for Anchor Verdict)`n"
        }
    }
    
    # Phase 81: Curriculum
    if (Get-Command CURRIC-GetTrainingQueue -ErrorAction SilentlyContinue) {
        $q = CURRIC-GetTrainingQueue
        $qPending = @($q.items) | Where-Object { $_.status -eq "pending" }
        if ($qPending.Count -gt 0) {
            $block += "Curriculum: $($qPending.Count) items in training queue.`n"
        }
    }
    
    # Phase 82: Autonomy Gate
    if (Get-Command GATE-GetPendingRequests -ErrorAction SilentlyContinue) {
        $reqs = GATE-GetPendingRequests
        if ($reqs.Count -gt 0) {
            $top = $reqs[0]
            $block += "Autonomy Treaty: $($reqs.Count) PENDING REQUESTS (Top: $($top.strategy_id) - $($top.reasons -join ','))`n"
        }
    }
    
    # Phase 86: Playbook Engine
    if (Get-Command PLAYBOOK-GetActiveState -ErrorAction SilentlyContinue) {
        $pbState = PLAYBOOK-GetActiveState
        if ($pbState) {
            $block += "Active Playbook: $($pbState.id) | Step: $($pbState.step)/$($pbState.total) | Status: $($pbState.status)`n"
        }
    }

    $block += "Voice:`n$voice`n"

    # Phase 85: Doctrine Context
    if (Get-Command DOCTRINE-GetSummaryForLLM -ErrorAction SilentlyContinue) {
        $doc = DOCTRINE-GetSummaryForLLM
        $block += "`n## DOCTRINE_CONTEXT`n"
        $block += "$doc`n"
    }

    $block += "`n## SHADOW_CONTEXT`n"
    $ShadowIndexPath = "$SymbiosisRoot\Infinity\Shadow\Shadow_Risk_Index.json"
    if (Test-Path $ShadowIndexPath) {
        try {
            $s = Get-Content $ShadowIndexPath -Raw | ConvertFrom-Json
            $block += "Risk Score: $($s.global_risk_score)`n"
            
            # Phase 72: Bias Integration
            if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
                $b = Get-ShadowBiasState
                $block += "Global Mode: $($b.global_mode.ToUpper())`n"
                foreach ($k in $b.band_modes.Keys) {
                    if ($b.band_modes[$k] -ne "normal") {
                        $block += "Band Bias [$k]: $($b.band_modes[$k])`n"
                    }
                }
            }
        }
        catch {
            $block += "State: UNAVAILABLE (Read Error)`n"
        }
    }
    else {
        $block += "State: NOT_INITIALIZED`n"
    }

    return $block
}

# --- Tools ---

function SYM-Snapshot {
    <#
    .SYNOPSIS
        Captures subject experience snapshot into Symbiosis Journal.
    #>
    param()
    
    Write-Host "[SYM] taking snapshot..."
    
    $timestamp = (Get-Date).ToUniversalTime().ToString("o")
    
    # 1. Gather Context
    $context = Get-SymbiosisContext
    
    # 2. Compose Entry
    # Ideally this queries the LLM for a "Subjective Reflection", but for now we log the State.
    $entry = @{
        id        = "SYM-" + [Guid]::NewGuid().ToString()
        timestamp = $timestamp
        type      = "snapshot"
        source    = "SYM-Snapshot"
        content   = $context
        tags      = @("heartbeat", "neural_intake")
    }
    
    # 3. Append to Journal
    $journal = @{ version = 1; entries = @() }
    if (Test-Path $JournalPath) {
        try { $journal = Get-Content $JournalPath -Raw | ConvertFrom-Json } catch {}
    }
    if (-not $journal.entries) { $journal.entries = @() }
    
    $journal.entries += $entry
    
    # Keep last 1000
    if ($journal.entries.Count -gt 1000) { $journal.entries = $journal.entries | Select-Object -Last 1000 }
    
    $journal | ConvertTo-Json -Depth 5 | Set-Content $JournalPath -Encoding UTF8
    
    return "Snapshot captured. ID: $($entry.id)"
}

# Export-ModuleMember -Function Get-SymbiosisContext, SYM-Snapshot

