param(
    [string] $AutoTuneQueuePath = "D:\Infinite\Infinity\AutoTune_Queue.json",
    [string] $GovernanceHistoryPath = "D:\Infinite\Infinity\Governance_History.json",
    [string] $DoctrineRulesPath = "D:\Infinite\Infinity\Doctrine\Doctrine_Rules.json",
    [string] $ToolRegistryPath = "D:\Infinite\Infinity\Tool_Registry.json",
    [string] $GovBackupDir = "D:\Infinite\Infinity\Backups\Governance",
    [string] $ConstraintsPath = "D:\Infinite\Infinity\Constitutional_Constraints.json",
    [string] $SimScriptPath = "D:\Infinite\Axis_Governance_Sim.ps1"
)

$ErrorActionPreference = "Stop"

function Get-Rank {
    param([string] $Severity)
    if (-not $Severity) { return 0 }
    $s = $Severity.ToLower()
    if ($s -eq "low") { return 1 }
    if ($s -eq "medium") { return 2 }
    if ($s -eq "high") { return 3 }
    if ($s -eq "critical") { return 4 }
    return 0
}

function Test-Constraints {
    param([object] $Proposal, [string] $ConstraintsPath)
    if (-not (Test-Path $ConstraintsPath)) { return @{ pass = $true } }
    $c = Get-Content $ConstraintsPath -Raw | ConvertFrom-Json
    
    # Tool Risk Bounds
    if ($Proposal.scope -eq "tool" -and ($Proposal.target_key -eq "risk_level" -or $Proposal.target_key -eq "suggested_risk")) {
        $r = Get-Rank -Severity $Proposal.suggested_risk
        if ($c.tool_risk_bounds) {
            $m = Get-Rank -Severity $c.tool_risk_bounds.max
            if ($r -gt $m) { return @{ pass = $false; reason = "Exceeds constitutional max for tools" } }
        }
    }
    return @{ pass = $true }
}

function Invoke-TreatyBroadcast {
    param([object] $Proposal, [string] $tLedgerPath, [string] $aInboxPath)
    
    $now = (Get-Date).ToUniversalTime().ToString("o")
    Write-Host "[GOV] Broadcasting Treaty for $($Proposal.target.rule_id)..." -ForegroundColor Cyan

    # 1. Update Ledger
    $ledgerData = if (Test-Path $tLedgerPath) { Get-Content $tLedgerPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{ version = 1; treaties = @() } }
    $entry = [ordered]@{
        rule_id         = $Proposal.target.rule_id
        timestamp_utc   = $now
        status          = "pending_consensus"
        source_realm    = "Infinite"
        proposed_change = $Proposal.proposed_change
    }
    
    # Robustly handle treaties list
    [System.Collections.ArrayList]$tList = @()
    if ($ledgerData.PSObject.Properties.Match('treaties').Count -and $ledgerData.treaties -ne $null) {
        foreach ($t in $ledgerData.treaties) { $tList.Add($t) | Out-Null }
    }
    $tList.Add($entry) | Out-Null
    
    if (-not $ledgerData.PSObject.Properties.Match('treaties').Count) {
        $ledgerData | Add-Member -NotePropertyName treaties -NotePropertyValue $tList.ToArray() -Force
    }
    else {
        $ledgerData.treaties = $tList.ToArray()
    }
    
    if (-not $ledgerData.PSObject.Properties.Match('last_broadcast_utc').Count) {
        $ledgerData | Add-Member -NotePropertyName last_broadcast_utc -NotePropertyValue $now -Force
    }
    else {
        $ledgerData.last_broadcast_utc = $now
    }
    $ledgerData | ConvertTo-Json -Depth 20 | Set-Content $tLedgerPath -Encoding UTF8

    # 2. Inject into Autonomy Inbox
    $inboxData = if (Test-Path $aInboxPath) { Get-Content $aInboxPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{ version = 1; items = @() } }
    $packetId = "TREATY-{0}-{1}" -f (Get-Date -Format "yyyyMMddHHmmss"), ($Proposal.target.rule_id -replace "[^A-Za-z0-9]", "")
    
    $item = [ordered]@{
        request_id  = $packetId
        packet_id   = $packetId
        type        = "treaty_proposal"
        strategy_id = "CONSENSUS-RECONCILE"
        summary     = "New Treaty Proposal: $($Proposal.target.rule_id) amendment from Infinite."
        status      = "pending"
        details     = $entry
    }
    
    [System.Collections.ArrayList]$iList = @()
    if ($inboxData.PSObject.Properties.Match('items').Count -and $inboxData.items -ne $null) {
        foreach ($i in $inboxData.items) { $iList.Add($i) | Out-Null }
    }
    $iList.Add($item) | Out-Null

    if (-not $inboxData.PSObject.Properties.Match('items').Count) {
        $inboxData | Add-Member -NotePropertyName items -NotePropertyValue $iList.ToArray() -Force
    }
    else {
        $inboxData.items = $iList.ToArray()
    }
    $inboxData | ConvertTo-Json -Depth 20 | Set-Content $aInboxPath -Encoding UTF8
}

function Commit-Proposal {
    param($proposalId, $qPath, $hPath, $rPath, $dPath, $bDir, $cPath, $sScript)
    
    $qd = Get-Content $qPath -Raw | ConvertFrom-Json
    $props = if ($qd.proposals) { $qd.proposals } else { $qd }
    $p = $props | Where-Object { $_.id -eq $proposalId }
    if (-not $p) { throw "No prop $proposalId" }

    $res = Test-Constraints -Proposal $p -ConstraintsPath $cPath
    if (-not $res.pass) { throw "VIOLATION: $($res.reason)" }

    if ($p.scope -eq "doctrine" -and $p.status -ne "sim_pass") {
        Write-Host "[GOV] Mandatory simulation required for Doctrine." -ForegroundColor Cyan
        & $sScript -ProposalId $proposalId | Out-Null
        $qd = Get-Content $qPath -Raw | ConvertFrom-Json
        $props = if ($qd.proposals) { $qd.proposals } else { $qd }
        $p = $props | Where-Object { $_.id -eq $proposalId }
        if ($p.status -ne "sim_pass") { throw "Simulation Failed for Doctrine." }
    }

    $oldValue = $null
    $targetKey = $null

    if ($p.scope -eq "doctrine") {
        $docBackupDir = Join-Path $bDir "Doctrine"
        if (-not (Test-Path $docBackupDir)) { New-Item -ItemType Directory -Path $docBackupDir -Force | Out-Null }
        Copy-Item $dPath (Join-Path $docBackupDir "Doctrine_Rules.$((Get-Date).ToString('yyyyMMddHHmmss')).bak") -Force

        $doctrine = Get-Content $dPath -Raw | ConvertFrom-Json
        $rule = $doctrine.rules | Where-Object { $_.rule_id -eq $p.target.rule_id }
        if (-not $rule) { throw "Rule $($p.target.rule_id) not found." }
        
        $oldValue = $rule.policy.severity
        if (-not $rule.policy.PSObject.Properties.Match('severity').Count) {
            $rule.policy | Add-Member -NotePropertyName severity -NotePropertyValue $p.proposed_change.after.severity -Force
        }
        else {
            $rule.policy.severity = $p.proposed_change.after.severity
        }

        if ($p.proposed_change.after.autonomy) {
            if (-not $rule.policy.PSObject.Properties.Match('autonomy').Count) {
                $rule.policy | Add-Member -NotePropertyName autonomy -NotePropertyValue $p.proposed_change.after.autonomy -Force
            }
            else {
                $rule.policy.autonomy = $p.proposed_change.after.autonomy
            }
        }
        
        if (-not $rule.PSObject.Properties.Match('last_updated_utc').Count) {
            $rule | Add-Member -NotePropertyName last_updated_utc -NotePropertyValue ((Get-Date).ToUniversalTime().ToString("o")) -Force
        }
        else {
            $rule.last_updated_utc = (Get-Date).ToUniversalTime().ToString("o")
        }

        $doctrine | ConvertTo-Json -Depth 20 | Set-Content $dPath -Encoding UTF8
        $targetKey = $p.target.rule_id
        Invoke-TreatyBroadcast -Proposal $p -tLedgerPath "D:\Infinite\Infinity\Governance\Treaty_Ledger.json" -aInboxPath "D:\Infinite\Infinity\Autonomy\Autonomy_Requests_Inbox.json"
    }
    else {
        $reg = Get-Content $rPath -Raw | ConvertFrom-Json
        $t = $reg.tools | Where-Object { $_.id -eq $p.tool -or $_.name -eq $p.tool }
        $oldValue = $t.risk_level
        $t.risk_level = $p.suggested_risk
        $reg | ConvertTo-Json -Depth 20 | Set-Content $rPath -Encoding UTF8
        $targetKey = $p.tool
    }

    $p.status = "ratified"
    if (-not $p.PSObject.Properties.Match('ratified_at').Count) {
        $p | Add-Member -NotePropertyName ratified_at -NotePropertyValue ((Get-Date).ToString("o")) -Force
    }
    else {
        $p.ratified_at = (Get-Date).ToString("o")
    }
    $qd | ConvertTo-Json -Depth 20 | Set-Content $qPath -Encoding UTF8

    $h = if (Test-Path $hPath) { Get-Content $hPath -Raw | ConvertFrom-Json } else { @{ history = @() } }
    [System.Collections.ArrayList]$hList = @()
    if ($h.history -ne $null) {
        foreach ($entry in $h.history) { $hList.Add($entry) | Out-Null }
    }
    $hList.Add(@{ 
            id          = "GOV-$((Get-Date).ToString('yyyyMMddHHmmss'))"
            type        = if ($p.scope -eq "doctrine") { "doctrine_amendment" } else { "calibration_ratify" }
            proposal_id = $proposalId; 
            target      = $targetKey; 
            timestamp   = (Get-Date).ToString("o"); 
            from        = $oldValue; 
            to          = if ($p.scope -eq "doctrine") { $p.proposed_change.after.severity } else { $p.suggested_risk } 
        }) | Out-Null
    @{ history = $hList.ToArray() } | ConvertTo-Json -Depth 20 | Set-Content $hPath -Encoding UTF8
    
    Write-Host "[GOV] Successfully ratified $proposalId" -ForegroundColor Green
}

$inbox = "D:\Infinite\Infinity\UI_Inbox"
if (Test-Path $inbox) {
    Get-ChildItem (Join-Path $inbox "*.json") | ForEach-Object {
        $intent = $_
        try {
            $json = Get-Content $intent.FullName -Raw | ConvertFrom-Json
            $id = $json.parameters.proposal_id
            if ($json.verb -eq "simulate_proposal") {
                & $SimScriptPath -ProposalId $id | Out-Null
            }
            elseif ($json.verb -eq "ratify_proposal") {
                Commit-Proposal -proposalId $id -qPath $AutoTuneQueuePath -hPath $GovernanceHistoryPath -rPath $ToolRegistryPath -dPath $DoctrineRulesPath -bDir $GovBackupDir -cPath $ConstraintsPath -sScript $SimScriptPath
            }
        }
        catch { Write-Host "GOV-ERR: $_" }
        finally { if (Test-Path $intent.FullName) { Remove-Item $intent.FullName -Force } }
    }
}
