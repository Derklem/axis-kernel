<#
.SYNOPSIS
    Phase 116 - Incident → AutoTune Bridge (Learning Loop)

.DESCRIPTION
    Scans incidents in Axis_State.json, applies Incident_AutoTune_Policies.json,
    and generates AutoTune proposals when repeated patterns are detected.

    - Idempotent per (policy_id, target) by checking existing open proposals.
    - Logs summary entries to Autonomy_Journal.md.
    - Writes a metrics snapshot to Incident_Metrics.json (for future use).

.NOTES
    AutoTune_Queue.json schema (expected by UI / STRAT):
      {
        "proposals": [
          {
            "id": "...",
            "tool": "SYSTEM_AUTONOMY",
            "current_risk": "medium",
            "suggested_risk": "high",
            "reason": "text",
            "metric_basis": {
              "calls": 3,
              "fail_rate": 0.0,
              "incident_count": 3,
              "window_minutes": 1440,
              "incident_type": "autonomy_escalation",
              "min_severity": "high"
            },
            "policy_id": "IAUT-...",
            "source": "Incident_AutoTune",
            "status": "open",
            "created_at": "..."
          }
        ]
      }
#>

param(
    [string] $AxisStatePath = "D:\Infinite\Infinity\Axis_State.json",
    [string] $PolicyPath = "D:\Infinite\Infinity\Incident_AutoTune_Policies.json",
    [string] $AutoTuneQueuePath = "D:\Infinite\Infinity\AutoTune_Queue.json",
    [string] $MetricsPath = "D:\Infinite\Infinity\Incident_Metrics.json",
    [string] $AutonomyJournalPath = "D:\Infinite\Infinity\Autonomy_Journal.md"
)

$ErrorActionPreference = "Stop"

function Get-SeverityRank {
    param([string] $Severity)

    if (-not $Severity) { return 0 }
    switch ($Severity.ToLowerInvariant()) {
        "low" { return 1 }
        "medium" { return 2 }
        "high" { return 3 }
        "critical" { return 4 }
        default { return 0 }
    }
}

function Get-OrInitAutoTuneQueue {
    param([string] $Path)

    if (-not (Test-Path $Path)) {
        return [pscustomobject]@{ proposals = @() }
    }

    $raw = Get-Content $Path -Raw | ConvertFrom-Json
    # If file is just an array, wrap it
    if ($raw -is [Array]) {
        return [pscustomobject]@{ proposals = $raw }
    }

    if ($null -eq $raw.PSObject.Properties['proposals']) {
        $raw | Add-Member -NotePropertyName proposals -NotePropertyValue @()
    }
    elseif ($raw.proposals -isnot [Array]) {
        $raw.proposals = @($raw.proposals)
    }

    return $raw
}

function New-AutoTuneProposalId {
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $randChars = (48..57 + 65..90)
    $suffix = -join (1..4 | ForEach-Object { [char]($randChars | Get-Random) })
    return "AT-INC-$stamp-$suffix"
}

function Format-ReasonFromTemplate {
    param(
        [string] $Template,
        [string] $IncidentType,
        [string] $MinSeverity,
        [int]    $Count,
        [int]    $WindowMinutes
    )

    if (-not $Template) {
        return "Detected $Count incidents of type '$IncidentType' (>= $MinSeverity) in the last $WindowMinutes minutes."
    }

    $minSevOrHigher = if ($MinSeverity) { "$MinSeverity or higher" } else { "any severity" }

    $reason = $Template.Replace("{incident_type}", $IncidentType)
    $reason = $reason.Replace("{min_severity}", $MinSeverity)
    $reason = $reason.Replace("{min_severity_or_higher}", $minSevOrHigher)
    $reason = $reason.Replace("{count}", $Count.ToString())
    $reason = $reason.Replace("{window_minutes}", $WindowMinutes.ToString())

    return $reason
}

function Add-JournalEntry {
    param(
        [string] $Path,
        [string] $Text
    )

    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $line = "* [$timestamp] $Text"

    # Ensure directory exists
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    Add-Content -Path $Path -Value $line -Encoding UTF8
}

function Invoke-IncidentAutoTune {
    param(
        [string] $AxisStatePath,
        [string] $PolicyPath,
        [string] $AutoTuneQueuePath,
        [string] $MetricsPath,
        [string] $AutonomyJournalPath
    )

    if (-not (Test-Path $AxisStatePath)) {
        throw "Axis state file not found at '$AxisStatePath'"
    }
    if (-not (Test-Path $PolicyPath)) {
        throw "Incident AutoTune policy config not found at '$PolicyPath'"
    }

    $state = Get-Content $AxisStatePath -Raw | ConvertFrom-Json
    $config = Get-Content $PolicyPath -Raw | ConvertFrom-Json
    $now = Get-Date

    if (-not $config.policies) {
        Write-Host "[IncidentAutoTune] No policies defined, nothing to do." -ForegroundColor Yellow
        return @{
            incidents_considered = 0
            policies_evaluated   = 0
            proposals_created    = 0
        }
    }

    if (-not $state.security) {
        $state | Add-Member -NotePropertyName security -NotePropertyValue (@{})
    }
    if ($null -eq $state.security.PSObject.Properties['incidents']) {
        $state.security | Add-Member -NotePropertyName incidents -NotePropertyValue @()
    }
    if ($state.security.incidents -isnot [Array]) {
        $state.security.incidents = @($state.security.incidents)
    }

    $allIncidents = $state.security.incidents
    $incidentsCount = if ($allIncidents) { $allIncidents.Count } else { 0 }

    $queue = Get-OrInitAutoTuneQueue -Path $AutoTuneQueuePath

    $metricsSnapshot = @()
    $proposalsCreated = 0
    $policiesEvaluated = 0

    foreach ($pol in $config.policies) {
        $policiesEvaluated++

        $policyId = $pol.id
        $match = $pol.match
        $threshold = $pol.threshold
        $action = $pol.action

        if (-not $action -or $action.type -ne "autotune_proposal") {
            continue
        }

        $incidentType = if ($match.incident_type) { $match.incident_type } else { "*" }
        $minSeverity = $match.min_severity
        $windowMinutes = if ($match.time_window_minutes) { [int]$match.time_window_minutes } else { 1440 }
        $minCount = if ($threshold.min_count) { [int]$threshold.min_count } else { 1 }

        $windowStart = $now.AddMinutes(-1 * $windowMinutes)
        $minRank = Get-SeverityRank -Severity $minSeverity

        # Filter incidents in window
        $matchingIncidents = @()
        
        foreach ($inc in $allIncidents) {
            # Type match
            if ($incidentType -ne "*" -and $inc.type -ne $incidentType) {
                continue
            }

            # Severity match
            $incRank = Get-SeverityRank -Severity $inc.severity
            if ($minRank -gt 0 -and $incRank -lt $minRank) {
                continue
            }

            # Time window match
            if ($inc.opened_at) {
                try {
                    $openedAt = [datetime]::Parse($inc.opened_at)
                }
                catch {
                    # If parse fails, skip time filter and include
                    $openedAt = $null
                }
            }
            else {
                $openedAt = $null
            }

            if ($openedAt) {
                if ($openedAt -lt $windowStart -or $openedAt -gt $now) {
                    continue
                }
            }
            # else: no timestamp -> include (conservative)

            $matchingIncidents += $inc
        }

        $count = $matchingIncidents.Count

        $metricsSnapshot += [pscustomobject]@{
            policy_id           = $policyId
            incident_type       = $incidentType
            min_severity        = $minSeverity
            time_window_minutes = $windowMinutes
            count               = $count
            window_start        = $windowStart.ToString("o")
            window_end          = $now.ToString("o")
        }

        if ($count -lt $minCount) {
            continue
        }

        # Idempotency: check for existing open proposal for this policy + target
        if ($null -eq $queue.PSObject.Properties['proposals']) {
            $queue | Add-Member -NotePropertyName proposals -NotePropertyValue @()
        }
        elseif ($queue.proposals -isnot [Array]) {
            $queue.proposals = @($queue.proposals)
        }

        $targetScope = $action.target.scope
        $targetKey = $action.target.key

        $existing = $queue.proposals | Where-Object {
            $_.source -eq "Incident_AutoTune" -and
            $_.policy_id -eq $policyId -and
            $_.target_scope -eq $targetScope -and
            $_.target_key -eq $targetKey -and
            ($_.status -eq "open" -or $_.status -eq "pending" -or $_.status -eq "sim_pass")
        }

        if ($existing) {
            continue
        }

        # Build proposal
        $proposalId = New-AutoTuneProposalId
        $suggestion = $action.suggestion
        $toolName = if ($suggestion.tool) { $suggestion.tool } else { "SYSTEM" }
        $currentRisk = if ($suggestion.current_risk) { $suggestion.current_risk } else { "medium" }
        $suggestedRisk = if ($suggestion.suggested_risk) { $suggestion.suggested_risk } else { "high" }

        $reason = Format-ReasonFromTemplate `
            -Template        $action.reason_template `
            -IncidentType    $incidentType `
            -MinSeverity     $minSeverity `
            -Count           $count `
            -WindowMinutes   $windowMinutes

        $metricBasis = [ordered]@{
            calls          = $count
            fail_rate      = 0.0      # Not truly "failures", but required by existing UI
            incident_count = $count
            window_minutes = $windowMinutes
            incident_type  = $incidentType
            min_severity   = $minSeverity
        }

        $proposal = [ordered]@{
            id             = $proposalId
            tool           = $toolName
            current_risk   = $currentRisk
            suggested_risk = $suggestedRisk
            reason         = $reason
            metric_basis   = $metricBasis
            policy_id      = $policyId
            target_scope   = $targetScope
            target_key     = $targetKey
            source         = "Incident_AutoTune"
            status         = "open"
            created_at     = $now.ToString("o")
        }

        $queue.proposals += [pscustomobject]$proposal
        $proposalsCreated++

        # Journal entry
        $journalText = "Incident_AutoTune opened proposal $proposalId via policy $policyId (count=$count, window=${windowMinutes}m, target=$targetScope/$targetKey, tool=$toolName)."
        Add-JournalEntry -Path $AutonomyJournalPath -Text $journalText
    }

    # Persist AutoTune queue
    $queue | ConvertTo-Json -Depth 20 | Set-Content -Path $AutoTuneQueuePath -Encoding UTF8

    # Persist metrics snapshot (optional telemetry)
    $metricsPayload = [ordered]@{
        last_run_at = $now.ToString("o")
        metrics     = $metricsSnapshot
    }
    $metricsPayload | ConvertTo-Json -Depth 10 | Set-Content -Path $MetricsPath -Encoding UTF8

    return @{
        incidents_considered = $incidentsCount
        policies_evaluated   = $policiesEvaluated
        proposals_created    = $proposalsCreated
    }
}

# Entry point when run as a script
if ($MyInvocation.PSScriptRoot -ne "") {
    try {
        $result = Invoke-IncidentAutoTune `
            -AxisStatePath       $AxisStatePath `
            -PolicyPath          $PolicyPath `
            -AutoTuneQueuePath   $AutoTuneQueuePath `
            -MetricsPath         $MetricsPath `
            -AutonomyJournalPath $AutonomyJournalPath

        Write-Host "[IncidentAutoTune] Completed:" -ForegroundColor Cyan
        $result.GetEnumerator() | ForEach-Object {
            Write-Host ("  {0} = {1}" -f $_.Key, $_.Value)
        }
    }
    catch {
        Write-Error "[IncidentAutoTune] Failed: $_"
    }
}
