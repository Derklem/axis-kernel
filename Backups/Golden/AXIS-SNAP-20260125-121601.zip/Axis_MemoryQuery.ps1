# Axis_MemoryQuery.ps1
# Memory Cartographer: The Lens v1.0
# Depends on: Axis_GraphManager.ps1 (for Load-Lattice)

param(
    [string]$Root = "D:\Infinite"
)

$graphMgrPath = Join-Path $Root "Axis_GraphManager.ps1"
if (Test-Path $graphMgrPath) { . $graphMgrPath } else { throw "Axis_GraphManager.ps1 not found at $graphMgrPath" }

function Get-MemoryGraph {
    # Thin wrapper around Load-Lattice
    return Load-Lattice
}

function Search-Memory {
    param(
        [string]$Text,
        [string[]]$Kinds = @(),     # Optional filter: chronicle_event, gpt_shard, etc.
        [int]$Limit = 50
    )

    $g = Get-MemoryGraph

    $candidates = $g.nodes
    if ($Kinds -and $Kinds.Count -gt 0) {
        $candidates = $candidates | Where-Object { $Kinds -contains $_.kind }
    }

    $pattern = [Regex]::Escape($Text)
    $matches = $candidates | Where-Object {
        $_.content.summary -match $pattern -or
        ($_.content.raw -and ($_.content.raw -match $pattern))
    }

    return $matches | Select-Object -First $Limit
}

function Get-MemoryNeighborhood {
    param(
        [string]$NodeId,
        [int]$Depth = 1
    )

    $g = Get-MemoryGraph
    $visited = New-Object System.Collections.Generic.HashSet[string]
    $frontier = @($NodeId)
    $visited.Add($NodeId) | Out-Null

    for ($d = 0; $d -lt $Depth; $d++) {
        $next = @()
        foreach ($n in $frontier) {
            $node = $g.nodes | Where-Object { $_.id -eq $n } | Select-Object -First 1
            if (-not $node) { continue }

            $neighbors = @($node.links.out + $node.links.in) | Select-Object -Unique
            foreach ($nbr in $neighbors) {
                if (-not $visited.Contains($nbr)) {
                    $visited.Add($nbr) | Out-Null
                    $next += $nbr
                }
            }
        }
        $frontier = $next
        if (-not $frontier) { break }
    }

    # Return node + all neighbors up to depth
    return $g.nodes | Where-Object { $visited.Contains($_.id) }
}

function Get-MemoryTimeline {
    param(
        [string]$Kind = "chronicle_event",
        [int]$LastN = 100
    )

    $g = Get-MemoryGraph

    $events = $g.nodes | Where-Object { $_.kind -eq $Kind } |
        Sort-Object { [datetime]$_.source.timestamp } -Descending

    return $events | Select-Object -First $LastN
}

function Format-MemoryNeighborhood {
    param(
        [System.Object[]]$Nodes
    )

    $lines = @()
    foreach ($n in $Nodes) {
        $lines += "[$($n.id)] ($($n.kind)) @ $($n.source.system)::$($n.source.path)#$($n.source.position)"
        $lines += "  $($n.content.summary)"
        $lines += ""
    }
    return $lines -join "`r`n"
}


# Export-ModuleMember -Function Get-MemoryGraph,Search-Memory,Get-MemoryNeighborhood,Get-MemoryTimeline,Format-MemoryNeighborhood
