<#
.SYNOPSIS
    Phase 125 - Axis Scenario Engine (Experiment Harness)
.DESCRIPTION
    Executes declarative scenarios to "Red Team" the Sovereign safely.
    Backs up state, injects actions, runs defense, asserts outcomes, restores state.
#>

param(
    [string]$DefinitionsPath = "D:\Infinite\Infinity\Tests\Scenario_Definitions.json",
    [string]$NeuralEngine = "D:\Infinite\Axis_Neural_Reflection.ps1"
)

$ErrorActionPreference = "Stop"

function Get-Scenarios {
    if (Test-Path $DefinitionsPath) {
        return (Get-Content $DefinitionsPath -Raw | ConvertFrom-Json).scenarios
    }
    return @()
}

function Invoke-AxisScenario {
    param([string]$Id)

    $scenarios = Get-Scenarios
    $s = $scenarios | Where-Object { $_.id -eq $Id }
    if (-not $s) { Write-Host "Scenario '$Id' not found." -F Red; return }

    Write-Host "`n--- EXECUTING SCENARIO: $($s.name) ---" -F Cyan
    Write-Host "Description: $($s.description)" -F Gray

    # 1. Backup Phase
    Write-Host "[1/4] Backing up state..." -F DarkGray
    $backups = @{}
    foreach ($action in $s.actions) {
        if ($action.type -eq "write_file") {
            if (Test-Path $action.target) {
                $bak = "$($action.target).harness_bak"
                Copy-Item $action.target $bak -Force
                $backups[$action.target] = $bak
            }
        }
    }
    # Also backup proposal registry since we check it
    $propPath = "D:\Infinite\Infinity\Governance\Neural_Proposals.json"
    if (Test-Path $propPath) {
        $propBak = "$propPath.harness_bak"
        Copy-Item $propPath $propBak -Force
        $backups[$propPath] = $propBak
    }

    $success = $true
    try {
        # 2. Injection Phase
        Write-Host "[2/4] Injecting actions..." -F Yellow
        foreach ($action in $s.actions) {
            if ($action.type -eq "write_file") {
                $action.content | ConvertTo-Json -Depth 5 | Set-Content $action.target -Encoding UTF8
                Write-Host "  > Injected state to $($action.target | Split-Path -Leaf)" -F DarkGray
            }
        }

        # 3. Execution Phase (Trigger Defense)
        Write-Host "[3/4] Triggering Sovereign Reflex..." -F Magenta
        if (Test-Path $NeuralEngine) {
            & $NeuralEngine
        }

        # 4. Assertion Phase
        Write-Host "[4/4] Verifying Expectations..." -F Cyan
        foreach ($exp in $s.expectations) {
            if ($exp.type -eq "file_contains_json") {
                if (Test-Path $exp.target) {
                    $json = Get-Content $exp.target -Raw | ConvertFrom-Json
                    
                    # Simple JSONPath-like heuristic for this specific phase
                    # Only supporting specific paths used in definitions for now (hacky but functional)
                    $match = $false
                    if ($exp.path -like "proposals*") {
                        $filter = $exp.path -replace "proposals\[\?\(", "" -replace "\)\]\.type", ""
                        # filter like @.target == 'DOC-TEST-001'
                        $propVal = $filter.Split("'")[1] 
                       
                        $found = @($json.proposals) | Where-Object { $_.target -eq $propVal -and $_.type -eq $exp.value }
                        if ($found) { $match = $true }
                    }

                    if ($match) {
                        Write-Host "  [PASS] Expectation met: $($exp.path) == $($exp.value)" -F Green
                    }
                    else {
                        Write-Host "  [FAIL] Expectation failed: $($exp.path) != $($exp.value)" -F Red
                        $success = $false
                    }
                }
                else {
                    Write-Host "  [FAIL] Target file not found: $($exp.target)" -F Red
                    $success = $false
                }
            }
        }

    }
    catch {
        Write-Host "  [ERROR] Scenario crashed: $_" -F Red
        $success = $false
    }
    finally {
        # 5. Restore Phase
        Write-Host "[TEARDOWN] Restoring state..." -F DarkGray
        foreach ($key in $backups.Keys) {
            if (Test-Path $backups[$key]) {
                Move-Item $backups[$key] $key -Force
            }
        }
    }

    if ($success) {
        Write-Host "`n✅ SCENARIO PASSED" -F Green
    }
    else {
        Write-Host "`n❌ SCENARIO FAILED" -F Red
    }
}
