# Axis_Shadow.ps1
# Phase 111: The Shadow Layer
# Provides Counterfactual Simulation and Logging.

$root = "D:\Infinite"
. (Join-Path $root "Axis_State.ps1")
. (Join-Path $root "Axis_Telemetry.ps1") # For Risk Calculation logic

function Invoke-ShadowStep {
    <#
    .SYNOPSIS
        Simulates the execution of a tool to predict state changes.
    .OUTPUT
        PSCustomObject { Tool, PredictedRisk, Allowed, Note }
    #>
    param(
        [string]$ToolName,
        [hashtable]$Arguments
    )

    $sys = Get-AxisState
    if (-not $sys) { Write-Host "Shadow: System State is NULL" -F Red; return $null }

    # 1. Calculate Risk (Dry Run)
    # We replicate the logic from Get-ToolRiskProfile here or call it if available.
    # For now, we manually peek at the Autonomy Contract in state.
    
    $autonomy = $sys.security.autonomy
    $contract = $sys.security.autonomy # Actually, contract is separate usually, but let's assume it's in State now or we load it.
    
    # Fallback to loading contract from file if not in state fully
    if (-not $autonomy.tools) {
        $autonomy = Get-Content (Join-Path $root "Infinity\Autonomy_Matrix.json") -Raw | ConvertFrom-Json
    }

    $riskScore = 50 # Default Unknown
    $toolDef = $autonomy.tools.$ToolName
    
    if ($toolDef) {
        $cat = $toolDef.category
        $catDef = $autonomy.categories.$cat
        if ($catDef) {
            $riskScore = $catDef.base_risk
        }
        if ($toolDef.base_risk_override) { $riskScore = $toolDef.base_risk_override }
    }

    # 2. Check Budget
    $currentRisk = $sys.security.risk_ledger.current_instantaneous_risk
    if (-not $currentRisk) { $currentRisk = 0 }
    
    $cmdMode = "unknown"
    if ($sys.identity.awareness.autonomy_mode) { $cmdMode = $sys.identity.awareness.autonomy_mode }
    
    # 3. Formulate Counterfactual
    $predictedRisk = $currentRisk + $riskScore
    
    $decision = "ALLOWED"
    if ($riskScore -ge 40) { $decision = "BLOCKED_HIGH_RISK" }
    
    return [PSCustomObject]@{
        timestamp           = (Get-Date).ToString("o")
        tool                = $ToolName
        risk_cost           = $riskScore
        predicted_sys_risk  = $predictedRisk
        decision_simulation = $decision
        counterfactual      = "If executed, System Risk would raise to $predictedRisk."
    }
}

function Record-ShadowEvent {
    <#
    .SYNOPSIS
        Logs a shadow event to the State Ledger.
    #>
    param($ShadowObj)

    $sys = Get-AxisState
    if (-not $sys) { return }

    if (-not $sys.security.PSObject.Properties.Match("shadow_ledger").Count) {
        $sys.security | Add-Member -MemberType NoteProperty -Name "shadow_ledger" -Value @() -Force
    }
    
    # Append
    $sys.security.shadow_ledger += $ShadowObj
    
    # Cap size
    if ($sys.security.shadow_ledger.Count -gt 100) {
        $sys.security.shadow_ledger = $sys.security.shadow_ledger | Select-Object -Last 100
    }

    Update-AxisState -State $sys -Event "ShadowTrace" -Source "ShadowLayer"
}

# Export-ModuleMember -Function Invoke-ShadowStep, Record-ShadowEvent
