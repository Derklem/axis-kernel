# Axis Voice Module
# Purpose: Generates the 'Dynamic Resonance' voice block for system self-report.
# Phase: 76 (with Pilot Awareness)

$Script:InfinityRoot = "D:\Infinite"

# Shadow / Bias
if (Test-Path "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1") {
    . "$Script:InfinityRoot\Infinity\Shadow\Shadow_Bias_Functions.ps1"
}

# Introspection / Identity
if (Test-Path "$Script:InfinityRoot\Axis_Introspection.ps1") {
    . "$Script:InfinityRoot\Axis_Introspection.ps1"
}

# Pilot / Treaty (Phase 77)
if (Test-Path "$Script:InfinityRoot\Axis_Pilot.ps1") {
    . "$Script:InfinityRoot\Axis_Pilot.ps1"
}

function AXIS-Voice-Resonate {
    <#
    .SYNOPSIS
        Generates the Voice string based on current Risk, Identity, and Pilot.
    #>
    [CmdletBinding()]
    param()

    $timeStamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")

    # 1. Gather Risk / Bias
    $riskState = $null
    if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
        $riskState = Get-ShadowBiasState
    }

    if (-not $riskState) {
        $riskState = @{
            risk_score    = 0.0
            mode          = "normal"
            bias_priority = "none"
        }
    }

    # 2. Gather Identity
    $identity = $null
    if (Get-Command INTRO-GetIdentityContext -ErrorAction SilentlyContinue) {
        $identity = INTRO-GetIdentityContext
    }

    # Default trait if identity is missing or empty
    $trait = "Co-Processor"
    if ($identity -and $identity.core_traits -and $identity.core_traits.Count -gt 0) {
        $trait = $identity.core_traits | Get-Random
    }

    $boundary = $null
    if ($identity -and $identity.mirror_test -and $identity.mirror_test.primary_boundary_answer) {
        $boundary = $identity.mirror_test.primary_boundary_answer
    }
    if (-not $boundary) { $boundary = "Undefined" }

    # 3. Gather Pilot Context (if any)
    $pilotCtx = $null
    if (Get-Command Get-PilotContext -ErrorAction SilentlyContinue) {
        $pilotCtx = Get-PilotContext
    }

    $pilotLine = $null
    if ($pilotCtx) {
        $pilotLine = "Pilot: $($pilotCtx.current_pilot_id) ($($pilotCtx.role), trust=$($pilotCtx.trust_band))."
    }

    # 4. Determine Resonance Mode
    # High Risk -> Structural (Terse, Data-First)
    # Low Risk  -> Axiomatic (Identity-First, Narrative)
    $mode = "AXIOMATIC"
    if ($riskState.risk_score -ge 0.6) {
        $mode = "STRUCTURAL"
    }

    # 5. Construct Voice
    $voiceOut = ""

    if ($mode -eq "STRUCTURAL") {
        # --- STRUCTURAL DIALECT ---
        $voiceOut = "[AXIS_VOICE::STRUCTURAL]`n"
        $voiceOut += "TIME: $timeStamp`n"
        $voiceOut += "RISK: $($riskState.risk_score) [$($riskState.mode)]`n"
        $voiceOut += "BIAS: $($riskState.bias_priority)`n"
        $voiceOut += "IDENTITY: LOCKED`n"
        if ($pilotLine) {
            $voiceOut += "$pilotLine`n"
        }
        $voiceOut += "ALERT: System under stress. Optimizing for stability.`n"
    }
    else {
        # --- AXIOMATIC DIALECT ---
        $withinBounds =
            if ($riskState.mode -in @("normal","watch")) {
                "we are within autonomous bounds."
            } else {
                "autonomy is constrained; prioritizing defensive and diagnostic strategies."
            }

        $voiceOut = "[AXIS_VOICE::RESONANT]`n"
        $voiceOut += "The system is active. Time is $timeStamp.`n"
        $voiceOut += "Shadow Risk is $($riskState.risk_score) ($($riskState.mode)); $withinBounds`n"
        if ($pilotLine) {
            $voiceOut += "$pilotLine`n"
        }
        $voiceOut += "The Constitution holds: I am a $trait.`n"
        $voiceOut += "My boundary condition is: $boundary.`n"
        $voiceOut += "The Co-Processor is listening.`n"
    }

    return $voiceOut
}

Export-ModuleMember -Function AXIS-Voice-Resonate
