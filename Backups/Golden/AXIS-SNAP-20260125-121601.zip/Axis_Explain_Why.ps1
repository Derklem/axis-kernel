# D:\infinite\Axis_Explain_Why.ps1
# v20.0 - Explain-Why Layer (Narrative Inspector)

param(
    [string]$RequestId,
    [string]$ThreadId,
    [int]$Last = 5
)

$queuePath = "D:\infinite\Infinity\Earth\Requests_Queue.json"
$simPath = "D:\infinite\Infinity\Sim_Trace.json"
$actionsPath = "D:\infinite\Infinity\Earth\Earth_Actions.json"

# ... (inside Explain-Thread) ...

# Earth Action (from Actions Log)
if ($actions -and $actions.actions) {
    $act = $actions.actions | Where-Object { $_.request_id -eq $req.id } | Select-Object -Last 1
    if ($act) {
        Write-Host ""
        Write-Host "--- EARTH ACTION ---" -ForegroundColor DarkCyan
        Write-Host ("Action ID  : {0}" -f $act.id)
        Write-Host ("Started    : {0}" -f (PrettyTime $act.started_at))
        Write-Host ("Finished   : {0}" -f (PrettyTime $act.finished_at))
        Write-Host ("Status     : {0}" -f $act.status)
        Write-Host ("Result     : {0}" -f $act.result)
    }
    else {
        Write-Host ""
        Write-Host "--- EARTH ACTION ---" -ForegroundColor DarkCyan
        Write-Host "No Earth action found for this request." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Summary:"
$riskTxt = if ($risk -ne $null) { "risk $risk" } else { "risk unknown" }
$anchorTxt = if ($req.anchor_decision) { "with anchor decision '$($req.anchor_decision.decision)'" } else { "with no recorded anchor decision" }
Write-Host ("  Tool {0} was requested at {1} with {2}, gated as '{3}', and {4}." -f `
        $req.tool, (PrettyTime $req.created_at), $riskTxt, $req.status, $anchorTxt)
}

$targets = Get-TargetThreads -ent $ent -queue $queue -ThreadId $ThreadId -RequestId $RequestId -Last $Last

if (-not $targets) {
    Write-Host "No threads selected; falling back to raw recent requests." -ForegroundColor Yellow

    $candidates = $queue.requests |
    Sort-Object created_at |
    Select-Object -Last $Last

    foreach ($r in $candidates) {
        $fakeThread = [pscustomobject]@{
            id         = "FAKE:" + $r.id
            request_id = $r.id
            sim_id     = $null
            summary    = "Synthetic thread (no Entanglement Index)."
        }
        Explain-Thread -thread $fakeThread -queue $queue -earth $earth -simTrace $simTrace -incLog $incLog -contract $contract
    }
}
else {
    if ($targets -isnot [System.Array]) { $targets = @($targets) }
    foreach ($t in $targets) {
        Explain-Thread -thread $t -queue $queue -earth $earth -simTrace $simTrace -incLog $incLog -contract $contract
    }
}
