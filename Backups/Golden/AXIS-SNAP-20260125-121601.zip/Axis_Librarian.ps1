# D:\infinite\Axis_Librarian.ps1
# v3.0 - The Semantic Librarian (Graph-Based)
# Manages the Wisdom Atrium via Axis_GraphManager

param($root = "D:\Infinite")

# Load Graph Manager
. (Join-Path $root "Axis_GraphManager.ps1")

$atriumPath = Join-Path $root "Infinity\Library\Wisdom_Atrium.json"

function Add-Wisdom {
    param($topic, $wisdom, $confidence = 1.0, $tags = @())
    
    $graph = Load-Graph -path $atriumPath
    
    # Generate ID
    $id = "NODE-" + (Get-Date).ToString("yyyyMMdd-HHmmss") + "-" + (Get-Random -Minimum 1000 -Maximum 9999)
    
    $node = New-Node -id $id -content "$($topic): $($wisdom)" -type "axiom" -tags $tags
    $graph = Add-NodeToGraph -graph $graph -node $node
    
    Save-Graph -graph $graph -path $atriumPath
    Write-Host "Librarian: Added Node [$id]" -ForegroundColor Green
    return $id
}

function Get-Wisdom {
    param($query)
    $graph = Load-Graph -path $atriumPath
    
    # Simple search for now
    $results = $graph.nodes | Where-Object { $_.content -like "*$query*" -or $_.tags -contains $query }
    return $results
}

function Add-KnowledgeLink {
    param($source, $target, $relation)
    $graph = Load-Graph -path $atriumPath
    $edge = New-Edge -sourceId $source -targetId $target -relation $relation
    $graph = Add-EdgeToGraph -graph $graph -edge $edge
    Save-Graph -graph $graph -path $atriumPath
    Write-Host "Librarian: Linked [$source] -> [$target] ($relation)" -ForegroundColor Cyan
}

Export-ModuleMember -Function Add-Wisdom, Get-Wisdom, Add-KnowledgeLink
