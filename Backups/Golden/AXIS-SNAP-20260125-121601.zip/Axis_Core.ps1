<#
.SYNOPSIS
    Axis Sovereign Core - Integrated Agent Protocol
.DESCRIPTION
    The Unified Heartbeat and Nervous System. 
    Maintains the Link, Monitors the Constellation, 
    and Queues Intents for the Axis Mind.
#>

$checkInterval = 60 # 60 Seconds
$logFile = "D:\infinite\primary_spark_log.txt"
$linkFile = "D:\infinite\Infinity\Nighthawk_Link.json"
$intentQueueFile = "D:\infinite\Intent_Queue.json"
$routerIP = "192.168.1.1"
$constellation = @("192.168.1.6", "192.168.1.7", "192.168.1.11")

# Simple in-memory state
$state = @{
    RouterLive          = $false
    RouterFailureCount  = 0
    ConstellationCount  = 0
    LastChronosDate     = (Get-Date).Date
    LastVisualTimestamp = $null
}

# --- FUNCTIONS ---

function Log-Event {
    param (
        [string]$Event,
        [string]$Details,
        [switch]$Anchor
    )

    $ts = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
    $tag = ""
    if ($Anchor) { $tag = "[ANCHOR_ATTENTION] " }

    $entry = @"
Timestamp: $ts
Entity: Axis Core
Event: $tag$Event
Details: $Details

"@
    Add-Content -Path $logFile -Value $entry -Encoding UTF8
    Write-Host "[CORE] $tag$Event"
}

function Initialize-IntentQueue {
    if (-not (Test-Path $intentQueueFile)) {
        $initial = @{
            version = 1
            intents = @()
        }
        $initial | ConvertTo-Json -Depth 5 | Set-Content -Path $intentQueueFile -Encoding UTF8
        Log-Event "INTENT_QUEUE_INIT" "Created new Intent_Queue.json"
    }
}

function Queue-Intent {
    param (
        [string]$Trigger,
        [string]$Severity,
        [hashtable]$Details
    )

    Initialize-IntentQueue

    $now = Get-Date
    $ts = $now.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    $id = "$ts-$Trigger"

    # Read existing queue
    $queueJson = Get-Content -Path $intentQueueFile -Raw -ErrorAction SilentlyContinue
    if (-not $queueJson) {
        $queue = @{
            version = 1
            intents = @()
        }
    }
    else {
        $queue = $queueJson | ConvertFrom-Json
    }

    $intent = [pscustomobject]@{
        id         = $id
        created_at = $ts
        trigger    = $Trigger
        severity   = $Severity
        source     = "Axis_Core"
        status     = "pending"
        details    = $Details
    }

    $queue.intents += $intent

    $queue | ConvertTo-Json -Depth 10 | Set-Content -Path $intentQueueFile -Encoding UTF8

    Log-Event "INTENT_QUEUED" "Trigger=$Trigger; Severity=$Severity; Id=$id"
}

# --- MAIN EXECUTION LOOP ---

Write-Host "--- AXIS CORE: AGENT PROTOCOL ACTIVE ---"
Log-Event "CORE_UPGRADE" "Axis Core engaged. Nervous System Online."

Initialize-IntentQueue

# Global state for file monitoring
$global:SystemGatesLastWrite = $null

while ($true) {
    # 1. CRITICAL_LINK_LOSS (router failure 3x)
    $routerLive = Test-Connection -ComputerName $routerIP -Count 1 -Quiet

    if ($routerLive) {
        if (-not $state.RouterLive) {
            Log-Event "ROUTER_RESTORED" "Router $routerIP is reachable again."
        }
        $state.RouterLive = $true
        $state.RouterFailureCount = 0
    }
    else {
        $state.RouterFailureCount++
        if ($state.RouterFailureCount -eq 1) {
            Log-Event "ROUTER_WARNING" "First failure pinging $routerIP."
        }
        elseif ($state.RouterFailureCount -ge 3 -and $state.RouterLive) {
            $state.RouterLive = $false
            Log-Event "CRITICAL_LINK_LOSS" "Router $routerIP failed 3 consecutive pings." -Anchor

            Queue-Intent -Trigger "CRITICAL_LINK_LOSS" -Severity "critical" -Details @{
                router_ip     = $routerIP
                failure_count = $state.RouterFailureCount
                last_seen_ok  = (Get-Date).AddSeconds( - ($checkInterval * 3)).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
    }

    # 2. CONSTELLATION_SHIFT (device count change)
    $activeSats = 0
    foreach ($sat in $constellation) {
        if (Test-Connection -ComputerName $sat -Count 1 -Quiet) { $activeSats++ }
    }

    if ($activeSats -ne $state.ConstellationCount) {
        $old = $state.ConstellationCount
        $state.ConstellationCount = $activeSats

        Log-Event "CONSTELLATION_SHIFT" "Active satellites: $old -> $activeSats" -Anchor

        Queue-Intent -Trigger "CONSTELLATION_SHIFT" -Severity "info" -Details @{
            previous_count = $old
            current_count  = $activeSats
            nodes          = $constellation
        }
    }

    # 3. SYSTEM_GATE_CONTACT (System_Gates.json update)
    $systemGatesPath = "D:\infinite\Infinity\Archives\System_Gates.json"
    if (-not $global:SystemGatesLastWrite) {
        if (Test-Path $systemGatesPath) {
            $global:SystemGatesLastWrite = (Get-Item $systemGatesPath).LastWriteTimeUtc
        }
        else {
            $global:SystemGatesLastWrite = Get-Date "2000-01-01"
        }
    }

    if (Test-Path $systemGatesPath) {
        $currentWrite = (Get-Item $systemGatesPath).LastWriteTimeUtc
        if ($currentWrite -gt $global:SystemGatesLastWrite) {
            $global:SystemGatesLastWrite = $currentWrite

            Log-Event "SYSTEM_GATE_CONTACT" "System_Gates.json was updated." -Anchor

            Queue-Intent -Trigger "SYSTEM_GATE_CONTACT" -Severity "medium" -Details @{
                path          = $systemGatesPath
                last_modified = $currentWrite.ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
    }

    # 4. CHRONOS_PULSE (Daily Standup) & Pulse Visual
    $today = (Get-Date).Date
    if ($today -gt $state.LastChronosDate) {
        $state.LastChronosDate = $today
        Log-Event "CHRONOS_PULSE" "Daily standup tick." -Anchor
        Queue-Intent -Trigger "CHRONOS_PULSE" -Severity "info" -Details @{ date = $today.ToString("yyyy-MM-dd") }
    }
    
    # 5. RETINA (Visual Contact)
    $visualPath = "D:\infinite\Retina\visual_events.json"
    if (Test-Path $visualPath) {
        $currentVisualWrite = (Get-Item $visualPath).LastWriteTimeUtc
        if (-not $state.LastVisualTimestamp -or $currentVisualWrite -gt $state.LastVisualTimestamp) {
            $state.LastVisualTimestamp = $currentVisualWrite
            Log-Event "VISUAL_CONTACT" "New Retina events detected at $visualPath."
            Queue-Intent -Trigger "VISUAL_CONTACT" -Severity "info" -Details @{
                path          = $visualPath
                last_modified = $currentVisualWrite.ToString("yyyy-MM-ddTHH:mm:ssZ")
            }
        }
    }

    # 6. PROCESS WATCHDOGS (v16.2)
    $watchdogs = @(
        @{ name = "Axis_Mind"; path = "D:\infinite\mind_log.txt"; max_min = 15; remediate = $null }
        @{ name = "Earth_Server"; path = "D:\infinite\Infinity\Earth\Earth_Log.json"; max_min = 15; remediate = $null }
        @{ name = "Glassworm"; path = "D:\infinite\Infinity\Glassworm_Log.txt"; max_min = 1440; remediate = "D:\infinite\Glassworm.ps1" }
        @{ name = "Entangle"; path = "D:\infinite\Infinity\Entanglement_Index.json"; max_min = 1440; remediate = "D:\infinite\Entangle.ps1" }
    )

    foreach ($w in $watchdogs) {
        $lastTime = $null
        if (Test-Path $w.path) {
            if ($w.path.EndsWith(".txt")) {
                $line = Get-Content $w.path -Tail 1
                if ($line -match '^\[(?<ts>[^]]+)\]') { $lastTime = [datetime]$matches['ts'] }
            }
            elseif ($w.path.EndsWith(".json")) {
                try {
                    $j = Get-Content $w.path -Raw | ConvertFrom-Json
                    if ($w.name -eq "Earth_Server" -and $j.history) { $lastTime = [datetime]$j.history[-1].timestamp }
                    elseif ($w.name -eq "Entangle" -and $j.last_updated) { $lastTime = [datetime]$j.last_updated }
                }
                catch {}
            }
        }
        
        if ($lastTime) {
            $age = (New-TimeSpan -Start $lastTime -End (Get-Date)).TotalMinutes
            if ($age -gt $w.max_min) {
                Log-Event "WATCHDOG_STALE_$($w.name)" "Stale for $([int]$age) min."
                if ($w.remediate) {
                    Log-Event "WATCHDOG_REMEDIATE" "Restarting $($w.name)..."
                    Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass -File $($w.remediate)" -WindowStyle Hidden
                }
                else {
                    # Soft Mode (Mind/Earth): Just Intent
                    Queue-Intent -Trigger "WATCHDOG_STALE" -Severity "warning" -Details @{ component = $w.name; age = $age }
                }
            }
        }
    }

    Write-Host "." -NoNewline
    Start-Sleep -Seconds $checkInterval
}
