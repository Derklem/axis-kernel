# Axis_Doctrine.ps1
# Phase 84: Doctrine Baseline

$Script:InfinityRoot = "D:\Infinite"
$Script:DoctrineRulesPath = "$Script:InfinityRoot\Infinity\Doctrine\Doctrine_Rules.json"

function DOCTRINE-GetRules {
    if (-not (Test-Path $Script:DoctrineRulesPath)) {
        return @{
            version     = 1
            doctrine_id = "AXIS-DOCTRINE-INIT"
            rules       = @()
        }
    }

    try {
        return Get-Content -Raw -LiteralPath $Script:DoctrineRulesPath | ConvertFrom-Json
    }
    catch {
        Write-Warning "DOCTRINE: Failed to read rules JSON. Returning empty."
        return @{
            version     = 1
            doctrine_id = "AXIS-DOCTRINE-RECOVER"
            rules       = @()
        }
    }
}

function DOCTRINE-SaveRules($doc) {
    $doc.last_saved_utc = (Get-Date).ToUniversalTime().ToString("o")
    try {
        $doc | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Script:DoctrineRulesPath -Encoding UTF8
    }
    catch {
        Write-Error "DOCTRINE: Failed to save rules. $_"
    }
}

function DOCTRINE-GetPolicyForStrategy {
    <#
    .SYNOPSIS
        Returns doctrine policy (if any) for a strategy under current context.
    #>
    param(
        [Parameter(Mandatory)][string]$StrategyId,
        [Parameter(Mandatory)]$Context
    )

    $doc = DOCTRINE-GetRules
    $rules = @($doc.rules) | Where-Object { $_.enabled }

    if (-not $rules -or $rules.Count -eq 0) { return $null }

    $shadowMode = $Context.shadow_global_mode
    $channelId = $Context.channel_id
    $tags = $Context.tags

    $matches = @()

    foreach ($rule in $rules) {
        # Strategy match
        if ($rule.match.strategy_ids_any -and
            -not ($rule.match.strategy_ids_any -contains $StrategyId)) { continue }

        # Shadow mode match
        if ($rule.match.shadow_global_modes -and
            -not ($shadowMode -in $rule.match.shadow_global_modes)) { continue }

        # Channel match (optional)
        if ($rule.match.channels_any -and
            $channelId -and
            -not ($channelId -in $rule.match.channels_any)) { continue }

        # Tag match (optional, relaxed)
        if ($rule.match.tags_any) {
            if (-not $tags) { continue }
            $intersect = $tags | Where-Object { $rule.match.tags_any -contains $_ }
            if (-not $intersect) { continue }
        }

        $matches += $rule
    }

    if ($matches.Count -eq 0) { return $null }

    # For now, pick the first. Later you can add explicit priority.
    return $matches[0].policy
}

function DOCTRINE-GetSummaryForLLM {
    $doc = DOCTRINE-GetRules
    $enabled = @($doc.rules) | Where-Object { $_.enabled }

    if (-not $enabled -or $enabled.Count -eq 0) {
        return "## DOCTRINE`nNo active doctrine rules."
    }

    $lines = @()
    foreach ($r in $enabled | Select-Object -First 10) {
        $modes = if ($r.match.shadow_global_modes) { $r.match.shadow_global_modes -join "," } else { "any" }
        $aut = $r.policy.autonomy
        $scopes = $r.scope
        $strats = if ($r.match.strategy_ids_any) { $r.match.strategy_ids_any -join "," } else { "any" }

        $lines += "- [$($r.rule_id)] [$scopes] When Shadow in {$modes} and strategy in {$strats} -> autonomy=$aut."
    }

    return "## DOCTRINE`n" + ($lines -join "`n")
}

# Export-ModuleMember -Function DOCTRINE-GetPolicyForStrategy, DOCTRINE-GetSummaryForLLM
