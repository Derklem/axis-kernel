<#
.SYNOPSIS
    Phase 118/119 - Governance Simulation Engine (CBO Pass)
.DESCRIPTION
    Predicts the impact of an AutoTune or Governance proposal by simulating 
    the configuration change and evaluating it against historical incident data.
#>

param(
    [string] $ProposalId,
    [string] $AutoTuneQueuePath = "D:\Infinite\Infinity\AutoTune_Queue.json",
    [string] $AxisStatePath = "D:\Infinite\Infinity\Axis_State.json",
    [string] $ConstraintsPath = "D:\Infinite\Infinity\Constitutional_Constraints.json"
)

$ErrorActionPreference = "Stop"

function Get-SeverityRank {
    param([string] $Severity)
    if (-not $Severity) { return 0 }
    switch ($Severity.ToLowerInvariant()) {
        "low" { return 1 }
        "medium" { return 2 }
        "high" { return 3 }
        "critical" { return 4 }
        default { return 0 }
    }
}

function Invoke-GovernanceSimulation {
    param([string] $ProposalId)

    $queueData = Get-Content $AutoTuneQueuePath -Raw | ConvertFrom-Json
    $props = if ($queueData.proposals) { $queueData.proposals } else { $queueData }
    $prop = $props | Where-Object { $_.id -eq $ProposalId }
    if (-not $prop) { throw "Proposal '$ProposalId' not found." }

    $constraints = if (Test-Path $ConstraintsPath) { Get-Content $ConstraintsPath -Raw | ConvertFrom-Json } else { @{} }
    $state = Get-Content $AxisStatePath -Raw | ConvertFrom-Json
    
    Write-Host "[SIM] Evaluating Proposal: $($prop.id) [Scope: $($prop.scope)]" -ForegroundColor Cyan

    $simStatus = "sim_pass"
    $predictedRiskIncrease = 0.0
    $reason = "Passed heuristic stability check."

    # Heuristic Logic
    if ($prop.scope -eq "doctrine") {
        # Doctrine Amendment Heuristics
        $beforeRank = Get-SeverityRank -Severity $prop.proposed_change.before.severity
        $afterRank = Get-SeverityRank -Severity $prop.proposed_change.after.severity

        if ($afterRank -lt $beforeRank) {
            # Loosening a rule
            $reason = "Loosening rule reduces friction. High confidence in stability."
        }
        else {
            # Tightening a rule
            $reason = "Tightening rule may increase autonomy blocking. Recommended window for observation."
        }
    }
    else {
        # Tool Calibration Heuristics (Phase 118)
        $newRiskRank = Get-SeverityRank -Severity $prop.suggested_risk
        $oldRiskRank = Get-SeverityRank -Severity $prop.current_risk
        
        if ($newRiskRank -gt $oldRiskRank -and $state.heartbeat.open_incidents -gt 5) {
            $simStatus = "sim_risk_increase"
            $reason = "Tightening constraints during high volume."
        }
    }

    # Certification Block
    $certification = [ordered]@{
        proposal_id = $ProposalId
        timestamp   = (Get-Date).ToString("o")
        status      = $simStatus
        forecasts   = @{
            system_stability_impact = if ($simStatus -eq "sim_pass") { "stable" } else { "volatile" }
        }
        note        = $reason
    }

    # Update Queue
    $prop.status = $simStatus
    if (-not $prop.PSObject.Properties.Match('certification').Count) {
        $prop | Add-Member -NotePropertyName certification -NotePropertyValue ([pscustomobject]$certification)
    }
    else {
        $prop.certification = [pscustomobject]$certification
    }

    $queueData | ConvertTo-Json -Depth 20 | Set-Content $AutoTuneQueuePath -Encoding UTF8
    Write-Host "[SIM] Result: $simStatus" -ForegroundColor Green
    return $certification
}

if ($ProposalId) {
    Invoke-GovernanceSimulation -ProposalId $ProposalId | Out-Null
}
