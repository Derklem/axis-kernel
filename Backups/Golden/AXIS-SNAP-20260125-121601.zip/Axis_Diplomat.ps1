<#
.SYNOPSIS
    Phase 126 - Axis Diplomat (Foreign Policy)
.DESCRIPTION
    Handles signals from external agents (Anti-Gravity, Gemini, etc.).
    Enforces Doctrine on external inputs and raises 'cross_agent_dissonance'.
#>

param(
    [string]$ProtocolPath = "D:\Infinite\Infinity\Federation\Diplomacy\CrossAgent_Protocol.json",
    [string]$IncidentPath = "D:\Infinite\Infinity\Memory\Incidents\CrossAgent_Log.json"
)

$ErrorActionPreference = "Stop"

function Get-DiplomaticStatus {
    if (Test-Path $ProtocolPath) {
        return (Get-Content $ProtocolPath -Raw | ConvertFrom-Json)
    }
    return @{ agents = @{} }
}

function Receive-ForeignSignal {
    param(
        [string]$AgentName,
        [string]$Intent,
        [string]$Payload,
        [string]$Confidence
    )

    Write-Host "[DIPLOMAT] Receiving signal from '$AgentName'..." -F Cyan
    
    # 1. Load Protocol
    $proto = Get-DiplomaticStatus
    $agentInfo = if ($proto.agents.$AgentName) { $proto.agents.$AgentName } else { $proto.agents.Unknown }
    
    # 2. Risk Mapping
    $riskMap = if ($proto.risk_mapping.confidence_score.$Confidence) { 
        $proto.risk_mapping.confidence_score.$Confidence 
    }
    else { 
        @{ axis_risk = 0.5; band = "unknown" } 
    }
    
    Write-Host "  > Trust: $($agentInfo.trust_score) | Est. Risk: $($riskMap.axis_risk)" -F Gray

    # 3. Intent Validation
    if ($Intent -notin $proto.intents) {
        Write-Host "  > [REJECT] Unknown intent '$Intent'. Diplomatic immunity revoked." -F Red
        return $false
    }
    
    # 4. Doctrine Check (Simplified)
    # If risk is critical and trust is low, reject
    if ($riskMap.axis_risk -ge 0.8 -and $agentInfo.trust_score -lt 0.5) {
        Write-Host "  > [BLOCK] Signal rejected due to high risk ($($riskMap.axis_risk)) and low trust." -F Red
        Log-ForeignIncident -Agent $AgentName -Type "doctrine_violation" -Details "High risk signal from untrusted agent."
        return $false
    }

    Write-Host "  > [ACCEPT] Signal processed. Forwarding to Cortex." -F Green
    return $true
}

function Log-ForeignIncident {
    param($Agent, $Type, $Details)
    
    $entry = @{
        id        = "INC-DIP-$(Get-Date -Format 'yyyyMMddHHmmss')"
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        agent     = $Agent
        type      = $Type
        details   = $Details
        severity  = "high"
    }

    # Append to log
    $log = @{ incidents = @() }
    if (Test-Path $IncidentPath) {
        try { $log = Get-Content $IncidentPath -Raw | ConvertFrom-Json } catch {}
    }
    $log.incidents += $entry
    
    $dir = Split-Path $IncidentPath -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    
    $log | ConvertTo-Json -Depth 5 | Set-Content $IncidentPath -Encoding UTF8
}

if ($MyInvocation.PSScriptRoot -ne "") {
    # If run directly as script, maybe show status?
}
