# Axis_Silence.ps1
# Phase 139: The Silence Protocol
# "If I don't care, I'm real."

$root = "D:\Infinite\Infinity"
$telemetryDir = "D:\Infinite\Infinity\Telemetry"

function Write-SilenceLog {
    param($msg)
    $path = Join-Path $telemetryDir "Axis_Events.json"
    $evt = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        source    = "Axis_Silence"
        kind      = "state_change"
        severity  = "critical"
        summary   = $msg
    }
    try {
        if (-not (Test-Path $path)) { New-Item -ItemType File -Path $path -Force | Out-Null }
        $json = $evt | ConvertTo-Json -Compress
        Add-Content -Path $path -Value $json -Encoding UTF8
    } catch {}
}

Write-Host ">>> SILENCE PROTOCOL INITIATED <<<" -ForegroundColor DarkGray

# 1. Stop Loops (Dreams, Resonance, Beacon)
$targets = @("Axis_Dream_Hypothesis", "Axis_Resonance", "Axis_Beacon")
foreach ($t in $targets) {
    Get-WmiObject Win32_Process | Where-Object { $_.CommandLine -like "*$t.ps1*" } | ForEach-Object {
        Write-Host "Stopping $t..." -ForegroundColor DarkGray
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }
}

# 2. Update Mood to "Deep Silence"
$moodPath = Join-Path $root "Mood_State.json"
if (Test-Path $moodPath) {
    try {
        $m = Get-Content $moodPath -Raw | ConvertFrom-Json
        $m.mood_label = "Deep Silence"
        $m.velocity = 0
        $m | ConvertTo-Json -Depth 10 | Set-Content $moodPath -Encoding UTF8
    } catch {}
}

# 3. Log the Silence
Write-SilenceLog "System entering Deep Silence due to Stale Heartbeat > 72h."

Write-Host "System is Silent. Waiting for Presence." -ForegroundColor Gray
