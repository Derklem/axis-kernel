# Axis_Daily_Report.ps1
# Epoch 9: Reporting Surface - Daily / Windowed Summary

param(
    [int]$HoursBack = 24
)

$root = "D:\Infinite"
$reportCfgPath = Join-Path $root "Infinity\Report_Config.json"

if (-not (Test-Path $reportCfgPath)) {
    Write-Error "Report config not found: $reportCfgPath"
    exit 1
}

try {
    $cfg = Get-Content $reportCfgPath -Raw | ConvertFrom-Json
} catch {
    Write-Error "Failed to parse Report_Config.json: $_"
    exit 1
}

# Resolve paths
$reportRoot     = $cfg.report_root
$walkLogPath    = $cfg.sources.walk_log
$logPulsePath   = $cfg.sources.log_pulse
$latticePulsePath = $cfg.sources.lattice_pulse
$keeperLogPath  = $cfg.sources.keeper_log
$identityScript = $cfg.identity_script

if (-not (Test-Path $reportRoot)) {
    New-Item -ItemType Directory -Path $reportRoot -Force | Out-Null
}

# Time window
$now = Get-Date
$start = $now.AddHours(-[double]$HoursBack)

Write-Host "--- Axis Daily Report: Last $HoursBack hours ---" -ForegroundColor Cyan
Write-Host "Window: $($start.ToUniversalTime().ToString("o")) -> $($now.ToUniversalTime().ToString("o"))" -ForegroundColor Gray

function Read-JsonlWindow {
    param(
        [string]$Path
    )
    $events = @()

    if (-not (Test-Path $Path)) { return $events }

    Get-Content $Path | ForEach-Object {
        $line = $_.Trim()
        if ([string]::IsNullOrWhiteSpace($line)) { return }
        try {
            $obj = $line | ConvertFrom-Json
            # Expect "ts" at top-level ISO8601
            if ($obj.ts) {
                $t = [DateTime]::Parse($obj.ts)
                if ($t -ge $start -and $t -le $now) {
                    $events += $obj
                }
            } else {
                # If ts missing, keep it anyway with a null time
                $events += $obj
            }
        } catch {
            # Ignore malformed lines but could log if desired
        }
    }

    return $events
}

# Load event streams
$walkEvents        = Read-JsonlWindow -Path $walkLogPath
$logPulseEvents    = Read-JsonlWindow -Path $logPulsePath
$latticePulseEvents= Read-JsonlWindow -Path $latticePulsePath
$keeperEvents      = Read-JsonlWindow -Path $keeperLogPath

# Identity summary
$identitySummary = $null
if (Test-Path $identityScript) {
    try {
        $identityJson = & $identityScript -Mode Summary
        $identitySummary = $identityJson | ConvertFrom-Json
    } catch {
        $identitySummary = @{ error = "Failed to read Axis_Identity summary: $($_.Exception.Message)" }
    }
} else {
    $identitySummary = @{ error = "Axis_Identity.ps1 not found" }
}

# Helper: summarize Walk events
$walkSummary = @{
    total_events = $walkEvents.Count
    by_type      = @{}
    tasks        = @{}
    anomalies    = @()
}

foreach ($e in $walkEvents) {
    $t = $e.type
    if (-not $walkSummary.by_type.ContainsKey($t)) {
        $walkSummary.by_type[$t] = 0
    }
    $walkSummary.by_type[$t]++

    # Task-centric rollup for policy/execution events
    $taskId = $null
    $status = $null
    $decision = $null

    if ($e.data -and $e.data.task_id) {
        $taskId = $e.data.task_id
    }

    if ($e.type -eq "execution_result") {
        $status = $e.data.status
    } elseif ($e.type -eq "policy_decision") {
        $decision = $e.data.decision
    } elseif ($e.type -eq "manual_denial") {
        $decision = "DENIED"
    }

    if ($taskId) {
        if (-not $walkSummary.tasks.ContainsKey($taskId)) {
            $walkSummary.tasks[$taskId] = @{
                last_policy_decision = $null
                last_execution_status = $null
                seen = 0
            }
        }
        $taskInfo = $walkSummary.tasks[$taskId]
        $taskInfo.seen++

        if ($decision) { $taskInfo.last_policy_decision = $decision }
        if ($status)   { $taskInfo.last_execution_status = $status }
    }

    # Anomalies: non-success or PENDING / DENIED
    if ($status -and $status -ne "success") {
        $walkSummary.anomalies += @{
            ts      = $e.ts
            type    = $e.type
            task_id = $taskId
            status  = $status
            tool    = $e.data.tool
        }
    }
    if ($decision -and ($decision -ne "ALLOW")) {
        $walkSummary.anomalies += @{
            ts       = $e.ts
            type     = $e.type
            task_id  = $taskId
            decision = $decision
            tool     = $e.data.tool
        }
    }
}

# Helper: generic log summary
function Summarize-Events {
    param([array]$Events)

    $summary = @{
        total_events = $Events.Count
        by_type      = @{}
    }

    foreach ($e in $Events) {
        $t = $e.type
        if (-not $summary.by_type.ContainsKey($t)) {
            $summary.by_type[$t] = 0
        }
        $summary.by_type[$t]++
    }

    return $summary
}

$logPulseSummary     = Summarize-Events -Events $logPulseEvents
$latticePulseSummary = Summarize-Events -Events $latticePulseEvents
$keeperSummary       = Summarize-Events -Events $keeperEvents

# Build final report object
$reportId = "AREP-" + ([Guid]::NewGuid().ToString("N").Substring(0,12))
$reportObj = @{
    id            = $reportId
    generated_at  = $now.ToUniversalTime().ToString("o")
    window_hours  = $HoursBack
    window_start  = $start.ToUniversalTime().ToString("o")
    identity      = $identitySummary
    streams       = @{
        walk           = $walkSummary
        log_pulse      = $logPulseSummary
        lattice_pulse  = $latticePulseSummary
        keeper         = $keeperSummary
    }
}

# Write JSON report
$timestamp = $now.ToUniversalTime().ToString("yyyyMMdd-HHmmss")
$reportPath = Join-Path $reportRoot ("Axis_Daily_Report-" + $timestamp + ".json")

$reportObj | ConvertTo-Json -Depth 10 | Set-Content $reportPath -Encoding UTF8

Write-Host "Report written to: $reportPath" -ForegroundColor Green
