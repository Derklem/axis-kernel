# Axis_Ingest_Remote.ps1
# Phase 502: Remote Ingestion
# Processes JSON intents from Infinity\UI_Inbox
# and routes them through the Agency Triad (Policy + Executor).

$root = "D:\Infinite"
$inboxDir = Join-Path $root "Infinity\UI_Inbox"

# Triad Scripts
$policyScript = Join-Path $root "Axis_Agency_Policy.ps1"
$executorScript = Join-Path $root "Axis_Agency_Executor.ps1"
$reviewScript = Join-Path $root "Axis_Agency_Review.ps1"

if (-not (Test-Path $inboxDir)) {
    Write-Host "UI_Inbox not found at $inboxDir. Nothing to ingest." -ForegroundColor DarkGray
    exit 0
}

$files = Get-ChildItem $inboxDir -Filter "*.json" | Sort-Object CreationTime

foreach ($f in $files) {
    try {
        $uiIntent = Get-Content $f.FullName -Raw | ConvertFrom-Json

        Write-Host "Processing Remote Intent: $($uiIntent.verb)" -ForegroundColor Cyan

        switch ($uiIntent.verb) {

            # ---------------------------------------------------------
            # 1) REMOTE TOOL REQUEST
            # ---------------------------------------------------------
            "request_tool" {
                $params = $uiIntent.parameters
                $uiToolId = $params.tool       # e.g. "DREAM-RunSuite"
                $arguments = $params.arguments  # may be $null or a PSObject

                # Mapping Table: UI ID -> { Tool, Effect, Target }
                $toolMap = @{
                    "DREAM-RunSuite"          = @{
                        Tool   = "Axis_Dream_Engine.ps1"
                        Effect = "run_simulation"
                        Target = "AXIS_CORE"
                    }
                    "CORE-RestartMind"        = @{
                        Tool   = "Axis_Mind.ps1"
                        Effect = "interact"
                        Target = "HUMAN_ARCHITECT"
                    }
                    "CORE-FlushQueue"         = @{
                        Tool   = "Axis_Agency_Review.ps1"
                        Effect = "read_write_logs"
                        Target = "AXIS_CORE"
                    }
                    "CMD-ExecPlaybook"        = @{
                        Tool   = "Axis_Playbook.ps1"
                        Effect = "execute_runbook"
                        Target = "AXIS_CORE"
                    }
                    "NEURAL-Intake-Heartbeat" = @{
                        Tool   = "NEURAL-INTAKE-HEARTBEAT.ps1"
                        Effect = "log_heartbeat"
                        Target = "AXIS_NEURAL"
                    }
                }

                $mapping = $toolMap[$uiToolId]

                if (-not $mapping) {
                    Write-Warning "Unknown remote tool id '$uiToolId'. Ignoring."
                    Remove-Item $f.FullName -Force
                    continue
                }

                $toolName = $mapping.Tool
                $effect = $mapping.Effect
                $target = $mapping.Target

                # Construct Agency-style Intent
                $agencyIntent = @{
                    id             = "RINT-" + [Guid]::NewGuid().ToString("N").Substring(0, 8)
                    created_at     = (Get-Date).ToUniversalTime().ToString("o")
                    source         = "REMOTE_UI"
                    ui_tool_id     = $uiToolId
                    proposed_edges = @(
                        @{
                            tool          = $toolName
                            target_entity = $target
                            effect        = $effect
                            args          = $arguments
                        }
                    )
                }

                $intentJson = $agencyIntent | ConvertTo-Json -Depth 6 -Compress

                # 1) Policy: classify the intent (ALLOW / PENDING / DENIED)
                $decisionJson = $intentJson | & $policyScript
                $decisionObj = $decisionJson | ConvertFrom-Json
                $edgeDecision = $decisionObj.decisions[0]

                $dec = $edgeDecision.decision
                $color = "Gray"
                if ($dec -eq "ALLOW") { $color = "Green" }
                elseif ($dec -eq "PENDING") { $color = "Yellow" }
                elseif ($dec -eq "DENIED") { $color = "Red" }

                Write-Host " [REMOTE-POLICY] $($toolName) -> $dec ($($edgeDecision.policy_applied))" -ForegroundColor $color

                # 2) Executor: executes ALLOW or queues PENDING into Agency Pending Queue
                if ($dec -ne "DENIED") {
                    $reportJson = $decisionJson | & $executorScript
                    $reportObj = $reportJson | ConvertFrom-Json
                    $result = $reportObj.results[0]

                    Write-Host " [REMOTE-EXEC] Status: $($result.status)" -ForegroundColor Gray
                    
                    # 3) GENERATE UI RESULT (For Axis_Heartbeat_Server feedback loop)
                    # We must mimic Earth Server output format so the UI picks it up.
                    $resDir = Join-Path $root "Infinity\Earth\Results"
                    if (-not (Test-Path $resDir)) { New-Item -ItemType Directory -Force -Path $resDir | Out-Null }
                    
                    $resFilename = "RES-RINT-$(Get-Date -Format 'yyyyMMddTHHmmss')-$($uiToolId).json"
                    $resPath = Join-Path $resDir $resFilename
                    
                    $uiResult = @{
                        id        = $reportObj.intent_id
                        tool      = $uiToolId
                        status    = $result.status
                        output    = if ($result.output) { $result.output } else { "Executed $uiToolId" }
                        timestamp = (Get-Date).ToUniversalTime().ToString("o")
                    }
                    
                    $uiResult | ConvertTo-Json -Depth 5 | Set-Content $resPath -Encoding UTF8
                }
                else {
                    Write-Host " [REMOTE-EXEC] Skipped (DENIED)" -ForegroundColor Red
                }
            }

            # ---------------------------------------------------------
            # 2) REMOTE ANCHOR DECISION (APPROVE / DENY)
            # ---------------------------------------------------------
            "anchor_decision" {
                $params = $uiIntent.parameters
                $reqId = $params.request_id  # intent_id from Pending Queue
                $decRaw = $params.decision    # "approve" or "deny"

                if (-not $reqId) {
                    Write-Warning "anchor_decision missing request_id."
                    break
                }

                $decisionWord = if ($decRaw -eq "approve") { "Allow" } else { "Deny" }

                if (-not (Test-Path $reviewScript)) {
                    Write-Error "Axis_Agency_Review.ps1 not found at $reviewScript"
                    break
                }

                Write-Host "Remote review: $reqId -> $decisionWord" -ForegroundColor Cyan
                & $reviewScript -Id $reqId -Decision $decisionWord | Out-String | Write-Host
            }

            default {
                Write-Warning "Unknown verb '$($uiIntent.verb)' in $($f.Name)."
            }
        }

        # Cleanup processed file
        Remove-Item $f.FullName -Force
    }
    catch {
        Write-Error "Failed to process $($f.Name): $_"
        # Rename to .err so it can be inspected later
        try {
            Rename-Item $f.FullName -NewName ($f.Name + ".err") -Force
        }
        catch {
            # If even rename fails, we just log and move on
        }
    }
}
