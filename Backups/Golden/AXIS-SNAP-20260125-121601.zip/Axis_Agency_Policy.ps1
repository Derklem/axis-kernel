# Axis_Agency_Policy.ps1
# Phase 302: The Policy Engine

param(
    [Parameter(ValueFromPipeline=$true)]
    [string]$IntentJson
)

$root = "D:\Infinite"
$policyPath = Join-Path $root "Infinity\Action_Policy.json"

if (-not (Test-Path $policyPath)) { Write-Error "Action Policy Missing"; exit 1 }
if ([string]::IsNullOrWhiteSpace($IntentJson)) { Write-Error "No Intent Provided"; exit 1 }

$policyDoc = Get-Content $policyPath -Raw | ConvertFrom-Json
$intent = $IntentJson | ConvertFrom-Json

$decisions = @()

foreach ($edge in $intent.proposed_edges) {
    $match = $null
    
    # scan rules
    foreach ($rule in $policyDoc.rules) {
        # Strict Exact Match
        if ($rule.target_entity -eq $edge.target_entity -and 
            $intent.source -ne $null -and
            $rule.tool -eq $edge.tool -and
            $rule.effect -eq $edge.effect) {
            $match = $rule
            break
        }
    }

    $status = "DENIED"
    $reason = "No matching policy rule found (Default Deny/Review)."
    $refs = @()

    if ($match) {
        $refs = $match.kernel_refs
        switch ($match.policy) {
            "auto" { 
                $status = "ALLOW" 
                $reason = "Authorized by Policy (Auto)."
            }
            "review_monitor" { 
                $status = "PENDING"
                $reason = "Policy requires Monitor/Review." 
            }
            "manual_review_only" { 
                $status = "PENDING"
                $reason = "Policy requires Manual Review."
            }
            "manual_consent_required" { 
                $status = "PENDING" 
                $reason = "Requires Explicit Consent String."
            }
            default { 
                $status = "DENIED"
                $reason = "Unknown policy type."
            }
        }
    } else {
        # Unmapped Edge -> Safety Fallback
        $status = "PENDING"
        $reason = "Unmapped Action. Requires Architect Review."
    }

    $decisions += @{
        tool = $edge.tool
        target_entity = $edge.target_entity
        effect = $edge.effect
        args = $edge.args
        decision = $status
        policy_applied = if ($match) { $match.policy } else { "default_fallback" }
        reason = $reason
        kernel_refs = $refs
    }
}

$decisionObj = @{
    intent_id = $intent.id
    timestamp = (Get-Date).ToUniversalTime().ToString("o")
    decisions = $decisions
}

$decisionObj | ConvertTo-Json -Depth 5
