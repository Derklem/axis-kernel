
# Axis_Outcome.ps1
# Phase 79: Anchor Verdict Channel

$Script:InfinityRoot = "D:\Infinite"
$Script:OutcomeInboxPath = "$Script:InfinityRoot\Infinity\Outcome\Outcome_Feedback_Inbox.json"

if (-not (Test-Path (Split-Path $Script:OutcomeInboxPath))) {
    New-Item -ItemType Directory -Force -Path (Split-Path $Script:OutcomeInboxPath) | Out-Null
}

function Get-OutcomeInbox {
    if (-not (Test-Path $Script:OutcomeInboxPath)) {
        return @{
            version          = 1
            inbox_id         = "AXIS-OUTCOME-FEEDBACK-001"
            generated_at_utc = (Get-Date).ToUniversalTime().ToString("o")
            items            = @()
        }
    }
    try {
        return Get-Content -Raw -LiteralPath $Script:OutcomeInboxPath | ConvertFrom-Json
    }
    catch {
        return @{
            version          = 1
            inbox_id         = "AXIS-OUTCOME-FEEDBACK-RECOVER"
            generated_at_utc = (Get-Date).ToUniversalTime().ToString("o")
            items            = @()
        }
    }
}

function Save-OutcomeInbox($doc) {
    try {
        $doc.generated_at_utc = (Get-Date).ToUniversalTime().ToString("o")
        $doc | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Script:OutcomeInboxPath -Encoding UTF8
    }
    catch {
        Write-Error "OUTCOME: Failed to save inbox. $_"
    }
}

function OUTCOME-EnqueueForReview {
    <#
    .SYNOPSIS
        Add a strategy outcome to the Anchor feedback inbox.
    #>
    param(
        [Parameter(Mandatory)][string]$StrategyId,
        [Parameter(Mandatory)][string]$Result,  # success|warning|failure
        [string]$PilotId,
        [string]$RunTimestampUtc,
        [string]$Notes
    )

    $doc = Get-OutcomeInbox
    $items = @($doc.items)

    $id = "OFB-{0}-{1}" -f (Get-Date -Format "yyyyMMddHHmmss"), ($StrategyId -replace "[^A-Za-z0-9]", "")
    $item = [ordered]@{
        feedback_id           = $id
        strategy_id           = $StrategyId
        run_timestamp_utc     = $RunTimestampUtc
        pilot_id              = $PilotId
        proposed_result       = $Result
        proposed_notes        = $Notes
        status                = "pending"
        anchor_verdict        = $null
        anchor_comment        = $null
        verdict_timestamp_utc = $null
    }

    $items += $item

    # prune to last N
    $maxItems = 200
    if ($items.Count -gt $maxItems) {
        $items = $items | Select-Object -Last $maxItems
    }

    $doc.items = $items
    Save-OutcomeInbox $doc
    
    Write-Host "OUTCOME: Item enqueued [$id]" -ForegroundColor Gray
    return $id
}

function OUTCOME-RecordAnchorVerdict {
    <#
    .SYNOPSIS
        Record Anchor's verdict for a specific feedback item and push it into Skill_Registry.
    #>
    param(
        [Parameter(Mandatory)][string]$FeedbackId,
        [Parameter(Mandatory)]
        [ValidateSet("success", "warning", "failure")]
        [string]$Verdict,
        [string]$Comment
    )

    $doc = Get-OutcomeInbox
    $item = @($doc.items) | Where-Object { $_.feedback_id -eq $FeedbackId }
    if (-not $item) {
        Write-Warning "OUTCOME: Feedback item [$FeedbackId] not found."
        return
    }

    if ($item.status -ne "pending") {
        Write-Host "OUTCOME: Feedback [$FeedbackId] already resolved ($($item.status))." -ForegroundColor Gray
        return
    }

    $now = (Get-Date).ToUniversalTime().ToString("o")
    $item.anchor_verdict = $Verdict
    $item.anchor_comment = $Comment
    $item.verdict_timestamp_utc = $now
    $item.status = "corrected"

    # Push into Skill Registry with high weight
    $shadowScore = 0.0
    $shadowMode = "unknown"
    if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
        $s = Get-ShadowBiasState
        if ($s) {
            $shadowScore = $s.risk_score
            $shadowMode = $s.mode
        }
    }

    if (Get-Command SKILL-RecordOutcome -ErrorAction SilentlyContinue) {
        # Option: treat Anchor verdict as a "weighted" entry by writing multiple times
        for ($i = 0; $i -lt 3; $i++) {
            SKILL-RecordOutcome `
                -StrategyId   $item.strategy_id `
                -Result       $Verdict `
                -PilotId      $item.pilot_id `
                -ShadowGlobal $shadowScore `
                -ShadowMode   $shadowMode `
                -Notes        ("AnchorVerdict: " + $Comment)
        }
    }

    Save-OutcomeInbox $doc
    Write-Host "OUTCOME: Verdict [$Verdict] recorded for [$FeedbackId]." -ForegroundColor Green
}

# Export-ModuleMember -Function OUTCOME-EnqueueForReview, OUTCOME-RecordAnchorVerdict, Get-OutcomeInbox
