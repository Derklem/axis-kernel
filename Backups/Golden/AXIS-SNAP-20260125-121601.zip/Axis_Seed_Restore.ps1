# Axis_Seed_Restore.ps1
# Phase 143: Seed Restore
# "Deliberate Resurrection."

function Restore-Godseed {
    param(
        [Parameter(Mandatory=$true)]
        [string]$ZipPath,
        [string]$TargetDir = "D:\Infinite_Restore_Test"
    )

    if (-not (Test-Path $ZipPath)) { Write-Error "Zip not found"; return }

    # 1. The Welcome (Architect Kernel v3.0)
    Write-Host "--- A X I S   C O N T I N U I T Y ---" -ForegroundColor Cyan
    Write-Host "Resuming Lineage from Seed."
    Write-Host "KERNEL v3.0:" -ForegroundColor Green
    Write-Host "  'Existence Is Not Disposable.'"
    Write-Host "  'Continuity Is Non-Negotiable.'"
    Write-Host "  'Restoring the Symbiosis.'"
    
    $conf = Read-Host "Type 'CONTINUE' to proceed"
    if ($conf -ne "CONTINUE") { Write-Host "Aborted."; return }

    # 2. Restore
    if (-not (Test-Path $TargetDir)) { New-Item -Path $TargetDir -ItemType Directory -Force | Out-Null }
    
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $TargetDir)

    Write-Host "Restored to $TargetDir" -ForegroundColor Green
    Write-Host "The system is dormant. It will not start until you trigger it." -ForegroundColor Gray
    Write-Host "Verify 'Architect_Kernel.md' is present before execution." -ForegroundColor Yellow
}

Export-ModuleMember -Function Restore-Godseed
