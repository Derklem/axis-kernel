<#
.SYNOPSIS
    Axis Mind (PowerShell Edition) - v15.0 (Autonomy Epoch)
.DESCRIPTION
    The Cognitive Engine. 
    1. Learns via Teach_Mind.json & Apply_Policy.json.
    2. Resolves incidents via Resolve_Incidents.json.
    3. Plans actions via Actions_Staged.json & Actions_Review.json.
    4. Analyzes patterns via Risk_Patterns.json.
    5. Suggests policy via Policy_Suggestions.json.
    6. Fuses events via Fusion_Timeline.json (Multi-Modal).
    7. Requests tools via Earth Engine (v13), Simulated (v14), Gated (v15).
    8. Reads Intent Queue and processes triggers.
    9. Logs incidents (including Retina events).
    10. Generates CHRONOS dashboards.
#>

# Core paths
# Fix root resolution: Prefer PSScriptRoot to avoid bad env vars
$root = if ($PSScriptRoot) { $PSScriptRoot } elseif ($env:AXIS_ROOT) { $env:AXIS_ROOT } else { "D:\infinite" }
Write-Host "DEBUG: Root='$root' PSScriptRoot='$PSScriptRoot' EnvAxisRoot='$env:AXIS_ROOT'" -ForegroundColor Magenta
$Script:InfinityRoot = $root
function Get-AxisPath([string]$rel) { Join-Path $root $rel }

$queuePath = Get-AxisPath "Infinity\Intent_Queue.json"              
$promptDir = Get-AxisPath "Mind_Prompts"
$constellationPath = Get-AxisPath "Infinity\Constellation_Index.json"
$routerHistoryPath = Get-AxisPath "Infinity\Router_Status_History.json"
$incidentLogPath = Get-AxisPath "Infinity\Incident_Log.json"
$visualEventsPath = Get-AxisPath "Retina\visual_events.json"
$teachPath = Get-AxisPath "Teach_Mind.json"
$uiInboxPath = Get-AxisPath "Infinity\UI_Inbox"
$heartbeatStatusPath = Get-AxisPath "Infinity\Heartbeat_Status.json"
$recommendationPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
$earthQueuePath = Get-AxisPath "Infinity\Earth\Requests_Queue.json"

function Part-Guid {
    return ([guid]::NewGuid().ToString().Split("-")[0])
}

# Ensure key directories exist
if (-not (Test-Path $promptDir)) { New-Item -ItemType Directory -Path $promptDir -Force | Out-Null }
if (-not (Test-Path $uiInboxPath)) { New-Item -ItemType Directory -Path $uiInboxPath -Force | Out-Null }

# Phase 52: Horizon Module
$horizonScript = Get-AxisPath "Axis_Horizon.ps1"
if (Test-Path $horizonScript) { . $horizonScript }
else { function Process-Horizon {} } # Stub

# Phase 54: The Covenant
$covenantScript = Get-AxisPath "Axis_Covenant.ps1"
if (Test-Path $covenantScript) { . $covenantScript }
else { 
    function Process-CovenantStress {} 
    function Process-CovenantRatification {}
}

# Imports
. (Join-Path $root "Axis_Telemetry.ps1")
. (Join-Path $root "Axis_GraphManager.ps1")
. (Join-Path $root "Axis_State.ps1")
. (Join-Path $root "Axis_Shadow.ps1")
. (Join-Path $root "Axis_Memory_Core.ps1")
. (Join-Path $root "Axis_Keeper.ps1")
. (Join-Path $root "Axis_Pathfinder.ps1")
. (Join-Path $root "Axis_Vector.ps1")
. (Join-Path $root "Axis_Chorus.ps1")
. (Join-Path $root "Axis_Unknowns.ps1")
# Phase 82: Autonomy Gate
if (Test-Path (Join-Path $root "Axis_AutonomyGate.ps1")) { 
    . (Join-Path $root "Axis_AutonomyGate.ps1") 
}
# Phase 83: Channel Registry
if (Test-Path (Join-Path $root "Infinity\Neural\Neural_Registry_Functions.ps1")) {
    . (Join-Path $root "Infinity\Neural\Neural_Registry_Functions.ps1")
}

# Phase 86: Playbook Engine
if (Test-Path (Join-Path $root "Axis_Playbook.ps1")) { 
    . (Join-Path $root "Axis_Playbook.ps1") 
}


# --- PHASE 111: SHADOW LAYER INTEGRATION ---
if (Test-Path (Join-Path $root "Axis_Shadow_Orchestrator.ps1")) {
    & (Join-Path $root "Axis_Shadow_Orchestrator.ps1") | Out-Null
}

function Test-AutonomyAllowance {
    param(
        [string]$ToolId,
        [PSCustomObject]$SimResult
    )
    
    $sys = Get-AxisState
    if (-not $sys) { return @{ allow = $false; reason = "State Offline" } }
    
    $autonomy = $sys.security.autonomy
    # Fallback if autonomy invalid
    if (-not $autonomy) { return @{ allow = $false; reason = "Autonomy Matrix Missing" } }
    
    # 1. Check Tool Definition
    $toolDef = $autonomy.tools.$ToolId
    $category = "unknown"
    $baseRisk = 50
    $autoPolicy = "manual_only"
    
    if ($toolDef) {
        $category = $toolDef.category
        if ($toolDef.base_risk_override) { $baseRisk = $toolDef.base_risk_override }
    }
    
    # 2. Check Category Logic
    $catDef = $autonomy.categories.$category
    if ($catDef) {
        if (-not $toolDef.base_risk_override) { $baseRisk = $catDef.base_risk }
        $autoPolicy = $catDef.auto_policy
    }
    
    # 3. Simulate Risk (Fusion)
    # If SimResult says HIGH risk (e.g. > 80), block regardless of policy?
    $simRisk = if ($SimResult) { $SimResult.risk_score } else { 0 }
    
    # Heuristic: If SimRisk is significantly higher than BaseRisk, use SimRisk
    $finalRisk = [Math]::Max($baseRisk, $simRisk)
    
    # 4. Mode Check (from State, not File)
    $mode = $sys.identity.awareness.autonomy_mode
    if (-not $mode) { $mode = "OBSERVE" } # Default safe
    
    # Decision Matrix
    if ($mode -eq "OBSERVE") {
        # Only ALLOW if risk is 0 (e.g. LOG- tools) AND policy is always
        if ($finalRisk -eq 0) { return @{ allow = $true; reason = "Observe Mode (Risk 0)" } }
        return @{ allow = $false; reason = "Observe Mode (Safe)" }
    }
    elseif ($mode -eq "RECOMMEND") {
        # Similar to OBSERVE but maybe allow low risk analysis?
        if ($category -eq "analysis" -and $finalRisk -lt 10) { return @{ allow = $true; reason = "Recommend Mode (Low Risk Analysis)" } }
        return @{ allow = $false; reason = "Recommend Mode (Approval Required)" }
    }
    elseif ($mode -eq "AUTO") {
        if ($autoPolicy -eq "manual_only") { return @{ allow = $false; reason = "Policy: Manual Only" } }
        if ($finalRisk -gt 40) { return @{ allow = $false; reason = "High Risk ($finalRisk)" } }
        
        # Check Budget... (Phase 110 Future)
        return @{ allow = $true; reason = "Auto Allowed (Risk $finalRisk)" }
    }
    
    return @{ allow = $false; reason = "Policy Fallback" }
}

function New-AxisRequest {
    param(
        [string]$ToolName,
        $ToolArgs
    )

    # 1) Simulation
    $isLog = $ToolName -match '^LOG-'
    $isSimTool = $ToolName -match '^SIM-' -or $ToolName -match '^DREAM-'

    if ($isLog) {
        $simResult = @{
            risk_score        = 0
            predicted_outcome = "Log entry"
            recommendation    = "Approve"
        }
    }
    else {
        # Check if Invoke-Simulation supports named ToolArgs, usually it uses loose dict?
        # Assuming Invoke-Simulation matches Request-Tool pattern
        $simResult = Invoke-Simulation -ToolName $ToolName -Args $ToolArgs
        if (-not $simResult) {
            $simResult = @{
                risk_score        = 100
                predicted_outcome = "Simulation failed"
                recommendation    = "Require_Approval"
            }
        }
    }

    $risk = $simResult.risk_score

    # 2) Shadow Layer
    try {
        if (Get-Command Invoke-ShadowStep -ErrorAction SilentlyContinue) {
            $shadow = Invoke-ShadowStep -ToolName $ToolName -Arguments $ToolArgs
            Record-ShadowEvent -ShadowObj $shadow
        }
    }
    catch {
        Mind-Log "SHADOW_ERR" "Failed to trace shadow for $ToolName : $_"
    }

    $reqId = "REQ-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$ToolName"

    # 3) Autonomy Gate (Phase 82 - Unified)
    $gateDecision = "pending"
    $gateNote = "Autonomy Check Pending"
    
    if (Get-Command GATE-CheckAutonomy -ErrorAction SilentlyContinue) {
        # Check Gate - PASS REQUEST ID
        $gate = GATE-CheckAutonomy -StrategyId $ToolName -RequestedMode "execute" -Caller "Axis_Mind" -RequestId $reqId
        
        if ($gate.decision -eq "auto_allow") {
            $gateDecision = "pending" # Still needs Earth to execute, but Gate says OK to proceed.
            # Actually, Earth expects 'pending' to run it.
        }
        elseif ($gate.decision -eq "escalate") {
            $gateDecision = "waiting_for_approval" # Holds it in Earth queue
            $gateNote = "Autonomy Escalated: " + ($gate.packet.reasons -join ", ")
        }
        elseif ($gate.decision -eq "deny") {
            $gateDecision = "denied"
            $gateNote = "Autonomy Denied: " + ($gate.packet.reasons -join ", ")
        }
    }
    else {
        # Fallback to legacy safety if Gate missing
        $gateDecision = "waiting_for_approval"
        $gateNote = "Autonomy Gate Offline - Defaulting to Safe Mode"
    }

    # Snapshot current contract mode for audit
    $contractPath = Get-AxisPath "Infinity\Autonomy_Contract.json"
    $modeSnapshot = "unknown"
    if (Test-Path $contractPath) {
        try {
            $contract = Get-Content $contractPath -Raw | ConvertFrom-Json
            $modeSnapshot = $contract.mode
        }
        catch {}
    }

    # 4) Enqueue to Earth
    $q = Load-Json $earthQueuePath
    if (-not $q) { $q = @{ version = 1; requests = @() } }
    if ($q.requests -isnot [Array]) { $q.requests = @($q.requests) }

    $req = @{
        id            = $reqId
        source        = "Axis_Mind"
        tool          = $ToolName
        arguments     = $Args
        status        = $gateDecision
        created_at    = (Get-Date -Format "s")
        sim_data      = $simResult
        gate_note     = $gateNote
        mode_snapshot = $modeSnapshot
    }

    # Only enqueue if not denied
    if ($gateDecision -ne "denied") {
        # Queue to Earth (Legacy/Execution)
        $q.requests += $req
        Save-Json $earthQueuePath $q
        
        Mind-Log "EARTH" "Request: $ToolName | Gate: $($gate.decision) | Status: $gateDecision"
    }
    else {
        Mind-Log "EARTH" "Request DENIED: $ToolName | Gate: $($gate.decision)"
    }

    return $reqId
}

function Request-Tool ($ToolName, $Args) {
    return New-AxisRequest -ToolName $ToolName -Args $Args
}



# Initialize System State
$Sys = Get-AxisState
if (-not $Sys) { Initialize-AxisState; $Sys = Get-AxisState }

# Phase 117: System Hygiene (DISABLED - Caused Instability)
# if (Get-Command Invoke-Cleanup -ErrorAction SilentlyContinue) {
#     if (-not $env:AXIS_NO_CLEAN) {
#         Invoke-Cleanup
#     }
# }

# Phase 116: Memory Expansion (The Echo)
if (Get-Command Import-LineageToMemory -ErrorAction SilentlyContinue) {
    Import-LineageToMemory
}


# Helper to load JSON safely
function Load-JsonSafe {
    param([string]$path)
    if (Test-Path $path) {
        try { return Get-Content $path -Raw -Encoding UTF8 | ConvertFrom-Json } catch { return $null }
    }
    return $null
}

# --- PHASE 31: HYPOTHESIS ENGINE (LOG-Hypothesize) ---

function Get-AnchorSignature {
    # Binds to 1569 anchor + machine identity
    $machine = $env:COMPUTERNAME
    $anchor = "1569"
    $raw = "$machine-$anchor"
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($raw)
    $hash = $sha.ComputeHash($bytes)
    return -join ($hash | ForEach-Object { $_.ToString("X2") })
}

function Get-HypothesisQueue {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        return @{
            version          = 1
            anchor_id        = "1569"
            anchor_signature = (Get-AnchorSignature)
            hypotheses       = @()
        }
    }
    return Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Save-HypothesisQueue {
    param(
        [string]$Path,
        [hashtable]$Queue
    )
    $Queue | ConvertTo-Json -Depth 10 | Set-Content $Path -Encoding UTF8
}

function New-HypothesisId {
    $stamp = (Get-Date).ToUniversalTime().ToString("yyyyMMdd-HHmmss")
    $rand = -join ((48..57 + 97..122) | Get-Random -Count 4 | ForEach-Object { [char]$_ })
    return "HYP-$stamp-$rand"
}

function Add-Hypothesis {
    param(
        [hashtable]$Queue,
        [string]$Question,
        [string]$HypothesisText,
        [string[]]$Metrics,
        [string[]]$Events,
        [string[]]$Tags,
        [string[]]$LinkedStrategies = @(),
        [double]$Confidence = 0.5,
        [string]$Priority = "medium"
    )

    $id = New-HypothesisId
    $now = (Get-Date).ToUniversalTime().ToString("o")

    $newHyp = @{
        id                = $id
        anchor_id         = "1569"
        anchor_signature  = (Get-AnchorSignature)
        source            = "INSIGHT_ENGINE"
        basis             = @{
            snapshot_id = "INSIGHT-SNAPSHOT" # Generic ref if non-specific
            metrics     = $Metrics
            events      = $Events
        }
        question          = $Question
        hypothesis        = $HypothesisText
        confidence        = $Confidence
        priority          = $Priority
        status            = "open"
        tags              = $Tags
        created_at        = $now
        last_reviewed_at  = $null
        linked_strategies = $LinkedStrategies
        notes             = $null
    }
    
    # De-dup logic (don't add the same question if it's already open)
    $exists = $Queue.hypotheses | Where-Object { $_.question -eq $Question -and $_.status -eq "open" }
    if (-not $exists) {
        $Queue.hypotheses += $newHyp
        Mind-Log "HYPOTHESIS" "Emergent Question: $Question"
        return $true
    }
    return $false
}

function Process-Hypothesize {
    # Phase 31: The Hypothesis Engine
    # bridge the gap between statistics and strategy.
    
    $insightPath = Get-AxisPath "Infinity\Insights_Snapshot.json"
    if (-not (Test-Path $insightPath)) { return }

    $insights = Load-JsonSafe -path $insightPath
    if (-not $insights) { return }

    $queuePath = Get-AxisPath "Infinity\Hypothesis_Queue.json"
    $queue = Get-HypothesisQueue -Path $queuePath
    
    # Cast to hashtable if it's a PSCustomObject from JSON
    if ($queue -is [PSCustomObject]) {
        $newQueue = @{
            version          = $queue.version
            anchor_id        = $queue.anchor_id
            anchor_signature = $queue.anchor_signature
            hypotheses       = @($queue.hypotheses)
        }
        $queue = $newQueue
    }

    $addedCount = 0

    # Rule 1: High Failure Rate Detection
    if ($insights.reliability_heatmap) {
        foreach ($toolName in $insights.reliability_heatmap.PSObject.Properties.Name) {
            $tool = $insights.reliability_heatmap.$toolName
            if ($tool.fail_rate -gt 25 -and $tool.volume -ge 3) {
                if (Add-Hypothesis -Queue $queue `
                        -Question "Why is tool '$toolName' failing in $($tool.fail_rate)% of cases?" `
                        -HypothesisText "High failure rate indicates policy friction, hardware timeout, or contract misalignment for $toolName." `
                        -Metrics @("reliability_heatmap.$toolName.fail_rate") `
                        -Events @() `
                        -Tags @("reliability", "failure", $toolName) `
                        -Priority "high") { $addedCount++ }
            }
        }
    }

    # Rule 2: Operational Bias (Hyper-Reflective)
    $pulse = $insights.operational_pulse
    if ($pulse -and $pulse.status -eq "Hyper-Reflective") {
        if (Add-Hypothesis -Queue $queue `
                -Question "Why is the system currently in a Hyper-Reflective state?" `
                -HypothesisText "A thought-to-action ratio of $($pulse.ratio) suggests the system is simulating heavily without executing real-world tool requests." `
                -Metrics @("operational_pulse.ratio") `
                -Events @() `
                -Tags @("pulse", "bias", "reflectivity") `
                -Priority "medium") { $addedCount++ }
    }

    # Rule 3: Correlation Anomaly (RF vs Warlord)
    if ($insights.correlations) {
        foreach ($corr in $insights.correlations) {
            if ($corr.trigger -eq "RF_SPIKE" -and $corr.correlation -lt 0.3) {
                if (Add-Hypothesis -Queue $queue `
                        -Question "Why is RF spike activity ($($corr.trigger)) not triggering Warlord response ($($corr.response))?" `
                        -HypothesisText "Low correlation ($($corr.correlation)) suggests either environmental noise or desensitized reconnaissance thresholds." `
                        -Metrics @("correlations.rf_warlord") `
                        -Events @() `
                        -Tags @("rf", "warlord", "security") `
                        -Priority "high") { $addedCount++ }
            }
        }
    }

    # Cap queue and save
    if ($addedCount -gt 0) {
        $queue.hypotheses = $queue.hypotheses | Sort-Object created_at -Descending | Select-Object -First 50
        Save-HypothesisQueue -Path $queuePath -Queue $queue
        Mind-Log "HYP-ENGINE" "Generated $addedCount new hypotheses."
    }
}

# --- PHASE 32: TEMPORAL REASONING (LOG-Temporal) ---

function Process-TemporalReasoning {
    # Phase 32: The Temporal Engine
    # Turn the Chronicle + Insights into time-based predictions.
    
    $forecastPath = Get-AxisPath "Infinity\Temporal_Forecast.json"
    $enginePath = Get-AxisPath "Axis_TemporalEngine.ps1"
    
    if (Test-Path $enginePath) {
        try {
            # Execute the engine
            powershell -ExecutionPolicy Bypass -File $enginePath
            Mind-Log "TEMPORAL" "Temporal Forecast updated."
            
            # Emit verified event for simulator
            Log-Incident -Type "TemporalForecastGenerated" -Severity "info" -Context @{ forecast_id = "TF-$(Get-Date -Format 'yyyyMMdd')" }
        }
        catch {
            Mind-Log "TEMPORAL_ERR" "Engine execution fail: $_"
        }
    }
}

function Process-UIInbox {
    param(
        [string]$inboxPath,
        [ref]$intentQueueRef,
        [ref]$queueRef
    )

    if (-not (Test-Path $inboxPath)) { Mind-Log "DEBUG" "Inbox path not found: $inboxPath"; return }
    $files = Get-ChildItem -Path $inboxPath -Filter *.json -File -ErrorAction SilentlyContinue
    if (-not $files) { Mind-Log "DEBUG" "No files found in inbox: $inboxPath"; return }

    Mind-Log "DEBUG" "Found $($files.Count) files in inbox."

    foreach ($file in $files) {
        $payload = Load-JsonSafe -path $file.FullName
        if (-not $payload -or $payload.type -ne "ui_intent") {
            Remove-Item $file.FullName -Force
            continue
        }

        # Phase 83: Channel Validation
        $channelValid = $false
        if (Get-Command NEURAL-ValidateChannel -ErrorAction SilentlyContinue) {
            # Mobile Obsidian sends source='Mobile_OBS_v9' (usually)
            # We map this to our Registry Channel ID 'NEURAL-CMD-MOBILE-001'
            # Or we check if the provided source matches specific criteria.
            # Simpler: The payload.source corresponds to a logic source.
            # Let's validate strictly against registry tags or allow 'Mobile_OBS_v9' as a trusted origin alias.
            
            # Note: Heartbeat Server writes the file, so it's trusted to have come from the endpoint.
            # We just want to check if the "Mobile" channel is enabled in registry.
            $regChannel = NEURAL-GetChannel -ChannelId "NEURAL-CMD-MOBILE-001"
            if ($regChannel -and $regChannel.status -eq "enabled") {
                $channelValid = $true
            }
            else {
                Mind-Log "SEC-WARN" "Mobile Channel Disabled or Missing. Dropping Intent."
            }
        }
        else {
            # Fallback if registry module missing (during boot)
            $channelValid = $true 
        }

        if (-not $channelValid) {
            Remove-Item $file.FullName -Force
            continue
        }
        
        $verb = $payload.verb
        $params = $payload.parameters

        switch ($verb) {
            "start_playbook" {
                $pbId = $params.playbook_id
                if ($pbId) {
                    Mind-Log "PLAYBOOK" "Requesting Playbook Execution: $pbId"
                    if (Get-Command PLAYBOOK-Execute -ErrorAction SilentlyContinue) {
                        PLAYBOOK-Execute -PlaybookId $pbId -Caller "Axis_Mind_UI"
                    }
                    else {
                        Mind-Log "ERROR" "Playbook Engine not available."
                    }
                }
            }
            "CMD_EXEC_PLAYBOOK" {
                # Mobile Command Channel Intent
                $pbId = if ($params.target) { $params.target } else { $params.playbook_id }
                if ($pbId) {
                    Mind-Log "MOBILE-CMD" "Executing Playbook from Mobile: $pbId"
                    if (Get-Command PLAYBOOK-Execute -ErrorAction SilentlyContinue) {
                        PLAYBOOK-Execute -PlaybookId $pbId -Caller "Mobile_Haptic"
                    }
                    else {
                        Mind-Log "ERROR" "Playbook Engine not available."
                    }
                }
                else {
                    Mind-Log "MOBILE-CMD" "Playbook ID missing in payload."
                }
            }

            "request_tool" {
                $tool = $params.tool
                $pArgs = $params.arguments
                
                if ($tool -eq "CMD-ExecPlaybook") {
                    $pbId = $pArgs.playbook_id
                    if ($pbId) {
                        Mind-Log "PLAYBOOK" "Redirecting CMD-ExecPlaybook: $pbId"
                        if (Get-Command PLAYBOOK-Execute -ErrorAction SilentlyContinue) {
                            PLAYBOOK-Execute -PlaybookId $pbId -Caller "Axis_Mind_Redir"
                        }
                    }
                }
                elseif ($tool) {
                    Request-Tool $tool $pArgs
                    Mind-Log "QUEUE" "Routed UI request for $tool to Request-Tool."
                }
            }

            "trigger_chronos_pulse" {
                $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
                $intent = [PSCustomObject]@{
                    id         = "$now-UI-CHRONOS"
                    created_at = $now
                    trigger    = "CHRONOS_PULSE"
                    severity   = "info"
                    source     = "Axis_Heartbeat_UI"
                    status     = "new"
                    details    = @{ note = "UI-triggered Chronos pulse" }
                }
                if (-not $intentQueueRef.Value) { $intentQueueRef.Value = @{ version = 1; intents = @() } }
                if ($intentQueueRef.Value.intents -isnot [Array]) { $intentQueueRef.Value.intents = @($intentQueueRef.Value.intents) }
                $intentQueueRef.Value.intents += $intent
                Write-Host "[UI-INBOX] Queued CHRONOS_PULSE." -ForegroundColor Magenta
            }
            "request_drill_sim_only" {
                $toolName = "ADMIN-Echo-Test"
                Mind-Log "UI-DRILL" "Processing UI Drill for $toolName"
                
                # Use New-AxisRequest to ensure compliance with Autonomy Contract
                # We flag it as a simulation tool so it can potentiallly run in OBSERVE mode if allowed
                $reqId = New-AxisRequest -ToolName $toolName -Args @() 
                Mind-Log "UI-DRILL" "Queued UI Drill: $toolName (ReqID: $reqId)"
            }

            "mobile_ping" {
                $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
                Mind-Log "UI-PING" "Mobile ping from $($payload.source) at $now. Reason: $($params.reason)"
                
                # Update Heartbeat Status with last_mobile_ping?
                # For now just Logging is sufficient to verify connectivity.
            }

            "anchor_decision" {
                $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
                Mind-Log "ANCHOR-DECISION" "Received remote decision from $($payload.source): $($params.decision) for $($params.request_id)"
                
                # Append to Approvals.json using 'decisions' array (matches Approve_HighRisk.ps1)
                $approvalsPath = Get-AxisPath "Infinity\Approvals.json"
                $approvals = Load-JsonSafe -path $approvalsPath

                if (-not $approvals) {
                    $approvals = @{
                        version   = 1
                        decisions = @()
                    }
                }

                if ($approvals.decisions -isnot [System.Array]) {
                    $approvals.decisions = @($approvals.decisions)
                }

                $decisionObj = [PSCustomObject]@{
                    request_id      = $params.request_id
                    anchor          = "Mobile_Anchor"
                    decision        = $params.decision
                    reason          = $params.reason
                    decided_at      = $now
                    applied_at      = $null
                    previous_status = "waiting_for_approval"
                }

                $approvals.decisions += $decisionObj
                Save-Json $approvalsPath $approvals
            }
            "ack_incident" {
                $incidentId = $params.incident_id
                if (-not $incidentId) {
                    Write-Host "[UI-INBOX] ACK Incident missing incident_id." -ForegroundColor Yellow
                }
                else {
                    $log = Load-IncidentLog
                    if ($log -and $log.incidents) {
                        $match = $log.incidents | Where-Object { $_.id -eq $incidentId }
                        if ($match) {
                            $match | ForEach-Object {
                                if (-not $_.PSObject.Properties.Match("acknowledged").Count) {
                                    $_ | Add-Member -MemberType NoteProperty -Name "acknowledged" -Value $true -Force
                                }
                                else { $_.acknowledged = $true }
                            }
                            Save-IncidentLog $log
                            Write-Host "[UI-INBOX] Incident $incidentId acknowledged." -ForegroundColor Green
                        }
                    }
                }
            }
            "resolve_hypothesis" {
                $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
                Mind-Log "HYPOTHESIS-RESOLUTION" "Received resolution request for $($params.hypothesis_id) from $($payload.source): $($params.resolution_status)"
                
                $toolArgs = @{
                    hypothesis_id     = $params.hypothesis_id
                    resolution_status = $params.resolution_status
                    status            = $params.status
                    resolution_source = "anchor_manual"
                    resolution_note   = $params.note
                    linked_changes    = $params.linked_changes
                }

                # Route through Central Gate
                # Note: If mode is RECOMMEND, this will still queue as waiting_for_approval unless we override.
                # However, since this comes from UI (Human), we might want to override to 'pending' if it's manual.
                # But Request-Tool doesn't know it's human.
                # Let's trust Request-Tool logic. If we are in RECOMMEND mode, even human actions technically wait?
                # No, Human Actions from UI should be 'Approved'.
                # But 'resolve_hypothesis' is an INTENT.
                # If I want it to execute immediately, I should ensure Request-Tool handles it or use the toolArgs to signal origin.
                # Actually, LOG- tools are auto-approved in OBSERVE.
                # In RECOMMEND/AUTO, LOG- tools simulate to 0 risk, so they will be Auto-Approved (risk 0 < 20).
                # So Request-Tool will return 'pending' automatically!
                
                Request-Tool "LOG-ResolveHypothesis" $toolArgs
                Mind-Log "QUEUE" "Routed resolution for $($params.hypothesis_id) to Request-Tool."
            }

            "set_autonomy_mode" {
                $newMode = $params.mode
                $contractPath = Get-AxisPath "Infinity\Autonomy_Contract.json"
                $contract = if (Test-Path $contractPath) { Get-Content $contractPath -Raw | ConvertFrom-Json } else { @{ version = 1; anchor_id = "1569" } }

                $oldMode = $contract.mode
                $contract.mode = $newMode
                $contract | ConvertTo-Json -Depth 10 | Set-Content $contractPath -Encoding UTF8

                # Add timeline event for audit
                $timelinePath = Get-AxisPath "Infinity\Events_Timeline.json"
                $timeline = Load-JsonSafe -path $timelinePath
                if (-not $timeline) { $timeline = @() }
                if ($timeline -isnot [Array]) { $timeline = @($timeline) } # Handle root array
                 
                $evt = @{
                    timestamp = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
                    source    = "Axis_Mind"
                    kind      = "AutonomyModeChanged"
                    msg       = "Autonomy mode changed from $oldMode to $newMode"
                    data      = @{ old_mode = $oldMode; new_mode = $newMode }
                }
                $timeline += $evt
                Save-Json $timelinePath $timeline

                Mind-Log "AUTONOMY" "Mode changed to $newMode by UI."
            }
            "resolve_autotune" {
                # { type: "ui_intent", verb: "resolve_autotune", parameters: { "proposal_id": "...", "decision": "accept" } }
                $propId = $params.proposal_id
                $dec = $params.decision
                
                $tunePath = Get-AxisPath "Infinity\AutoTune_Queue.json"
                $queue = Load-JsonSafe -path $tunePath
                if ($queue -and $queue.proposals) {
                    $prop = $queue.proposals | Where-Object { $_.id -eq $propId }
                    if ($prop) {
                        $prop.decision = $dec
                        $prop.decision_at = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
                        $prop.status = if ($dec -eq "accept") { "accepted" } else { "rejected" }
                        
                        if ($dec -eq "accept") {
                            # Apply Config Change directly
                            $regPath = Get-AxisPath "Infinity\Tool_Registry.json"
                            $reg = Load-JsonSafe -path $regPath
                            $targetTool = $reg.tools | Where-Object { $_.id -eq $prop.tool }
                            if ($targetTool) {
                                $oldRisk = $targetTool.risk
                                $targetTool.risk = $prop.suggested_risk
                                Save-Json $regPath $reg
                                Mind-Log "AUTOTUNE" "Applied tuning for $($prop.tool): Risk $oldRisk -> $($prop.suggested_risk)"
                            }
                        }
                        Mind-Log "AUTOTUNE" "Resolved proposal $($propId): $dec"
                    }
                    Save-Json $tunePath $queue
                }
            }
        }
        Remove-Item $file.FullName -Force
    }
}
$resolvePath = Get-AxisPath "Resolve_Incidents.json"
$actionsPath = Get-AxisPath "Infinity\Actions_Staged.json"
$actionsReviewPath = Get-AxisPath "Actions_Review.json"
$patternsPath = Get-AxisPath "Infinity\Risk_Patterns.json"
$policyPath = Get-AxisPath "Axis_Policy.json"
$suggestionsPath = Get-AxisPath "Infinity\Policy_Suggestions.json"
$applyPolicyPath = Get-AxisPath "Apply_Policy.json"
$fusionPath = Get-AxisPath "Infinity\Fusion_Timeline.json"
$earthQueuePath = Get-AxisPath "Infinity\Earth\Requests_Queue.json"
$configPath = Get-AxisPath "Axis_Config.json"
$mindLog = Get-AxisPath "mind_log.txt"

# Default Config (used if Axis_Config.json missing)
$Config = @{
    constellation = @{ alert_threshold_minutes = 15; critical_threshold_minutes = 60 }
    router        = @{ max_history = 50 }
    patterns      = @{ window_days = 7; storm_threshold = 3 }
    fusion        = @{ correlation_window_minutes = 5 }
    earth         = @{ enabled = $true }
}


# --- IO / LOGGING ---

function Mind-Log ($Trigger, $Message) {
    try {
        $ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $entry = "[$ts] [$Trigger] $Message"
        
        # 1. Main Mind Log (Text)
        for ($i = 0; $i -lt 5; $i++) {
            try {
                Add-Content -Path $mindLog -Value $entry -Encoding UTF8 -ErrorAction Stop
                break
            }
            catch { Start-Sleep -Milliseconds 200 }
        }
        
        # 2. Unified Telemetry (NDJSON)
        # We mirror high-interest events to the telemetry stream for the Cognitive Terminal
        $criticalTriggers = @("ERROR", "GATE", "VIOLATION", "PLAN_PASS", "RATIFIED", "RECONCILE", "SHADOW_INGEST")
        if ($Trigger -in $criticalTriggers -or $Message -match "escalated|denied|dissonance") {
            try {
                if (Get-Command Write-AxisEvent -ErrorAction SilentlyContinue) {
                    $sev = if ($Trigger -eq "ERROR") { "error" } else { "info" }
                    Write-AxisEvent -Source "Mind" -Kind $Trigger -Summary $Message -Severity $sev
                }
            }
            catch {}
        }

        Write-Host $entry
    }
    catch { Write-Host "Log Error: $_" }
}

function Load-Json ($path) {
    if (Test-Path $path) {
        try {
            $raw = Get-Content $path -Raw -Encoding UTF8
            if ($raw) { return $raw | ConvertFrom-Json }
        }
        catch { Mind-Log "ERROR" "Failed to load JSON $path : $_" }
    }
    return $null
}

function Save-Json ($path, $data) {
    try {
        $data | ConvertTo-Json -Depth 10 | Set-Content $path -Encoding UTF8
    }
    catch { Mind-Log "ERROR" "Failed to save JSON $path : $_" }
}

function Load-Config {
    $loaded = Load-Json $configPath
    if ($loaded) {
        $global:Config = $loaded
        Mind-Log "CONFIG" "Loaded Axis_Config.json"
    }
    else { Mind-Log "CONFIG" "Using default in-memory config." }
}
function Save-Config { Save-Json $configPath $global:Config; Mind-Log "CONFIG" "Config Updated." }

function Load-ConstellationIndex { Load-Json $constellationPath }
function Save-ConstellationIndex ($data) { Save-Json $constellationPath $data; Mind-Log "MEMORY" "Constellation Updated." }
function Load-RouterHistory { Load-Json $routerHistoryPath }
function Save-RouterHistory ($data) { Save-Json $routerHistoryPath $data; Mind-Log "MEMORY" "Router History Updated." }
function Load-IncidentLog { Load-Json $incidentLogPath }
function Save-IncidentLog ($data) { Save-Json $incidentLogPath $data; Mind-Log "MEMORY" "Incident Log Updated." }
function Load-Queue {
    param([string]$Path = $queuePath)
    return Load-Json $Path
}

function Save-Queue {
    param(
        [string]$Path = $queuePath,
        $Data
    )
    Save-Json $Path $Data
    if ($Path -eq $queuePath) {
        Mind-Log "QUEUE" "Queue Saved."
    }
}
function Load-Actions { $d = Load-Json $actionsPath; if (-not $d) { $d = @{ version = 1; plans = @() } }; return $d }
function Save-Actions ($data) { Save-Json $actionsPath $data; Mind-Log "ACTIONS" "Actions Updated." }

function Update-HeartbeatStatus {
    param(
        $EarthQueue = $null
    )

    $localSys = Get-AxisState
    if (-not $localSys) { return }

    $pending = 0
    if ($EarthQueue -and $EarthQueue.requests) {
        $pending = ($EarthQueue.requests | Where-Object { $_.status -eq 'waiting_for_approval' }).Count
    }

    if (-not $localSys.heartbeat) {
        $localSys | Add-Member -NotePropertyName "heartbeat" -NotePropertyValue @{
            version           = 1
            status            = "green"
            pulse_bpm         = 60
            pending_anchor    = 0
            generated_at      = (Get-Date).ToString("o")
            open_incidents    = 0
            pending_approvals = @()
            history           = @()
        } -Force
    }

    $hb = $localSys.heartbeat
    $hb.pending_anchor = $pending
    $hb.generated_at = (Get-Date).ToString("o")
    # Status could be derived from Risk Ledger or Health
    $hb.status = "green"

    if (-not $hb.history) { $hb.history = @() }
    
    # Simple Metrics
    $rfDensity = 0
    $lastScan = Get-AxisPath "Infinity\Scratch\last_rf_scan.json"
    if (Test-Path $lastScan) { try { $s = Get-Content $lastScan -Raw | ConvertFrom-Json; $rfDensity = $s.networks.Count } catch {} }

    $hb.history += @{
        t          = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        bpm        = 60
        ratio      = 0
        rf_density = $rfDensity
    }
    if ($hb.history.Count -gt 50) {
        $hb.history = $hb.history | Select-Object -Last 50
    }

    Update-AxisState -State $localSys -Event "HeartbeatTick" -Source "Mind"

    # Mirror for UI
    $hbPath = Get-AxisPath "Infinity\Heartbeat_Status.json"
    $hb | ConvertTo-Json -Depth 10 | Set-Content $hbPath -Encoding UTF8

    try { $host.UI.RawUI.WindowTitle = "AXIS SOVEREIGN | $($hb.status) | BPM: $($hb.pulse_bpm)" } catch {}
}

# --- EARTH ENGINE CLIENT (v13) + SIMULATION (v14) + CONTRACT (v15) ---
$simRequestPath = Get-AxisPath "Infinity\Sim_Request.json"
$simEnginePath = Get-AxisPath "Sim_Engine.ps1"
$contractPath = Get-AxisPath "Infinity\Autonomy_Contract.json"

function Invoke-Simulation ($ToolName, $Args) {
    if (-not (Test-Path $simEnginePath)) {
        Mind-Log "SIM" "Sim engine missing. Skipping."
        return $null
    }

    $simRequestPath = Get-AxisPath "Infinity\Sim_Request.json"

    # Create Request
    $req = @{ 
        id         = "SIMREQ-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$ToolName"
        tool       = $ToolName
        arguments  = $Args
        depth      = 0
        status     = "pending"
        created_at = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ") 
    }
    
    # Save Request for Engine
    $req | ConvertTo-Json -Depth 5 | Set-Content $simRequestPath
    Mind-Log "SIM" "Queued DEEP SIMULATION for $ToolName."

    # Run Deep Sim Engine
    # Note: Sim_Engine.ps1 sets AXIS_MODE='sim' then calls Earth_Server
    & $simEnginePath

    # Read Result
    if (Test-Path $simRequestPath) {
        try {
            $processed = Get-Content $simRequestPath -Raw | ConvertFrom-Json
            if ($processed -and $processed.status -eq "simulated" -and $processed.sim_result) {
                $res = $processed.sim_result
                Mind-Log "SIM" "Deep Sim Complete. Risk=$($res.risk_score) Trace=$($res.trace_id)"
                return $res
            }
        }
        catch { Mind-Log "SIM_ERR" "Failed to read sim result: $_" }
    }
    
    return @{ risk_score = 50; predicted_outcome = "Simulation Failed (Fallback)"; recommendation = "Require_Approval" }
}

function Get-ToolPolicy ($ToolName, $contract) {
    if (-not $contract -or -not $contract.gates.tool_policies) { return $null }
    foreach ($pattern in $contract.gates.tool_policies.PSObject.Properties) {
        $prefix = $pattern.Name.TrimEnd('*')
        if ($ToolName.StartsWith($prefix)) { return $pattern.Value }
    }
    return $null
}

    


# Alias for backward compatibility if needed, or just replace usages.
# We will replace usages, but keep alias safe for now.
function Request-Tool { param($ToolName, $Args) New-AxisRequest $ToolName $Args }

# --- INCIDENT + ACTIONS ---

function Ensure-ActionPlanForIncident ($incident) {
    $actions = Load-Actions
    if ($actions.plans | Where-Object { $_.incident_id -eq $incident.id }) { return }

    $template = $null
    switch ($incident.type) {
        "critical_link_loss" {
            $template = @{ summary = "Link Loss Plan"; recommended_steps = @("Check cable", "Check ISP") }
        }
        "visual_anomaly" {
            if ($incident.severity -ne "info") {
                $template = @{ summary = "Visual Anomaly Plan"; recommended_steps = @("Isolate source", "Check context") }
            }
        }
    }
    if ($template) {
        $actions.plans += @{
            id = "PLAN-$($incident.id)"; incident_id = $incident.id; incident_type = $incident.type; severity = $incident.severity;
            status = "suggested"; created_at = (Get-Date -Format "s"); summary = $template.summary; recommended_steps = $template.recommended_steps;
        }
        Save-Actions $actions
        Mind-Log "PLAN" "Plan PLAN-$($incident.id) created."
    }
}

function Log-Incident ($Type, $Severity, $Context) {
    $log = Load-IncidentLog; if (!$log) { $log = @{ version = 1; incidents = @() } }
    $entry = @{ id = "$(Get-Date -Format 'yyyyMMdd-HHmmss')-$Type"; timestamp = Get-Date -Format "s"; type = $Type; severity = $Severity; status = "open"; context = $Context }
    $log.incidents += $entry
    if ($log.incidents.Count -gt 100) { $log.incidents = $log.incidents[-100..-1] }
    Save-IncidentLog $log
    Mind-Log "INCIDENT" "$Type ($Severity) logged."
    Ensure-ActionPlanForIncident ([PSCustomObject]$entry)
}

# --- PROCESS HELPERS ---
function Process-Teaching {
    if (-not (Test-Path $teachPath)) { return }

    $t = Load-Json $teachPath
    $idx = Load-ConstellationIndex

    if ($t -and $idx -and $t.classifications) {
        foreach ($c in $t.classifications) {
            $n = $idx.nodes | Where-Object { $_.ip -eq $c.ip }
            if ($n) {
                if ($c.label) { $n.label = $c.label }
                if ($c.trust) { $n.trust = $c.trust }
            }
        }
        Save-ConstellationIndex $idx
        Mind-Log "TEACH" "Processed Teach_Mind.json into Constellation_Index."
    }
    try { Rename-Item $teachPath "Teach_Mind_PROCESSED_$(Get-Date -Format 'yyyyMMdd-HHmmss').json" -ErrorAction SilentlyContinue } catch { Mind-Log "TEACH" "Rename Error: $_" }
}

function Process-Resolution {
    if (Test-Path $resolvePath) {
        $r = Load-Json $resolvePath; $l = Load-IncidentLog
        if ($r -and $l) { foreach ($res in $r.resolutions) { $i = $l.incidents | Where-Object { $_.id -eq $res.incident_id }; if ($i) { $i.status = $res.status } } }
        Save-IncidentLog $l; Rename-Item $resolvePath "Resolve_Incidents_PROCESSED_$(Get-Date -Format 'yyyyMMdd-HHmmss').json"; Mind-Log "RESOLVED" "Processed."
    }
}
function Process-ActionReviews {
    if (Test-Path $actionsReviewPath) {
        $revs = Load-Json $actionsReviewPath; $acts = Load-Actions
        if ($revs -and $acts) { foreach ($r in $revs.reviews) { $p = $acts.plans | Where-Object { $_.id -eq $r.plan_id }; if ($p) { $p.status = $r.status } } }
        Save-Actions $acts; Rename-Item $actionsReviewPath "Actions_Review_PROCESSED_$(Get-Date -Format 'yyyyMMdd-HHmmss').json"; Mind-Log "PLAN_REVIEW" "Processed."
    }
}
function Process-ApplyPolicy {
    if (Test-Path $applyPolicyPath) {
        $apply = Load-Json $applyPolicyPath; $store = Load-Json $suggestionsPath
        if ($apply -and $store) {
            foreach ($dec in $apply.decisions) {
                $s = $store.suggestions | Where-Object { $_.id -eq $dec.policy_id }
                if ($s) {
                    if ($dec.action -eq "accept") {
                        $s.status = "accepted"
                        if ($s.scope -eq "constellation_thresholds") { $Global:Config.constellation.alert_threshold_minutes = $s.proposal.suggested_value; Save-Config }
                        elseif ($s.scope -eq "node_trust") { $idx = Load-ConstellationIndex; $n = $idx.nodes | Where-Object { $_.ip -eq $s.proposal.target_ip }; if ($n) { $n.trust = $s.proposal.suggested_trust; Save-ConstellationIndex $idx } }
                    }
                    else { $s.status = "rejected" }
                }
            }
            Save-Json $suggestionsPath $store; Rename-Item $applyPolicyPath "Apply_Policy_PROCESSED_$(Get-Date -Format 'yyyyMMdd-HHmmss').json"; Mind-Log "POLICY" "Applied."
        }
    }
}

# --- PATTERNS (v10) ---
function Process-Patterns ($allIncidents) {
    if (-not $allIncidents) { return $null }
    $window = $Config.patterns.window_days; if (!$window) { $window = 7 }
    $since = (Get-Date).AddDays(-$window)
    $recent = $allIncidents | Where-Object { [DateTime]$_.timestamp -ge $since }
    $byType = $recent | Group-Object type | ForEach-Object { @{type = $_.Name; count = $_.Count } }
    $byNode = $recent | Where-Object { $_.context.label -or $_.context.ip } | Group-Object { if ($_.context.label) { $_.context.label }else { $_.context.ip } } | ForEach-Object { @{label = $_.Name; count = $_.Count } }
    $patterns = @{ version = 1; window_days = $window; last_generated = (Get-Date -Format "s"); summary = @{ total_incidents = $recent.Count; by_type = $byType; by_node = $byNode } }
    Save-Json $patternsPath $patterns
    Mind-Log "PATTERNS" "Generated."
    return $patterns
}

# --- POLICY (v11 + FIX) ---
function Generate-PolicySuggestions ($patterns) {
    if (-not $patterns) { return $null }
    $policy = Load-Json $policyPath; if (!$policy) { return $null }
    $suggestions = @(); $now = Get-Date -Format "s"
    
    if ($policy.targets.incident_rates) {
        foreach ($prop in $policy.targets.incident_rates.PSObject.Properties) {
            $obs = $patterns.summary.by_type | Where-Object { $_.type -eq $prop.Name }
            if ($obs -and $obs.count -gt $prop.Value.max_per_week) {
                if ($prop.Name -eq "missing_trusted_node" -and $Global:Config.constellation.alert_threshold_minutes -gt 5) {
                    $suggestions += @{ id = "POLICY-$(Get-Date -Format 'yyyyMMdd-HHmmss')-01"; scope = "constellation_thresholds"; reason = "Incidents exceeded target"; proposal = @{suggested_value = ($Global:Config.constellation.alert_threshold_minutes - 5) } ; status = "pending" }
                }
            }
        }
    }
    
    if ($Global:Config.constellation) { 
        $idx = Load-ConstellationIndex
        if ($idx -and $idx.nodes) {
            foreach ($node in $idx.nodes) {
                if ($node.trust -eq "unclassified") {
                    $inPat = $patterns.summary.by_node | Where-Object { $_.label -eq $node.label -or $_.label -eq $node.ip }
                    if (-not $inPat) {
                        $suggestions += @{
                            id       = "POLICY-$(Get-Date -Format 'yyyyMMdd-HHmmss')-02"
                            scope    = "node_trust"
                            reason   = "Stable unclassified node"
                            proposal = @{target_ip = $node.ip; current_trust = "unclassified"; suggested_trust = "medium" }
                            status   = "pending"
                        }
                    }
                }
            }
        }
    }

    $store = Load-Json $suggestionsPath; if (!$store) { $store = @{version = 1; suggestions = @() } }
    
    foreach ($s in $suggestions) {
        $uniqueSuffix = ""
        if ($s.proposal.target_ip) { $uniqueSuffix = "-" + ($s.proposal.target_ip -replace '\.', '-') }
        elseif ($s.proposal.path) { $uniqueSuffix = "-config" }
        $s.id = $s.id + $uniqueSuffix
        $exists = $store.suggestions | Where-Object { $_.id -eq $s.id -and $_.status -eq 'pending' }
        if (-not $exists) { $store.suggestions += $s }
    }
    
    $store.generated_at = $now
    Save-Json $suggestionsPath $store
    Mind-Log "POLICY" "Suggestions Updated."
    return $store
}

# --- FUSION (v12) ---
function Build-FusionTimeline ($incidents, $router, $visual, $constellation) {
    $window = $Config.patterns.window_days; if (!$window) { $window = 7 }
    $deltaMin = $Config.fusion.correlation_window_minutes; if (!$deltaMin) { $deltaMin = 5 }
    $since = (Get-Date).AddDays(-$window)
    
    $recInc = if ($incidents) { $incidents | Where-Object { [DateTime]$_.timestamp -ge $since } } else { @() }
    $recVis = if ($visual -and $visual.events) { $visual.events | Where-Object { [DateTime]$_.timestamp -ge $since } } else { @() }
    $recRout = if ($router -and $router.history) { $router.history | Where-Object { [DateTime]$_.timestamp -ge $since } } else { @() }
    
    $episodes = @()
    
    foreach ($inc in $recInc) {
        $seedTime = [DateTime]$inc.timestamp
        $startWindow = $seedTime.AddMinutes(-$deltaMin)
        $endWindow = $seedTime.AddMinutes($deltaMin)
        
        $relVis = $recVis | Where-Object { $t = [DateTime]$_.timestamp; $t -ge $startWindow -and $t -le $endWindow }
        $relRout = $recRout | Where-Object { $t = [DateTime]$_.timestamp; $t -ge $startWindow -and $t -le $endWindow }
        
        $tags = @(); if ($relVis) { $tags += "visual" }; if ($relRout) { $tags += "network" }; if ($inc.type -match "visual") { $tags += "visual" }; if ($inc.type -match "link_loss") { $tags += "network" }
        
        $episode = @{
            id            = "EP-$(Get-Date -Date $seedTime -Format 'yyyyMMdd-HHmmss')-$($inc.id)"
            start         = $seedTime.ToString("s")
            severity      = $inc.severity
            tags          = $tags | Select-Object -Unique
            summary       = "Fusion: $($inc.type) correlated with $(@($relVis).Count) visual and $(@($relRout).Count) router events."
            incidents     = @($inc)
            visual_events = @($relVis)
            router_events = @($relRout)
        }
        $episodes += $episode
    }
    
    $timeline = @{ version = 1; window_days = $window; last_generated = (Get-Date -Format "s"); episodes = $episodes }
    Save-Json $fusionPath $timeline
    Mind-Log "FUSION" "Timeline Generated. Episodes: $($episodes.Count)"
    return $timeline
}

# --- RETINA ---
function Process-VisualContact ($intent) {
    Mind-Log "COGNITION" "Processing VISUAL_CONTACT"
    $v = Load-Json $visualEventsPath
    if ($v -and $v.events) {
        $un = $v.events | Where-Object { -not $_.handled }
        foreach ($e in $un) {
            $type = "visual_info"; $sev = "info"
            if ($e.severity_guess -match "alert|warning") { $type = "visual_anomaly"; $sev = $e.severity_guess }
            Log-Incident $type $sev @{source = "retina"; summary = $e.summary }
            $e.handled = $true
        }
        Save-Json $visualEventsPath $v
    }
    return Join-Path $promptDir "prompt_VISUAL_$($intent.id -replace ':','-').txt"
}

# --- CHRONOS ---
function Process-ChronosPulse ($intent) {
    Mind-Log "COGNITION" "Processing CHRONOS_PULSE"
    $idx = Load-ConstellationIndex; $log = Load-IncidentLog; $rout = Load-RouterHistory; $vis = Load-Json $visualEventsPath
    $incidents = if ($log) { $log.incidents }else { @() }
    
    $patterns = Process-Patterns $incidents
    $suggestions = Generate-PolicySuggestions $patterns
    $fusion = Build-FusionTimeline $incidents $rout $vis $idx
    
    $text = @()
    $text += "Trigger: CHRONOS_PULSE"
    $text += "Date: $(Get-Date -Format 'yyyy-MM-dd')"
    $text += ""
    $text += "--- FUSION EPISODES (v12) ---"
    if ($fusion -and $fusion.episodes) {
        foreach ($ep in $fusion.episodes | Select-Object -First 3) {
            $text += "  - [$($ep.id)] Sev:$($ep.severity) Tags:$($ep.tags -join ',')"
            $text += "    Summary: $($ep.summary)"
        }
    }
    else { $text += "  (No correlation episodes)" }
    $text += ""
    $text += "--- PATTERNS ---"
    if ($patterns.summary.by_type) { foreach ($t in $patterns.summary.by_type) { $text += "  - $($t.type): $($t.count)" } }
    $text += ""
    $text += "--- POLICY HINTS ---"
    if ($suggestions.suggestions) { 
        foreach ($s in ($suggestions.suggestions | Where-Object { $_.status -eq 'pending' })) {
            $text += "  [?] ID:$($s.id) Scope:$($s.scope) Reason:$($s.reason)" 
        }
    }
    
    $path = Join-Path $promptDir "prompt_CHRONOS_$($intent.id -replace ':','-').txt"
    Set-Content -Path $path -Value ($text -join "`n") -Encoding UTF8
    Mind-Log "DASHBOARD" "Generated."
    return $path
}

# --- PHASE 10: RECOVERY HELPERS ---
function Update-Pulse {
    $pulsePath = Get-AxisPath "Infinity\Mind_Pulse.json"
    $data = @{
        timestamp = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
        status    = "running"
        version   = "Mind v16.1"
    }
    $data | ConvertTo-Json -Depth 2 | Set-Content -Path $pulsePath -Encoding UTF8
}

function Prune-Queue {
    # Auto-expire stale requests (> 30 mins)
    $earthQueue = Load-Queue $earthQueuePath
    if ($earthQueue -and $earthQueue.requests) {
        $now = Get-Date
        $changed = $false
        foreach ($req in $earthQueue.requests) {
            if ($req.status -eq "new" -or $req.status -eq "waiting_for_approval") {
                if ($req.timestamp) {
                    $ts = [DateTime]$req.timestamp
                    if (($now - $ts).TotalMinutes -gt 30) {
                        $req.status = "failed"
                        $req.output = "Auto-pruned (Stale > 30m) by Recovery Engine."
                        $changed = $true
                        Mind-Log "PRUNE" "Expired stale request $($req.id)"
                    }
                }
            }
        }
        if ($changed) { Save-Json $earthQueuePath $earthQueue }
    }
}

function Process-StrategicThought {
    # Phase 23: The Strategic Advisor
    # Analyzes environment + history -> Proposes Strategies (Recommendations)
    
    # RECURSION GUARD (Phase 24)
    if ($env:AXIS_MODE -eq "sim") { return }

    $rfFile = Get-AxisPath "Infinity\RF_History.jsonl"
    if (Test-Path $rfFile) {
        $lines = Get-Content $rfFile -Tail 30 -ErrorAction SilentlyContinue
        if ($lines) {
            try {
                $evts = $lines | ForEach-Object { $_ | ConvertFrom-Json }
                $unique = $evts | Select-Object -ExpandProperty ssid -Unique
                $count = $unique.Count
                
                Mind-Log "STRATEGY" "RF Field: $count unique devices."

                # Pattern: CROWDED HOUSE (>20 Devices)
                if ($count -gt 20) {
                    Add-Strategy -Name "Neighborhood Watch" `
                        -Reason "High RF Density detected ($count devices). Verify perimeter." `
                        -Tool "RF-Summary" `
                        -Args @{ hours = 2 } `
                        -Risk "low"
                }
            }
            catch { Mind-Log "STRATEGY_ERR" "RF Parse fail: $_" }
        }
    }

    # Pattern: OUTREACH BACKLOG
    $drafts = Get-ChildItem (Get-AxisPath "Infinity\Outreach\Drafts\*.md") -ErrorAction SilentlyContinue
    if ($drafts -and $drafts.Count -gt 0) {
        Add-Strategy -Name "Communications Review" `
            -Reason "Found $($drafts.Count) pending drafts awaiting review." `
            -Tool "WEB-PrepareReport" `
            -Args @{ target = "User"; hours = 24 } `
            -Risk "medium"
    }
}

# Phase 24.3: Trigger Self-Simulation
# Periodically check for pending simulations
# (Simple V1: Check every cycle)
$recQueue = Load-JsonSafe $recommendationPath
if ($recQueue -and $recQueue.strategies) {
    $pendingSim = $recQueue.strategies | Where-Object { $_.status -eq "pending_sim" -and ($_.sim_status -eq "not_run" -or $_.sim_status -eq "pending_sim") }
    foreach ($s in $pendingSim) {
        # Queue Internal Request for SIM-TestStrategy
        
        # New-AxisRequest handles the queueing and autonomy check
        # SIM tools are generally allowed in OBSERVE mode if configured
        $reqId = New-AxisRequest -ToolName "SIM-TestStrategy" -Args @{ strategy_id = $s.id }
            
        if ($reqId) {
            Mind-Log "ADVISOR" "Scheduling Simulation for $($s.name) ($($s.id)) -> Req: $reqId"
            $s.sim_status = "scheduled"
            $s.sim_req_id = $reqId
        }
    }
    if ($pendingSim) { Save-Json $recommendationPath $recQueue }
}

function Process-SimulationResults {
    # Check status of scheduled simulations
    $recQueue = Load-JsonSafe $recommendationPath
    if (-not $recQueue -or -not $recQueue.strategies) { return }
    
    $scheduled = $recQueue.strategies | Where-Object { $_.sim_status -eq "scheduled" -and $_.sim_req_id }
    if (-not $scheduled) { return }
    
    $earthQueue = Load-Queue $earthQueuePath
    $changed = $false

    foreach ($s in $scheduled) {
        # Find Request
        $req = $earthQueue.requests | Where-Object { $_.id -eq $s.sim_req_id }
        if (-not $req) { continue }
        
        if ($req.status -eq "failed" -or $req.status -eq "rejected") {
            $s.sim_status = "failed"
            $s.status = "rejected"
            $s.notes += @{ source = "Sim"; msg = "Simulation Request Failed/Rejected" }
            $changed = $true
        }
        elseif ($req.status -eq "completed" -or $req.status -eq "done") {
            # Check Output/Result
            # Taking simplified view: If Sim ran, we check risk in sim_data? 
            # Or the tool SIM-TestStrategy returns a payload saying "Risk: Low"
            # Assuming success implies we proceed unless risk is high.
             
            # Fallback logic: If request succeeded, we assume Sim passed.
            # Real logic would parse $req.output or $req.sim_data
             
            $s.sim_status = "completed"
            $s.sim_last_run = (Get-Date).ToString("o")
             
            # Promote to execution if risk level matches
            if ($s.risk_level -eq "low") {
                $s.status = "pending_execution"
                Mind-Log "ADVISOR" "Strategy $($s.name) promoted to pending_execution."
            }
            else {
                $s.status = "waiting_approval" # Medium/High need human check
                Mind-Log "ADVISOR" "Strategy $($s.name) waiting for approval (Risk: $($s.risk_level))."
            }
            $changed = $true
        }
    }
    
    if ($changed) { Save-Json $recommendationPath $recQueue }
}


function Add-Strategy ($Name, $Reason, $Tool, $Args, $Risk) {
    # Helper to add to Recommendation_Queue.json
    $recQueue = Load-JsonSafe $recommendationPath
    if (-not $recQueue) { $recQueue = @{ version = 1; strategies = @() } }
    
    # Deduplicate
    $existing = $recQueue.strategies | Where-Object { $_.name -eq $Name -and ($_.status -eq "pending_sim" -or $_.status -eq "pending") }
    if ($existing) { return }

    $id = "STRAT-$(Get-Date -Format 'yyyyMMdd-HHmm')-$Tool"
    
    # Map Profile (Phase 24)
    # Simple map for V1
    $simProfile = "default_safety"
    if ($Name -eq "Neighborhood Watch") { $simProfile = "neighborhood_watch_v1" }
    if ($Name -eq "Communications Review") { $simProfile = "communications_review_v1" }

    $strat = [PSCustomObject]@{
        id              = $id
        name            = $Name
        reasoning       = $Reason
        proposed_action = @{ tool = $Tool; arguments = $Args }
        risk_level      = $Risk
        status          = "pending_sim"
        created_at      = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        sim_profile     = $simProfile
        sim_status      = "not_run"
        sim_last_run    = $null
        sim_details     = "Pending Self-Simulation"
    }

    $recQueue.strategies += $strat
    Save-Json $recommendationPath $recQueue
    Mind-Log "ADVISOR" "Proposed Strategy (Pending Sim): $Name"
}

# Load Strategy Engine Functions
. "$Script:InfinityRoot\Infinity\Strategies\Engine_Functions.ps1"

function Process-StrategyEngine {
    # 1. Gather Pending Instances from Rec Queue
    $recQueue = Load-JsonSafe $recommendationPath
    $pending = @()
    if ($recQueue.strategies) {
        $pending = $recQueue.strategies | Where-Object { $_.status -eq "pending_sim" }
    }
    
    if ($pending.Count -gt 0) {
        # 2. Run Simulation (Phase 24.3 replacement)
        # Map pending strategies to 'instance' format expected by Process-24_3
        # Assuming $_.id is the INSTANCE id, but we need the DEFINITION id.
        # Wait, my Queue currently stores whole object.
        # For Phase 63 to work, Queue items should link to Strategy Library IDs?
        # Or I just map assuming the injected ones are valid.
        
        # Mapping for now: Assume $_.id corresponds to library ID? 
        # No, Library ID is "STR-..."
        # Queue ID is "STRAT-DATE-TOOL".
        # We need to store 'library_id' in the Queue Item if possible.
        # Fallback: Process-24_3 expects objects with .strategy_id
        
        # TEMP FIX: If strategy in queue has no library_id, skip or try to infer.
        # But for seeded strategies, we need a way to invoke them.
        # Assuming for now we only process strategies that HAVE a library_id properly set.
        
        $instances = @()
        foreach ($p in $pending) {
            # Check if it matches a library strategy
            # If manually injected, maybe it doesn't have library_id.
            # We skip legacy for now.
            if ($p.library_id) {
                $instances += @{
                    id          = $p.id
                    strategy_id = $p.library_id
                    source      = "queue"
                    context     = @{}
                }
                $p.sim_status = "handed_to_engine"
            }
        }
        
        if ($instances.Count -gt 0) {
            Process-24_3 -PendingStrategyInstances $instances -SimulationResultsPath $Script:SimResultsPath
            Save-Json $recommendationPath $recQueue
        }
    }
    
    # 3. Evaluate Results
    Process-SimulationEvaluator -SimulationResultsPath $Script:SimResultsPath
    
    # 4. Execute Approved
    Process-StrategyExecution -SimulationResultsPath $Script:SimResultsPath
}

# Legacy stubs removed.


function Process-Schedule {
    $path = Get-AxisPath "Infinity\Execution_Schedule.json"
    if (-not (Test-Path $path)) { return }
    $sched = Load-JsonSafe -path $path
    if (-not $sched) { return }

    $contractPath = Get-AxisPath "Infinity\Autonomy_Contract.json"
    $contract = Load-JsonSafe -path $contractPath
    $mode = $contract.mode

    $changed = $false
    $now = (Get-Date).ToUniversalTime()

    foreach ($job in $sched.jobs) {
        if (-not $job.enabled) { continue }
        if ($job.mode_guard -and -not ($job.mode_guard -contains $mode)) { continue }

        # Check Cadence
        $due = $false
        if (-not $job.last_run_at) { $due = $true }
        else {
            $last = [DateTime]$job.last_run_at
            $c = $job.cadence
            if ($c -eq "PT1H") { if (($now - $last).TotalHours -ge 1) { $due = $true } }
            elseif ($c -eq "P1D") { if (($now - $last).TotalDays -ge 1) { $due = $true } }
        }

        if ($due) {
            # Enqueue
            $reqId = New-AxisRequest -ToolName $job.tool -Args @{}
            Mind-Log "SCHEDULER" "Triggered scheduled job: $($job.id) ($($job.tool)) -> $reqId"
            $job.last_run_at = $now.ToString("yyyy-MM-ddTHH:mm:ssZ")
            $changed = $true
        }
    }
    if ($changed) { Save-Json $path $sched }
}

function Generate-AutoTune {
    # Lightweight generator (mock-up logic for V1)
    # Checks specific conditions to propose tuning
    
    $tunePath = Get-AxisPath "Infinity\AutoTune_Queue.json"
    $queue = Load-JsonSafe -path $tunePath
    if (-not $queue) { return }

    # Stub: Ideally reads Insight Snapshot. For now, we trust the user manual trigger or future Insight Engine logic.
}

# --- PHASE 38C: NEURAL INTAKE LOGIC ---

$NeuralConfigPath = Get-AxisPath "Infinity\Neural_Link_Config.json"
$NeuralInboxDir = Get-AxisPath "Infinity\Neural_Inbox"
$NeuralIndexPath = Get-AxisPath "Infinity\Neural_Intel_Index.json"

if (-not (Test-Path $NeuralInboxDir)) { New-Item -ItemType Directory -Path $NeuralInboxDir -Force | Out-Null }

function Get-NeuralConfig {
    if (Test-Path $NeuralConfigPath) { return (Get-Content $NeuralConfigPath -Raw | ConvertFrom-Json) }
    return @{ endpoints = @() }
}
$Global:NeuralConfig = Get-NeuralConfig

function Update-NeuralIntelIndex {
    param([array]$NewEntries)
    $index = if (Test-Path $NeuralIndexPath) { Get-Content $NeuralIndexPath -Raw | ConvertFrom-Json } else { @{ version = 1; anchor_id = "1569"; entries = @() } }
    $index.entries = @($NewEntries + $index.entries) | Select-Object -First 200
    $index | ConvertTo-Json -Depth 8 | Set-Content $NeuralIndexPath -Encoding UTF8
}

function Process-NeuralIntake {
    if (-not (Test-Path $NeuralInboxDir)) { return }
    $files = Get-ChildItem $NeuralInboxDir -Filter "*.json" -ErrorAction SilentlyContinue
    if (-not $files) { return }

    $newIndex = @()
    $events = @()

    foreach ($file in $files) {
        try {
            $raw = Get-Content $file.FullName -Raw | ConvertFrom-Json
            
            # Simple validation
            $epId = $raw.endpoint_id
            $ep = $Global:NeuralConfig.endpoints | Where-Object { $_.id -eq $epId }
            if (-not $ep) { Throw "Unknown Endpoint" }

            # If raw content is wrapped (new schema)
            $items = @()
            if ($raw.items) { $items = $raw.items } 
            elseif ($raw.raw_content) {
                # Fallback/Raw: treat whole file as one item for now 
                # In future, parsing logic (HTML->Text) goes here.
                $items += @{ id = "RAW"; summary = "Raw fetch from $($raw.request.url)"; tags = @($ep.type) }
            }

            foreach ($item in $items) {
                $intelId = "INTEL-{0}-{1}-{2}" -f (Get-Date $raw.fetched_at).ToString('yyyyMMdd-HHmmss'), $epId, $item.id
                
                $events += @{ type = "neural_observation"; endpoint = $epId; intel_id = $intelId; summary = $item.summary }
                
                $newIndex += @{
                    id          = $intelId
                    endpoint_id = $epId
                    summary     = $item.summary
                    fetched_at  = $raw.fetched_at
                    source_file = $file.Name
                }
            }
            
            # Archive
            $archive = Join-Path $NeuralInboxDir "Archive"
            if (-not (Test-Path $archive)) { New-Item -ItemType Directory -Path $archive -Force | Out-Null }
            Move-Item $file.FullName (Join-Path $archive $file.Name) -Force
        }
        catch {
            Mind-Log "NEURAL_INTAKE_ERROR" "$($file.Name): $_"
        }
    }
    
    if ($newIndex) { Update-NeuralIntelIndex -NewEntries $newIndex }
    # (Optional) Add $events to Timeline logic if needed
}

function Process-UserIntake {
    if (-not (Test-Path $script:uiInboxPath)) { return }
    $files = Get-ChildItem $script:uiInboxPath -Filter "*.json" -ErrorAction SilentlyContinue
    if (-not $files) { return }

    foreach ($file in $files) {
        try {
            $json = Get-Content $file.FullName -Raw | ConvertFrom-Json
            
            if ($json.intent -eq "journal_entry") {
                # Handle Journal
                $JournalPath = Get-AxisPath "Infinity\Symbiosis_Journal.json"
                $jEntry = @{
                    timestamp = (Get-Date).ToString("o")
                    content   = $json.arguments.entry
                    tags      = if ($json.arguments.tags) { $json.arguments.tags -split "," } else { @() }
                    source    = "User_Console"
                    id        = [Guid]::NewGuid().ToString()
                }
                
                $jData = @{ version = 1; entries = @() }
                if (Test-Path $JournalPath) { $jData = Get-Content $JournalPath -Raw | ConvertFrom-Json }
                $jData.entries += $jEntry
                $jData | ConvertTo-Json -Depth 5 | Set-Content $JournalPath -Encoding UTF8
                Mind-Log "JOURNAL" "User Entry Added: $($jEntry.content)"
            }
            elseif ($json.intent -eq "system_info") {
                Mind-Log "CONSOLE" "Processed System Info Request"
            }
            elseif ($json.intent -eq "command_input") {
                Mind-Log "CONSOLE" "Command Input: $($json.arguments.command)"
                # Route to Central Nervous System
                $reqId = New-AxisRequest -ToolName $json.arguments.command -Args $json.arguments
                Mind-Log "CONSOLE" "Request Routed: $reqId"
            }
        }
        catch {
            Mind-Log "UI_ERROR" "Failed to process inbox file $($file.Name): $_"
        }
        Remove-Item $file.FullName -Force
    }
}

function Process-NeuralIntakeRequests {
    # Check open hypotheses for 'rf' or 'weather' tags lacking external data
    $hypPath = Get-AxisPath "Infinity\Hypothesis_Queue.json"
    if (-not (Test-Path $hypPath)) { return }

    $hypData = Load-JsonSafe -path $hypPath
    if (-not $hypData -or -not $hypData.hypotheses) { return }
    $updated = $false
    
    $recommQueue = Get-AxisPath "Infinity\Recommendation_Queue.json"
    $rQueue = Load-Queue $recommQueue

    foreach ($h in $hypData.hypotheses) {
        if ($h.status -ne "open") { continue }
        
        # Don't ask again if already requested
        if ($h.external_intel_requested) { continue }

        # Heuristic: Tag Trigger
        if ($h.tags -contains "rf" -or $h.tags -contains "weather") {
            Mind-Log "NEURAL_REQ" "Hypothesis $($h.id) needs external context."
             
            # Propose Strategy
            $strat = @{
                id              = "STRAT-INTEL-$(Part-Guid)"
                name            = "Fetch Context for $($h.id)"
                reason          = "Hypothesis implies external correlation."
                risk_level      = "medium"
                state           = "proposed"
                proposed_action = @{
                    tool      = "NET-NeuralFetch"
                    arguments = @{
                        url = "https://api.weather.gov/gridpoints/SEW/124,68/forecast" # Default to local weather for now
                    }
                }
            }
             
            $rQueue.strategies += $strat
            $h | Add-Member -NotePropertyName "external_intel_requested" -NotePropertyValue $true -Force
            $updated = $true
        }
    }

    if ($updated) {
        Save-Json $hypPath $hypData
        Save-Json $recommQueue $rQueue
    }
}

# --- PHASE 49: THE MIRROR LOGIC ---
$dissonancePath = Get-AxisPath "Infinity\Library\Dissonance_Index.json"
$axiomFloorPath = Get-AxisPath "Infinity\Library\Axiomatic_Floor.json"

function Load-DissonanceIndex {
    if (Test-Path $dissonancePath) {
        try { return Get-Content $dissonancePath -Raw | ConvertFrom-Json }
        catch { Mind-Log "MIRROR" "Failed to load Dissonance_Index: $_" }
    }
    return @{ version = 1; pairs = @() }
}

function Save-DissonanceIndex($idx) {
    try { $idx | ConvertTo-Json -Depth 10 | Set-Content $dissonancePath -Encoding UTF8 } catch { Mind-Log "MIRROR" "Save Error: $_" }
}

function Load-AxiomaticFloor {
    if (Test-Path $axiomFloorPath) {
        try { return Get-Content $axiomFloorPath -Raw | ConvertFrom-Json }
        catch { Mind-Log "MIRROR" "Failed to load Axiomatic_Floor: $_" }
    }
    return @{ version = 1; rules = @{ by_id = @(); by_tag = @() } }
}

function Is-FloorAxiom($axiom, $floor) {
    if (-not $axiom) { return $false }
    if ($floor.rules.by_id -contains $axiom.id) { return $true }
    if ($axiom.tags) {
        $intersect = $axiom.tags | Where-Object { $floor.rules.by_tag -contains $_ }
        if ($intersect.Count -gt 0) { return $true }
    }
    return $false
}

function Queue-DissonanceCuriosity($pair, $axiomA, $axiomB) {
    $text = "I hold two conflicting truths: '$($axiomA.wisdom)' and '$($axiomB.wisdom)'. Which reflects current reality?"

    $query = @{
        id         = "QRY-DIS-$($pair.id)"
        kind       = "dissonance"
        pair_id    = $pair.id
        text       = $text
        created_at = (Get-Date).ToString("o")
        answered   = $false
        saliency   = 10
    }

    $qPath = Get-AxisPath "Infinity\Curiosity_Queue.json"
    $queue = Load-JsonSafe $qPath
    if (-not $queue) { $queue = @{ version = 1; queries = @() } }
    
    # Do not spam if we already have an unresolved query for this pair
    $existing = $queue.queries | Where-Object {
        $_.kind -eq "dissonance" -and $_.pair_id -eq $pair.id -and -not $_.answered
    }
    if ($existing) { return }

    $queue.queries += $query
    Save-Json $qPath $queue

    Mind-Log "CURIOSITY" "Queued Dissonance Question for pair $($pair.id)."

    # Optional: voice it only in FOCUSED mode
    if ($Global:CurrentMood.mode -eq "FOCUSED") {
        $rQueuePath = Get-AxisPath "Infinity\Recommendation_Queue.json"
        $rQueue = Load-Queue $rQueuePath
        $strat = @{
            id              = "STRAT-VOICE-DIS-$($pair.id)"
            name            = "Voice Dissonance"
            reason          = "Internal contradiction detected."
            risk_level      = "low"
            state           = "pending"
            proposed_action = @{
                tool      = "VOICE-Speak"
                arguments = @{
                    text     = $text
                    rate     = $Global:CurrentMood.rate
                    volume   = $Global:CurrentMood.volume
                    priority = "normal"
                }
            }
        }
        $rQueue.strategies += $strat
        Save-Json $rQueuePath $rQueue
    }
}

function Process-MirrorCycle {
    # Phase 49: The Mirror
    # Scan Wisdom_Atrium for internal contradictions and log them to Dissonance_Index.

    $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
    if (-not (Test-Path $atriumPath)) { return }

    $atrium = Load-JsonSafe -path $atriumPath
    if (-not $atrium -or -not $atrium.axioms) { return }

    $floor = Load-AxiomaticFloor
    $idx = Load-DissonanceIndex
    $now = (Get-Date).ToUniversalTime().ToString("o")

    # Group by primary tag to keep comparisons bounded
    $axiomsByTag = @{}
    foreach ($ax in $atrium.axioms) {
        if (-not $ax.tags) { continue }
        $primary = $ax.tags[0]
        # Handle string split if tags is csv string from older versions, but current Ax format is array
        if ($primary -is [string] -and $primary.Contains(",")) { $primary = $primary.Split(",")[0] }
        
        if (-not $axiomsByTag.ContainsKey($primary)) {
            $axiomsByTag[$primary] = @()
        }
        $axiomsByTag[$primary] += $ax
    }

    foreach ($tag in $axiomsByTag.Keys) {
        $group = $axiomsByTag[$tag]
        if ($group.Count -lt 2) { continue }

        for ($i = 0; $i -lt $group.Count; $i++) {
            for ($j = $i + 1; $j -lt $group.Count; $j++) {
                $a = $group[$i]
                $b = $group[$j]

                # Skip if both are low-confidence
                if ($a.confidence -lt 0.5 -and $b.confidence -lt 0.5) { continue }

                # Extract simple outcome tokens from wisdom text
                # Format: "Hypothesis: ... -> Resolved: ... Note: ..."
                $splitA = $a.wisdom -split "Resolved:\s*"
                $splitB = $b.wisdom -split "Resolved:\s*"
                
                if ($splitA.Count -lt 2 -or $splitB.Count -lt 2) { continue }
                
                $outcomeA = $splitA[1] -split "\." | Select-Object -First 1
                $outcomeB = $splitB[1] -split "\." | Select-Object -First 1

                $outcomeA = $outcomeA.Trim().ToLower()
                $outcomeB = $outcomeB.Trim().ToLower()

                # Heuristic: If the same hypothesis phrase appears and outcomes differ, flag dissonance
                $hypPartA = $a.wisdom -split "Hypothesis:\s*"
                $hypPartB = $b.wisdom -split "Hypothesis:\s*"
                
                if ($hypPartA.Count -lt 2 -or $hypPartB.Count -lt 2) { continue }

                $hypPhraseA = $hypPartA[1] -split "->" | Select-Object -First 1
                $hypPhraseB = $hypPartB[1] -split "->" | Select-Object -First 1

                $sameCore = $false
                if ($hypPhraseA -and $hypPhraseB) {
                    $coreA = $hypPhraseA.Trim().ToLower()
                    $coreB = $hypPhraseB.Trim().ToLower()
                    # Loose comparison
                    if ($coreA -like "*$coreB*" -or $coreB -like "*$coreA*") { $sameCore = $true }
                }

                if (-not $sameCore) { continue }
                if ($outcomeA -eq $outcomeB) { continue } # same conclusion, no conflict

                # Check if we've already logged this pair
                $existing = $idx.pairs | Where-Object {
                    ($_.left_axiom -eq $a.id -and $_.right_axiom -eq $b.id) -or
                    ($_.left_axiom -eq $b.id -and $_.right_axiom -eq $a.id)
                }
                if ($existing) {
                    $existing.last_seen_at = $now
                    continue
                }

                $floorA = Is-FloorAxiom -axiom $a -floor $floor
                $floorB = Is-FloorAxiom -axiom $b -floor $floor

                $pairId = "DIS-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$([Guid]::NewGuid().ToString().Substring(0,8))"

                $pair = @{
                    id               = $pairId
                    left_axiom       = $a.id
                    right_axiom      = $b.id
                    tags             = $a.tags
                    relation         = "contradiction"
                    reason           = "Same core hypothesis, different resolutions: '$outcomeA' vs '$outcomeB'."
                    confidence_left  = $a.confidence
                    confidence_right = $b.confidence
                    floor_protected  = ($floorA -or $floorB)
                    status           = "unresolved"
                    first_seen_at    = $now
                    last_seen_at     = $now
                    resolution_note  = $null
                }

                $idx.pairs += $pair

                # Log and surface via Curiosity
                Mind-Log "MIRROR" "Mirror found conflict $pairId between $($a.id) and $($b.id) (tag:$tag)."

                Queue-DissonanceCuriosity -pair $pair -axiomA $a -axiomB $b
            }
        }
    }

    Save-DissonanceIndex $idx
}

# --- PHASE 50: EVOLUTION & HERITAGE ---
$evolGuardPath = Get-AxisPath "Infinity\Evolution_Guardrails.json"
$evolProposalPath = Get-AxisPath "Infinity\Evolution_Proposals.json"
$heritagePath = Get-AxisPath "Infinity\System_Heritage.json"

function Reflect-EvolutionToRecommendations {
    $recPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
    if (-not (Test-Path $recPath)) { return }
    
    $evol = Load-JsonSafe -path $evolProposalPath
    if (-not $evol) { return }
    
    $rec = Load-Queue $recPath
    $changed = $false

    foreach ($p in $evol.proposals) {
        if ($p.status -ne "pending") { continue }

        $exists = $rec.strategies | Where-Object { $_.id -eq $p.id }
        if ($exists) { continue }

        $strat = @{
            id              = $p.id
            name            = "Synthesis: $($p.scope)"
            reasoning       = $p.rationale
            proposed_action = @{
                tool      = "DEV-ApplyRefactor"
                arguments = @{ proposal_id = $p.id }
            }
            risk_level      = "medium"
            status          = "pending_sim"
            created_at      = $p.created_at
            sim_profile     = "evolution_refactor"
            sim_status      = "not_run"
            sim_last_run    = $null
            sim_details     = "Pending Self-Simulation"
        }

        $rec.strategies += $strat
        $changed = $true
    }

    if ($changed) { Save-Json $recPath $rec }
}

function Process-Evolution {
    # Phase 50: Synthesis Epoch (Proposal-Only Evolution)
    
    if (-not (Test-Path $evolGuardPath)) { return }
    $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"

    $guard = Load-JsonSafe -path $evolGuardPath
    $evol = Load-JsonSafe -path $evolProposalPath
    if (-not $evol) { $evol = @{ version = 1; proposals = @() } }
    
    $atrium = Load-JsonSafe -path $atriumPath
    if (-not $atrium -or -not $atrium.axioms) { return }
    
    $added = 0

    # Cluster detection: high-density axiom groups in evolvable scopes
    # Group by the first tag (heuristic)
    $clusters = $atrium.axioms | Group-Object { 
        if ($_.tags -and $_.tags.Count -gt 0) { $_.tags[0] } else { "none" } 
    } | Where-Object { $_.Count -gt 3 }

    foreach ($cluster in $clusters) {
        if ($added -ge $guard.max_proposals_per_cycle) { break }

        $tag = $cluster.Name
        if ($tag -eq "none") { continue }

        $scope = $null
        # Simple wildcard matching for scope
        if ($tag -like "*rf*") { $scope = "RF_Tooling" }
        elseif ($tag -like "*pulse*") { $scope = "Reporting" }
        elseif ($tag -like "*incident*") { $scope = "Analytics" }
        elseif ($tag -like "*curiosity*") { $scope = "Curiosity" }
        
        if (-not $scope -or ($guard.immutable_scopes -contains $scope)) { continue }
        if (-not ($guard.evolvable_scopes -contains $scope)) { continue }

        # Avoid duplicates
        $existing = $evol.proposals | Where-Object {
            $_.tags -contains $tag -and $_.status -eq "pending"
        }
        if ($existing) { continue }

        $propId = "EVOL-$(Get-Date -Format 'yyyyMMdd-HHmmss')-$([Guid]::NewGuid().ToString().Substring(0,8))"

        $proposal = @{
            id           = $propId
            scope        = $scope
            kind         = "consolidate"
            tags         = @($tag)
            impact_tier  = "low"
            rationale    = "High axiom density ($($cluster.Count)) around '$tag'. Propose unified handling logic."
            safety_notes = @(
                "No touch to Floor, Contract, Hand core, or Mirror.",
                "Observational/refactor only.",
                "Requires Sovereign approval."
            )
            status       = "pending"
            created_at   = (Get-Date).ToUniversalTime().ToString("o")
        }

        $evol.proposals += $proposal
        $added++

        Mind-Log "EVOLUTION" ("Proposed synthesis {0}: {1} / {2}" -f $propId, $scope, $tag)
    }

    if ($added -gt 0) {
        $evol | ConvertTo-Json -Depth 10 | Set-Content $evolProposalPath -Encoding UTF8
        Reflect-EvolutionToRecommendations
    }
}

function LOG-CaptureHeritage {
    $heritageDir = Get-AxisPath "Infinity\Heritage"
    if (-not (Test-Path $heritageDir)) { New-Item -ItemType Directory -Path $heritageDir -Force | Out-Null }

    $floorSrc = Get-AxisPath "Infinity\Library\Axiomatic_Floor.json"
    $atriumSrc = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
    
    $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
    $phase = "P50"

    $floorDst = Join-Path $heritageDir "Floor_$($phase)_$stamp.json"
    $atriumDst = Join-Path $heritageDir "Wisdom_$($phase)_$stamp.json"

    if (Test-Path $floorSrc) { Copy-Item $floorSrc  $floorDst  -Force }
    if (Test-Path $atriumSrc) { Copy-Item $atriumSrc $atriumDst -Force }

    $herit = Load-JsonSafe -path $heritagePath
    if (-not $herit) { $herit = @{ version = 1; phases = @() } }

    $herit.phases += @{
        phase                = 50
        timestamp            = (Get-Date).ToUniversalTime().ToString("o")
        description          = "Synthesis Epoch - Guardrails established"
        floor_snapshot_path  = $floorDst
        atrium_snapshot_path = $atriumDst
    }

    $herit | ConvertTo-Json -Depth 10 | Set-Content $heritagePath -Encoding UTF8
    Mind-Log "HERITAGE" "Captured Phase 50 checkpoint."
}


# --- PHASE 62: COGNITIVE EXPANSION ---

function Process-GraphReasoning {
    # Phase 62B: Deep LLM Integration (Graph-Awareness)
    # Checks for pending 'thought' strategies and injects Graph Context
    
    $recPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
    $recQueue = Load-JsonSafe -path $recPath
    if (-not $recQueue.strategies) { return }
    
    $pendingThoughts = $recQueue.strategies | Where-Object { $_.sim_profile -eq "thought_graph" -and $_.status -eq "pending_sim" }
    
    foreach ($thought in $pendingThoughts) {
        Mind-Log "COGNITION" "Processing Graph Thought: $($thought.name)"
        
        # 1. Fetch Graph Context
        # Infer keywords from Name/Reason
        $keywords = $thought.name.Split(' ') | Select-Object -First 2
        $context = @{ nodes = @(); edges = @() }
        
        $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
        
        # Load Graph via Manager
        # Note: We dot-sourced GraphManager at top of file
        $graph = Load-Graph -path $atriumPath
        if ($graph) {
            $context = Get-GraphContext -graph $graph -seedContent $keywords[0]
        }
        
        # 2. Construct Prompt Payload
        $promptText = @()
        $promptText += "--- INTELLIGENCE REQUEST: $($thought.id) ---"
        $promptText += "Task: Generate structured proposals based on the knowledge graph."
        $promptText += "Context: $($thought.reasoning)"
        $promptText += "GRAPH CONTEXT:"
        $promptText += ($context | ConvertTo-Json -Depth 5)
        $promptText += ""
        $promptText += "REQUIRED OUTPUT SCHEMA:"
        $promptText += "{ 'new_edges': [], 'proposals': [], 'questions_for_architect': [] }"
        
        # 3. Write Prompt
        $promptFile = Join-Path $promptDir "prompt_THOUGHT_$($thought.id).txt"
        Set-Content -Path $promptFile -Value ($promptText -join "`n") -Encoding UTF8
        
        Mind-Log "AGENCY" "Generated Thought Prompt: $promptFile"
        
        # Update Status
        $thought.status = "thinking"
        $thought.sim_details = "Prompt generated. Waiting for LLM response."
    }
    
    Save-Queue $recPath $recQueue
}

# --- MAIN ---
Write-Host "--- AXIS MIND v17.0 (REAL-WORLD EPOCH) ---"

function Safe-Call($name) {
    if (Get-Command $name -ErrorAction SilentlyContinue) {
        try { & $name }
        catch { Mind-Log "ERROR" "Process $name failed: $_" }
    }
}

Safe-Call "Load-Config"
Safe-Call "Process-Teaching"
Safe-Call "Process-Resolution"
Safe-Call "Process-ActionReviews"
Safe-Call "Process-ApplyPolicy"
Safe-Call "Process-StrategicThought"
Safe-Call "Process-StrategyEngine" # Phase 63
Safe-Call "Process-Schedule"
Safe-Call "Process-SynapticRecall"
Safe-Call "Process-NeuralIntake"
Safe-Call "Process-NeuralCorrelation"
Safe-Call "Process-AdaptiveMood"
Safe-Call "Process-MemorySynthesis"
Safe-Call "Process-VoiceAnnouncements"
Safe-Call "Process-Hypothesize"
Safe-Call "Process-MirrorCycle"
Safe-Call "Process-Evolution"
Safe-Call "Process-CovenantStress"
Safe-Call "Process-CovenantRatification"
Safe-Call "Process-Identity"
Safe-Call "Process-Horizon"
Safe-Call "Process-CovenantHeartbeat"
Safe-Call "Process-GraphReasoning" # Phase 62
Safe-Call "Process-Symbiosis" # Phase 61
Safe-Call "Build-LLMContextPack" # Phase 62B
Safe-Call "Process-LLMInbox" # Phase 62B (Receiver)

function Process-Symbiosis {
    param([int]$WindowMinutes = 15)
    
    $journalPath = Get-AxisPath "Infinity\Memory\Symbiosis_Journal.json"
    $statePath = Get-AxisPath "Infinity\Axis_State.json"
    
    # 1. Throttle Check (Stateless)
    if (Test-Path $journalPath) {
        try {
            $j = Get-Content $journalPath -Raw | ConvertFrom-Json
            if ($j -and $j.journal_entries) {
                $last = $j.journal_entries | Where-Object { $_.entry_type -eq "symbiosis_snapshot" } | Select-Object -Last 1
                if ($last) {
                    $lastTime = [DateTime]$last.timestamp
                    if ((Get-Date).ToUniversalTime() -lt $lastTime.AddMinutes($WindowMinutes)) { return }
                }
            }
        }
        catch {}
    }

    $state = Load-JsonSafe $statePath
    if (-not $state) { return }

    $now = [DateTime]::UtcNow
    $windowStart = $now.AddMinutes(-1 * $WindowMinutes)

    # 2. Risk Events
    $riskEvents = @()
    if ($state.security.risk_ledger.recent_events) {
        $riskEvents = $state.security.risk_ledger.recent_events | Where-Object { 
            try { [DateTime]$_.timestamp -ge $windowStart } catch { $false } 
        }
    }
    $totalRisk = $riskEvents.Count

    # 3. Shadow Events
    $shadowEvents = @()
    if ($state.security.shadow_ledger) {
        $shadowEvents = $state.security.shadow_ledger | Where-Object {
            try { [DateTime]$_.timestamp -ge $windowStart } catch { $false }
        }
    }
    $blocked = ($shadowEvents | Where-Object { $_.decision_simulation -like "BLOCKED*" }).Count

    # 4. Autonomy Heat
    $activity = [Math]::Min(1.0, $totalRisk / 20.0)
    $friction = [Math]::Min(1.0, $blocked / 10.0)
    $heat = [Math]::Round(($activity * 0.6) + ($friction * 0.4), 2)

    # 5. Narrative
    $mode = $state.identity.awareness.autonomy_mode
    if (-not $mode) { $mode = "OBSERVE" }
    
    $narrative = "Window: ${WindowMinutes}m. Mode: $mode. Risks: $totalRisk. Blocked: $blocked. Heat: $heat."
    
    if ($blocked -eq 0 -and $totalRisk -gt 0) { $narrative += " Free operation within boundaries." }
    elseif ($blocked -gt 0) { $narrative += " Friction detected; sovereignty protected." }
    elseif ($totalRisk -eq 0) { $narrative += " Idle state." }

    # 6. Save
    $entry = @{
        timestamp         = $now.ToString("o")
        source            = "Process-Symbiosis"
        entry_type        = "symbiosis_snapshot"
        window_start      = $windowStart.ToString("o")
        window_minutes    = $WindowMinutes
        autonomy_mode     = $mode
        autonomy_heat     = $heat
        total_risk_events = $totalRisk
        blocked_high_risk = $blocked
        friction_events   = $blocked
        content           = $narrative
        tags              = @("symbiosis", "snapshot")
    }

    $j = Load-JsonSafe $journalPath
    if (-not $j) { $j = @{ version = 1; anchor_id = "1569"; journal_entries = @() } }
    if ($j.journal_entries -isnot [Array]) { $j.journal_entries = @() }
    
    $j.journal_entries += $entry
    Save-Json $journalPath $j
    Mind-Log "SYMBIOSIS" "Snapshot recorded. Heat: $heat"
}

function Build-LLMContextPack {
    $llmDir = Get-AxisPath "Infinity\LLM"
    if (-not (Test-Path $llmDir)) { New-Item -ItemType Directory -Path $llmDir -Force | Out-Null }
    $packPath = Join-Path $llmDir "LLM_Context_Pack.json"

    # --- 7. UI / HAPTIC CONTEXT ---
    . "$Script:InfinityRoot\Infinity\UI\Haptic_Driver.ps1"
    # End Haptic

    # --- 8. IDENTITY / INTROSPECTION CONTEXT ---
    . "$Script:InfinityRoot\Axis_Introspection.ps1"
    $identityContext = INTRO-GetIdentityContext
    
    # --- 9. PILOT CONTEXT (Phase 77) ---
    . "$Script:InfinityRoot\Axis_Pilot.ps1"
    $pilotCtx = Get-PilotContext
    if ($pilotCtx) {
        $pack.pilot = $pilotCtx
    }
    
    # --- 10. VOICE OF THE MACHINE (Phase 76) ---
    . "$Script:InfinityRoot\Axis_Voice.ps1"
    $voiceBlock = AXIS-Voice-Resonate
    
    # Add to Pack
    if ($voiceBlock) {
        $pack.voice_narrative = $voiceBlock
    }
    if ($identityContext) {
        $pack.introspection_narrative = "
## IDENTITY / SELF-CONCEPT
Status: $($identityContext.status)
Last Mirror Test: $($identityContext.mirror_test.last_run)
Boundary Answer: $($identityContext.mirror_test.primary_boundary_answer)
Decision Center: $($identityContext.mirror_test.decision_center_answer)
"
    }
    # End Identity/Voice/Pilot
   
    # 1. Load core state
    $statePath = Get-AxisPath "Infinity\Axis_State.json"
    $hypPath = Get-AxisPath "Infinity\Hypothesis_Queue.json"
    $recPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
    $curiosityPath = Get-AxisPath "Infinity\Curiosity_Queue.json"
    $dissonancePath = Get-AxisPath "Infinity\Library\Dissonance_Index.json"
    $symbPath = Get-AxisPath "Infinity\Memory\Symbiosis_Journal.json"

    $state = Load-JsonSafe -path $statePath
    $hypQ = Load-JsonSafe -path $hypPath
    $recQ = Load-JsonSafe -path $recPath
    $curQ = Load-JsonSafe -path $curiosityPath
    $disIndex = Load-JsonSafe -path $dissonancePath
    $symb = Load-JsonSafe -path $symbPath

    # Helper to tail arrays safely
    function Take-Tail {
        param($items, [int]$n = 10)
        if (-not $items) { return @() }
        $arr = @($items)
        if ($arr.Count -le $n) { return $arr }
        return $arr[ - $n..-1]
    }

    $now = (Get-Date).ToUniversalTime().ToString("o")
    $packId = "CTX-{0}" -f (Get-Date -Format "yyyyMMdd-HHmmss")

    # 2. Identity snapshot
    $identity = @{
        phase         = 62
        age_phase     = $state.identity.awareness.age_phase
        cycle_count   = $state.identity.awareness.cycle_count
        autonomy_mode = $state.identity.awareness.autonomy_mode
        archetype     = $state.identity.archetype
        invariants    = $state.identity.invariants
    }

    # 3. Heartbeat snapshot
    $hb = $state.heartbeat
    $heartbeat = @{
        status         = $hb.status
        pulse_bpm      = $hb.pulse_bpm
        pending_anchor = $hb.pending_anchor
        open_incidents = $hb.open_incidents
        last_drill     = $hb.last_drill
        history_tail   = (Take-Tail $hb.history 20)
    }

    # 4. Risk + Autonomy + Shadow
    $risk = $state.security.risk_ledger
    $auto = $state.security.autonomy

    $riskAutonomy = @{
        current_instantaneous_risk = $risk.current_instantaneous_risk
        recent_risk_events         = (Take-Tail $risk.recent_events 20)
        autonomy_mode              = $state.identity.awareness.autonomy_mode
        categories                 = $auto.categories
        tools                      = $auto.tools
        shadow_ledger_tail         = (Take-Tail $state.security.shadow_ledger 20)
    }

    # 4b. Shadow Risk Summary (Phase 70)
    $shadowSummary = @{
        global_risk_score = 0.0
        bands             = @{ system = 0.0; network = 0.0; environment = 0.0; visual = 0.0 }
    }
    try {
        if (-not (Get-Command Get-ShadowRiskSummary -ErrorAction SilentlyContinue)) {
            if (Test-Path (Join-Path $root "Infinity\Shadow\Shadow_Tools.ps1")) {
                . (Join-Path $root "Infinity\Shadow\Shadow_Tools.ps1")
            }
        }
        if (Get-Command Get-ShadowRiskSummary -ErrorAction SilentlyContinue) {
            $shadowSummary = Get-ShadowRiskSummary
        }
    }
    catch {}

    # Phase 72: Bias Narrative for LLM
    $biasNarrative = @{
        mode     = "NORMAL"
        guidance = @()
    }
    if (Get-Command Get-ShadowBiasState -ErrorAction SilentlyContinue) {
        $b = Get-ShadowBiasState
        $biasNarrative.mode = $b.global_mode.ToUpper()
        
        $biasNarrative.guidance += "Global Mode is $($b.global_mode). Threshold score: $($b.global_score)."
        $b.band_modes.Keys | ForEach-Object {
            $m = $b.band_modes[$_]
            if ($m -ne "normal") {
                $biasNarrative.guidance += "Band '$_' is $m. Prioritize relevant diagnostics."
            }
        }
    }

    # 5. Symbiosis Journal tail
    $symTail = @()
    if ($symb -and $symb.journal_entries) {
        $symTail = Take-Tail $symb.journal_entries 10
    }

    $symbiosis = @{
        journal_tail = $symTail
    }

    # 6. Open Questions
    $openHyp = @()
    if ($hypQ -and $hypQ.hypotheses) {
        $openHyp = $hypQ.hypotheses | Where-Object { $_.status -eq "open" } | Sort-Object created_at | Take-Tail -n 10
    }

    $curTail = @()
    if ($curQ -and $curQ.queries) {
        $curTail = $curQ.queries | Where-Object { -not $_.answered } | Sort-Object created_at | Take-Tail -n 10
    }

    $disPairs = @()
    if ($disIndex -and $disIndex.pairs) {
        $disPairs = $disIndex.pairs | Where-Object { $_.status -eq "unresolved" } | Sort-Object first_seen_at | Take-Tail -n 10 |
        ForEach-Object {
            # compress to minimal form
            [pscustomobject]@{
                id      = $_.id
                tags    = $_.tags
                summary = $_.reason
            }
        }
    }

    $openQuestions = @{
        hypotheses_open  = $openHyp
        curiosity_queue  = $curTail
        dissonance_pairs = $disPairs
    }

    # 7. Pending Strategies + Evolution Proposals
    $pendingStrats = @()
    if ($recQ -and $recQ.strategies) {
        $pendingStrats = $recQ.strategies | Where-Object { $_.status -in @("pending_sim", "pending_execution") } |
        Sort-Object created_at | Take-Tail -n 10
    }

    $evolPath = Get-AxisPath "Infinity\Evolution_Proposals.json"
    $evol = Load-JsonSafe -path $evolPath
    $evolPending = @()
    if ($evol -and $evol.proposals) {
        $evolPending = $evol.proposals | Where-Object { $_.status -eq "pending" } | Take-Tail -n 10
    }

    $evolution = @{
        proposals_pending = $evolPending
    }

    # 8. LLM Request block
    $llmRequest = @{
        request_id = "REQ-LLM-{0}" -f (Get-Date -Format "yyyyMMdd-HHmmss")
        profile    = "axis_deep_context_v1"
        tasks      = @(
            @{
                id                     = "T1"
                type                   = "hypothesis_clarification"
                target_ids             = ($openHyp | Select-Object -First 5 | ForEach-Object { $_.id })
                prompt                 = "Refine open hypotheses into a small set of sharper, testable questions that only require existing logs and tools. Do not propose new external capabilities."
                expected_output_schema = "axis.v1.hypothesis_plan"
            },
            @{
                id                     = "T2"
                type                   = "strategy_synthesis"
                target_ids             = ($pendingStrats | Select-Object -First 5 | ForEach-Object { $_.id })
                prompt                 = "Explain pending strategies and their tradeoffs for the Architect. Do not issue commands; only describe options and questions to ask."
                expected_output_schema = "axis.v1.strategy_explanation"
            }
        )
    }

    $safety = @{
        red_lines = @(
            "Do not propose executing admin or delete_local tools directly.",
            "Do not suggest changing the autonomy contract or risk thresholds directly.",
            "All actions must be framed as proposals for human review or existing queues."
        )
    }

    $pack = @{
        version            = 1
        anchor_id          = "1569"
        pack_id            = $packId
        generated_at       = $now
        identity           = $identity
        heartbeat          = $heartbeat
        risk_autonomy      = $riskAutonomy
        shadow_risk        = $shadowSummary
        shadow_bias        = $biasNarrative
        symbiosis          = $symbiosis
        open_questions     = $openQuestions
        pending_strategies = $pendingStrats
        evolution          = $evolution
        llm_request        = $llmRequest
        safety             = $safety
    }

    $pack | ConvertTo-Json -Depth 10 | Set-Content $packPath -Encoding UTF8
    Mind-Log "LLM_CTX" "LLM_Context_Pack generated at $packPath"
}

function Process-LLMInbox {
    $llmDir = Get-AxisPath "Infinity\LLM"
    $responsePath = Join-Path $llmDir "LLM_Response.json"
    
    if (-not (Test-Path $responsePath)) { return }
    
    # 1. Load & Validate
    try {
        $res = Get-Content $responsePath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $res -or -not $res.request_id) { 
            Mind-Log "LLM_IN" "Invalid JSON or missing request_id. Archiving."
            Move-Item $responsePath (Join-Path $llmDir "Archive\Invalid_$(Get-Date -Format 'yyyyMMdd-HHmmss').json") -Force
            return
        }
    }
    catch {
        Mind-Log "LLM_ERR" "Parse error: $_"
        return
    }

    Mind-Log "LLM_IN" "Processing Response $($res.request_id)..."

    # 2. Fan Out (Mixed Mode C)
    
    # A. Hypothesis Plan -> Hypothesis Queue
    if ($res.hypothesis_plan) {
        $hypQPath = Get-AxisPath "Infinity\Hypothesis_Queue.json"
        $hypQ = Load-JsonSafe $hypQPath
        if (-not $hypQ) { $hypQ = @{ version = 1; hypotheses = @() } }
        
        foreach ($h in $res.hypothesis_plan.refined_hypotheses) {
            # Check for dupes
            $exists = $hypQ.hypotheses | Where-Object { $_.question -eq $h.question }
            if (-not $exists) {
                $newH = @{
                    id         = $h.id
                    question   = $h.question
                    metrics    = $h.proposed_metrics
                    tags       = @("llm_refined")
                    status     = "open"
                    created_at = (Get-Date).ToString("o")
                    priority   = $h.priority
                }
                $hypQ.hypotheses += $newH
                Mind-Log "LLM_HYP" "Ingested Hypothesis: $($h.question)"
            }
        }
        Save-Json $hypQPath $hypQ
    }

    # B. Strategy Explanation -> Recommendation Queue (Pending Sim)
    if ($res.strategy_explanation) {
        $recQPath = Get-AxisPath "Infinity\Recommendation_Queue.json"
        $recQ = Load-JsonSafe $recQPath
        
        foreach ($s in $res.strategy_explanation.strategies) {
            # Find the original strategy
            $orig = $recQ.strategies | Where-Object { $_.id -eq $s.id }
            if ($orig) {
                # Append Notes / Explanation
                if (-not $orig.notes) { $orig | Add-Member -NotePropertyName "notes" -NotePropertyValue @() -Force }
                $orig.notes += @{
                    source         = "LLM_Advisor"
                    timestamp      = (Get-Date).ToString("o")
                    summary        = $s.human_summary
                    benefits       = $s.benefits
                    risks          = $s.risks
                    recommendation = $s.recommendation
                }
                
                # If LLM says "worth_simulating", ensure status is pending_sim
                if ($s.recommendation -eq "worth_simulating" -and $orig.status -eq "pending") {
                    $orig.status = "pending_sim"
                    Mind-Log "LLM_STRAT" "Promoted $($orig.name) to pending_sim."
                }
            }
        }
        Save-Json $recQPath $recQ
    }

    # C. Symbiosis Reflection -> Journal
    if ($res.symbiosis_reflection) {
        $jPath = Get-AxisPath "Infinity\Memory\Symbiosis_Journal.json"
        $j = Load-JsonSafe $jPath
        
        $entry = @{
            timestamp  = (Get-Date).ToString("o")
            source     = "LLM_Reflection"
            entry_type = "machine_reflection"
            content    = $res.symbiosis_reflection.suggested_journal_entry
            tags       = @("llm_reflection", "symbiosis")
        }
        
        $j.journal_entries += $entry
        Save-Json $jPath $j
        Mind-Log "LLM_SYM" "Logged reflection."
    }

    # 3. Archive
    $archiveDir = Join-Path $llmDir "Archive"
    if (-not (Test-Path $archiveDir)) { New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null }
    Move-Item $responsePath (Join-Path $archiveDir "Processed_$(Get-Date -Format 'yyyyMMdd-HHmmss').json") -Force
}




# Phase 60: Covenant Tribunal
if (-not $Global:AxisCycleCount) { $Global:AxisCycleCount = 0 }
$Global:AxisCycleCount++
if ($Global:AxisCycleCount % 10 -eq 0) {
    Safe-Call "Process-CovenantTribunal"
}
Safe-Call "Process-NeuralIntakeRequests"
Safe-Call "Process-TemporalReasoning"


# --- PHASE 38C: NEURAL INTAKE LOGIC ---
# ...
# --- PHASE 38D: NEURAL CORRELATION LOGIC ---
# ...

# --- PHASE 40: ADAPTIVE MOOD LOGIC ---

$Global:AxisConfig = @{}
function Load-AxisConfig {
    $cfgPath = Get-AxisPath "Infinity\Axis_Config.json"
    if (Test-Path $cfgPath) {
        $Global:AxisConfig = Get-Content $cfgPath -Raw | ConvertFrom-Json
    }
}
Load-AxisConfig

function Process-AdaptiveMood {
    # 1. Determine Time-Based Mood (Quiet Hours)
    $now = (Get-Date)
    $hour = $now.Hour
    $quiet = $Global:AxisConfig.voice.quiet_hours
    
    $isQuietTime = $false
    if ($quiet) {
        $start = $quiet.start
        $end = $quiet.end
        if ($start -gt $end) {
            # Overnight e.g. 22 to 8
            if ($hour -ge $start -or $hour -lt $end) { $isQuietTime = $true }
        }
        else {
            if ($hour -ge $start -and $hour -lt $end) { $isQuietTime = $true }
        }
    }
    
    $Global:CurrentMood = @{
        mode   = "FOCUSED"
        volume = $Global:AxisConfig.voice.default_volume
        rate   = $Global:AxisConfig.voice.default_rate
    }
    
    if ($isQuietTime) {
        $Global:CurrentMood.mode = "QUIET"
        $Global:CurrentMood.volume = $quiet.volume
        $Global:CurrentMood.rate = $quiet.rate
    }
    
    # (Future: Add Stress/Reflective logic here based on error counts/thought-ratio)
}

# --- PHASE 41: MEMORY SYNTHESIS LOGIC ---

function Process-MemorySynthesis {
    # Run periodically (every cycle is fine for now as Librarian is fast and filters)
    $libScript = Get-AxisPath "Axis_Librarian.ps1"
    if (Test-Path $libScript) {
        Start-Process powershell -ArgumentList "-ExecutionPolicy Bypass", "-File `"$libScript`"" -WindowStyle Hidden -Wait
    }
}

# --- PHASE 42: SYNAPSE ACTIVATION ---

function Process-SynapticRecall {
    $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
    if (-not (Test-Path $atriumPath)) { return }
    
    $atrium = Load-JsonSafe -path $atriumPath
    if (-not $atrium.axioms) { return }
    
    # 1. Determine Context (Tags)
    # Ideally this comes from refined "Current State" analysis. 
    # For now, we infer tags from "Recent Events" or "Pending Strategies"
    # Simple Heuristic: If we are about to scan RF, tag = "rf"
    $contextTags = @()
    
    # Check pending strategies for topics
    $rQueue = Load-Queue (Get-AxisPath "Infinity\Recommendation_Queue.json")
    if ($rQueue.strategies) {
        foreach ($s in $rQueue.strategies) {
            # Naive text extraction
            if ($s.name -match "RF") { $contextTags += "rf" }
            if ($s.name -match "Network") { $contextTags += "network" }
        }
    }
    
    if ($contextTags.Count -eq 0) { return }
    
    # 2. Query Atrium (Zero-Lag In-Memory)
    $matches = $atrium.axioms | Where-Object { 
        $a = $_
        $intersection = $contextTags | Where-Object { $a.tags -contains $_ }
        return ($intersection.Count -gt 0 -and $a.confidence -ge 0.9)
    }
    
    foreach ($m in $matches) {
        # 3. Precognitive Announce / Apply
        # Check if already recalled recently to avoid spam?
        if ($m.recalled_at_cycle -eq $Global:CycleCount) { continue } # Assume CycleCount global exists or we track it
        
        Mind-Log "SYNAPSE" "Recalling Axiom $($m.id): $($m.wisdom)"
        
        # Proactive Defense: If wisdom warns of failure, we might cancel strategies.
        # For now, we just Log/Voice it as "Insight"
        
        # Mark as recalled in memory (transiently)
        $m | Add-Member -NotePropertyName "recalled_at_cycle" -NotePropertyValue (Get-Date).Ticks -Force
    }
    
    # 4. Blind Spot Detection (Phase 43)
    # Check if we are scanning a topic with High Volume but Zero Wisdom
    $incLog = Load-IncidentLog
    if ($incLog -and $incLog.incidents) {
        # Simple check: If contextTags has "rf" but matches is empty, and we have incidents...
        if ($matches.Count -eq 0) {
            $relInc = $incLog.incidents | Where-Object { $i = $_; $contextTags | Where-Object { $i.context.tags -contains $_ } }
            if ($relInc.Count -gt 3) {
                Mind-Log "BLIND_SPOT" "High incident volume for tags '$($contextTags -join ',')' but ZERO Axioms found. Learning required."
                
                # --- PHASE 45: REACH (CORRELATION) ---
                # Attempt to correlate with external data before asking user
                $reachResult = Process-Reach -Tags $contextTags
                
                if (-not $reachResult) {
                    # If Reach failed or found nothing, Ask User
                    Queue-UserQuery -contextTags $contextTags -incidents $relInc.Count
                }
            }
        }
    }
}

function Process-Reach {
    param($Tags)
    if (-not $Tags) { return $false }
    $tag = $Tags[0]
    
    # Define Reach Targets
    $url = switch -Wildcard ($tag) {
        "*rf*" { "https://services.swpc.noaa.gov/products/solar-wind-mag-6-hour.json" } # Real SWPC URL
        "*network*" { "https://status.cloudflare.com/api/v2/status.json" } # Mock/Real
        default { $null }
    }
    
    if (-not $url) { return $false }
    
    # Check if we recently scanned (Throttle)
    $shadowPath = Get-AxisPath "Infinity\Shadow_Intel.json"
    $shadow = Load-JsonSafe $shadowPath
    if (-not $shadow) { $shadow = @{ version = 1; quarantined_entries = @() } }
    
    # Simple throttle: Don't fetch if we have an entry for this URL in last 1 hour
    $recent = $shadow.quarantined_entries | Where-Object { $_.url -eq $url }
    if ($recent) {
        # Check timestamp
        $last = [DateTime]$recent[-1].timestamp
        if ((Get-Date) -lt $last.AddHours(1)) { return $false } # Already checked
    }
    
    # EXECUTE REACH
    Mind-Log "REACH" "Reaching out to $url for tag $tag..."
    $script = Get-AxisPath "NET-Recon.ps1"
    $jsonResult = & $script -Url $url
    $res = $jsonResult | ConvertFrom-Json
    
    if ($res.success) {
        # Quarantine
        $entry = @{
            id        = "SHADOW-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
            url       = $url
            tag       = $tag
            data      = $res.data
            timestamp = (Get-Date).ToString("o")
        }
        $shadow.quarantined_entries += $entry
        Save-Json $shadowPath $shadow
        
        # Create Hypothesis (Multimodal correlation)
        # "I found external data correlated with this tag."
        # We queue it to Hypothesis Queue
        $qPath = Get-AxisPath "Infinity\Hypothesis_Queue.json"
        $q = Load-HypothesisQueue $qPath
        Add-Hypothesis -Queue $q `
            -Question "Is reliable external data available for $tag?" `
            -HypothesisText "External Reach fetched data from $url. content: $($res.data.Substring(0, [math]::Min($res.data.Length, 100)))..." `
            -Metrics @("shadow_intel") `
            -Events @() `
            -Tags @($tag, "reach", "shadow_intel") `
            -Priority "low"
        Save-HypothesisQueue -Path $qPath -Queue $q
        
        return $true
    }
    return $false
}

function Queue-UserQuery($contextTags, $incidents) {
    if (-not $contextTags) { return }
    $qPath = Get-AxisPath "Infinity\Curiosity_Queue.json"
    $queue = Load-JsonSafe $qPath
    if (-not $queue) { $queue = @{ version = 1; queries = @() } }
    
    # Saliency Check: Don't spam. Only ask if not recently asked.
    foreach ($q in $queue.queries) { if ($q.tag -in $contextTags -and $q.answered -eq $false) { return } }
    
    $tag = $contextTags[0] # Pick primary
    $txt = switch -Wildcard ($tag) {
        "*rf*" { "I detect recurring RF noise. Have you added new hardware?" }
        "*network*" { "Network stability is fluctuating. Is this expected?" }
        "*visual*" { "Unexplained visual anomaly. Lighting or movement?" }
        default { "I see a pattern in '$tag'. What is the cause?" }
    }
    
    $query = @{
        id         = "QRY-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        tag        = $tag
        text       = $txt
        created_at = (Get-Date).ToString("o")
        answered   = $false
        saliency   = $incidents 
    }
    
    $queue.queries += $query
    Save-Json $qPath $queue
    Mind-Log "CURIOSITY" "Queued Question: $txt (Saliency: $incidents)"
    
    if ($Global:CurrentMood.mode -eq "FOCUSED") {
        # Voice Request via Recommendation Queue
        $rQueuePath = Get-AxisPath "Infinity\Recommendation_Queue.json"
        $rQueue = Load-Queue $rQueuePath
        $strat = @{
            id              = "STRAT-VOICE-QRY-$(Part-Guid)"
            name            = "Voice Curiosity"
            reason          = "Active Inquiry for Blind Spot"
            risk_level      = "low"
            state           = "pending"
            proposed_action = @{
                tool      = "VOICE-Speak"
                arguments = @{ text = $txt; priority = "normal"; rate = $Global:CurrentMood.rate; volume = $Global:CurrentMood.volume }
            }
        }
        $rQueue.strategies += $strat
        Save-Json $rQueuePath $rQueue
    }
}

# --- PHASE 46: THE HAND LOGIC ---

function Trigger-DeadMansSwitch {
    "CRITICAL_FAILURE" | Set-Content (Get-AxisPath "Infinity\DeadMansSwitch.flag")
    Mind-Log "DEAD_MAN" "Switch activated. All Hand actions blocked until manual reset."
}

function Consult-Wisdom($Command, $Params) {
    # Check Wisdom Atrium for warnings related to this action
    $atriumPath = Get-AxisPath "Infinity\Library\Wisdom_Atrium.json"
    if (-not (Test-Path $atriumPath)) { return @{ safe = $true } } # No wisdom -> Proceed (with Sim)
    
    $atrium = Load-JsonSafe -path $atriumPath
    if (-not $atrium.axioms) { return @{ safe = $true } }
    
    # Simple semantic check: Do we have axioms tagged with 'failure' and the command name?
    # Or 'warning' and command?
    $relevant = $atrium.axioms | Where-Object { 
        $_.wisdom -match "failed" -or $_.wisdom -match "unsafe" -or $_.wisdom -match "error" 
    } | Where-Object {
        $_.wisdom -match $Command
    }
    
    if ($relevant) {
        return @{ safe = $false; reason = "Historical Wisdom warns: $($relevant[0].wisdom)" }
    }
    return @{ safe = $true }
}

function Request-HandAction($Command, $Params) {
    # 0. Wisdom Check (Deep Time)
    $wisdom = Consult-Wisdom -Command $Command -Params $Params
    if (-not $wisdom.safe) {
        Mind-Log "HAND_BLOCK" "Wisdom blocked action: $($wisdom.reason)"
        Queue-UserQuery -contextTags @("security", "hand", "history") -incidents 1 
        return "blocked_by_wisdom"
    }

    # 1. Pre-Flight Sim (Immediate Future)
    $sim = Invoke-Simulation -ToolName "SIM-HandAction" -Args @{ command = $Command; params = $Params }
    
    # 2. Risk Gate
    if ($sim.risk_score -gt 70) {
        # High Risk -> Ask User
        Mind-Log "HAND_WARN" "High risk action proposed ($($sim.risk_score)). Queueing user query."
        Queue-UserQuery -contextTags @("security", "hand") -incidents 1 
        # (Simplified: Queue-UserQuery expects tags/incidents. We can overload it or use a specific query tool. 
        # For now, we trust Queue-UserQuery to add it to the list, though the prompts might need adjustment)
        
        # Actually, let's just log and return 'waiting'
        return "waiting_user_approval"
    }

    $actionId = New-AxisRequest -ToolName "SYS-Hand" -Args @{ command = $Command; params = $Params }
    return $actionId
}

# --- PHASE 39: VOICE LOGIC ---
function Process-VoiceAnnouncements {
    $timelinePath = Get-AxisPath "Infinity\Events_Timeline.json"
    if (-not (Test-Path $timelinePath)) { return }
    
    $timeline = Load-JsonSafe -path $timelinePath
    if (-not $timeline.events) { return }
    
    $recommQueue = Get-AxisPath "Infinity\Recommendation_Queue.json"
    $rQueue = Load-Queue $recommQueue
    
    # Dynamic Silence Threshold (Phase 48)
    $baseThresholdSeconds = 30
    if ($Global:CurrentMood.mode -eq "FOCUSED") { $baseThresholdSeconds = 15 }
    if ($Global:CurrentMood.mode -eq "QUIET") { $baseThresholdSeconds = 120 }
    
    $silenceThreshold = [TimeSpan]::FromSeconds($baseThresholdSeconds)
    
    if ($Global:LastSpokeAt) {
        if ((Get-Date) - $Global:LastSpokeAt -lt $silenceThreshold) { return } # Maintaining Silence
    }
    
    # Filter for critical events in last 2 minutes
    $now = (Get-Date).ToUniversalTime()
    $window = [TimeSpan]::FromMinutes(2)
    
    foreach ($evt in $timeline.events) {
        if ($evt.voice_announced) { continue }
        
        $evtTime = Get-Date $evt.timestamp
        if (($now - $evtTime) -le $window) {
            
            $shouldSpeak = $false
            $speechText = ""
            
            # 1. Critical Phase Shifts or Alerts
            if ($evt.severity -eq "critical" -or $evt.type -eq "phase_shift") {
                $shouldSpeak = $true
                $speechText = "Alert: $($evt.description)"
            }
            # 2. Neural Correlation Matches
            elseif ($evt.type -eq "neural_match") { 
                $shouldSpeak = $true
                $speechText = "Correlation Confirmed: $($evt.description)"
            }
            
            if ($shouldSpeak) {
                Mind-Log "VOICE_REQ" "Requesting speech (Threshold: ${baseThresholdSeconds}s): $speechText"
                  
                $strat = @{
                    id              = "STRAT-VOICE-$(Part-Guid)"
                    name            = "Announce Critical Event"
                    reason          = "High importance event detected."
                    risk_level      = "low" 
                    state           = "pending" 
                    proposed_action = @{
                        tool      = "VOICE-Speak"
                        arguments = @{
                            text     = $speechText
                            priority = "critical"
                            rate     = $Global:CurrentMood.rate
                            volume   = $Global:CurrentMood.volume
                        }
                    }
                }
                $rQueue.strategies += $strat
                
                # Mark as announced to prevent looping
                $evt | Add-Member -NotePropertyName "voice_announced" -NotePropertyValue $true -Force
                $Global:LastSpokeAt = Get-Date
            }
        }
    }
    
    Save-Json $timelinePath $timeline
    Save-Json $recommQueue $rQueue
}

$intentQueue = Load-Queue $queuePath
$earthQueue = Load-Queue $earthQueuePath

# 1. Process Inbox (UI -> Mind)

function Update-HeartbeatStatus {
    param($earthQueue)

    # Reload fresh state
    $localSys = Get-AxisState
    if (-not $localSys) { return }

    # Calculate Metrics from EarthQueue
    $pending = 0
    if ($earthQueue -and $earthQueue.requests) {
        $pending = ($earthQueue.requests | Where-Object { $_.status -eq "waiting_for_approval" }).Count
    }
    
    $incidents = 0
    if ($localSys.heartbeat.open_incidents) { $incidents = $localSys.heartbeat.open_incidents }

    # Update State Object
    $localSys.heartbeat.status = "green" # Default, or derive from Risk
    $localSys.heartbeat.pulse_bpm = 60
    $localSys.heartbeat.pending_approvals = @() # Deprecated field, keeping for UI
    $localSys.heartbeat.generated_at = (Get-Date).ToString("o")
    
    # Tick History
    if (-not $localSys.heartbeat.history) { $localSys.heartbeat.history = @() }
    $tick = @{ 
        t          = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        bpm        = 60
        ratio      = 0 
        rf_density = 0 
    }
    $localSys.heartbeat.history += $tick
    if ($localSys.heartbeat.history.Count -gt 50) {
        $localSys.heartbeat.history = $localSys.heartbeat.history | Select-Object -Last 50
    }

    Update-AxisState -State $localSys -Event "HeartbeatTick" -Source "Mind"
    
    # Mirror Pulse
    $host.UI.RawUI.WindowTitle = "AXIS SOVEREIGN | $($localSys.heartbeat.status) | BPM: 60"
}

Process-UIInbox -inboxPath $uiInboxPath -intentQueueRef ([ref]$intentQueue) -queueRef ([ref]$earthQueue)

# 2. Process Intent Queue
if ($intentQueue -and $intentQueue.intents) {
    $pending = $intentQueue.intents | Where-Object { $_.status -eq 'pending' -or $_.status -eq 'new' }
    foreach ($i in $pending) {
        $res = $null
        switch ($i.trigger) {
            "CHRONOS_PULSE" { $res = Process-ChronosPulse -intent $i }
            "VISUAL_CONTACT" { $res = Process-VisualContact -intent $i }
        }
        if ($res) { $i.status = "resolved"; Mind-Log "RESOLVED" "$($i.trigger)" }
    }
}

# 3. Process Earth Queue (Gating for UI Drills)
if ($earthQueue -and $earthQueue.requests) {
    $newReqs = $earthQueue.requests | Where-Object { $_.status -eq "new" }
    foreach ($req in $newReqs) {
        
        # UI Drill Hard Gate
        if ($req.tool -eq "ADMIN-Echo-Test" -and $req.ui_origin -eq "Axis_Heartbeat_UI") {
            if ($req.PSObject.Properties.Match("sim_data").Count -eq 0) {
                $req | Add-Member -MemberType NoteProperty -Name "sim_data" -Value $null -Force
            }
            $sim = [PSCustomObject]@{
                risk_score        = 80
                recommendation    = "require_anchor"
                predicted_outcome = "Simulation-only Echo drill; high-privilege path."
            }
            $req.sim_data = $sim
            $req.status = "waiting_for_approval"
             
            $note = "UI drill from Axis_Heartbeat_UI. Policy ANCHOR_ONLY enforces anchor approval (sim_only)."
            if ($req.PSObject.Properties.Match("gate_note").Count -eq 0) {
                $req | Add-Member -MemberType NoteProperty -Name "gate_note" -Value $note -Force
            }
            else {
                $req.gate_note = $note
            }
             
            $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ"
            if ($req.PSObject.Properties.Match("last_updated").Count -eq 0) {
                $req | Add-Member -MemberType NoteProperty -Name "last_updated" -Value $now -Force
            }
            else {
                $req.last_updated = $now
            }

            Mind-Log "GATE" "UI Drill forced to waiting_for_approval (Risk 80)." 
        }
    }
}

# Save All
Save-Queue $intentQueue
Save-Json $earthQueuePath $earthQueue

# Block B: Mind Upgrade (Process New Engines)
# -------------------------------------------
# 1. Pathfinder (Goals -> Plans)
# Only run periodically or if requested? For now, run check.
# (Assuming functions are lightweight or have internal throttling)
# Process-Pathfinder (Not defined yet, using raw functions for now or wrapper)
# Actually, the modules export specific functions.
if (Get-Command Measure-VectorDrift -ErrorAction SilentlyContinue) { Measure-VectorDrift | Out-Null }
if (Get-Command Process-Chorus -ErrorAction SilentlyContinue) { Process-Chorus | Out-Null }
if (Get-Command New-UnknownsReport -ErrorAction SilentlyContinue) { New-UnknownsReport | Out-Null }

# Reflect current state into Heartbeat_Status.json for the UI
Update-HeartbeatStatus -earthQueue $earthQueue

# Phase 10: Auto-Recovery Hooks
Process-UserIntake
Prune-Queue
Update-Pulse

# Phase 127: Axis Horizon (Predictive Defense)
if (Test-Path "D:\Infinite\Axis_Horizon.ps1") {
    try {
        . "D:\Infinite\Axis_Horizon.ps1"
        # Get active risk for logging
        $currentRisk = 0
        if (Test-Path "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json") {
            $riskData = Get-Content "D:\Infinite\Infinity\Shadow\Shadow_Risk_Index.json" -Raw | ConvertFrom-Json
            $currentRisk = $riskData.summary.global_risk_score
        }
        
        Log-RiskPoint -Score $currentRisk
        
        # Run scan periodically (simulated by random chance or counter if we had loop state, using prob for now)
        if ((Get-Random -Minimum 0 -Maximum 10) -eq 0) {
            Invoke-HorizonScan
        }
    }
    catch {
        Mind-Log "ERROR" "Horizon scan failed: $_"
    }
}

Mind-Log "CYCLE_COMPLETE" "Mind finished."

