# Axis_LatticePulse.ps1
# Read-only lattice health check. Computes simple metrics on the Memory Lattice.

$root = "D:\Infinite"

$latticePulsePath = Join-Path $root "Infinity\Axis_LatticePulse.jsonl"

# Candidate index paths (favor explicit Memory_Lattice_Index if present)
$candidates = @(
    (Join-Path $root "Infinity\Memory_Lattice_Index.json"),
    (Join-Path $root "Infinity\Chronicle_Index.json")
)

$indexPath = $null
foreach ($c in $candidates) {
    if (Test-Path $c) {
        $indexPath = $c
        break
    }
}

if (-not $indexPath) {
    $result = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        kind      = "lattice_pulse"
        status    = "no_index_found"
        detail    = "None of the candidate lattice index files exist."
    }

    $result | ConvertTo-Json -Depth 4
    $line = $result | ConvertTo-Json -Depth 4 -Compress
    Add-Content -Path $latticePulsePath -Value $line
    exit 0
}

# Load index
try {
    $raw = Get-Content $indexPath -Raw
    $index = $raw | ConvertFrom-Json
}
catch {
    $result = @{
        timestamp = (Get-Date).ToUniversalTime().ToString("o")
        kind      = "lattice_pulse"
        status    = "parse_error"
        indexPath = $indexPath
        error     = $_.Exception.Message
    }

    $result | ConvertTo-Json -Depth 4
    $line = $result | ConvertTo-Json -Depth 4 -Compress
    Add-Content -Path $latticePulsePath -Value $line
    exit 0
}

$nodes = @()
$edges = @()

if ($index.nodes) { $nodes = $index.nodes }
if ($index.edges) { $edges = $index.edges }

$totalNodes = $nodes.Count
$totalEdges = $edges.Count

# Nodes by kind
$nodesByKind = @{}
foreach ($n in $nodes) {
    $k = if ($n.kind) { $n.kind } else { "_unknown" }
    if (-not $nodesByKind.ContainsKey($k)) {
        $nodesByKind[$k] = 0
    }
    $nodesByKind[$k]++
}

# Orphan nodes (no links.in and no links.out)
$orphanCount = 0
foreach ($n in $nodes) {
    $hasLinks = $false
    if ($n.links) {
        if ($n.links.in -and $n.links.in.Count -gt 0) { $hasLinks = $true }
        if ($n.links.out -and $n.links.out.Count -gt 0) { $hasLinks = $true }
    }
    if (-not $hasLinks) {
        $orphanCount++
    }
}

# Duplicate IDs
$duplicates = 0
$idGroups = $nodes | Group-Object -Property id
foreach ($g in $idGroups) {
    if ($g.Count -gt 1) { $duplicates++ }
}

# Edge validity: references existing node IDs
$nodeIdSet = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($n in $nodes) {
    if ($n.id) { [void]$nodeIdSet.Add([string]$n.id) }
}

$invalidEdges = 0
foreach ($e in $edges) {
    $srcValid = $false
    $tgtValid = $false
    if ($e.source -and $nodeIdSet.Contains([string]$e.source)) { $srcValid = $true }
    if ($e.target -and $nodeIdSet.Contains([string]$e.target)) { $tgtValid = $true }
    if (-not ($srcValid -and $tgtValid)) {
        $invalidEdges++
    }
}

$ts = (Get-Date).ToUniversalTime().ToString("o")

$result = @{
    timestamp     = $ts
    kind          = "lattice_pulse"
    indexPath     = $indexPath
    status        = "ok"
    totals        = @{
        nodes        = $totalNodes
        edges        = $totalEdges
        orphan_nodes = $orphanCount
        duplicate_ids= $duplicates
        invalid_edges= $invalidEdges
    }
    nodes_by_kind = $nodesByKind
}

$result | ConvertTo-Json -Depth 6

try {
    $line = $result | ConvertTo-Json -Depth 6 -Compress
    Add-Content -Path $latticePulsePath -Value $line
}
catch {
    # Failure to log doesn't change the pulse result.
}
