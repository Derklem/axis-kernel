
# Axis Skills Module
# Purpose: Manages the Competence Ledger and Autonomy Calibration.
# Phase: 78

$Script:InfinityRoot = "D:\Infinite"
$Script:SkillRegistryPath = "$Script:InfinityRoot\Infinity\Skills\Skill_Registry.json"

# Ensure Directory
if (-not (Test-Path (Split-Path $Script:SkillRegistryPath))) {
    New-Item -ItemType Directory -Force -Path (Split-Path $Script:SkillRegistryPath) | Out-Null
}

function Get-SkillRegistry {
    if (-not (Test-Path $Script:SkillRegistryPath)) {
        return @{
            version     = 1
            registry_id = "AXIS-SKILL-2026-001"
            skills      = @()
        }
    }
    try {
        return Get-Content -Raw -LiteralPath $Script:SkillRegistryPath | ConvertFrom-Json
    }
    catch {
        Write-Warning "SKILL: Registry read failed. Returning empty."
        return @{
            version     = 1
            registry_id = "AXIS-SKILL-RECOVER"
            skills      = @()
        }
    }
}

function Save-SkillRegistry($reg) {
    try {
        $reg | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $Script:SkillRegistryPath -Encoding UTF8
    }
    catch {
        Write-Error "SKILL: Failed to save registry. $_"
    }
}

function SKILL-RecordOutcome {
    <#
    .SYNOPSIS
        Record the outcome of a strategy run (real or simulated).
    #>
    param(
        [Parameter(Mandatory)][string]$StrategyId,
        [ValidateSet("success", "warning", "failure")][string]$Result,
        [string]$PilotId,
        [double]$ShadowGlobal,
        [string]$ShadowMode,
        [string]$Notes,
        [string]$Source = "production" # Phase 81: Distinguish training vs real
    )

    $reg = Get-SkillRegistry
    $skills = @($reg.skills) # Ensure array

    $skill = $skills | Where-Object { $_.skill_id -eq $StrategyId }
    if (-not $skill) {
        $skill = [ordered]@{
            skill_id                = $StrategyId
            label                   = $StrategyId
            category                = $null
            risk_class              = $null
            autonomy_level_declared = $null
            stats                   = [ordered]@{
                runs_total   = 0
                runs_success = 0
                runs_warning = 0
                runs_failure = 0
                last_run_utc = $null
            }
            outcome_last            = $null
            outcome_history         = @()
            autonomy_calibrated     = [ordered]@{
                recommended_level = "recommend"
                confidence        = 0.0
                last_update_utc   = $null
            }
        }
        $skills += $skill
    }

    $now = (Get-Date).ToUniversalTime().ToString("o")

    # Update stats
    $skill.stats.runs_total++
    switch ($Result) {
        "success" { $skill.stats.runs_success++ }
        "warning" { $skill.stats.runs_warning++ }
        "failure" { $skill.stats.runs_failure++ }
    }
    $skill.stats.last_run_utc = $now
    $skill.outcome_last = $Result

    # History, capped
    if (-not $skill.outcome_history) { $skill.outcome_history = @() }
    $entry = [ordered]@{
        timestamp_utc = $now
        pilot_id      = $PilotId
        shadow_global = $ShadowGlobal
        shadow_mode   = $ShadowMode
        result        = $Result
        notes         = $Notes
        source        = $Source
    }
    $skill.outcome_history += $entry
    if ($skill.outcome_history.Count -gt 100) {
        $skill.outcome_history = $skill.outcome_history | Select-Object -Last 100
    }

    # Recompute calibration
    SKILL-RecomputeCalibration -Skill $skill

    $reg.skills = $skills
    Save-SkillRegistry $reg

    Write-Host "SKILL: Outcome recorded for [$StrategyId]: $Result" -ForegroundColor Gray
    return $skill
}

function SKILL-RecomputeCalibration {
    param(
        [Parameter(Mandatory)]$Skill
    )

    $total = [int]$Skill.stats.runs_total
    if ($total -le 0) {
        $Skill.autonomy_calibrated.recommended_level = $null
        $Skill.autonomy_calibrated.confidence = 0.0
        $Skill.autonomy_calibrated.last_update_utc = (Get-Date).ToUniversalTime().ToString("o")
        return
    }

    $success = [int]$Skill.stats.runs_success
    $failure = [int]$Skill.stats.runs_failure

    $successRate = $success / [double]$total
    $failureRate = $failure / [double]$total

    # Policy:
    # - If failureRate > 0.2 -> "manual"
    # - Else if successRate > 0.8 -> "auto"
    # - Else -> "recommend"
    $rec = "recommend"
    if ($failureRate -gt 0.2) {
        $rec = "manual"
    }
    elseif ($successRate -gt 0.8) {
        $rec = "auto"
    }

    $Skill.autonomy_calibrated.recommended_level = $rec
    $Skill.autonomy_calibrated.confidence = [Math]::Round($successRate, 3)
    $Skill.autonomy_calibrated.last_update_utc = (Get-Date).ToUniversalTime().ToString("o")
}

function SKILL-GetSkillProfile {
    param(
        [Parameter(Mandatory)][string]$StrategyId
    )

    $reg = Get-SkillRegistry
    $skill = @($reg.skills) | Where-Object { $_.skill_id -eq $StrategyId }
    return $skill
}

# Export-ModuleMember -Function SKILL-RecordOutcome, SKILL-GetSkillProfile
