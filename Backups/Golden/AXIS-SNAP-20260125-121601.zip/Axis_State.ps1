# Axis_State.ps1
# Phase 110: The Unified State Authority
# Serves as the single API for reading/writing the System State.

$root = "D:\Infinite"
$statePath = Join-Path $root "Infinity\Axis_State.json"
$historyPath = Join-Path $root "Infinity\Memory\State_History.jsonl" # Event Sourcing Log

function Get-AxisState {
    <#
    .SYNOPSIS
        Returns the current Axis State object.
    #>
    if (Test-Path $statePath) {
        try {
            return Get-Content $statePath -Raw | ConvertFrom-Json
        }
        catch {
            Write-Error "CRITICAL: State Corruption Detected. $_"
            return $null
        }
    }
    return $null
}

function Update-AxisState {
    <#
    .SYNOPSIS
        Updates the State file and logs the mutation event.
    .PARAMETER State
        The modified PSObject state.
    .PARAMETER Event
        Name/Description of the change (e.g. "Identity Update").
    #>
    param(
        [Parameter(Mandatory = $true)]$State,
        [string]$Event = "StateUpdate",
        [string]$Source = "System"
    )

    # timestamp
    $State.timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
    
    # 1. Update State File (Atomic-ish)
    try {
        $json = $State | ConvertTo-Json -Depth 20 -Compress
        $json | Set-Content $statePath -Encoding UTF8 -Force
    }
    catch {
        Write-Error "CRITICAL: Failed to write State! $_"
        return $false
    }

    # 2. Append to Event Log (Lightweight History)
    $eventData = @{
        t      = $State.timestamp
        event  = $Event
        source = $Source
    }
    $eventJson = $eventData | ConvertTo-Json -Compress
    Add-Content $historyPath $eventJson

    return $true
}

function Initialize-AxisState {
    <#
    .SYNOPSIS
        Creates a blank state if none exists.
    #>
    if (-not (Test-Path $statePath)) {
        $seed = @{
            version   = "1.0"
            timestamp = (Get-Date).ToString("o")
            identity  = @{}
            memory    = @{ journal = @(); short_term = @() }
            security  = @{ risk_ledger = @{}; autonomy = @{} }
            heartbeat = @{}
            reasoning = @{ hypotheses = @(); forecasts = @() }
        }
        Update-AxisState -State $seed -Event "Genesis"
    }
}

# Export-ModuleMember -Function Get-AxisState, Update-AxisState, Initialize-AxisState
