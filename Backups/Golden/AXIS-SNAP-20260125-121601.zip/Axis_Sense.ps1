
# Axis_Sense.ps1
# Phase 70A: The Sensory Cortex
# Abstraction layer for environmental sensors (Home Awareness).
# defaults to Mock Adapter if no live configuration is found.

$configPath = Join-Path $PSScriptRoot "Infinity\Axis_Config.json"
$mockSensorPath = Join-Path $PSScriptRoot "Infinity\Sensors\Mock_Sensors.json"

function Get-AxisConfig {
    if (Test-Path $configPath) {
        return Get-Content $configPath -Raw | ConvertFrom-Json
    }
    return @{}
}

function Get-EnvironmentalState {
    # Main entry point for the SENSE-ReadEnv tool.
    # Returns a standardized sensor object:
    # { temperature: 22.0, light_level: 0-100, occupancy: bool, timestamp: "..." }
    
    $cfg = Get-AxisConfig
    
    # 1. Try Network Presence Adapter
    if ($cfg.sensors -and $cfg.sensors.type -eq "network_presence") {
        return Invoke-NetworkPresenceAdapter $cfg.sensors
    }

    # 2. Fallback to Mock Adapter
    return Get-MockSensorState
}

function Invoke-NetworkPresenceAdapter ($config) {
    # Phase 70C: Network Proprioception
    # - Occupancy: Are any Candidate IPs online?
    # - Temp/Vitality: Router Connection Stats (Simulated or Real Scrape)
    
    # A. Occupancy Check (Parallel Ping ideally, but doing sequential for simplicity/stability)
    $occupancy = $false
    $onlineCount = 0
    
    foreach ($ip in $config.candidates) {
        if (Test-Connection -ComputerName $ip -Count 1 -Quiet -ErrorAction SilentlyContinue) {
            $occupancy = $true
            $onlineCount++
        }
    }
    
    # B. Router Vitality (Motorola MG7550)
    # We will try to scrape connection data. If fails, we degrade gracefully.
    $routerIp = $config.router_ip
    $creds = $config.router_creds
    
    # Default Vitality
    $temp = 25.0
    $light = 50
    $noise = "low"
    
    try {
        # Construct Basic Auth Header
        $pair = "$($creds.user):$($creds.pass)"
        $bytes = [System.Text.Encoding]::ASCII.GetBytes($pair)
        $base64 = [System.Convert]::ToBase64String($bytes)
        $headers = @{ Authorization = "Basic $base64" }
        
        # Determine "Temperature" from Network Load (Response Time of Router)
        $ping = Test-Connection -ComputerName $routerIp -Count 1 -ErrorAction Stop
        $latency = $ping.ResponseTime
        
        # Temp = Base 20C + (Latency / 2) -> High Latency = Hot Room
        $temp = 20.0 + ($latency / 2)
        
        if ($latency -gt 100) { $noise = "high" }
        elseif ($latency -gt 50) { $noise = "medium" }
        
    }
    catch {
        # Router might not respond to Ping or Auth
        $noise = "unknown"
    }
    
    # Light Level = Activity (Candidates Online * 25%)
    $light = ($onlineCount * 25)
    if ($light -gt 100) { $light = 100 }

    return @{
        temperature    = [Math]::Round($temp, 1)
        light_level    = $light
        occupancy      = $occupancy
        humidity       = 45 # Static for now
        noise_level    = $noise
        timestamp      = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        source         = "Network_Proprioception"
        online_devices = $onlineCount
    }
}

function Get-MockSensorState {
    # Reads from a JSON file that the user (or tests) can update to simulate environment.
    
    $default = @{
        temperature = 21.5
        humidity    = 45
        light_level = 60 # Percentage or Lux normalized
        occupancy   = $true
        noise_level = "low"
        timestamp   = (Get-Date -Format "yyyy-MM-ddTHH:mm:ssZ")
        source      = "Mock_Adapter"
    }

    if (Test-Path $mockSensorPath) {
        try {
            $data = Get-Content $mockSensorPath -Raw | ConvertFrom-Json
            # Merge with default to ensure fields exist
            foreach ($key in $data.PSObject.Properties.Name) {
                $default[$key] = $data.$key
            }
        }
        catch {
            Write-Warning "Failed to parse Mock Sensor Data."
        }
    }
    else {
        # Create default mock file if it doesn't exist
        $mockDir = Split-Path $mockSensorPath -Parent
        if (-not (Test-Path $mockDir)) { New-Item -ItemType Directory -Path $mockDir -Force | Out-Null }
        $default | ConvertTo-Json | Set-Content $mockSensorPath -Encoding UTF8
    }

    return $default
}
