# D:\Infinite\Axis_Console.ps1
# Phase 130: Architect Console (The Collaboration Surface)
# "The Porch" - Ratification & Conversation Interface.

$root = "D:\Infinite"

# Define helpers FIRST to avoid scope issues
function Get-AxisPath {
    param($Path)
    return Join-Path "D:\Infinite" $Path
}

function Load-JsonSafe {
    param($Path)
    if (Test-Path $Path) {
        try {
            return Get-Content $Path -Raw -Encoding UTF8 | ConvertFrom-Json
        } catch {
            return $null
        }
    }
    return $null
}

function Get-ConsoleColorFromHex {
    param($Hex)
    if ($Hex -eq "#00ff9d") { return "Green" }
    if ($Hex -eq "#00ccff") { return "Cyan" }
    if ($Hex -eq "#ff5555") { return "Red" }
    return "Gray"
}

# Try to load Covenant, but don't fail if missing (we have polyfills)
if (Test-Path "$PSScriptRoot\Axis_Covenant.ps1") {
    . "$PSScriptRoot\Axis_Covenant.ps1"
}

function Get-SystemPulse {
    $StatePath = "D:\Infinite\Infinity\Mood_State.json"
    if (Test-Path $StatePath) {
        return Get-Content $StatePath -Raw | ConvertFrom-Json
    }
    return @{ mood_label = "Offline"; color = "#888888" }
}

function Invoke-ArchitectConsole {
    Clear-Host
    $Pulse = Get-SystemPulse
    
    # Map Hex to ConsoleColor
    $MoodColor = Get-ConsoleColorFromHex -Hex $Pulse.color

    # 1. Header (Telemetry)
    Write-Host "--- AXIS SOVEREIGN CONSOLE ---" -ForegroundColor Cyan
    Write-Host "Mood: " -NoNewline
    Write-Host "$($Pulse.mood_label)" -ForegroundColor $MoodColor
    Write-Host "Orbit: $($Pulse.physics.orbit_min)m | Eccentricity: $($Pulse.physics.eccentricity)" -ForegroundColor Gray
    Write-Host "------------------------------" -ForegroundColor DarkGray
    Write-Host ""

    # 2. Check Proposals
    $proposalsPath = Get-AxisPath "Infinity\Covenant\Covenant_Proposals.json"
    $proposals = Load-JsonSafe -path $proposalsPath
    $pending = $null
    
    if ($proposals -and $proposals.proposals) {
        $pending = $proposals.proposals | Where-Object { $_.status -eq "pending_ratification" }
    }

    if ($pending) {
        Write-Host "PENDING RATIFICATIONS:" -ForegroundColor Yellow
        $pending | Select-Object id, timestamp, target_domain, proposed_value | Format-Table -AutoSize
    } else {
        Write-Host "No pending ratifications." -ForegroundColor DarkGray
    }
    
    # 3. Command Loop
    Write-Host ""
    Write-Host "[T]alk <Message> | [A]pprove <ID> | [R]eject <ID> | [Q]uit" -ForegroundColor White
    $raw = Read-Host "Axis"
    
    if ($raw -match "^T\s+(.+)$" -or $raw -match "^Talk\s+(.+)$") {
        $msg = $matches[1]
        Powershell -File "$PSScriptRoot\Axis_Talk.ps1" -InputText $msg
        Write-Host ""
        Pause
        Invoke-ArchitectConsole
    }
    elseif ($raw -match "^A\s+(.+)$") {
        $id = $matches[1]
        Apply-CovenantAmendment -AmendmentId $id -Action "approve" -Note "Manual Ratification" -By "Architect"
        Start-Sleep -Seconds 1
        Invoke-ArchitectConsole
    }
    elseif ($raw -match "^R\s+(.+)$") {
        Apply-CovenantAmendment -AmendmentId $matches[1] -Action "reject" -Note "Manual Rejection" -By "Architect"
        Start-Sleep -Seconds 1
        Invoke-ArchitectConsole
    }
    elseif ($raw -eq "Q" -or $raw -eq "Quit") {
        Write-Host "Closing Console." -ForegroundColor Gray
    }
    else {
        # Default to Talk if typed naturally
        if ($raw -ne "") {
            Powershell -File "$PSScriptRoot\Axis_Talk.ps1" -InputText $raw
            Write-Host ""
            Pause
            Invoke-ArchitectConsole
        } else {
            Invoke-ArchitectConsole
        }
    }
}

Invoke-ArchitectConsole
