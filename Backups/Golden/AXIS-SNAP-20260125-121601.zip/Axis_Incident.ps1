function Register-AxisIncident {
    param(
        [Parameter(Mandatory)]
        [string] $AxisStatePath,

        [Parameter(Mandatory)]
        [string] $Type,          # doctrine_violation, autonomy_escalation, manual_trigger, etc.

        [Parameter(Mandatory)]
        [string] $Severity,      # low | medium | high | critical

        [Parameter(Mandatory)]
        [string] $Summary,

        [string] $Source = "Unknown",

        [string] $Id = $null
    )

    if (-not (Test-Path $AxisStatePath)) {
        throw "Axis state file not found at $AxisStatePath"
    }

    $state = Get-Content $AxisStatePath -Raw | ConvertFrom-Json

    if (-not $Id) {
        $stamp = (Get-Date).ToString("yyyyMMdd-HHmmss")
        $rand = -join ((48..57 + 65..90) | Get-Random -Count 4 | ForEach-Object { [char]$_ })
        $Id = "INC-$stamp-$rand"
    }

    if (-not $state.security) { $state | Add-Member -NotePropertyName security -NotePropertyValue (@{}) }
    if (-not $state.security.incidents) { $state.security | Add-Member -NotePropertyName incidents -NotePropertyValue @() }

    # If incidents is not an array (e.g. converted from single object), force array
    if ($state.security.incidents -isnot [Array]) {
        $state.security.incidents = @($state.security.incidents)
    }

    $incident = [ordered]@{
        id        = $Id
        type      = $Type
        severity  = $Severity
        summary   = $Summary
        opened_at = (Get-Date).ToString("o")
        status    = "active"
        source    = $Source
    }

    $state.security.incidents += $incident

    # Recompute open_incidents in risk_ledger
    if (-not $state.security.risk_ledger) {
        $state.security | Add-Member -NotePropertyName risk_ledger -NotePropertyValue (@{})
    }

    # Count active incidents
    $activeCount = 0
    if ($state.security.incidents) {
        $activeCount = ($state.security.incidents | Where-Object { $_.status -eq "active" }).Count
    }
    
    if ($null -eq $state.security.risk_ledger.PSObject.Properties['open_incidents']) {
        $state.security.risk_ledger | Add-Member -NotePropertyName 'open_incidents' -NotePropertyValue $activeCount
    }
    else {
        $state.security.risk_ledger.open_incidents = $activeCount
    }

    $state | ConvertTo-Json -Depth 20 | Set-Content $AxisStatePath -Encoding UTF8

    return $incident
}

function Resolve-AxisIncident {
    param(
        [Parameter(Mandatory)]
        [string] $AxisStatePath,

        [Parameter(Mandatory)]
        [string] $IncidentId,

        [Parameter(Mandatory)]
        [ValidateSet("acknowledged", "resolved")]
        [string] $ResolutionStatus
    )

    if (-not (Test-Path $AxisStatePath)) {
        throw "Axis state file not found at $AxisStatePath"
    }

    $state = Get-Content $AxisStatePath -Raw | ConvertFrom-Json

    if (-not $state.security.incidents) {
        throw "No incidents array in state."
    }

    if ($state.security.incidents -isnot [Array]) {
        $state.security.incidents = @($state.security.incidents)
    }

    $found = $false
    foreach ($inc in $state.security.incidents) {
        if ($inc.id -eq $IncidentId) {
            $inc.status = $ResolutionStatus
            $found = $true
            break
        }
    }

    if (-not $found) {
        throw "Incident '$IncidentId' not found."
    }

    # Recalculate open_incidents
    $activeCount = ($state.security.incidents | Where-Object { $_.status -eq "active" }).Count
    if (-not $state.security.risk_ledger) {
        $state.security | Add-Member -NotePropertyName risk_ledger -NotePropertyValue (@{})
    }
    if ($null -eq $state.security.risk_ledger.PSObject.Properties['open_incidents']) {
        $state.security.risk_ledger | Add-Member -NotePropertyName 'open_incidents' -NotePropertyValue $activeCount
    }
    else {
        $state.security.risk_ledger.open_incidents = $activeCount
    }

    $state | ConvertTo-Json -Depth 20 | Set-Content $AxisStatePath -Encoding UTF8

    return $state.security.risk_ledger
}
