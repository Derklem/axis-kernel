"""Agenda JSON Schemas."""
